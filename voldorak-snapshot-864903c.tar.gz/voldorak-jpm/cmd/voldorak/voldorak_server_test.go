package main

import (
	"context"
	"net"
	"net/http"
	"testing"
	"time"

	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
	"github.com/edgelaboratories/voldorak/internal/resource/picsou"
	"github.com/edgelaboratories/voldorak/internal/resource/tarantino"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
)

func Test_newVoldorakServer_InvalidConfig(t *testing.T) {
	t.Parallel()

	// We hereby test an ill-defined config triggers an error.
	// Tests over the correctness of the gRPC/HTTP listeners
	// are not included for simplicity.

	const (
		grpcAddr = ":80"
		httpAddr = ":81"
	)

	ctx := t.Context()

	for name, tc := range map[string]struct {
		cfg *Configuration
	}{
		"nil config": {
			cfg: nil,
		},
		"empty tarantino config": {
			cfg: &Configuration{
				TarantinoConf: tarantino.DefaultConfig(),
			},
		},
		"empty cerberus config": {
			cfg: &Configuration{
				CerberusConf: cerberus.DefaultConfig(),
			},
		},
		"empty picsou config": {
			cfg: &Configuration{
				PicsouConf: picsou.DefaultConfig(),
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			_, err := newVoldorakServer(ctx, tc.cfg, grpcAddr, httpAddr)
			require.Error(t, err)
		})
	}
}

// newTestVoldorakServer creates a minimal voldorakServer for testing the run and shutdown methods.
// It uses ephemeral ports and does not require external services.
func newTestVoldorakServer(t *testing.T) *voldorakServer {
	t.Helper()

	lc := &net.ListenConfig{}

	grpcListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
	require.NoError(t, err)

	httpListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
	require.NoError(t, err)

	grpcServer := grpc.NewServer()
	healthServer := health.NewServer()

	const readHeaderTimeout = 2 * time.Second

	httpServer := &http.Server{
		Addr:              httpListener.Addr().String(),
		Handler:           http.NewServeMux(),
		ReadHeaderTimeout: readHeaderTimeout,
	}

	// Start the HTTP server on the pre-created listener since
	// run() calls ListenAndServe which would try to listen again.
	go func() {
		_ = httpServer.Serve(httpListener)
	}()

	return &voldorakServer{
		grpcServer:   grpcServer,
		grpcListener: grpcListener,
		healthServer: healthServer,
		httpServer:   httpServer,
	}
}

func Test_voldorakServer_run(t *testing.T) {
	t.Parallel()

	server := newTestVoldorakServer(t)

	errChan := server.run()
	require.NotNil(t, errChan)

	// Give the goroutines time to start.
	time.Sleep(10 * time.Millisecond)

	// Shutdown should close everything gracefully.
	ctx, cancel := context.WithTimeout(t.Context(), 5*time.Second)
	defer cancel()

	err := server.shutdown(ctx)
	require.NoError(t, err)
}

func Test_voldorakServer_shutdown(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		setupServer   func(t *testing.T) *voldorakServer
		expectError   bool
		errorContains string
		startRunFirst bool
	}{
		"clean shutdown without clients": {
			setupServer: func(t *testing.T) *voldorakServer {
				t.Helper()

				return newTestVoldorakServer(t)
			},
			expectError:   false,
			startRunFirst: true,
		},
		"shutdown without running": {
			setupServer: func(t *testing.T) *voldorakServer {
				t.Helper()

				lc := &net.ListenConfig{}

				grpcListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
				require.NoError(t, err)

				httpListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
				require.NoError(t, err)

				grpcServer := grpc.NewServer()
				healthServer := health.NewServer()

				const readHeaderTimeout = 2 * time.Second

				httpServer := &http.Server{
					Addr:              httpListener.Addr().String(),
					Handler:           http.NewServeMux(),
					ReadHeaderTimeout: readHeaderTimeout,
				}

				// Start HTTP server on listener.
				go func() {
					_ = httpServer.Serve(httpListener)
				}()

				return &voldorakServer{
					grpcServer:   grpcServer,
					grpcListener: grpcListener,
					healthServer: healthServer,
					httpServer:   httpServer,
				}
			},
			expectError:   false,
			startRunFirst: false,
		},
		"shutdown with nil clients": {
			setupServer: func(t *testing.T) *voldorakServer {
				t.Helper()

				server := newTestVoldorakServer(t)
				server.cerberusClient = nil
				server.tarantinoClient = nil

				return server
			},
			expectError:   false,
			startRunFirst: true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			server := tc.setupServer(t)

			if tc.startRunFirst {
				_ = server.run()

				time.Sleep(10 * time.Millisecond)
			}

			ctx, cancel := context.WithTimeout(t.Context(), 5*time.Second)
			defer cancel()

			err := server.shutdown(ctx)

			if tc.expectError {
				require.Error(t, err)

				if tc.errorContains != "" {
					assert.Contains(t, err.Error(), tc.errorContains)
				}
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func Test_voldorakServer_run_returnsErrorOnListenerClose(t *testing.T) {
	t.Parallel()

	lc := &net.ListenConfig{}

	grpcListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
	require.NoError(t, err)

	grpcServer := grpc.NewServer()
	healthServer := health.NewServer()

	httpListener, err := lc.Listen(t.Context(), "tcp", "127.0.0.1:0")
	require.NoError(t, err)

	const readHeaderTimeout = 2 * time.Second

	httpServer := &http.Server{
		Addr:              httpListener.Addr().String(),
		Handler:           http.NewServeMux(),
		ReadHeaderTimeout: readHeaderTimeout,
	}

	go func() {
		_ = httpServer.Serve(httpListener)
	}()

	server := &voldorakServer{
		grpcServer:   grpcServer,
		grpcListener: grpcListener,
		healthServer: healthServer,
		httpServer:   httpServer,
	}

	errChan := server.run()
	require.NotNil(t, errChan)

	// Close the gRPC listener to trigger an error in Serve.
	time.Sleep(10 * time.Millisecond)
	grpcServer.GracefulStop()

	// The error channel should receive an error when the listener is closed.
	select {
	case err := <-errChan:
		// Serve returns nil on GracefulStop, which is also acceptable.
		if err != nil {
			require.Error(t, err)
		}
	case <-time.After(1 * time.Second):
		// GracefulStop may not send to errChan, that's acceptable.
	}

	// Cleanup HTTP server.
	ctx, cancel := context.WithTimeout(t.Context(), time.Second)
	defer cancel()

	_ = httpServer.Shutdown(ctx)
}
