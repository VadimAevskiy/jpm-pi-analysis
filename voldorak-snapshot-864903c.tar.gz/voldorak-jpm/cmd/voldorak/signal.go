package main

import (
	"os"
	"os/signal"
	"syscall"
)

// makeSignalChannel creates a read-only signal channel.
// This channel handles pre-defined signals only.
func makeSignalChannel() <-chan os.Signal {
	osSignals := make(chan os.Signal, 1)
	for _, s := range []os.Signal{
		os.Interrupt,
		syscall.SIGHUP,
		syscall.SIGTERM,
	} {
		signal.Notify(osSignals, s)
	}

	return osSignals
}
