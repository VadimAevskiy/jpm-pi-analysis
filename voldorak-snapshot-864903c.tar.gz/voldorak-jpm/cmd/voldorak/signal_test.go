package main

import (
	"os"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_makeSignalChannel(t *testing.T) {
	t.Parallel()

	timeout := time.After(time.Second)
	signals := makeSignalChannel()

	var wg sync.WaitGroup
	wg.Go(func() {
		select {
		case <-timeout:
			return
		case s := <-signals:
			assert.Equal(t, syscall.SIGHUP, s)
		}
	})

	require.NoError(t, syscall.Kill(os.Getpid(), syscall.SIGHUP))

	wg.Wait()
}
