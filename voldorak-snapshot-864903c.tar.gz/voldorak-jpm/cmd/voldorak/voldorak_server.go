package main

import (
	"context"
	"fmt"
	"net"
	"net/http"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/nowcasting"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
	"github.com/edgelaboratories/voldorak/internal/resource/picsou"
	"github.com/edgelaboratories/voldorak/internal/resource/tarantino"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	"github.com/edgelaboratories/voldorak/internal/service/v1"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	grpc_prometheus "github.com/grpc-ecosystem/go-grpc-prometheus"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/health"
	healthv1 "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/reflection"
)

type voldorakServer struct {
	grpcServer   *grpc.Server
	grpcListener net.Listener
	healthServer *health.Server
	httpServer   *http.Server

	cerberusClient  *cerberus.Client
	tarantinoClient *tarantino.Client
	picsouClient    *picsou.Client
}

// Compile-time check to verify that voldorakServer
// implements the server interface.
var _ server = &voldorakServer{}

func newVoldorakServer(ctx context.Context, cfg *Configuration, grpcAddr, httpAddr string) (*voldorakServer, error) {
	if cfg == nil {
		return nil, errors.Bug("the configuration is missing")
	}

	cerberusClient, err := cerberus.NewClient(cfg.CerberusConf)
	if err != nil {
		return nil, fmt.Errorf("could not create the client for Cerberus: %w", err)
	}

	log.Info("configuring the gRPC client for Tarantino")

	tarantinoClient, err := tarantino.NewClient(cfg.TarantinoConf)
	if err != nil {
		return nil, fmt.Errorf("could not create the client for Tarantino: %w", err)
	}

	log.Info("creating the service")

	picsouClient, err := picsou.NewClient(cfg.PicsouConf)
	if err != nil {
		return nil, fmt.Errorf("could not create the client for Picsou: %w", err)
	}

	log.Info("creating the Voldorak service")

	privateAssetMappingFetcher, err := nowcasting.MakeMappingFetcher(cfg.PrivateAssetConf.Mapping)
	if err != nil {
		return nil, fmt.Errorf("could not create the private asset fetcher: %w", err)
	}

	service := service.NewService(
		cerberusClient,
		scenario.NewProvider(tarantinoClient, cerberusClient),
		picsouClient,
		privateAssetMappingFetcher,
		service.NewPrivateAssetConfig(cfg.PrivateAssetConf.ActivateSSMPipeline, cfg.PrivateAssetConf.CalibrationWeeks),
		cfg.CerberusConf.SSVICalibrationActivated,
		cfg.CerberusConf.HestonCalibrationActivated,
		service.WithVolatilityBackboneModel(cfg.VolatilityConf.BackboneModel),
	)

	log.Info("creating the gRPC server")

	server := newGRPCServer()
	pb.RegisterVoldorakServiceServer(server, service)

	// Register the health service.
	healthServer := health.NewServer()
	healthv1.RegisterHealthServer(server, healthServer)

	healthServer.SetServingStatus("", healthv1.HealthCheckResponse_SERVING)

	grpc_prometheus.Register(server)
	reflection.Register(server)

	listenConfig := &net.ListenConfig{}

	listen, err := listenConfig.Listen(ctx, "tcp", grpcAddr)
	if err != nil {
		return nil, fmt.Errorf("could not start listening on %s: %w", grpcAddr, err)
	}

	log.Info("creating the HTTP server")

	// Create and start the HTTP reverse proxy that will
	// translate JSON over HTTP 1.1 to gRPC.

	httpServer, err := newHTTPServer(ctx, grpcAddr, httpAddr)
	if err != nil {
		return nil, fmt.Errorf("could not create the HTTP server: %w", err)
	}

	log.Info("Voldorak is ready")

	return &voldorakServer{
		grpcServer:   server,
		grpcListener: listen,
		healthServer: healthServer,
		httpServer:   httpServer,

		cerberusClient:  cerberusClient,
		tarantinoClient: tarantinoClient,
	}, nil
}

func (s voldorakServer) run() <-chan error {
	errChan := make(chan error)

	log.Info("starting the gRPC server")

	go func() {
		errChan <- s.grpcServer.Serve(s.grpcListener)
	}()

	log.Info("starting the HTTP server")

	go func() {
		if err := s.httpServer.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
			// ErrServerClosed is the standard HTTP server termination.
			errChan <- err
		}
	}()

	return errChan
}

func (s voldorakServer) shutdown(ctx context.Context) error {
	// Graceful shutdown of all the servers.
	// Since HTTP depends on gRPC, it shuts down first.
	if err := s.httpServer.Shutdown(ctx); err != nil {
		return fmt.Errorf("could not shut down the HTTP server: %w", err)
	}

	s.healthServer.Shutdown()
	s.grpcServer.GracefulStop()

	// Close all the resources the servers depended on.
	if s.cerberusClient != nil {
		if err := s.cerberusClient.Close(); err != nil {
			return fmt.Errorf("could not close Cerberus resource: %w", err)
		}
	}

	if s.tarantinoClient != nil {
		if err := s.tarantinoClient.Close(); err != nil {
			return fmt.Errorf("could not close Tarantino resource: %w", err)
		}
	}

	if s.picsouClient != nil {
		if err := s.picsouClient.Close(); err != nil {
			return fmt.Errorf("could not close Picsou resource: %w", err)
		}
	}

	return nil
}
