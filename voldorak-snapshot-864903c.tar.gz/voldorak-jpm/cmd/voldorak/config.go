package main

import (
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/resource/picsou"
	"github.com/edgelaboratories/voldorak/internal/resource/tarantino"
)

// Configuration describes the global configuration structure.
type Configuration struct {
	LoggerConf       *logger.Config    `yaml:"logging"`
	TraceConf        *trace.Config     `yaml:"tracing"`
	CerberusConf     *cerberus.Config  `yaml:"cerberus"`
	TarantinoConf    *tarantino.Config `yaml:"tarantino"`
	PicsouConf       *picsou.Config    `yaml:"picsou"`
	PrivateAssetConf struct {
		ActivateSSMPipeline bool   `yaml:"activate_ssm_pipeline"`
		CalibrationWeeks    int    `yaml:"calibration_weeks"`
		Mapping             string `yaml:"mapping"`
	} `yaml:"private_asset"`
	VolatilityConf struct {
		BackboneModel model.VolatilityBackboneModel `yaml:"backbone_model"`
	} `yaml:"volatility"`
}
