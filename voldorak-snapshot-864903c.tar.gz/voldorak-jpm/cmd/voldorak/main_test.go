package main

import (
	"bytes"
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"syscall"
	"testing"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_newHTTPServer(t *testing.T) { //nolint:paralleltest
	server, err := newHTTPServer(t.Context(), ":80", ":81")
	require.NoError(t, err)

	require.NotNil(t, server)
	assert.Equal(t, ":81", server.Addr)
	assert.NotNil(t, server.Handler)

	ctx := t.Context()

	for name, tc := range map[string]struct { //nolint:paralleltest
		method       string
		endpoint     string
		body         io.Reader
		expectedCode int
	}{
		"get": {
			method:       http.MethodGet,
			endpoint:     "metrics",
			body:         nil,
			expectedCode: http.StatusOK,
		},
		"post": {
			method:       http.MethodPost,
			endpoint:     "volatility",
			body:         bytes.NewBufferString(`not even a json`),
			expectedCode: http.StatusBadRequest,
		},
	} {
		t.Run(name, func(t *testing.T) {
			w := httptest.NewRecorder()

			r, err := http.NewRequestWithContext(ctx, tc.method, "http://:81/"+tc.endpoint, tc.body)
			require.NoError(t, err)

			server.Handler.ServeHTTP(w, r)
			assert.Equal(t, tc.expectedCode, w.Code)
		})
	}

	require.NoError(t, server.Close())
}

func sendSignal(t *testing.T, signal os.Signal) {
	t.Helper()

	proc, err := os.FindProcess(os.Getpid())
	require.NoError(t, err)
	require.NoError(t, proc.Signal(signal))
}

type testServer struct {
	errChan chan error
	up      chan struct{}
}

var _ server = &testServer{}

func newTestServer(errs ...error) *testServer {
	errChan := make(chan error)

	go func() {
		for _, err := range errs {
			errChan <- err
		}
	}()

	return &testServer{
		errChan: errChan,
		up:      make(chan struct{}),
	}
}

func (s testServer) wait() {
	<-s.up
}

func (s testServer) run() <-chan error {
	close(s.up)

	return s.errChan
}

func (s testServer) shutdown(_ context.Context) error {
	return errors.Bug("could not shut down server")
}

func Test_runServer_EarlyTermination(t *testing.T) { //nolint:paralleltest
	assert.Equal(t, unexpected, runServer(t.Context(), newTestServer(
		errors.Bug("server terminated unexpectedly"),
	)))
}

func Test_runServer_InterceptSignal(t *testing.T) { //nolint:paralleltest
	for name, tc := range map[string]struct { //nolint:paralleltest
		signal   os.Signal
		expected termination
	}{
		"sighup": {
			signal:   syscall.SIGHUP,
			expected: reload,
		},
		"sigterm": {
			signal:   syscall.SIGTERM,
			expected: stop,
		},
		"interrupt": {
			signal:   os.Interrupt,
			expected: stop,
		},
	} {
		t.Run(name, func(t *testing.T) {
			s := newTestServer()

			termChan := make(chan termination, 1)

			go func() {
				termChan <- runServer(t.Context(), s)
			}()

			s.wait()
			sendSignal(t, tc.signal)
			assert.Equal(t, tc.expected, <-termChan)
		})
	}
}
