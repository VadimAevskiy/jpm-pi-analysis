package main

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"os"
	"runtime/debug"
	"syscall"
	"time"

	"github.com/bombsimon/logrusr/v4"
	"github.com/edgelaboratories/go-libraries/config"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/resource/grpcclient"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	grpclogging "github.com/grpc-ecosystem/go-grpc-middleware/v2/interceptors/logging"
	grpcrecovery "github.com/grpc-ecosystem/go-grpc-middleware/v2/interceptors/recovery"
	grpcprometheus "github.com/grpc-ecosystem/go-grpc-prometheus"
	grpcruntime "github.com/grpc-ecosystem/grpc-gateway/v2/runtime"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	healthv1 "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/status"
)

const (
	// defaultHTTPPort is the default port for the HTTP server.
	defaultHTTPPort = 8080
	// defaultGRPCPort is the default port for the gRPC server.
	defaultGRPCPort = 8081
)

func main() {
	appConfigFilename := flag.String("app-config", "config/app-config.yml", "Path to application config")
	infraConfigFilename := flag.String("infra-config", "testdata/infra-config.yml", "Path to infrastructure config")
	httpPort := flag.Int("http-port", defaultHTTPPort, "HTTP port")
	grpcPort := flag.Int("grpc-port", defaultGRPCPort, "gRPC port")

	flag.Parse()

	for {
		cfg, err := config.ReadYAML[Configuration](*appConfigFilename, *infraConfigFilename)
		if err != nil {
			log.Fatal(err)
		}

		switch configureAndRun(cfg, *grpcPort, *httpPort) {
		case reload:
			log.Info("reloading Voldorak")

		case stop:
			log.Info("stopping Voldorak")
			os.Exit(0)

		case unexpected:
			fallthrough

		default:
			log.Fatal("Voldorak shut down unexpectedly")
		}
	}
}

type termination int

const (
	stop termination = iota
	reload
	unexpected
)

type server interface {
	run() <-chan error
	shutdown(ctx context.Context) error
}

func runServer(ctx context.Context, s server) termination {
	signalChan := makeSignalChannel()

	errChan := s.run()

	select {
	case signal := <-signalChan:
		log.Infof("received signal %s", signal.String())

		if err := s.shutdown(ctx); err != nil {
			log.Errorf("could not shut down the server gracefully: %v", err)
		}

		if signal == syscall.SIGHUP {
			return reload
		}

		return stop

	case err := <-errChan:
		log.Errorf("unexpected error while running the server: %v", err)

		return unexpected
	}
}

func configureAndRun(cfg *Configuration, grpcPort, httpPort int) termination {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	if err := logger.Configure(cfg.LoggerConf,
		logger.WithTracer(logger.TracerFunc(trace.FieldsFromContext)),
	); err != nil {
		log.Errorf("couldn't configure the logger properly: %v", err)
	}

	log.Info("configuring OpenTelemetry tracing")

	traceLogger := logrusr.New(log.StandardLogger(), logrusr.WithName("tracer"))

	if err := trace.AutoConfigure(ctx, cfg.TraceConf, traceLogger); err != nil {
		// Tracing must not be a blocking resource
		log.Warnf("couldn't configure the tracing properly: %v", err)
	}
	defer trace.Close(ctx)

	log.Info("Voldorak is starting")

	server, err := newVoldorakServer(ctx,
		cfg,
		fmt.Sprintf(":%d", grpcPort),
		fmt.Sprintf(":%d", httpPort),
	)
	if err != nil {
		log.Errorf("could not create Voldorak server: %v", err)

		return unexpected
	}

	return runServer(ctx, server)
}

func newGRPCServer() *grpc.Server {
	// Configure logging
	logEntry := log.WithFields(nil)

	// Configure metrics
	grpcprometheus.EnableHandlingTimeHistogram()

	// Configure recovery
	recoveryOpt := grpcrecovery.WithRecoveryHandlerContext(func(ctx context.Context, p any) error {
		logger.FromContext(ctx).Errorf("%v, stacktrace: %#v\n", p, string(debug.Stack()))

		return status.Error(codes.Internal, "panic occurred")
	})

	return grpc.NewServer(
		trace.GRPCServerStatsHandler(),
		grpc.ChainStreamInterceptor(
			grpclogging.StreamServerInterceptor(grpcclient.InterceptorLogger(logEntry)),
			grpcprometheus.StreamServerInterceptor,
			grpcrecovery.StreamServerInterceptor(recoveryOpt),
		),
		grpc.ChainUnaryInterceptor(
			grpclogging.UnaryServerInterceptor(grpcclient.InterceptorLogger(logEntry)),
			grpcprometheus.UnaryServerInterceptor,
			grpcrecovery.UnaryServerInterceptor(recoveryOpt),
		),
	)
}

func newHTTPServer(ctx context.Context, serverAddress string, httpAddr string) (*http.Server, error) {
	// Create and start the HTTP reverse proxy that will translate JSON over HTTP 1.1 to gRPC
	httpGatewayHandler, err := newHTTPGatewayHandler(ctx, serverAddress)
	if err != nil {
		return nil, fmt.Errorf("could not create the HTTP gateway handler: %w", err)
	}

	mux := http.NewServeMux()
	mux.Handle("/", httpGatewayHandler)
	mux.Handle("/metrics", promhttp.Handler())

	const readHeaderTimeout = 2 * time.Second

	return &http.Server{
		Addr:              httpAddr,
		Handler:           tracingWrapper(mux),
		ReadHeaderTimeout: readHeaderTimeout,
	}, nil
}

func newHTTPGatewayHandler(ctx context.Context, serviceEndpoint string) (http.Handler, error) {
	// Configure a unary client tracing interceptor
	opts := []grpc.DialOption{
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		trace.WithGRPCClientStatsHandler(),
	}

	// Register the HTTP health endpoint configuring the gateway.
	conn, err := grpc.DialContext(ctx, serviceEndpoint, opts...)
	if err != nil {
		return nil, fmt.Errorf("could not establish gRPC connection to health server: %w", err)
	}

	const healthEndpoint = "/manage/health"

	mux := grpcruntime.NewServeMux(
		grpcruntime.WithHealthEndpointAt(healthv1.NewHealthClient(conn), healthEndpoint),
	)

	if err := pb.RegisterVoldorakServiceHandlerFromEndpoint(ctx, mux, serviceEndpoint, opts); err != nil {
		return nil, fmt.Errorf("could not register HTTP service: %w", err)
	}

	return mux, nil
}

func tracingWrapper(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx, span := trace.StartSpan(trace.ContextFromHTTPRequest(r), "ServeHTTP",
			"component", "grpc-gateway",
		)
		defer span.End()

		r = r.WithContext(ctx) //nolint:contextcheck

		h.ServeHTTP(w, r)
	})
}
