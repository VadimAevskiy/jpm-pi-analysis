Context
=======
Describe what this PR means to achieve. Include relevant JIRA tickets and Github issues.

Content
========
Explain what changes you made. Be sure to highlight your doubts and elements that require special attention.

Testing
========
How is this change tested in local (CI/CD tests, benchmarks, running in local, ...)?

Validation
========
What is the validation plan in the dev and prod environments?

Documentation
========
Should doc (e.g. confluence, README, openAPI, ADR, ...) be added to reflect the current change?

What's next?
========
Is there anything to do after this PR?
