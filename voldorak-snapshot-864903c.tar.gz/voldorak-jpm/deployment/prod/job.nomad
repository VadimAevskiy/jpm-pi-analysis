variable "docker_image" {}

job "voldorak" {
  region      = "europe"
  datacenters = ["aws-eu-central-1"]
  namespace   = "quant-engine"

  type = "service"

  update {
    stagger      = "10s"
    max_parallel = 1
    auto_revert  = true
  }

  constraint {
    attribute = "${node.class}"
    value     = "services-default"
  }

  constraint {
    distinct_hosts = true
  }

  group "voldorak" {
    count = 4

    network {
      port "http" {}
      port "grpc" {}
    }

    task "voldorak" {
      driver = "docker"

      config {
        image = "${var.docker_image}"

        command = "/usr/local/bin/voldorak"
        args = [
          "-app-config", "/etc/voldorak/app-config.yml",
          "-infra-config", "/secrets/infra-config.yml",
          "-http-port", "${NOMAD_PORT_http}",
          "-grpc-port", "${NOMAD_PORT_grpc}",
        ]

        ports = ["http", "grpc"]
      }

      env {
        OTEL_SERVICE_NAME           = "${NOMAD_JOB_NAME}"
        OTEL_LOGS_EXPORTER          = "${meta.OTEL_LOGS_EXPORTER}"
        OTEL_METRICS_EXPORTER       = "${meta.OTEL_METRICS_EXPORTER}"
        OTEL_TRACES_EXPORTER        = "${meta.OTEL_TRACES_EXPORTER}"
        OTEL_PROPAGATORS            = "${meta.OTEL_PROPAGATORS}"
        OTEL_EXPORTER_OTLP_PROTOCOL = "${meta.OTEL_EXPORTER_OTLP_PROTOCOL}"
        OTEL_EXPORTER_OTLP_ENDPOINT = "${meta.OTEL_EXPORTER_OTLP_ENDPOINT}"
        OTEL_TRACES_SAMPLER         = "parentbased_traceidratio"
        OTEL_TRACES_SAMPLER_ARG     = "1.0"
      }

      template {
        destination   = "secrets/infra-config.yml"
        change_mode   = "signal"
        change_signal = "SIGHUP"
	data          = file("infra-config.yml")
      }

      service {
        name = "${NOMAD_TASK_NAME}"
        port = "grpc"

        tags = [
          "traefik.tags=http-edgelab-services",
          "traefik.protocol=h2c"
        ]

        check {
          type     = "grpc"
          port     = "grpc"
          interval = "10s"
          timeout  = "2s"
        }
      }

      service {
        name = "${NOMAD_TASK_NAME}-http"
        port = "http"

        tags = [
          "traefik.tags=http-edgelab-services",
          "prometheus-metrics",
        ]

        check {
          type     = "http"
          port     = "http"
          path     = "/manage/health"
          interval = "10s"
          timeout  = "2s"
        }
      }

      # The signal sent to the service when a shutdown is requested.
      kill_signal = "SIGTERM"
      # Give enough time for the load-balancer to de-register the service before shutting it down
      # This value depends on the load-balancer's configuration itself (Traefik).
      shutdown_delay = "5s"
      # The maximum duration the service is expected to take to correctly shutdown.
      # After that, it will be forcefully killed.
      kill_timeout = "10s"

      resources {
        cpu    = 200 # Mhz
        memory = 256 # MB
      }
    }
  }
}
