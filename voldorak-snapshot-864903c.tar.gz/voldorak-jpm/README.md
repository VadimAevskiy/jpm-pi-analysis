# Voldorak

## Description

<p align="center"><img src=".github/logo.png" width="250"></p>

Voldorak is a gRPC service responsible for generating and serving **underlyings**:
- **attributes**: spot, volatility
- **data**: time series, scenarios

## How may I contribute?

### Clone

Voldorak is a private go module that can be cloned via the following commands:

```sh
GONOPROXY=github.com/edgelaboratories/voldorak  \
GONOSUMDB=github.com/edgelaboratories/voldorak  \ 
go get -u github.com/edgelaboratories/voldorak
```

### Build

To compile the executable:

```sh
make build
```

## Test

```sh
make test
```

For more information, have a look at the [Makefile](Makefile).

## Protobuf API

### Requirements

Install the following Go packages:

```sh
  go get github.com/grpc-ecosystem/grpc-gateway/v2/protoc-gen-grpc-gateway
  go get github.com/golang/protobuf/protoc-gen-go
  go get google.golang.org/grpc/cmd/protoc-gen-go-grpc
```

together with [buf](https://buf.build/). 

### Structure

The API is managed via `buf`:
- `.proto` sources are stored in `/proto`
- `.pb.go` generated files are written in `pkg/voldorak` as public API

Notice that [pkg/voldorak](./pkg/voldorak/go.mod) is a Go module Voldorak [depends on](go.mod).

Have a look at the following configuration files for more info:
- [buf.yaml](./buf.yaml)
- [buf.gen.yaml](./buf.gen.yaml)
- [buf.work.yaml](./buf.work.yaml)

### Source

#### Service

Source `.proto` files shall be placed under `proto/voldorak/vX`. The corresponding Go files shall be generated under `pkg/voldorak/vX` and will be visible for `go get`.

#### Health

Source `.proto` files defining the health-check service shall be placed under `proto/voldorak/health/vX`. The corresponding Go files will be generated under `pkg/voldorak/health/vX`. Separating health and service sources allows a unique registration file name for the sake of reflection and prevents [registration conflicts](https://developers.google.com/protocol-buffers/docs/reference/go/faq#namespace-conflict).

#### Generate

```sh
buf mod update
buf build
buf generate
```

- The first command updates the dependencies and the [buf.lock](./buf.lock) file. It can be omitted when not needed
- The second verifies the `.proto` sources compile
- The third writes the generated stubs

The last two commands can be replaced by `make proto-generate`.

#### Lint


```sh
make proto-lint
```

## Continuous Integration/Delivery

The branch `main` is the main branch and any push on it will trigger a [CI pipeline](./Jenkinsfile) and ultimately a deployment in the `dev` environment.
Deployments rely on [Nomad](https://www.nomadproject.io) and use the configuration defined in the corresponding [docker environment](https://github.com/edgelaboratories/docker-environments).
