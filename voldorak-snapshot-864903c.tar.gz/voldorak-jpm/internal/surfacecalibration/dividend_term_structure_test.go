package surfacecalibration

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	"github.com/stretchr/testify/require"
)

func Test_findNnearestATMforwardStrikes(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		slice           SurfaceSlice
		n               int
		expectedStrikes []Strike
	}{
		"Normal case - 3 smallest from 5": {
			slice: SurfaceSlice{
				100.0: OptionPair{Call: new(10.0), Put: new(15.0)},
				110.0: OptionPair{Call: new(8.0), Put: new(9.0)},
				120.0: OptionPair{Call: new(5.0), Put: new(5.5)},
				130.0: OptionPair{Call: new(3.0), Put: new(3.2)},
				140.0: OptionPair{Call: new(2.0), Put: new(4.0)},
			},
			n:               3,
			expectedStrikes: []Strike{130.0, 120.0, 110.0},
		},
		"Request more than available": {
			slice: SurfaceSlice{
				100.0: OptionPair{Call: new(10.0), Put: new(15.0)},
				110.0: OptionPair{Call: new(8.0), Put: new(9.0)},
			},
			n:               5,
			expectedStrikes: []Strike{110.0, 100.0},
		},
		"Single Strike requested": {
			slice: SurfaceSlice{
				100.0: OptionPair{Call: new(10.0), Put: new(15.0)},
				110.0: OptionPair{Call: new(8.0), Put: new(9.0)},
				120.0: OptionPair{Call: new(5.0), Put: new(5.5)},
			},
			n:               1,
			expectedStrikes: []Strike{120.0},
		},
		"No valid pairs 1": {
			slice: SurfaceSlice{
				100.0: OptionPair{Call: new(10.0)},
				110.0: OptionPair{Put: new(9.0)},
			},
			n:               3,
			expectedStrikes: nil,
		},
		"No valid pairs 2": {
			slice: SurfaceSlice{
				100.0: OptionPair{},
				110.0: OptionPair{Put: new(9.0)},
			},
			n:               3,
			expectedStrikes: nil,
		},
		"No valid pairs 3": {
			slice: SurfaceSlice{
				100.0: OptionPair{},
				110.0: OptionPair{},
			},
			n:               3,
			expectedStrikes: nil,
		},
		"Mixed valid and invalid pairs": {
			slice: SurfaceSlice{
				100.0: OptionPair{Call: new(10.0)},
				110.0: OptionPair{Call: new(8.0), Put: new(9.0)},
				120.0: OptionPair{Put: new(5.5)},
				130.0: OptionPair{Call: new(3.0), Put: new(3.2)},
			},
			n:               2,
			expectedStrikes: []Strike{130.0, 110.0},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotStrikes := findNnearestATMforwardStrikes(tc.slice, tc.n)

			require.Equal(t, tc.expectedStrikes, gotStrikes)
		})
	}
}

func Test_computeAmericanDividendYield(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	for name, tc := range map[string]struct {
		americanPair OptionPair
		spot         float64
		strike       float64
		tenor        float64
		r            float64
		qEuropean    float64
		expectedDiv  float64
		validPair    bool
	}{
		"valid pair 1": {
			OptionPair{Call: new(638.0), Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.002756,
			true,
		},
		"valid pair 2": {
			OptionPair{Call: new(578.5), Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.002745,
			true,
		},
		"missing call price": {
			OptionPair{Put: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.02,
			0.0,
			false,
		},
		"missing put price": {
			OptionPair{Call: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.02,
			0.0,
			false,
		},
		"missing both call and put price": {
			OptionPair{},
			10.0,
			10.0,
			0.5,
			0.01,
			0.02,
			0.0,
			false,
		},
		"valid pair just below call-put diff threshold": {
			OptionPair{Call: new(3.1), Put: new(1.2)},
			19.18,
			17.0,
			0.77,
			0.018,
			0.01,
			0.039549,
			true,
		},
		"call-put diff too large": {
			OptionPair{Call: new(3.2), Put: new(1.2)},
			19.18,
			17.0,
			0.77,
			0.018,
			0.01,
			0.0,
			false,
		},
		"ITM call too close to intrinsic value": {
			OptionPair{Call: new(13.7), Put: new(0.02)},
			19.18,
			5.6,
			0.77,
			0.018,
			0.01,
			0.0,
			false,
		},
		"ITM put too close to intrinsic value": {
			OptionPair{Put: new(21.0), Call: new(0.01)},
			19.18,
			40.0,
			0.77,
			0.018,
			0.01,
			0.0,
			false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotDiv, err := computeAmericanDividendYield(tc.americanPair, tc.spot, tc.strike, tc.tenor, tc.r, tc.qEuropean)

			if !tc.validPair {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.InDelta(t, tc.expectedDiv, gotDiv, tol)
		})
	}
}

func Test_computeEuropeanDividendYield(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	for name, tc := range map[string]struct {
		europeanPair OptionPair
		spot         float64
		strike       float64
		tenor        float64
		r            float64
		expectedDiv  float64
		validPair    bool
	}{
		"valid pair 1": {
			OptionPair{Call: new(638.0), Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002656,
			true,
		},
		"valid pair 2": {
			OptionPair{Call: new(578.5), Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002658,
			true,
		},
		"missing call price": {
			OptionPair{Put: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
		"missing put price": {
			OptionPair{Call: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
		"missing both call and put price": {
			OptionPair{},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotDiv, err := computeEuropeanDividendYield(tc.europeanPair, tc.spot, tc.strike, tc.tenor, tc.r)

			if !tc.validPair {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.InDelta(t, tc.expectedDiv, gotDiv, tol)
		})
	}
}

func Test_computeDividendFromPair(t *testing.T) {
	t.Parallel()

	const (
		tol          = 1e-6
		exerciseType = marketdata.American
	)

	for name, tc := range map[string]struct {
		OptionPair  OptionPair
		spot        float64
		strike      float64
		tenor       float64
		r           float64
		expectedDiv float64
		validPair   bool
	}{
		"valid pair 1": {
			OptionPair{Call: new(638.0), Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002756,
			true,
		},
		"valid pair 2": {
			OptionPair{Call: new(578.5), Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002745,
			true,
		},
		"missing call price": {
			OptionPair{Put: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
		"missing put price": {
			OptionPair{Call: new(1.0)},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
		"missing both call and put price": {
			OptionPair{},
			10.0,
			10.0,
			0.5,
			0.01,
			0.0,
			false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotDiv, err := computeDividendFromPair(exerciseType, tc.OptionPair, tc.spot, tc.strike, tc.tenor, tc.r)
			if !tc.validPair {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.InDelta(t, tc.expectedDiv, gotDiv, tol)
		})
	}
}

func Test_ComputeDividendCurveFromOptionChain(t *testing.T) {
	t.Parallel()

	const (
		tol          = 1e-6
		exerciseType = marketdata.American
	)

	for name, tc := range map[string]struct {
		chainDesc           OptionChainDescription
		spot                float64
		irCurve             termstructure.TermStructure
		expectedDivCurve    marketdata.DividendYieldCurve
		expectEmptyDivCurve bool
	}{
		"2 Strikes x 2 tenors Option chain": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					0.274: SurfaceSlice{
						15600.0: OptionPair{Call: new(638.0), Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5), Put: new(667.5)},
					},
					0.10: SurfaceSlice{
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0), Put: new(260.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			spot: 15620.847,
			irCurve: termstructure.TermStructure{
				Data: map[termstructure.Tenor]float64{
					"M1": 0.000355,
					"M3": 0.000355,
					"M6": 0.000355,
				},
			},
			expectedDivCurve: marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.10, DividendZeroRate: -0.020270},
					{YearFraction: 0.274, DividendZeroRate: 0.002751},
				},
			},
		},
		"missing data and expect 2 points in dividend curve": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					0.274: SurfaceSlice{
						15600.0: OptionPair{Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5), Put: new(667.5)},
					},
					0.10: SurfaceSlice{
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			spot: 15620.847,
			irCurve: termstructure.TermStructure{
				Data: map[termstructure.Tenor]float64{
					"M1": 0.000355,
					"M3": 0.000355,
					"M6": 0.000355,
				},
			},
			expectedDivCurve: marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.10, DividendZeroRate: 0.007666},
					{YearFraction: 0.274, DividendZeroRate: 0.002745},
				},
			},
		},
		"missing data and expect 1 point in dividend curve": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					0.274: SurfaceSlice{
						15600.0: OptionPair{Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5)},
					},
					0.10: SurfaceSlice{
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			spot: 15620.847,
			irCurve: termstructure.TermStructure{
				Data: map[termstructure.Tenor]float64{
					"M1": 0.000355,
					"M3": 0.000355,
					"M6": 0.000355,
				},
			},
			expectedDivCurve: marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.1, DividendZeroRate: 0.007666},
				},
			},
		},
		"missing data and expect empty dividend curve": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					0.274: SurfaceSlice{
						15600.0: OptionPair{Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5)},
					},
					0.10: SurfaceSlice{
						15600.0: OptionPair{Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			spot: 15620.847,
			irCurve: termstructure.TermStructure{
				Data: map[termstructure.Tenor]float64{
					"M1": 0.000355,
					"M3": 0.000355,
					"M6": 0.000355,
				},
			},
			expectEmptyDivCurve: true,
		},
		"nasdaq 2021-06-21": {
			chainDesc: OptionChainDescription{
				OptionChain:  nasdaq21optionChain,
				ExerciseType: exerciseType,
			},
			spot:             nasdaq21spot,
			irCurve:          nasdaq21irCurve,
			expectedDivCurve: nasdaq21divCurve,
		},
		"nasdaq 2021-06-22": {
			chainDesc: OptionChainDescription{
				OptionChain:  nasdaq22optionChain,
				ExerciseType: exerciseType,
			},
			spot:             nasdaq22spot,
			irCurve:          nasdaq22irCurve,
			expectedDivCurve: nasdaq22divCurve,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			err := tc.irCurve.BuildInterpolator()
			require.NoError(t, err)

			gotDivCurve, err := ComputeDividendCurveFromOptionChain(tc.chainDesc, tc.spot, tc.irCurve)

			if tc.expectEmptyDivCurve {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)

			for i := range tc.expectedDivCurve.Dividends {
				require.InDelta(t, tc.expectedDivCurve.Dividends[i].YearFraction, gotDivCurve.Dividends[i].YearFraction, tol)
				require.InDelta(t, tc.expectedDivCurve.Dividends[i].DividendZeroRate, gotDivCurve.Dividends[i].DividendZeroRate, tol)
			}
		})
	}
}
