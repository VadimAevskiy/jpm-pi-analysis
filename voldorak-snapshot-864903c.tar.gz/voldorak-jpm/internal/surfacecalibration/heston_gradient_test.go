package surfacecalibration

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_finiteDifferenceGradientValue(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	t.Run("valid gradients", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			f    func([]float64) float64
			x    []float64
			want []float64
		}{
			"quadratic function": {
				f: func(x []float64) float64 {
					return x[0]*x[0] + 3.0*x[1]*x[1]
				},
				x:    []float64{2.0, -1.0},
				want: []float64{4.0, -6.0},
			},
			"linear function": {
				f: func(x []float64) float64 {
					return 2.0*x[0] - 5.0*x[1] + 7.0*x[2]
				},
				x:    []float64{1.0, 2.0, 3.0},
				want: []float64{2.0, -5.0, 7.0},
			},
			"constant function": {
				f: func(_ []float64) float64 {
					return 42.0
				},
				x:    []float64{1.0, 2.0},
				want: []float64{0.0, 0.0},
			},
			"mixed scale inputs": {
				f: func(x []float64) float64 {
					return x[0]*x[0] + x[1]*x[1]
				},
				x:    []float64{1e-8, 1e3},
				want: []float64{2e-8, 2e3},
			},
			"negative inputs": {
				f: func(x []float64) float64 {
					return x[0]*x[0] + x[1]*x[1]
				},
				x:    []float64{-2.0, -3.0},
				want: []float64{-4.0, -6.0},
			},
			"empty input": {
				f: func(_ []float64) float64 {
					return 1.0
				},
				x:    []float64{},
				want: []float64{},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				grad := finiteDifferenceGradientValue(tc.f, tc.x)

				require.Len(t, grad, len(tc.want))

				for i := range tc.want {
					assert.InDelta(t, tc.want[i], grad[i], tol)
				}
			})
		}
	})

	t.Run("does not mutate input", func(t *testing.T) {
		t.Parallel()

		var (
			x    = []float64{2.0, -1.0}
			want = append([]float64(nil), x...)

			f = func(x []float64) float64 {
				return x[0]*x[0] + x[1]*x[1]
			}
		)

		_ = finiteDifferenceGradientValue(f, x)

		assert.Equal(t, want, x)
	})
}

func Test_scaleToUnit(t *testing.T) {
	t.Parallel()

	const tol = 1e-12

	t.Run("valid inputs", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			x    float64
			lo   float64
			hi   float64
			want float64
		}{
			"lower bound": {x: 2.0, lo: 2.0, hi: 6.0, want: 0.0},
			"upper bound": {x: 6.0, lo: 2.0, hi: 6.0, want: 1.0},
			"mid point":   {x: 4.0, lo: 2.0, hi: 6.0, want: 0.5},
			"below range": {x: 0.0, lo: 2.0, hi: 6.0, want: -0.5},
			"above range": {x: 8.0, lo: 2.0, hi: 6.0, want: 1.5},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := scaleToUnit(tc.x, tc.lo, tc.hi)

				require.NoError(t, err)
				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})

	t.Run("invalid bounds", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			x  float64
			lo float64
			hi float64
		}{
			"equal bounds":    {x: 1.0, lo: 2.0, hi: 2.0},
			"inverted bounds": {x: 1.0, lo: 6.0, hi: 2.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := scaleToUnit(tc.x, tc.lo, tc.hi)
				require.Error(t, err)
			})
		}
	})
}

func Test_unscaleFromUnit(t *testing.T) {
	t.Parallel()

	const tol = 1e-12

	t.Run("valid inputs", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			y    float64
			lo   float64
			hi   float64
			want float64
		}{
			"lower bound": {y: 0.0, lo: 2.0, hi: 6.0, want: 2.0},
			"upper bound": {y: 1.0, lo: 2.0, hi: 6.0, want: 6.0},
			"mid point":   {y: 0.5, lo: 2.0, hi: 6.0, want: 4.0},
			"below range": {y: -0.5, lo: 2.0, hi: 6.0, want: 0.0},
			"above range": {y: 1.5, lo: 2.0, hi: 6.0, want: 8.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got := unscaleFromUnit(tc.y, tc.lo, tc.hi)

				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})
}

func Test_packHestonParameters(t *testing.T) {
	t.Parallel()

	const tol = 1e-12

	t.Run("valid params", func(t *testing.T) {
		t.Parallel()

		got, err := packHestonParameters(marketdata.HestonParameters{
			Kappa: kMin,
			Theta: thetaMax,
			Sigma: (sigmaMin + sigmaMax) / 2.0,
			Rho:   (rhoMin + rhoMax) / 2.0,
			V0:    v0Max,
		})

		require.NoError(t, err)
		require.Len(t, got, 5)

		assert.InDelta(t, 0.0, got[0], tol)
		assert.InDelta(t, 1.0, got[1], tol)
		assert.InDelta(t, 0.5, got[2], tol)
		assert.InDelta(t, 0.5, got[3], tol)
		assert.InDelta(t, 1.0, got[4], tol)
	})
}

func Test_unpackHestonParameters(t *testing.T) {
	t.Parallel()

	const tol = 1e-12

	t.Run("valid input", func(t *testing.T) {
		t.Parallel()

		got, err := unpackHestonParameters([]float64{
			0.0,
			1.0,
			0.5,
			0.5,
			1.0,
		})

		require.NoError(t, err)

		assert.InDelta(t, kMin, got.Kappa, tol)
		assert.InDelta(t, thetaMax, got.Theta, tol)
		assert.InDelta(t, (sigmaMin+sigmaMax)/2.0, got.Sigma, tol)
		assert.InDelta(t, (rhoMin+rhoMax)/2.0, got.Rho, tol)
		assert.InDelta(t, v0Max, got.V0, tol)
	})

	t.Run("invalid input", func(t *testing.T) {
		t.Parallel()

		for name, x := range map[string][]float64{
			"nil":       nil,
			"empty":     {},
			"too short": {0.0, 1.0, 0.5, 0.5},
			"too long":  {0.0, 1.0, 0.5, 0.5, 1.0, 0.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := unpackHestonParameters(x)
				require.Error(t, err)
			})
		}
	})
}

func Test_toLBFGSBBounds(t *testing.T) {
	t.Parallel()

	t.Run("converts parameter bounds", func(t *testing.T) {
		t.Parallel()

		input := []parameterBound{
			{Lower: 0.0, Upper: 1.0},
			{Lower: -0.95, Upper: 0.95},
			{Lower: 1e-4, Upper: 10.0},
		}

		got := toLBFGSBBounds(input)

		want := [][2]float64{
			{0.0, 1.0},
			{-0.95, 0.95},
			{1e-4, 10.0},
		}

		assert.Equal(t, want, got)
	})

	t.Run("empty bounds", func(t *testing.T) {
		t.Parallel()

		got := toLBFGSBBounds(nil)

		assert.Empty(t, got)
	})
}
