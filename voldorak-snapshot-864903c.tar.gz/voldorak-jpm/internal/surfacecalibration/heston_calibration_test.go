package surfacecalibration

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_validHestonConstraints(t *testing.T) {
	t.Parallel()

	t.Run("valid params", func(t *testing.T) {
		t.Parallel()

		for name, params := range map[string]marketdata.HestonParameters{
			"standard": testHestonParams(),
			"rho near upper bound": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   0.999999,
			},
			"rho near lower bound": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   -0.999999,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.True(t, validHestonConstraints(params))
			})
		}
	})

	t.Run("invalid params", func(t *testing.T) {
		t.Parallel()

		for name, params := range map[string]marketdata.HestonParameters{
			"zero v0": {
				V0:    0.0,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   -0.7,
			},
			"negative v0": {
				V0:    -0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   -0.7,
			},
			"zero kappa": {
				V0:    0.04,
				Kappa: 0.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   -0.7,
			},
			"zero theta": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.0,
				Sigma: 0.3,
				Rho:   -0.7,
			},
			"zero sigma": testZeroSigmaHestonParams(),
			"rho equals one": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   1.0,
			},
			"rho equals negative one": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   -1.0,
			},
			"rho above one": {
				V0:    0.04,
				Kappa: 2.0,
				Theta: 0.04,
				Sigma: 0.3,
				Rho:   1.1,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.False(t, validHestonConstraints(params))
			})
		}
	})
}

func Test_hestonImpliedVolRMSE(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	t.Run("valid surface", func(t *testing.T) {
		t.Parallel()

		irCurve := nasdaq21irCurve
		err := irCurve.BuildInterpolator()
		require.NoError(t, err)

		surface, err := ComputeRawVolatilitySurface(
			OptionChainDescription{
				OptionChain:  nasdaq21optionChain,
				ExerciseType: marketdata.American,
			},
			nasdaq21spot,
			irCurve,
			marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.4904109589, DividendZeroRate: 0.003530},
					{YearFraction: 0.7397260274, DividendZeroRate: 0.002717},
					{YearFraction: 0.9890410959, DividendZeroRate: 0.002708},
				},
			},
		)
		require.NoError(t, err)

		rmse, err := hestonImpliedVolRMSE(
			surface,
			testHestonParams(),
			defaultLaguerre96(),
		)

		require.NoError(t, err)
		require.InDelta(t, 0.034066147825150786, rmse, tol)
	})

	t.Run("invalid surface returns error", func(t *testing.T) {
		t.Parallel()

		rmse, err := hestonImpliedVolRMSE(
			VolatilitySurface{},
			testHestonParams(),
			defaultLaguerre96(),
		)

		require.Error(t, err)
		assert.InDelta(t, 0.0, rmse, tol)
	})
}

func Test_hestonObjectiveFunctionWrapper(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	var (
		lag = defaultLaguerre96()

		surface = VolatilitySurface{
			Slices: map[Tenor]volatilitySurfaceSlice{
				1.0: {
					tenor: 1.0,
					spot:  100.0,
					r:     0.02,
					q:     0.01,
					data: map[Strike]volatilityDataPoint{
						100.0: {
							strike:                  100.0,
							iv:                      0.20,
							vega:                    25.0,
							europeanCallOptionPrice: 8.0,
						},
					},
				},
			},
		}

		invalidVegaSurface = VolatilitySurface{
			Slices: map[Tenor]volatilitySurfaceSlice{
				1.0: {
					tenor: 1.0,
					spot:  100.0,
					r:     0.02,
					q:     0.01,
					data: map[Strike]volatilityDataPoint{
						100.0: {
							strike:                  100.0,
							iv:                      0.20,
							vega:                    1e-5,
							europeanCallOptionPrice: 8.0,
						},
					},
				},
			},
		}
	)

	t.Run("valid sum squared error", func(t *testing.T) {
		t.Parallel()

		var (
			stats     = &HestonObjectiveFunctionStats{}
			objective = hestonObjectiveFunctionWrapper(surface, lag, stats)
		)

		got := objective([]float64{
			0.2,
			0.2,
			0.2,
			0.5,
			0.2,
		})

		assert.InDelta(t, 0.16242196702494738, got, tol)
		assert.NotEqual(t, hestonHeavyPenalty, got)

		assert.Equal(t, 1, stats.Evaluations)
		require.NoError(t, stats.vegaErr)
		assert.Equal(t, 0, stats.HeavyPenaltyCount)
	})

	t.Run("heavy penalty for invalid packed parameters", func(t *testing.T) {
		t.Parallel()

		var (
			stats     = &HestonObjectiveFunctionStats{}
			objective = hestonObjectiveFunctionWrapper(surface, lag, stats)
		)

		got := objective([]float64{0.1, 0.2})

		assert.InDelta(t, hestonHeavyPenalty, got, tol)

		assert.Equal(t, 1, stats.Evaluations)
		require.NoError(t, stats.vegaErr)
		assert.Equal(t, 1, stats.HeavyPenaltyCount)
	})

	t.Run("heavy penalty for invalid heston constraints", func(t *testing.T) {
		t.Parallel()

		var (
			stats     = &HestonObjectiveFunctionStats{}
			objective = hestonObjectiveFunctionWrapper(surface, lag, stats)
		)

		got := objective([]float64{
			0.2,
			0.2,
			0.2,
			10.0,
			0.2,
		})

		assert.InDelta(t, hestonHeavyPenalty, got, tol)

		assert.Equal(t, 1, stats.Evaluations)
		require.NoError(t, stats.vegaErr)
		assert.Equal(t, 1, stats.HeavyPenaltyCount)
	})

	t.Run("heavy penalty and report error if minimum vega not satisfied", func(t *testing.T) {
		t.Parallel()

		var (
			stats     = &HestonObjectiveFunctionStats{}
			objective = hestonObjectiveFunctionWrapper(invalidVegaSurface, lag, stats)
		)

		got := objective([]float64{
			0.2,
			0.2,
			0.2,
			0.5,
			0.2,
		})

		assert.InDelta(t, 0.0, got, tol)

		assert.Equal(t, 1, stats.Evaluations)
		require.Error(t, stats.vegaErr)
		assert.Equal(t, 0, stats.HeavyPenaltyCount)
	})
}
