package surfacecalibration

import (
	"math"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	log "github.com/sirupsen/logrus"
	"gonum.org/v1/gonum/optimize"
)

// HestonCalibrationResult represents the result of a Heston calibration,
// including the calibrated Heston parameters to which the optimizer converged,
// the RMSE of the fit to assess the quality of the calibration,
// and the optimization status which provides insights into the convergence of the optimization process.
type HestonCalibrationResult struct {
	Parameters       marketdata.HestonParameters
	RMSE             float64
	Status           optimize.Status
	CalibrationStats HestonObjectiveFunctionStats
}

// HestonObjectiveFunctionStats tracks statistics of the Heston objective function evaluations,
// such as the number of evaluations and the count of heavy penalties applied due to constraint violations or pricing errors.
type HestonObjectiveFunctionStats struct {
	Evaluations       int
	HeavyPenaltyCount int
	vegaErr           error
}

const hestonHeavyPenalty = 1e10

func validHestonConstraints(p marketdata.HestonParameters) bool {
	if p.V0 <= 0 || p.Kappa <= 0 || p.Theta <= 0 || p.Sigma <= 0 {
		return false
	}

	if math.Abs(p.Rho) >= 1.0 {
		return false
	}

	return true
}

func hestonImpliedVolRMSE(surface VolatilitySurface, params marketdata.HestonParameters, lag laguerre) (float64, error) {
	var (
		sumSquaredError  float64
		numPoints        int
		skipPriceCounter int
		skipIVCounter    int
	)

	for t, slice := range surface.Slices {
		T := float64(t)

		for _, dp := range slice.data {
			modelPrice, err := hestonCallPrice(slice.spot, dp.strike, T, slice.r, slice.q, params, lag)
			if err != nil {
				skipPriceCounter++

				continue
			}

			modelIV, err := computeEuropeanIV(vanillaoptionpricer.Call, OptionPair{Call: &modelPrice}, slice.spot, dp.strike, T, slice.r, slice.q)
			if err != nil {
				skipIVCounter++

				continue
			}

			diff := modelIV - dp.iv
			sumSquaredError += diff * diff
			numPoints++
		}
	}

	if skipPriceCounter > 0 || skipIVCounter > 0 {
		log.Warnf("skipped %d price points and %d IV points in RMSE calculation", skipPriceCounter, skipIVCounter)
	}

	if numPoints == 0 {
		return 0.0, errors.Bug("no valid points to compute RMSE for Heston calibration")
	}

	return math.Sqrt(sumSquaredError / float64(numPoints)), nil
}

const vegaTol = 1e-4

func hestonObjectiveFunctionWrapper(surface VolatilitySurface, lag laguerre, stats *HestonObjectiveFunctionStats) func([]float64) float64 {
	return func(packedParams []float64) float64 {
		stats.Evaluations++

		params, err := unpackHestonParameters(packedParams)
		if err != nil {
			stats.HeavyPenaltyCount++

			return hestonHeavyPenalty
		}

		if !validHestonConstraints(params) {
			stats.HeavyPenaltyCount++

			return hestonHeavyPenalty
		}

		var sumSquaredError float64

		for t, slice := range surface.Slices {
			for _, dp := range slice.data {
				modelPrice, err := hestonCallPrice(slice.spot, dp.strike, float64(t), slice.r, slice.q, params, lag)
				if err != nil {
					stats.HeavyPenaltyCount++

					return hestonHeavyPenalty
				}

				if dp.vega < vegaTol {
					stats.vegaErr = errors.Bug("vega below allowed threshold")

					return 0.0
				}

				diff := (modelPrice - dp.europeanCallOptionPrice) / dp.vega
				sumSquaredError += diff * diff
			}
		}

		return math.Sqrt(sumSquaredError)
	}
}
