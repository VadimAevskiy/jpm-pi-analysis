package surfacecalibration

import (
	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

type OptionChainDescription struct {
	Currency           *marketdata.Currency
	DaycountConvention marketdata.DaycountConvention
	ExerciseType       marketdata.ExerciseType
	OptionChain        OptionChain
}

type OptionChain map[Tenor]SurfaceSlice

type SurfaceSlice map[Strike]OptionPair

type Strike float64

type Tenor float64

type OptionPair struct {
	Call *float64
	Put  *float64
}

func (p OptionPair) Price(callPut vanillaoptionpricer.OptionType) (float64, error) {
	switch callPut {
	case vanillaoptionpricer.Call:
		if p.Call == nil {
			return 0.0, errors.Bug("call option price is nil")
		}

		return *p.Call, nil
	case vanillaoptionpricer.Put:
		if p.Put == nil {
			return 0.0, errors.Bug("put option price is nil")
		}

		return *p.Put, nil
	default:
		return 0.0, errors.Bug("invalid option type: %v", callPut)
	}
}
