package surfacecalibration

import (
	"testing"

	"github.com/stretchr/testify/require"
)

func Test_newVarianceBackboneInterpolator(t *testing.T) {
	t.Parallel()

	const tol = 1e-10

	t.Run("ordered backbone", func(t *testing.T) {
		t.Parallel()

		varBackbone := varianceBackbone{
			data: map[Tenor]volatilityDataPoint{
				30:  {totalVariance: 0.01},
				60:  {totalVariance: 0.02},
				90:  {totalVariance: 0.03},
				120: {totalVariance: 0.04},
			},
		}

		err := varBackbone.buildInterpolator()
		require.NoError(t, err)
		require.NotNil(t, varBackbone.interpolator)
		require.InDelta(t, 0.0, varBackbone.value(0.0), tol)
		require.InDelta(t, 0.01, varBackbone.value(30.0), tol)
		require.InDelta(t, 0.015, varBackbone.value(45.0), tol)
		require.InDelta(t, 0.025, varBackbone.value(75.0), tol)
		require.InDelta(t, 0.05, varBackbone.value(150.0), tol)
	})

	t.Run("unordered backbone", func(t *testing.T) {
		t.Parallel()

		varBackbone := varianceBackbone{
			data: map[Tenor]volatilityDataPoint{
				90:  {totalVariance: 0.03},
				30:  {totalVariance: 0.01},
				120: {totalVariance: 0.04},
				60:  {totalVariance: 0.02},
			},
		}

		err := varBackbone.buildInterpolator()
		require.NoError(t, err)
		require.NotNil(t, varBackbone.interpolator)
		require.InDelta(t, 0.0, varBackbone.value(0.0), tol)
		require.InDelta(t, 0.01, varBackbone.value(30.0), tol)
		require.InDelta(t, 0.015, varBackbone.value(45.0), tol)
		require.InDelta(t, 0.025, varBackbone.value(75.0), tol)
		require.InDelta(t, 0.05, varBackbone.value(150.0), tol)
	})
}
