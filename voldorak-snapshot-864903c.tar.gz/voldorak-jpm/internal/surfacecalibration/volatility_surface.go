package surfacecalibration

import (
	"fmt"
	"sort"

	"github.com/edgelaboratories/go-libraries/interpolator"
)

// VolatilitySurface is represented as collection of surface slices, one for each tenor.
// We use maps for error-proof lookups.
type VolatilitySurface struct {
	Slices       map[Tenor]volatilitySurfaceSlice
	SortedTenors []Tenor
}

// volatilitySurfaceSlice is a slice of the volatility surface for a given tenor.
// It contains a map of strikes to volatility data points, the forward price and the tenor.
type volatilitySurfaceSlice struct {
	data  map[Strike]volatilityDataPoint
	tenor float64
	// forward is the forward price defined as spot * exp((r-q)*tenor).
	forward float64
	spot    float64
	r       float64
	q       float64
}

// volatilityDataPoint is the relevant surface data for a given strike and tenor.
type volatilityDataPoint struct {
	// iv is the implied volatility.
	iv float64
	// totalVariance is defined as iv^2 * tenor.
	totalVariance float64
	// kappa is the log forward moneyness log(K/F), where K is the strike and F is the forward price.
	kappa                   float64
	strike                  float64
	vega                    float64
	europeanCallOptionPrice float64
}

// varianceBackbone is the ATM-forward total variance for each tenor, i.e. w(0,t) in SSVI notation.
type varianceBackbone struct {
	data         map[Tenor]volatilityDataPoint
	interpolator *interpolator.PiecewiseLinear
}

// buildInterpolator initializes the piecewise linear interpolator for the total variance backbone.
// The point (0,0) is added to the backbone to enforce the boundary condition at the origin.
func (varBackbone *varianceBackbone) buildInterpolator() error {
	xys := make(interpolator.XYs, len(varBackbone.data)+1)

	// add the point (0,0) for the total variance backbone.
	xys[0].X = 0.0
	xys[0].Y = 0.0

	i := 1
	for t, dp := range varBackbone.data {
		xys[i].X = float64(t)
		xys[i].Y = dp.totalVariance
		i++
	}

	sort.Slice(xys, func(i, j int) bool {
		return xys[i].X < xys[j].X
	})

	interp, err := interpolator.NewPiecewiseLinear(xys)
	if err != nil {
		return fmt.Errorf("could not create piecewise linear interpolator: %w", err)
	}

	varBackbone.interpolator = interp

	return nil
}

// value returns the total variance for a given tenor using the backbone interpolator. If the interpolator is not initialized, it returns 0.
func (varBackbone *varianceBackbone) value(tenor float64) float64 {
	if varBackbone.interpolator == nil {
		return 0.0
	}

	return varBackbone.interpolator.Value(tenor)
}
