package surfacecalibration

import (
	"testing"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	"github.com/stretchr/testify/require"
)

func Test_computeAmericanIVvalue(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	for name, tc := range map[string]struct {
		callPut      vanillaoptionpricer.OptionType
		americanPair OptionPair
		spot         float64
		strike       float64
		tenor        float64
		r            float64
		q            float64
		expectedIV   float64
		expectError  bool
	}{
		"Put option": {
			vanillaoptionpricer.Put,
			OptionPair{Call: new(638.0), Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.194109,
			false,
		},
		"Call option": {
			vanillaoptionpricer.Call,
			OptionPair{Call: new(578.5), Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.190311,
			false,
		},
		"Call option missing put": {
			vanillaoptionpricer.Call,
			OptionPair{Call: new(578.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.190311,
			false,
		},
		"Put option missing call": {
			vanillaoptionpricer.Put,
			OptionPair{Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.194109,
			false,
		},
		"Call option missing call": {
			vanillaoptionpricer.Call,
			OptionPair{Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.0,
			true,
		},
		"Put option missing put": {
			vanillaoptionpricer.Put,
			OptionPair{},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.0,
			true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotIV, err := computeAmericanIV(tc.callPut, tc.americanPair, tc.spot, tc.strike, tc.tenor, tc.r, tc.q)

			if tc.expectError {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.InDelta(t, tc.expectedIV, gotIV, tol)
		})
	}
}

func Test_computeEuropeanIVvalue(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	for name, tc := range map[string]struct {
		callPut      vanillaoptionpricer.OptionType
		americanPair OptionPair
		spot         float64
		strike       float64
		tenor        float64
		r            float64
		q            float64
		expectedIV   float64
		expectError  bool
	}{
		"Put option": {
			vanillaoptionpricer.Put,
			OptionPair{Call: new(638.0), Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.194109,
			false,
		},
		"Call option": {
			vanillaoptionpricer.Call,
			OptionPair{Call: new(578.5), Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.190427,
			false,
		},
		"Call option missing put": {
			vanillaoptionpricer.Call,
			OptionPair{Call: new(578.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.190427,
			false,
		},
		"Put option missing call": {
			vanillaoptionpricer.Put,
			OptionPair{Put: new(627.0)},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.194109,
			false,
		},
		"Call option missing call": {
			vanillaoptionpricer.Call,
			OptionPair{Put: new(667.5)},
			15620.847,
			15700.0,
			0.274,
			0.000355,
			0.002777,
			0.0,
			true,
		},
		"Put option missing put (and call)": {
			vanillaoptionpricer.Put,
			OptionPair{},
			15620.847,
			15600.0,
			0.274,
			0.000355,
			0.002777,
			0.0,
			true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotIV, err := computeEuropeanIV(tc.callPut, tc.americanPair, tc.spot, tc.strike, tc.tenor, tc.r, tc.q)

			if tc.expectError {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.InDelta(t, tc.expectedIV, gotIV, tol)
		})
	}
}

var (
	fullSlice1 = volatilitySurfaceSlice{
		data: map[Strike]volatilityDataPoint{
			15400.0: {totalVariance: 0.003207},
			15600.0: {totalVariance: 0.002344},
			15700.0: {totalVariance: 0.002107},
			15800.0: {totalVariance: 0.002294},
			15900.0: {totalVariance: 0.002583},
		},
	}
	fullSlice2 = volatilitySurfaceSlice{
		data: map[Strike]volatilityDataPoint{
			15400.0: {totalVariance: 0.009635},
			15600.0: {totalVariance: 0.010599},
			15700.0: {totalVariance: 0.009682},
			15800.0: {totalVariance: 0.009884},
			15900.0: {totalVariance: 0.009960},
		},
	}
	fullSlice3 = volatilitySurfaceSlice{
		data: map[Strike]volatilityDataPoint{
			15400.0: {totalVariance: 0.000321},
			15600.0: {totalVariance: 0.000083},
			15700.0: {totalVariance: 0.000110},
			15800.0: {totalVariance: 0.000196},
			15900.0: {totalVariance: 0.000257},
		},
	}
	fullChainSlice1 = SurfaceSlice{
		15400.0: OptionPair{Call: new(350.0), Put: new(250.0)},
		15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
		15700.0: OptionPair{Call: new(250.0), Put: new(260.0)},
		15800.0: OptionPair{Call: new(220.0), Put: new(300.0)},
		15900.0: OptionPair{Call: new(200.0), Put: new(350.0)},
	}
	fullChainSlice2 = SurfaceSlice{
		15400.0: OptionPair{Call: new(700.0), Put: new(500.0)},
		15600.0: OptionPair{Call: new(638.0), Put: new(627.0)},
		15700.0: OptionPair{Call: new(578.5), Put: new(667.5)},
		15800.0: OptionPair{Call: new(540.0), Put: new(720.0)},
		15900.0: OptionPair{Call: new(500.0), Put: new(800.0)},
	}
	fullChainSlice3 = SurfaceSlice{
		15400.0: OptionPair{Call: new(60.0), Put: new(30.0)},
		15600.0: OptionPair{Call: new(50.0), Put: new(40.0)},
		15700.0: OptionPair{Call: new(40.0), Put: new(50.0)},
		15800.0: OptionPair{Call: new(30.0), Put: new(60.0)},
		15900.0: OptionPair{Call: new(20.0), Put: new(70.0)},
	}
)

func Test_ComputeRawVolatilitySurface(t *testing.T) {
	t.Parallel()

	const (
		tol          = 1e-6
		testQ        = 0.002
		testR        = 0.00355
		exerciseType = marketdata.American
		testSpot     = 15620.847
		testTenor1   = 0.10
		testTenor2   = 0.274
		testTenor3   = 0.8
	)

	testIRCurve := termstructure.TermStructure{
		Data: map[termstructure.Tenor]float64{
			"M1": testR,
			"M3": testR,
			"M6": testR,
		},
	}

	err := testIRCurve.BuildInterpolator()
	require.NoError(t, err)

	testDivCurve := marketdata.DividendYieldCurve{
		Dividends: []marketdata.DividendPoint{
			{YearFraction: testTenor1, DividendZeroRate: testQ},
			{YearFraction: testTenor2, DividendZeroRate: testQ},
		},
	}

	for name, tc := range map[string]struct {
		chainDesc       OptionChainDescription
		expectedSurface *VolatilitySurface
	}{
		"5 Strikes x 3 tenors Option chain": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					testTenor1: fullChainSlice1,
					testTenor2: fullChainSlice2,
					testTenor3: fullChainSlice3,
				},
				ExerciseType: exerciseType,
			},
			expectedSurface: &VolatilitySurface{
				Slices: map[Tenor]volatilitySurfaceSlice{
					testTenor1: fullSlice1,
					testTenor2: fullSlice2,
					testTenor3: fullSlice3,
				},
			},
		},
		"missing ITM option doesn't affect surface": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					testTenor1: SurfaceSlice{
						15400.0: OptionPair{Put: new(250.0)},
						15600.0: OptionPair{Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0)},
						15800.0: OptionPair{Call: new(220.0)},
						15900.0: OptionPair{Call: new(200.0)},
					},
					testTenor2: SurfaceSlice{
						15400.0: OptionPair{Put: new(500.0)},
						15600.0: OptionPair{Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5)},
						15800.0: OptionPair{Call: new(540.0)},
						15900.0: OptionPair{Call: new(500.0)},
					},
					testTenor3: SurfaceSlice{
						15400.0: OptionPair{Put: new(30.0)},
						15600.0: OptionPair{Put: new(40.0)},
						15700.0: OptionPair{Call: new(40.0)},
						15800.0: OptionPair{Call: new(30.0)},
						15900.0: OptionPair{Call: new(20.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			expectedSurface: &VolatilitySurface{
				Slices: map[Tenor]volatilitySurfaceSlice{
					testTenor1: fullSlice1,
					testTenor2: fullSlice2,
					testTenor3: fullSlice3,
				},
			},
		},
		"missing data in three slices": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					testTenor1: SurfaceSlice{
						15400.0: OptionPair{Call: new(350.0)},
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0), Put: new(260.0)},
						15800.0: OptionPair{Call: new(220.0), Put: new(300.0)},
						15900.0: OptionPair{Call: new(200.0), Put: new(350.0)},
					},
					testTenor2: SurfaceSlice{
						15400.0: OptionPair{Call: new(700.0), Put: new(500.0)},
						15700.0: OptionPair{Call: new(578.5), Put: new(667.5)},
						15800.0: OptionPair{Call: new(540.0), Put: new(720.0)},
						15900.0: OptionPair{Call: new(500.0), Put: new(800.0)},
					},
					testTenor3: SurfaceSlice{
						15400.0: OptionPair{Call: new(60.0), Put: new(30.0)},
						15600.0: OptionPair{Call: new(50.0), Put: new(40.0)},
						15700.0: OptionPair{},
						15800.0: OptionPair{Call: new(30.0), Put: new(60.0)},
						15900.0: OptionPair{Call: new(20.0), Put: new(70.0)},
					},
				},
				ExerciseType: exerciseType,
			},
			expectedSurface: &VolatilitySurface{
				Slices: map[Tenor]volatilitySurfaceSlice{
					testTenor1: {
						data: map[Strike]volatilityDataPoint{
							15600.0: {totalVariance: 0.002344},
							15700.0: {totalVariance: 0.002107},
							15800.0: {totalVariance: 0.002294},
							15900.0: {totalVariance: 0.002583},
						},
					},
					testTenor2: {
						data: map[Strike]volatilityDataPoint{
							15400.0: {totalVariance: 0.009635},
							15700.0: {totalVariance: 0.009682},
							15800.0: {totalVariance: 0.009884},
							15900.0: {totalVariance: 0.009960},
						},
					},
					testTenor3: {
						data: map[Strike]volatilityDataPoint{
							15400.0: {totalVariance: 0.000321},
							15600.0: {totalVariance: 0.000083},
							15800.0: {totalVariance: 0.000196},
							15900.0: {totalVariance: 0.000257},
						},
					},
				},
			},
		},
		"slice shorter than min size because of missing data is skipped": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					testTenor1: SurfaceSlice{
						15400.0: OptionPair{},
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0), Put: new(260.0)},
						15900.0: OptionPair{Call: new(200.0), Put: new(350.0)},
					},
					testTenor2: fullChainSlice2,
					testTenor3: fullChainSlice3,
				},
				ExerciseType: exerciseType,
			},
			expectedSurface: &VolatilitySurface{
				Slices: map[Tenor]volatilitySurfaceSlice{
					testTenor2: fullSlice2,
					testTenor3: fullSlice3,
				},
			},
		},
		"two skipped slices gives single tenor surface and raises error": {
			chainDesc: OptionChainDescription{
				OptionChain: OptionChain{
					testTenor1: SurfaceSlice{
						15400.0: OptionPair{},
						15600.0: OptionPair{Call: new(300.0), Put: new(290.0)},
						15700.0: OptionPair{Call: new(250.0), Put: new(260.0)},
						15900.0: OptionPair{Call: new(200.0), Put: new(350.0)},
					},
					testTenor2: SurfaceSlice{
						15400.0: OptionPair{Call: new(700.0), Put: new(500.0)},
						15600.0: OptionPair{Call: new(638.0), Put: new(627.0)},
						15700.0: OptionPair{Call: new(578.5), Put: new(667.5)},
						15800.0: OptionPair{Put: new(720.0)},
						15900.0: OptionPair{Put: new(800.0)},
					},
					testTenor3: fullChainSlice3,
				},
				ExerciseType: exerciseType,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			gotSurface, err := ComputeRawVolatilitySurface(tc.chainDesc, testSpot, testIRCurve, testDivCurve)
			if tc.expectedSurface == nil {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			assertVolatilitySurfaceTotalVariance(t, tc.expectedSurface, gotSurface, tol)
		})
	}
}

func Test_ComputeRawVolatilitySurface_WithEuropeanCallPriceCheck(t *testing.T) {
	t.Parallel()

	const (
		tol          = 1e-4
		exerciseType = marketdata.American
	)

	t.Run("nasdaq 2021-06-21", func(t *testing.T) {
		t.Parallel()

		var (
			chainDesc = OptionChainDescription{
				OptionChain:  nasdaq21optionChain,
				ExerciseType: exerciseType,
			}
			spot     = nasdaq21spot
			irCurve  = nasdaq21irCurve
			divCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.4904109589, DividendZeroRate: 0.003530},
					{YearFraction: 0.7397260274, DividendZeroRate: 0.002717},
					{YearFraction: 0.9890410959, DividendZeroRate: 0.002708},
				},
			}
			expectedSurface = &nasdaq21expectedSurface
		)

		err := irCurve.BuildInterpolator()
		require.NoError(t, err)

		gotSurface, err := ComputeRawVolatilitySurface(chainDesc, spot, irCurve, divCurve)
		require.NoError(t, err)

		assertVolatilitySurfaceTotalVariance(t, expectedSurface, gotSurface, tol)
	})

	t.Run("nasdaq 2021-06-22", func(t *testing.T) {
		t.Parallel()

		var (
			chainDesc = OptionChainDescription{
				OptionChain:  nasdaq22optionChain,
				ExerciseType: exerciseType,
			}
			spot     = nasdaq22spot
			irCurve  = nasdaq22irCurve
			divCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{YearFraction: 0.4876712329, DividendZeroRate: 0.004149},
					{YearFraction: 0.7369863014, DividendZeroRate: 0.003170},
					{YearFraction: 0.9863013699, DividendZeroRate: 0.003198},
				},
			}
			expectedSurface = &nasdaq22expectedSurface
		)

		err := irCurve.BuildInterpolator()
		require.NoError(t, err)

		gotSurface, err := ComputeRawVolatilitySurface(chainDesc, spot, irCurve, divCurve)
		require.NoError(t, err)

		assertVolatilitySurfaceTotalVariance(t, expectedSurface, gotSurface, tol)
	})

	t.Run("small european chain stores european call prices", func(t *testing.T) {
		t.Parallel()

		const (
			spot = 100.0
			r    = 0.03
			q    = 0.01
			vol  = 0.25
		)

		var (
			tenor = termstructure.M1
			chain = SurfaceSlice{}

			irCurve = termstructure.TermStructure{
				Data: map[termstructure.Tenor]float64{
					tenor: r,
				},
			}
		)

		tf, err := tenor.ToYearFraction()
		require.NoError(t, err)

		divCurve := marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{YearFraction: tf, DividendZeroRate: q},
			},
		}

		for _, strike := range []Strike{101.0, 102.0, 103.0, 104.0} {
			k := float64(strike)

			d1, d2 := vanillaoptionpricer.DPlusMinus(
				spot,
				k,
				vol,
				tf,
				tf,
				r,
				q,
			)

			chain[strike] = OptionPair{
				Call: new(vanillaoptionpricer.EuropeanBlackScholesPrice(
					spot,
					k,
					r,
					q,
					tf,
					d1,
					d2,
					1.0,
				)),
				Put: new(vanillaoptionpricer.EuropeanBlackScholesPrice(
					spot,
					k,
					r,
					q,
					tf,
					d1,
					d2,
					-1.0,
				)),
			}
		}

		err = irCurve.BuildInterpolator()
		require.NoError(t, err)

		gotSurface, err := ComputeRawVolatilitySurface(
			OptionChainDescription{
				OptionChain: OptionChain{
					Tenor(tf):     chain,
					Tenor(2 * tf): chain,
				},
				ExerciseType: marketdata.European,
			},
			spot,
			irCurve,
			divCurve,
		)
		require.NoError(t, err)

		gotSlice, ok := gotSurface.Slices[Tenor(tf)]
		require.True(t, ok)
		require.Len(t, gotSlice.data, len(chain))

		for strike, gotDataPoint := range gotSlice.data {
			k := float64(strike)

			require.GreaterOrEqual(t, k, gotSlice.forward)

			d1, d2 := vanillaoptionpricer.DPlusMinus(
				spot,
				k,
				vol,
				tf,
				tf,
				r,
				q,
			)

			expectedCallPrice := vanillaoptionpricer.EuropeanBlackScholesPrice(
				spot,
				k,
				r,
				q,
				tf,
				d1,
				d2,
				1.0,
			)

			require.InDelta(t, vol, gotDataPoint.iv, tol)
			require.InDelta(t, vol*vol*tf, gotDataPoint.totalVariance, tol)
			require.InDelta(t, expectedCallPrice, gotDataPoint.europeanCallOptionPrice, tol)
		}
	})
}

func assertVolatilitySurfaceTotalVariance(t *testing.T, expectedSurface *VolatilitySurface, gotSurface VolatilitySurface, tol float64) {
	t.Helper()

	require.Len(t, gotSurface.Slices, len(expectedSurface.Slices))

	for tenor, expectedSlice := range expectedSurface.Slices {
		gotSlice, ok := gotSurface.Slices[tenor]
		require.True(t, ok)
		require.Len(t, gotSlice.data, len(expectedSlice.data))

		for strike, expectedDataPoint := range expectedSlice.data {
			gotDataPoint, ok := gotSlice.data[strike]
			require.True(t, ok)
			require.InDelta(t, expectedDataPoint.totalVariance, gotDataPoint.totalVariance, tol)
		}
	}
}
