package surfacecalibration

import (
	"math"
	"math/cmplx"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// This file computes the semi-analyticalprice of a European call option under the Heston stochastic volatility model.
//
// The original semi-closed-form pricing formula is due to Heston (1993)
// "A Closed-Form Solution for Options with Stochastic Volatility with Applications to Bond and Currency Options".
//
// This implementation follows an equivalent Fourier inversion formulation and numerically stable characteristic
// function representation as described in Cui, Y., del Baño Rollin, S., Germano, G. (2015)
// "Full and fast calibration of the Heston stochastic volatility model"

// hestonCallPrice computes the European call option price under the Heston stochastic volatility model.
// It uses the standard semi-closed-form formula, where P1 and P2 are Heston pseudo-probabilities.
func hestonCallPrice(s, k, t, r, q float64, p marketdata.HestonParameters, lag laguerre) (float64, error) {
	const tol = 1e-8

	P1, P2, err := hestonProbabilities(s, k, t, r, q, p, lag)
	if err != nil {
		return 0, errors.Bug("could not compute hestonProbabilities: %w", err)
	}

	var (
		spotDF   = s * math.Exp(-q*t)
		strikeDF = k * math.Exp(-r*t)
		price    = spotDF*P1 - strikeDF*P2
		lower    = math.Max(0.0, spotDF-strikeDF)
	)

	if price < lower-tol || price > spotDF+tol {
		return 0, errors.Bug("heston price violates arbitrage bounds")
	}

	return price, nil
}

// hestonProbabilities computes the risk-neutral probabilities P1 and P2 used in the Heston pricing formula.
// These are obtained via numerical integration of the characteristic function of log(S_T).
// The integral is evaluated using Gauss-Laguerre quadrature over [0, ∞).
// The exp(u) term compensates for the Laguerre weight e^{-u}.
// P1 uses the shifted characteristic function phi(u - i), corresponding to a change of numeraire to the forward measure.
// P2 uses the standard characteristic function phi(u) under the risk-neutral measure.
func hestonProbabilities(s, k, t, r, q float64, p marketdata.HestonParameters, lag laguerre) (float64, float64, error) {
	var (
		lnK      = math.Log(k)
		fwdAsset = s * math.Exp((r-q)*t)

		acc1 float64
		acc2 float64
	)

	for i := range lag.nodes {
		var (
			uReal = lag.nodes[i]

			u     = complex(uReal, 0)
			iu    = complex(0, uReal)
			eTerm = cmplx.Exp(complex(0, -uReal*lnK))
		)

		scaledWeight := lag.weights[i] * math.Exp(uReal)
		if !finite(scaledWeight) {
			return 0, 0, errors.Bug("invalid scaled laguerre weight")
		}

		h1, err := hestonCFLogS(u, s, t, r, q, p)
		if err != nil {
			return 0, 0, errors.Bug("could not compute hestonCFLogS for h1: %w", err)
		}

		acc2 += scaledWeight * real(eTerm*h1/iu)

		h2, err := hestonCFLogS(u-complex(0, 1), s, t, r, q, p)
		if err != nil {
			return 0, 0, errors.Bug("could not compute hestonCFLogS for h2: %w", err)
		}

		acc1 += scaledWeight * real(eTerm*h2/(iu*complex(fwdAsset, 0)))
	}

	return 0.5 + acc1/math.Pi, 0.5 + acc2/math.Pi, nil
}

// hestonCFLogS computes the characteristic function φ(u) = E[e^{iu log S_T}] under the Heston model.
// The implementation uses the "little Heston trap" formulation for numerical stability.
// Output is a complex number used in Fourier inversion for option pricing.
//
//nolint:cyclop
func hestonCFLogS(u complex128, s, t, r, q float64, p marketdata.HestonParameters) (complex128, error) {
	const eps = 1e-14

	var (
		kappa = p.Kappa
		sigma = p.Sigma
		rho   = p.Rho

		b      = kappa
		iu     = complex(0, 1) * u
		sigma2 = sigma * sigma
	)

	if sigma2 <= eps || !finite(sigma2) {
		return 0, errors.Bug("invalid sigma2")
	}

	z := complex(rho*sigma, 0)*iu - complex(b, 0)

	d := cmplx.Sqrt(z*z + complex(sigma2, 0)*(iu+u*u))
	if !complexFinite(d) {
		return 0, errors.Bug("invalid d")
	}

	// Enforce Re(d) >= 0 to avoid branch switching in the complex square root.
	// This follows the stability principles behind the "little Heston trap".
	if real(d) < 0 {
		d = -d
	}

	var (
		gp = complex(b, 0) - complex(rho*sigma, 0)*iu + d
		gm = complex(b, 0) - complex(rho*sigma, 0)*iu - d
	)

	if !complexFinite(gp) || cmplx.Abs(gp) < eps {
		return 0, errors.Bug("invalid gp")
	}

	g := gm / gp
	if !complexFinite(g) {
		return 0, errors.Bug("invalid g")
	}

	expNegDT := cmplx.Exp(-d * complex(t, 0))
	if !complexFinite(expNegDT) {
		return 0, errors.Bug("invalid expNegDT")
	}

	oneMinusGExp := 1 - g*expNegDT
	if !complexFinite(oneMinusGExp) || cmplx.Abs(oneMinusGExp) < eps {
		return 0, errors.Bug("invalid oneMinusGExp")
	}

	denom := 1 - g
	if !complexFinite(denom) || cmplx.Abs(denom) < eps {
		return 0, errors.Bug("invalid 1-g")
	}

	logTerm := cmplx.Log(oneMinusGExp / denom)
	if !complexFinite(logTerm) {
		return 0, errors.Bug("invalid logTerm")
	}

	C := iu*complex((r-q)*t, 0) +
		complex(kappa*p.Theta/sigma2, 0)*(gm*complex(t, 0)-2*logTerm)

	if !complexFinite(C) {
		return 0, errors.Bug("invalid C")
	}

	D := (gm / complex(sigma2, 0)) * ((1 - expNegDT) / oneMinusGExp)
	if !complexFinite(D) {
		return 0, errors.Bug("invalid D")
	}

	logS := math.Log(s)
	if !finite(logS) {
		return 0, errors.Bug("invalid log(s)")
	}

	exponent := iu*complex(logS, 0) + C + D*complex(p.V0, 0)
	if !complexFinite(exponent) || real(exponent) > math.Log(math.MaxFloat64)-1 {
		return 0, errors.Bug("invalid exponent")
	}

	cf := cmplx.Exp(exponent)
	if !complexFinite(cf) {
		return 0, errors.Bug("invalid cf")
	}

	return cf, nil
}

func finite(x float64) bool {
	return !math.IsNaN(x) && !math.IsInf(x, 0)
}

func complexFinite(z complex128) bool {
	return finite(real(z)) && finite(imag(z))
}
