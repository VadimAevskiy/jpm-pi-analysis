package surfacecalibration

import (
	"math"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// hestonLBFGSBObjective implements the optimize.Problem interface for the Heston calibration problem,
// allowing the use of the L-BFGS-B optimization algorithm with box constraints.
type hestonLBFGSBObjective struct {
	f func([]float64) float64
}

// evaluateFunction evaluates the objective function at the given point x in the packed parameter space.
func (o hestonLBFGSBObjective) evaluateFunction(x []float64) float64 {
	return o.f(x)
}

// evaluateGradient computes the gradient of the objective function at the given point x in the packed parameter space.
func (o hestonLBFGSBObjective) evaluateGradient(x []float64) []float64 {
	return finiteDifferenceGradientValue(o.f, x)
}

// finiteDifferenceGradientValue computes the gradient of the objective function
// using central finite differences in the packed parameter space.
//
// This is a simple and robust approximation that avoids the need for deriving
// analytic gradients, but it is computationally expensive (requiring 2N function
// evaluations per gradient) and introduces numerical noise.
//
// For the Heston model, a much more efficient approach is to use the analytic gradient derived in:
// Cui, Y., del Baño Rollin, S., Germano, G. (2015)
// "Full and fast calibration of the Heston stochastic volatility model".
//
// Note that if an analytic gradient is implemented in terms of the original (unpacked)
// Heston parameters, the chain rule must be applied to convert derivatives
// into the packed parameter space used by the optimizer.
func finiteDifferenceGradientValue(f func([]float64) float64, x []float64) []float64 {
	const eps = 1e-5

	grad := make([]float64, len(x))
	xp := make([]float64, len(x))
	xm := make([]float64, len(x))

	copy(xp, x)
	copy(xm, x)

	for i := range x {
		step := eps * math.Max(1.0, math.Abs(x[i]))

		xp[i] = x[i] + step
		xm[i] = x[i] - step

		fp := f(xp)
		fm := f(xm)

		grad[i] = (fp - fm) / (2.0 * step)

		xp[i] = x[i]
		xm[i] = x[i]
	}

	return grad
}

// Heston parameters need to be scaled before the optimization so that the gradient does not explode.
// The initial guess is bounded to fit within the optimizer box constraints.
// The optimizer then runs in the scaled parameter space.
const (
	kMin = 0.1
	kMax = 10.0

	thetaMin = 1e-4
	thetaMax = 0.5

	sigmaMin = 0.05
	sigmaMax = 4.0

	rhoMin = -0.95
	rhoMax = 0.95

	v0Min = 1e-4
	v0Max = 0.5
)

var DefaultHestonInitialParams = marketdata.HestonParameters{
	V0:    0.04,
	Kappa: 1.0,
	Theta: 0.04,
	Rho:   -0.5,
	Sigma: 0.5,
}

type parameterBound struct {
	Lower float64
	Upper float64
}

var hestonBounds = []parameterBound{
	{Lower: 0.0, Upper: 1.0},
	{Lower: 0.0, Upper: 1.0},
	{Lower: 0.0, Upper: 1.0},
	{Lower: 0.0, Upper: 1.0},
	{Lower: 0.0, Upper: 1.0},
}

func toLBFGSBBounds(bounds []parameterBound) [][2]float64 {
	out := make([][2]float64, len(bounds))

	for i, b := range bounds {
		out[i] = [2]float64{b.Lower, b.Upper}
	}

	return out
}

func scaleToUnit(x, lo, hi float64) (float64, error) {
	if hi <= lo {
		return 0.0, errors.Bug("invalid scaling bounds")
	}

	return (x - lo) / (hi - lo), nil
}

func unscaleFromUnit(y, lo, hi float64) float64 {
	return lo + y*(hi-lo)
}

func packHestonParameters(p marketdata.HestonParameters) ([]float64, error) {
	kappa, err := scaleToUnit(p.Kappa, kMin, kMax)
	if err != nil {
		return nil, errors.Bug("could not scale kappa: %w", err)
	}

	theta, err := scaleToUnit(p.Theta, thetaMin, thetaMax)
	if err != nil {
		return nil, errors.Bug("could not scale theta: %w", err)
	}

	sigma, err := scaleToUnit(p.Sigma, sigmaMin, sigmaMax)
	if err != nil {
		return nil, errors.Bug("could not scale sigma: %w", err)
	}

	rho, err := scaleToUnit(p.Rho, rhoMin, rhoMax)
	if err != nil {
		return nil, errors.Bug("could not scale rho: %w", err)
	}

	v0, err := scaleToUnit(p.V0, v0Min, v0Max)
	if err != nil {
		return nil, errors.Bug("could not scale v0: %w", err)
	}

	return []float64{kappa, theta, sigma, rho, v0}, nil
}

func unpackHestonParameters(x []float64) (marketdata.HestonParameters, error) {
	if len(x) != 5 {
		return marketdata.HestonParameters{}, errors.Bug("expected 5 Heston parameters, got %d", len(x))
	}

	return marketdata.HestonParameters{
		Kappa: unscaleFromUnit(x[0], kMin, kMax),
		Theta: unscaleFromUnit(x[1], thetaMin, thetaMax),
		Sigma: unscaleFromUnit(x[2], sigmaMin, sigmaMax),
		Rho:   unscaleFromUnit(x[3], rhoMin, rhoMax),
		V0:    unscaleFromUnit(x[4], v0Min, v0Max),
	}, nil
}
