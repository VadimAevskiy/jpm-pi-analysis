package surfacecalibration

import (
	"fmt"
	"math"
	"sort"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	log "github.com/sirupsen/logrus"
)

const (
	rootSearchTol      = 1e-8
	upperBoundIV       = 5.0
	lowerBoundIV       = 1e-12
	numATMstrikesToUse = 3
)

type strikeDiff struct {
	strike Strike
	diff   float64
}

// findNnearestATMforwardStrikes returns the n strikes with the smallest absolute put-call price differences (i.e. nearest to at-the-money forward).
// Only strikes with both call and put prices available are considered. Returns nil if no valid strikes exist.
func findNnearestATMforwardStrikes(s SurfaceSlice, n int) []Strike {
	candidates := make([]strikeDiff, 0, len(s))

	for k, pair := range s {
		call, err := pair.Price(vanillaoptionpricer.Call)
		if err != nil {
			log.Warnf("could not get call price for strike %f: %v", k, err)
			continue
		}

		put, err := pair.Price(vanillaoptionpricer.Put)
		if err != nil {
			log.Warnf("could not get put price for strike %f: %v", k, err)
			continue
		}

		diff := math.Abs(call - put)
		candidates = append(candidates, strikeDiff{strike: k, diff: diff})
	}

	if len(candidates) == 0 {
		return nil
	}

	sort.Slice(candidates, func(i, j int) bool {
		return candidates[i].diff < candidates[j].diff
	})

	if n > len(candidates) {
		log.Warnf("requested %d ATM strikes but only %d valid strikes available, returning all valid strikes", n, len(candidates))
		n = len(candidates)
	}

	result := make([]Strike, n)
	for i := range n {
		result[i] = candidates[i].strike
	}

	return result
}

// ComputeDividendCurveFromOptionChain computes the dividend term structure from the option chain using the de-Americanized put-call parity for each tenor.
// If no valid pairs are found for a given tenor or if the dividend computation fails, the slice is skipped.
func ComputeDividendCurveFromOptionChain(
	chainDesc OptionChainDescription,
	spot float64,
	irCurve termstructure.TermStructure,
) (marketdata.DividendYieldCurve, error) {
	dividends := make([]marketdata.DividendPoint, 0, len(chainDesc.OptionChain))

	for t, slice := range chainDesc.OptionChain {
		var (
			tf         = float64(t)
			r          = irCurve.Value(tf)
			divAtSlice float64
			validPairs int
		)

		atmStrikes := findNnearestATMforwardStrikes(slice, numATMstrikesToUse)

		for _, k := range atmStrikes {
			var (
				kf         = float64(k)
				optionPair = slice[k]
				dividend   float64
			)

			dividend, err := computeDividendFromPair(chainDesc.ExerciseType, optionPair, spot, kf, tf, r)
			if err != nil {
				log.Warnf("could not compute dividend for strike %f and tenor %f: %v", kf, tf, err)
				continue
			}

			divAtSlice += dividend
			validPairs++
		}

		if validPairs == 0 {
			log.Warnf("could not compute dividend for slice with tenor %f, skipping slice", tf)
			continue
		}

		dividends = append(dividends, marketdata.DividendPoint{DividendZeroRate: divAtSlice / float64(validPairs), YearFraction: tf})
	}

	if len(dividends) == 0 {
		return marketdata.DividendYieldCurve{}, errors.Bug("could not compute any dividend points from option chain")
	}

	sort.Slice(dividends, func(i, j int) bool {
		return dividends[i].YearFraction < dividends[j].YearFraction
	})

	return marketdata.DividendYieldCurve{Dividends: dividends}, nil
}

// computeDividendFromPair computes the dividend yield from an option pair, depending on exercise style.
// For American exercise style, we use the European dividend as a first guess, or try with a default guess if the European dividend computation fails.
func computeDividendFromPair(exerciseType marketdata.ExerciseType, optionPair OptionPair, spot, kf, tf, r float64) (float64, error) {
	const defaultDividendGuess = 0.01

	qEuropean, err := computeEuropeanDividendYield(optionPair, spot, kf, tf, r)

	switch exerciseType {
	case marketdata.European:
		if err != nil {
			return 0.0, fmt.Errorf("could not compute European dividend yield: %w", err)
		}

		return qEuropean, nil
	case marketdata.American:
		firstGuess := qEuropean

		if err != nil {
			log.Warnf("could not compute European dividend first guess for American option, trying with default guess of %f: %v", defaultDividendGuess, err)
			firstGuess = defaultDividendGuess
		}

		americanDiv, err := computeAmericanDividendYield(optionPair, spot, kf, tf, r, firstGuess)
		if err != nil {
			return 0.0, fmt.Errorf("could not compute American dividend yield: %w", err)
		}

		return americanDiv, nil
	default:
		return 0.0, errors.Bug("unsupported exercise type: %s", exerciseType)
	}
}

// computeEuropeanDividendYield computes the dividend yield of a European option using the put-call parity formula.
func computeEuropeanDividendYield(optionPair OptionPair, spot, strike, tenor, r float64) (float64, error) {
	DF := math.Exp(-r * tenor)

	call, err := optionPair.Price(vanillaoptionpricer.Call)
	if err != nil {
		return 0.0, fmt.Errorf("could not get call price for dividend yield calculation: %w", err)
	}

	put, err := optionPair.Price(vanillaoptionpricer.Put)
	if err != nil {
		return 0.0, fmt.Errorf("could not get put price for dividend yield calculation: %w", err)
	}

	F := (call-put)/DF + strike

	if F <= 0.0 {
		return 0.0, errors.Bug("invalid negative forward price for dividend yield calculation: F=%f", F)
	}

	return r - (1.0/tenor)*math.Log(F/spot), nil
}

func hasTooLittleTimeValue(call, put, spot, strike float64) bool {
	const minTimeValuePct = 0.01

	var (
		intrinsicValue = spot - strike
		itmOptionPrice = call
	)

	if intrinsicValue < 0 {
		intrinsicValue = -intrinsicValue
		itmOptionPrice = put
	}

	return itmOptionPrice-intrinsicValue < minTimeValuePct*intrinsicValue
}

// computeAmericanDividendYield computes the dividend yield of an American option using an iterative method based on the de-Americanized put-call parity.
// The first guess is the European Dividend Yield.
func computeAmericanDividendYield(americanPair OptionPair, spot, strike, tenor, r, qEuropean float64) (float64, error) {
	const (
		maxAbsCallMinusPutPct = 0.1
		maxIterations         = 20
		tolerance             = 1e-8
	)

	call, err := americanPair.Price(vanillaoptionpricer.Call)
	if err != nil {
		return 0.0, fmt.Errorf("could not get call price for dividend yield calculation: %w", err)
	}

	put, err := americanPair.Price(vanillaoptionpricer.Put)
	if err != nil {
		return 0.0, fmt.Errorf("could not get put price for dividend yield calculation: %w", err)
	}

	// avoid optimal early exercise cases that have zero vega
	if hasTooLittleTimeValue(call, put, spot, strike) {
		return 0.0, errors.Bug("price of ITM option is too close to intrinsic value for a reliable dividend yield extraction")
	}

	// we use |call - put| as a proxy for forward moneyness (put-call parity implies |call-put| = |F-K|*DF). We impose a max forward moneyness to avoid vega being too small.
	if math.Abs(call-put) > maxAbsCallMinusPutPct*spot {
		return 0.0, errors.Bug("option pair is too far from ATM for a reliable dividend yield extraction")
	}

	q := qEuropean

	for range maxIterations {
		qPrev := q

		ivCall, err := computeAmericanIV(vanillaoptionpricer.Call, americanPair, spot, strike, tenor, r, qPrev)
		if err != nil {
			return 0.0, fmt.Errorf("could not compute implied volatility for dividend yield calculation: %w", err)
		}

		ivPut, err := computeAmericanIV(vanillaoptionpricer.Put, americanPair, spot, strike, tenor, r, qPrev)
		if err != nil {
			return 0.0, fmt.Errorf("could not compute implied volatility for dividend yield calculation: %w", err)
		}

		d1Call, d2Call := vanillaoptionpricer.DPlusMinus(spot, strike, ivCall, tenor, tenor, r, qPrev)
		d1Put, d2Put := vanillaoptionpricer.DPlusMinus(spot, strike, ivPut, tenor, tenor, r, qPrev)

		europeanPair := OptionPair{
			Call: new(vanillaoptionpricer.EuropeanBlackScholesPrice(spot, strike, r, qPrev, tenor, d1Call, d2Call, 1)),
			Put:  new(vanillaoptionpricer.EuropeanBlackScholesPrice(spot, strike, r, qPrev, tenor, d1Put, d2Put, -1)),
		}

		q, err = computeEuropeanDividendYield(europeanPair, spot, strike, tenor, r)
		if err != nil {
			return 0.0, fmt.Errorf("could not compute in-loop European dividend yield: %w", err)
		}

		if math.Abs(q-qPrev) < tolerance {
			return q, nil
		}
	}

	return q, nil
}
