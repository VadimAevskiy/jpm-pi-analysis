package surfacecalibration

import (
	"fmt"
	"math"
	"slices"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	log "github.com/sirupsen/logrus"
	"gonum.org/v1/exp/root"
)

// computeEuropeanIV computes the implied volatility of a European option given its market price, solving BS(sigma) = market_price where BS is the Black-Scholes formula.
func computeEuropeanIV(callPut vanillaoptionpricer.OptionType, americanPair OptionPair, spot, strike, tenor, r, q float64) (float64, error) {
	optionPrice, err := americanPair.Price(callPut)
	if err != nil {
		return 0.0, fmt.Errorf("could not get option price from option pair: %w", err)
	}

	var (
		phi = 1.0

		f = func(vol float64) float64 {
			d1, d2 := vanillaoptionpricer.DPlusMinus(spot, strike, vol, tenor, tenor, r, q)
			return vanillaoptionpricer.EuropeanBlackScholesPrice(spot, strike, r, q, tenor, d1, d2, phi) - optionPrice
		}
	)

	if callPut == vanillaoptionpricer.Put {
		phi = -1.0
	}

	if f(lowerBoundIV) > 0.0 {
		log.Warnf("European implied volatility was floored to %f", lowerBoundIV)

		return lowerBoundIV, nil
	}

	if f(upperBoundIV) < 0.0 {
		log.Warnf("European implied volatility was capped to %f", upperBoundIV)

		return upperBoundIV, nil
	}

	return root.Brent(f, lowerBoundIV, upperBoundIV, rootSearchTol)
}

// computeAmericanIV computes the implied volatility of an American option given its market price, solving QD(sigma) = market_price where QD is the QD vanilla American option pricer.
func computeAmericanIV(callPut vanillaoptionpricer.OptionType, americanPair OptionPair, spot, strike, tenor, r, q float64) (float64, error) {
	optionPrice, err := americanPair.Price(callPut)
	if err != nil {
		return 0.0, fmt.Errorf("could not get option price from option pair: %w", err)
	}

	var pricingErr error

	f := func(vol float64) float64 {
		params := &vanillaoptionpricer.QdPricerParameters{
			Spot:       spot,
			Strike:     strike,
			YfMaturity: tenor,
			IR:         r,
			Div:        q,
			Vol:        vol,
			CallPut:    callPut,
		}

		americanPrice, err := vanillaoptionpricer.PriceQD(params)
		if err != nil {
			pricingErr = err

			return 0.0
		}

		return americanPrice - optionPrice
	}

	fLower, fUpper := f(lowerBoundIV), f(upperBoundIV)

	if pricingErr != nil {
		return 0.0, fmt.Errorf("could not price American option at IV bounds: %w", pricingErr)
	}

	if fLower > 0.0 {
		log.Warnf("American implied volatility was floored to %f", lowerBoundIV)

		return lowerBoundIV, nil
	}

	if fUpper < 0.0 {
		log.Warnf("American implied volatility was capped to %f", upperBoundIV)

		return upperBoundIV, nil
	}

	iv, err := root.Brent(f, lowerBoundIV, upperBoundIV, rootSearchTol)

	if pricingErr != nil {
		return 0.0, fmt.Errorf("could not price American option during root search: %w", pricingErr)
	}

	return iv, err
}

// computeIV computes the implied volatility of an option given depending on its exercise style.
func computeIV(exerciseType marketdata.ExerciseType, callPut vanillaoptionpricer.OptionType, optionPair OptionPair, spot, strike, tenor, r, q float64) (float64, error) {
	switch exerciseType {
	case marketdata.American:
		return computeAmericanIV(callPut, optionPair, spot, strike, tenor, r, q)
	case marketdata.European:
		return computeEuropeanIV(callPut, optionPair, spot, strike, tenor, r, q)
	default:
		return 0.0, errors.Bug("unsupported exercise type: %s", exerciseType)
	}
}

// ComputeRawVolatilitySurface computes the implied volatility for each tenor and strike in the option chain
// and returns a volatility surface.
func ComputeRawVolatilitySurface(chainDesc OptionChainDescription, spot float64, irCurve termstructure.TermStructure, dividendCurve marketdata.DividendYieldCurve) (VolatilitySurface, error) {
	const minNumSlices = 2

	if len(chainDesc.OptionChain) < minNumSlices {
		return VolatilitySurface{}, errors.Bug("need at least %d tenors in the option chain to compute a volatility surface, got %d", minNumSlices, len(chainDesc.OptionChain))
	}

	resultSlices := make(map[Tenor]volatilitySurfaceSlice, len(chainDesc.OptionChain))
	resultTenors := make([]Tenor, 0, len(chainDesc.OptionChain))

	divInterp, err := marketdata.NewZeroDividendInterpolator(dividendCurve)
	if err != nil {
		return VolatilitySurface{}, fmt.Errorf("could not create dividend interpolator: %w", err)
	}

	for t, slice := range chainDesc.OptionChain {
		const minSliceSize = 4

		tf := float64(t)

		if len(slice) < minSliceSize {
			log.Warnf("skipping slice for tenor %f: only %d strikes in the option chain at this tenor, need at least %d", tf, len(slice), minSliceSize)

			continue
		}

		var (
			q   = divInterp.Value(tf)
			r   = irCurve.Value(tf)
			fwd = spot * math.Exp((r-q)*tf)
		)

		sliceData, smallVegaCount, ivErrCount := buildSliceData(slice, chainDesc.ExerciseType, tf, r, q, spot, fwd)

		if smallVegaCount > 0 || ivErrCount > 0 {
			log.Warnf("%d vega lower than threshold errors and %d IV computation errors at tenor %f", smallVegaCount, ivErrCount, tf)
		}

		if len(sliceData) < minSliceSize {
			log.Warnf("skipping slice for tenor %f: only %d valid data points out of %d, need at least %d", tf, len(sliceData), len(slice), minSliceSize)

			continue
		}

		resultTenors = append(resultTenors, t)
		resultSlices[t] = volatilitySurfaceSlice{
			data:    sliceData,
			tenor:   tf,
			forward: fwd,
			spot:    spot,
			r:       r,
			q:       q,
		}
	}

	if len(resultTenors) < minNumSlices {
		return VolatilitySurface{}, errors.Bug("need at least %d valid slices but got %d: check log for error count", minNumSlices, len(resultTenors))
	}

	slices.Sort(resultTenors)

	return VolatilitySurface{
		Slices:       resultSlices,
		SortedTenors: resultTenors,
	}, nil
}

// buildSliceData computes the volatility data points for each strike in the slice from the option chain, counting the number of small vega or IV computation errors.
func buildSliceData(slice SurfaceSlice, exType marketdata.ExerciseType, tf, r, q, spot, fwd float64) (map[Strike]volatilityDataPoint, int, int) {
	var (
		sliceData      = make(map[Strike]volatilityDataPoint, len(slice))
		smallVegaCount int
		ivErrCount     int
	)

	for k, optionPair := range slice {
		const minStandardVega = 1e-3

		var (
			kf      = float64(k)
			callPut vanillaoptionpricer.OptionType
			kappa   = math.Log(kf / fwd)
		)

		// We only use OTM options because (deep) ITM options have vegas close to zero, which can lead to instability in the root-fiding algorithm.
		switch kappa >= 0.0 {
		case true:
			callPut = vanillaoptionpricer.Call
		default:
			callPut = vanillaoptionpricer.Put
		}

		iv, err := computeIV(exType, callPut, optionPair, spot, kf, tf, r, q)
		if err != nil {
			ivErrCount++
			continue
		}

		d1, d2 := vanillaoptionpricer.DPlusMinus(spot, kf, iv, tf, tf, r, q)

		vega := vanillaoptionpricer.EuropeanBlackScholesVega(spot, q, tf, d1)

		if vega < minStandardVega*spot*math.Exp(-q*tf)*math.Sqrt(tf) {
			smallVegaCount++
			continue
		}

		sliceData[k] = volatilityDataPoint{
			iv:                      iv,
			totalVariance:           iv * iv * tf,
			strike:                  kf,
			kappa:                   kappa,
			vega:                    vega,
			europeanCallOptionPrice: vanillaoptionpricer.EuropeanBlackScholesPrice(spot, kf, r, q, tf, d1, d2, 1),
		}
	}

	return sliceData, smallVegaCount, ivErrCount
}
