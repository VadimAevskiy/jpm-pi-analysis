package surfacecalibration

import (
	"math"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	log "github.com/sirupsen/logrus"
)

// populateKappaAndVegaValues is a helper function to create the test surfaces with kappa values populated.
func populateKappaAndVegaValues(surface VolatilitySurface, spot float64, irCurve termstructure.TermStructure, divCurve marketdata.DividendYieldCurve) VolatilitySurface {
	result := VolatilitySurface{
		Slices:       make(map[Tenor]volatilitySurfaceSlice),
		SortedTenors: surface.SortedTenors,
	}

	divInterp, err := marketdata.NewZeroDividendInterpolator(divCurve)
	if err != nil {
		log.Warnf("could not create dividend interpolator: %v", err)
		return result
	}

	_ = irCurve.BuildInterpolator()

	for t, slice := range surface.Slices {
		var (
			tf = float64(t)
			r  = irCurve.Value(tf)
			q  = divInterp.Value(tf)
		)

		forward := spot * math.Exp((r-q)*tf)

		data := make(map[Strike]volatilityDataPoint)
		for Strike, dp := range slice.data {
			iv := math.Sqrt(dp.totalVariance / tf)
			d1 := vanillaoptionpricer.DPlus(spot, float64(Strike), iv, tf, tf, r, q)

			data[Strike] = volatilityDataPoint{
				iv:            iv,
				totalVariance: dp.totalVariance,
				strike:        dp.strike,
				kappa:         math.Log(float64(Strike) / forward),
				vega:          vanillaoptionpricer.EuropeanBlackScholesVega(spot, q, tf, d1),
			}
		}

		result.Slices[t] = volatilitySurfaceSlice{
			data:    data,
			tenor:   slice.tenor,
			forward: slice.forward,
		}
	}

	return result
}

// Test data gathered and generated in an independent POC from Paul-Emile Chapuy (in dentist)

// data for 2021-06-21

var nasdaq21optionChain = OptionChain{
	0.4904109589: SurfaceSlice{
		10000.0: OptionPair{Call: new(4213.75), Put: new(97.75)},
		10100.0: OptionPair{Call: new(4118.75), Put: new(102.75)},
		10200.0: OptionPair{Call: new(4024.00), Put: new(108.25)},
		10300.0: OptionPair{Call: new(3929.75), Put: new(113.75)},
		10400.0: OptionPair{Call: new(3835.75), Put: new(119.75)},
		10500.0: OptionPair{Call: new(3742.00), Put: new(126.00)},
		10600.0: OptionPair{Call: new(3648.50), Put: new(132.50)},
		10700.0: OptionPair{Call: new(3555.25), Put: new(139.25)},
		10800.0: OptionPair{Call: new(3462.50), Put: new(146.50)},
		10900.0: OptionPair{Call: new(3370.25), Put: new(154.25)},
		11000.0: OptionPair{Call: new(3278.25), Put: new(162.25)},
		11100.0: OptionPair{Call: new(3186.75), Put: new(170.75)},
		11200.0: OptionPair{Call: new(3095.75), Put: new(179.75)},
		11300.0: OptionPair{Call: new(3005.25), Put: new(189.00)},
		11400.0: OptionPair{Call: new(2915.25), Put: new(199.00)},
		11500.0: OptionPair{Call: new(2825.75), Put: new(209.50)},
		11600.0: OptionPair{Call: new(2736.75), Put: new(220.50)},
		11700.0: OptionPair{Call: new(2648.50), Put: new(232.25)},
		11800.0: OptionPair{Call: new(2561.00), Put: new(244.75)},
		11900.0: OptionPair{Call: new(2474.00), Put: new(257.75)},
		12000.0: OptionPair{Call: new(2388.00), Put: new(271.75)},
		12100.0: OptionPair{Call: new(2302.50), Put: new(286.25)},
		12200.0: OptionPair{Call: new(2218.00), Put: new(301.75)},
		12300.0: OptionPair{Call: new(2134.50), Put: new(318.00)},
		12400.0: OptionPair{Call: new(2051.75), Put: new(335.25)},
		12500.0: OptionPair{Call: new(1969.75), Put: new(353.50)},
		12600.0: OptionPair{Call: new(1889.00), Put: new(372.50)},
		12700.0: OptionPair{Call: new(1809.00), Put: new(392.75)},
		12800.0: OptionPair{Call: new(1730.25), Put: new(413.75)},
		12900.0: OptionPair{Call: new(1652.50), Put: new(436.00)},
		13000.0: OptionPair{Call: new(1576.00), Put: new(459.50)},
		13100.0: OptionPair{Call: new(1500.75), Put: new(484.25)},
		13200.0: OptionPair{Call: new(1426.75), Put: new(510.00)},
		13300.0: OptionPair{Call: new(1354.00), Put: new(537.25)},
		13400.0: OptionPair{Call: new(1282.50), Put: new(566.00)},
		13500.0: OptionPair{Call: new(1212.75), Put: new(596.00)},
		13600.0: OptionPair{Call: new(1144.25), Put: new(627.50)},
		13700.0: OptionPair{Call: new(1077.50), Put: new(660.75)},
		13800.0: OptionPair{Call: new(1012.25), Put: new(695.50)},
		13900.0: OptionPair{Call: new(948.75), Put: new(732.00)},
		14000.0: OptionPair{Call: new(887.25), Put: new(770.50)},
		14100.0: OptionPair{Call: new(827.50), Put: new(810.75)},
		14200.0: OptionPair{Call: new(769.75), Put: new(853.00)},
		14300.0: OptionPair{Call: new(714.25), Put: new(897.50)},
		14400.0: OptionPair{Call: new(661.25), Put: new(944.50)},
		14500.0: OptionPair{Call: new(610.50), Put: new(993.50)},
		14600.0: OptionPair{Call: new(562.00), Put: new(1045.00)},
		14700.0: OptionPair{Call: new(516.00), Put: new(1099.00)},
		14800.0: OptionPair{Call: new(472.25), Put: new(1155.50)},
		14900.0: OptionPair{Call: new(431.25), Put: new(1214.25)},
		15000.0: OptionPair{Call: new(392.50), Put: new(1275.50)},
		15100.0: OptionPair{Call: new(356.25), Put: new(1339.25)},
		15200.0: OptionPair{Call: new(322.50), Put: new(1405.50)},
		15300.0: OptionPair{Call: new(291.25), Put: new(1474.00)},
		15500.0: OptionPair{Call: new(235.75), Put: new(1618.50)},
		15600.0: OptionPair{Call: new(211.50), Put: new(1694.25)},
		15700.0: OptionPair{Call: new(189.50), Put: new(1772.25)},
		15800.0: OptionPair{Call: new(169.50), Put: new(1852.50)},
		15900.0: OptionPair{Call: new(151.75), Put: new(1934.50)},
		16000.0: OptionPair{Call: new(135.75), Put: new(2018.75)},
		16100.0: OptionPair{Call: new(121.75), Put: new(2104.50)},
		16200.0: OptionPair{Call: new(109.00), Put: new(2191.75)},
		16300.0: OptionPair{Call: new(98.00), Put: new(2280.75)},
		16400.0: OptionPair{Call: new(88.00), Put: new(2370.75)},
		16500.0: OptionPair{Call: new(79.25), Put: new(2462.00)},
		16600.0: OptionPair{Call: new(71.25), Put: new(2554.00)},
		16700.0: OptionPair{Call: new(64.50), Put: new(2647.00)},
		16800.0: OptionPair{Call: new(58.25), Put: new(2741.00)},
		16900.0: OptionPair{Call: new(52.75), Put: new(2835.50)},
		17000.0: OptionPair{Call: new(48.00), Put: new(2930.50)},
		17100.0: OptionPair{Call: new(43.50), Put: new(3026.00)},
		17200.0: OptionPair{Call: new(39.50), Put: new(3122.25)},
		17300.0: OptionPair{Call: new(36.00), Put: new(3218.75)},
		17400.0: OptionPair{Call: new(33.00), Put: new(3315.50)},
		17500.0: OptionPair{Call: new(30.00), Put: new(3412.50)},
		17600.0: OptionPair{Call: new(27.50), Put: new(3510.00)},
		17700.0: OptionPair{Call: new(25.25), Put: new(3607.75)},
		17800.0: OptionPair{Call: new(23.00), Put: new(3705.50)},
		17900.0: OptionPair{Call: new(21.25), Put: new(3803.50)},
		18000.0: OptionPair{Call: new(19.50), Put: new(3901.75)},
		18100.0: OptionPair{Call: new(17.75), Put: new(4000.25)},
		18200.0: OptionPair{Call: new(16.25), Put: new(4098.75)},
		18300.0: OptionPair{Call: new(15.00), Put: new(4197.50)},
	},
	0.7397260274: SurfaceSlice{
		10000.0: OptionPair{Call: new(4265.50), Put: new(152.00)},
		10100.0: OptionPair{Call: new(4173.00), Put: new(159.50)},
		10200.0: OptionPair{Call: new(4080.75), Put: new(167.25)},
		10300.0: OptionPair{Call: new(3989.25), Put: new(175.50)},
		10400.0: OptionPair{Call: new(3897.75), Put: new(184.25)},
		10500.0: OptionPair{Call: new(3807.00), Put: new(193.25)},
		10600.0: OptionPair{Call: new(3716.75), Put: new(203.00)},
		10700.0: OptionPair{Call: new(3626.75), Put: new(213.00)},
		10800.0: OptionPair{Call: new(3537.25), Put: new(223.50)},
		10900.0: OptionPair{Call: new(3448.25), Put: new(234.50)},
		11000.0: OptionPair{Call: new(3360.00), Put: new(246.00)},
		11100.0: OptionPair{Call: new(3272.00), Put: new(258.00)},
		11200.0: OptionPair{Call: new(3184.50), Put: new(270.75)},
		11300.0: OptionPair{Call: new(3097.75), Put: new(283.75)},
		11400.0: OptionPair{Call: new(3011.50), Put: new(297.50)},
		11500.0: OptionPair{Call: new(2925.75), Put: new(311.75)},
		11600.0: OptionPair{Call: new(2840.75), Put: new(326.75)},
		11700.0: OptionPair{Call: new(2756.25), Put: new(342.25)},
		11800.0: OptionPair{Call: new(2672.50), Put: new(358.50)},
		11900.0: OptionPair{Call: new(2589.50), Put: new(375.50)},
		12000.0: OptionPair{Call: new(2507.25), Put: new(393.00)},
		12100.0: OptionPair{Call: new(2425.75), Put: new(411.50)},
		12200.0: OptionPair{Call: new(2345.00), Put: new(430.75)},
		12300.0: OptionPair{Call: new(2265.00), Put: new(450.75)},
		12400.0: OptionPair{Call: new(2185.75), Put: new(471.50)},
		12500.0: OptionPair{Call: new(2107.50), Put: new(493.25)},
		12600.0: OptionPair{Call: new(2030.25), Put: new(515.75)},
		12700.0: OptionPair{Call: new(1953.75), Put: new(539.25)},
		12800.0: OptionPair{Call: new(1878.50), Put: new(564.00)},
		12900.0: OptionPair{Call: new(1804.00), Put: new(589.50)},
		13000.0: OptionPair{Call: new(1730.50), Put: new(616.00)},
		13100.0: OptionPair{Call: new(1658.25), Put: new(643.50)},
		13200.0: OptionPair{Call: new(1587.00), Put: new(672.25)},
		13300.0: OptionPair{Call: new(1516.75), Put: new(702.00)},
		13400.0: OptionPair{Call: new(1448.00), Put: new(733.25)},
		13500.0: OptionPair{Call: new(1380.50), Put: new(765.75)},
		13600.0: OptionPair{Call: new(1314.25), Put: new(799.50)},
		13700.0: OptionPair{Call: new(1249.75), Put: new(835.00)},
		13800.0: OptionPair{Call: new(1187.00), Put: new(872.00)},
		13900.0: OptionPair{Call: new(1126.00), Put: new(911.00)},
		14000.0: OptionPair{Call: new(1066.75), Put: new(951.75)},
		14100.0: OptionPair{Call: new(1009.25), Put: new(994.25)},
		14200.0: OptionPair{Call: new(953.50), Put: new(1038.50)},
		14300.0: OptionPair{Call: new(899.75), Put: new(1084.75)},
		14400.0: OptionPair{Call: new(848.00), Put: new(1132.75)},
		14500.0: OptionPair{Call: new(797.75), Put: new(1182.75)},
		14600.0: OptionPair{Call: new(749.50), Put: new(1234.50)},
		14700.0: OptionPair{Call: new(703.25), Put: new(1288.00)},
		14800.0: OptionPair{Call: new(658.50), Put: new(1343.25)},
		14900.0: OptionPair{Call: new(615.75), Put: new(1400.50)},
		15000.0: OptionPair{Call: new(574.75), Put: new(1459.50)},
		15100.0: OptionPair{Call: new(535.75), Put: new(1520.25)},
		15200.0: OptionPair{Call: new(498.25), Put: new(1582.75)},
		15300.0: OptionPair{Call: new(462.75), Put: new(1647.25)},
		15400.0: OptionPair{Call: new(429.00), Put: new(1713.50)},
		15500.0: OptionPair{Call: new(397.00), Put: new(1781.50)},
		15600.0: OptionPair{Call: new(367.00), Put: new(1851.50)},
		15700.0: OptionPair{Call: new(338.75), Put: new(1923.25)},
		15800.0: OptionPair{Call: new(312.50), Put: new(1996.75)},
		15900.0: OptionPair{Call: new(287.75), Put: new(2072.25)},
		16000.0: OptionPair{Call: new(265.00), Put: new(2149.25)},
		16100.0: OptionPair{Call: new(243.75), Put: new(2228.00)},
		16200.0: OptionPair{Call: new(224.25), Put: new(2308.50)},
		16300.0: OptionPair{Call: new(206.25), Put: new(2390.25)},
		16400.0: OptionPair{Call: new(189.50), Put: new(2473.50)},
		16500.0: OptionPair{Call: new(174.00), Put: new(2558.25)},
		16600.0: OptionPair{Call: new(160.00), Put: new(2644.00)},
		16700.0: OptionPair{Call: new(147.00), Put: new(2731.25)},
		16800.0: OptionPair{Call: new(135.25), Put: new(2819.25)},
		16900.0: OptionPair{Call: new(124.50), Put: new(2908.50)},
		17000.0: OptionPair{Call: new(114.50), Put: new(2998.50)},
		17100.0: OptionPair{Call: new(105.75), Put: new(3089.50)},
		17200.0: OptionPair{Call: new(97.50), Put: new(3181.50)},
		17300.0: OptionPair{Call: new(90.25), Put: new(3274.00)},
		17400.0: OptionPair{Call: new(83.50), Put: new(3367.25)},
		17500.0: OptionPair{Call: new(77.25), Put: new(3461.25)},
		17600.0: OptionPair{Call: new(71.75), Put: new(3555.50)},
		17700.0: OptionPair{Call: new(66.75), Put: new(3650.50)},
		17800.0: OptionPair{Call: new(62.00), Put: new(3745.75)},
		17900.0: OptionPair{Call: new(57.75), Put: new(3841.50)},
		18000.0: OptionPair{Call: new(53.75), Put: new(3937.50)},
		18100.0: OptionPair{Call: new(50.25), Put: new(4033.75)},
		18200.0: OptionPair{Call: new(46.75), Put: new(4130.50)},
		18300.0: OptionPair{Call: new(43.50), Put: new(4227.25)},
	},
	0.9890410959: SurfaceSlice{
		10000.0: OptionPair{Call: new(4357.00), Put: new(250.25)},
		10100.0: OptionPair{Call: new(4266.75), Put: new(260.00)},
		10200.0: OptionPair{Call: new(4177.00), Put: new(270.25)},
		10300.0: OptionPair{Call: new(4087.75), Put: new(280.75)},
		10400.0: OptionPair{Call: new(3998.75), Put: new(291.75)},
		10500.0: OptionPair{Call: new(3910.25), Put: new(303.25)},
		10600.0: OptionPair{Call: new(3822.25), Put: new(315.25)},
		10700.0: OptionPair{Call: new(3734.75), Put: new(327.75)},
		10800.0: OptionPair{Call: new(3647.75), Put: new(340.50)},
		10900.0: OptionPair{Call: new(3561.25), Put: new(354.00)},
		11000.0: OptionPair{Call: new(3475.25), Put: new(368.00)},
		11100.0: OptionPair{Call: new(3389.75), Put: new(382.25)},
		11200.0: OptionPair{Call: new(3304.75), Put: new(397.25)},
		11300.0: OptionPair{Call: new(3220.25), Put: new(412.75)},
		11400.0: OptionPair{Call: new(3136.25), Put: new(428.75)},
		11500.0: OptionPair{Call: new(3052.75), Put: new(445.25)},
		11600.0: OptionPair{Call: new(2970.00), Put: new(462.25)},
		11700.0: OptionPair{Call: new(2887.75), Put: new(480.00)},
		11800.0: OptionPair{Call: new(2806.00), Put: new(498.25)},
		11900.0: OptionPair{Call: new(2725.00), Put: new(517.25)},
		12000.0: OptionPair{Call: new(2644.75), Put: new(537.00)},
		12100.0: OptionPair{Call: new(2565.25), Put: new(557.25)},
		12200.0: OptionPair{Call: new(2486.25), Put: new(578.25)},
		12300.0: OptionPair{Call: new(2408.00), Put: new(600.00)},
		12400.0: OptionPair{Call: new(2330.50), Put: new(622.50)},
		12500.0: OptionPair{Call: new(2253.75), Put: new(645.75)},
		12600.0: OptionPair{Call: new(2178.00), Put: new(669.75)},
		12700.0: OptionPair{Call: new(2103.00), Put: new(694.75)},
		12800.0: OptionPair{Call: new(2028.75), Put: new(720.50)},
		12900.0: OptionPair{Call: new(1955.25), Put: new(747.00)},
		13000.0: OptionPair{Call: new(1882.75), Put: new(774.50)},
		13100.0: OptionPair{Call: new(1811.25), Put: new(802.75)},
		13200.0: OptionPair{Call: new(1740.75), Put: new(832.25)},
		13300.0: OptionPair{Call: new(1671.00), Put: new(862.50)},
		13400.0: OptionPair{Call: new(1602.50), Put: new(894.00)},
		13500.0: OptionPair{Call: new(1535.25), Put: new(926.50)},
		13600.0: OptionPair{Call: new(1469.25), Put: new(960.50)},
		13700.0: OptionPair{Call: new(1404.50), Put: new(995.75)},
		13800.0: OptionPair{Call: new(1341.25), Put: new(1032.50)},
		13900.0: OptionPair{Call: new(1279.75), Put: new(1071.00)},
		14000.0: OptionPair{Call: new(1220.00), Put: new(1111.00)},
		14100.0: OptionPair{Call: new(1161.75), Put: new(1152.75)},
		14200.0: OptionPair{Call: new(1105.25), Put: new(1196.25)},
		14300.0: OptionPair{Call: new(1050.25), Put: new(1241.25)},
		14400.0: OptionPair{Call: new(997.00), Put: new(1288.00)},
		14500.0: OptionPair{Call: new(945.50), Put: new(1336.25)},
		14600.0: OptionPair{Call: new(895.50), Put: new(1386.25)},
		14700.0: OptionPair{Call: new(847.25), Put: new(1438.00)},
		14800.0: OptionPair{Call: new(800.75), Put: new(1491.25)},
		14900.0: OptionPair{Call: new(755.50), Put: new(1546.25)},
		15000.0: OptionPair{Call: new(712.25), Put: new(1602.75)},
		15100.0: OptionPair{Call: new(670.25), Put: new(1660.75)},
		15200.0: OptionPair{Call: new(630.00), Put: new(1720.50)},
		15300.0: OptionPair{Call: new(591.50), Put: new(1781.75)},
		15400.0: OptionPair{Call: new(554.50), Put: new(1844.75)},
		15500.0: OptionPair{Call: new(519.25), Put: new(1909.50)},
		15600.0: OptionPair{Call: new(486.00), Put: new(1976.00)},
		15700.0: OptionPair{Call: new(454.25), Put: new(2044.25)},
		15800.0: OptionPair{Call: new(424.25), Put: new(2114.50)},
		15900.0: OptionPair{Call: new(396.25), Put: new(2186.25)},
		16000.0: OptionPair{Call: new(369.75), Put: new(2259.75)},
		16100.0: OptionPair{Call: new(345.00), Put: new(2335.00)},
		16200.0: OptionPair{Call: new(322.00), Put: new(2411.75)},
		16300.0: OptionPair{Call: new(300.25), Put: new(2490.00)},
		16400.0: OptionPair{Call: new(280.00), Put: new(2569.75)},
		16500.0: OptionPair{Call: new(261.25), Put: new(2651.00)},
		16600.0: OptionPair{Call: new(243.75), Put: new(2733.50)},
		16700.0: OptionPair{Call: new(227.75), Put: new(2817.25)},
		16800.0: OptionPair{Call: new(212.50), Put: new(2902.25)},
		16900.0: OptionPair{Call: new(198.75), Put: new(2988.25)},
		17000.0: OptionPair{Call: new(186.00), Put: new(3075.25)},
		17100.0: OptionPair{Call: new(174.00), Put: new(3163.50)},
		17200.0: OptionPair{Call: new(163.25), Put: new(3252.50)},
		17300.0: OptionPair{Call: new(153.25), Put: new(3342.50)},
		17400.0: OptionPair{Call: new(144.00), Put: new(3433.25)},
		17500.0: OptionPair{Call: new(135.50), Put: new(3524.75)},
		17600.0: OptionPair{Call: new(127.75), Put: new(3617.00)},
		17700.0: OptionPair{Call: new(120.50), Put: new(3709.75)},
		17800.0: OptionPair{Call: new(113.75), Put: new(3803.00)},
		17900.0: OptionPair{Call: new(107.50), Put: new(3896.50)},
		18000.0: OptionPair{Call: new(101.75), Put: new(3990.75)},
		18100.0: OptionPair{Call: new(96.25), Put: new(4085.25)},
		18200.0: OptionPair{Call: new(91.25), Put: new(4180.00)},
	},
}

const nasdaq21spot = 14137.23

var nasdaq21irCurve = termstructure.TermStructure{
	Data: map[termstructure.Tenor]float64{
		"M1":  -5.403085386509094e-15,
		"M12": 0.00059419151966005,
		"M18": 0.0013354644743006647,
		"M2":  0.0003863392712832488,
		"M3":  0.00030538367879285255,
		"M6":  0.00043956239085725065,
		"M9":  0.0004934147884558118,
		"ON":  0,
		"W1":  -1.1578040113948059e-14,
		"Y10": 0.012059956055181825,
		"Y11": 0.012622136338563645,
		"Y12": 0.013090784766965855,
		"Y15": 0.014139090839135034,
		"Y2":  0.0017320908167300642,
		"Y20": 0.015043579461290577,
		"Y25": 0.01530529369406153,
		"Y3":  0.003673360736305828,
		"Y30": 0.015268101901473274,
		"Y35": 0.015228232155448187,
		"Y4":  0.005501990446774308,
		"Y40": 0.01519834757654104,
		"Y45": 0.015175103207062526,
		"Y5":  0.007094580947049567,
		"Y50": 0.015156507202348844,
		"Y6":  0.00855275153647943,
		"Y7":  0.009731249927837905,
		"Y8":  0.010657472675339189,
		"Y9":  0.011398099281105672,
	},
}

var nasdaq21withoutKappas = VolatilitySurface{
	Slices: map[Tenor]volatilitySurfaceSlice{
		0.4904109589: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.0581267673703757,
				},
				10100.0: {
					totalVariance: 0.056816408630998044,
				},
				10200.0: {
					totalVariance: 0.05559197409492189,
				},
				10300.0: {
					totalVariance: 0.054318354012811786,
				},
				10400.0: {
					totalVariance: 0.05311783720511756,
				},
				10500.0: {
					totalVariance: 0.051922804460145335,
				},
				10600.0: {
					totalVariance: 0.050734601754846315,
				},
				10700.0: {
					totalVariance: 0.049549674962059954,
				},
				10800.0: {
					totalVariance: 0.048413920222908156,
				},
				10900.0: {
					totalVariance: 0.04731919354309654,
				},
				11000.0: {
					totalVariance: 0.04621645206534208,
				},
				11100.0: {
					totalVariance: 0.04514715777165378,
				},
				11200.0: {
					totalVariance: 0.044101839667142415,
				},
				11300.0: {
					totalVariance: 0.04304177330526464,
				},
				11400.0: {
					totalVariance: 0.04203757749718192,
				},
				11500.0: {
					totalVariance: 0.04104651469208572,
				},
				11600.0: {
					totalVariance: 0.04006684615273739,
				},
				11700.0: {
					totalVariance: 0.03912043129141041,
				},
				11800.0: {
					totalVariance: 0.0382072646123765,
				},
				11900.0: {
					totalVariance: 0.037290900034243034,
				},
				12000.0: {
					totalVariance: 0.0364210887470836,
				},
				12100.0: {
					totalVariance: 0.035543049214114976,
				},
				12200.0: {
					totalVariance: 0.03470112173367309,
				},
				12300.0: {
					totalVariance: 0.03386639001714296,
				},
				12400.0: {
					totalVariance: 0.03305575828129105,
				},
				12500.0: {
					totalVariance: 0.03226996033747354,
				},
				12600.0: {
					totalVariance: 0.03147833761618112,
				},
				12700.0: {
					totalVariance: 0.030719457195467672,
				},
				12800.0: {
					totalVariance: 0.02995148410094394,
				},
				12900.0: {
					totalVariance: 0.029203023131903504,
				},
				13000.0: {
					totalVariance: 0.028476600514441675,
				},
				13100.0: {
					totalVariance: 0.027764353651762504,
				},
				13200.0: {
					totalVariance: 0.027045962461916748,
				},
				13300.0: {
					totalVariance: 0.026349485918167444,
				},
				13400.0: {
					totalVariance: 0.02567494918536456,
				},
				13500.0: {
					totalVariance: 0.024998785390562123,
				},
				13600.0: {
					totalVariance: 0.02433360099315719,
				},
				13700.0: {
					totalVariance: 0.0236884120730062,
				},
				13800.0: {
					totalVariance: 0.023049933650888067,
				},
				13900.0: {
					totalVariance: 0.022423986587836377,
				},
				14000.0: {
					totalVariance: 0.021821381601778867,
				},
				14100.0: {
					totalVariance: 0.02122512506742911,
				},
				14200.0: {
					totalVariance: 0.0206438719752396,
				},
				14300.0: {
					totalVariance: 0.020087915430684996,
				},
				14400.0: {
					totalVariance: 0.01956616722016027,
				},
				14500.0: {
					totalVariance: 0.019061885722601063,
				},
				14600.0: {
					totalVariance: 0.018576181550243723,
				},
				14700.0: {
					totalVariance: 0.0181155312601896,
				},
				14800.0: {
					totalVariance: 0.01766679990619038,
				},
				14900.0: {
					totalVariance: 0.017255659417142053,
				},
				15000.0: {
					totalVariance: 0.016854740405320603,
				},
				15100.0: {
					totalVariance: 0.016477260865052776,
				},
				15200.0: {
					totalVariance: 0.01612543129087528,
				},
				15300.0: {
					totalVariance: 0.01579895254620088,
				},
				15500.0: {
					totalVariance: 0.015212411404429502,
				},
				15600.0: {
					totalVariance: 0.014959830534657614,
				},
				15700.0: {
					totalVariance: 0.014736858991542532,
				},
				15800.0: {
					totalVariance: 0.014535011346593638,
				},
				15900.0: {
					totalVariance: 0.014378507076482661,
				},
				16000.0: {
					totalVariance: 0.014243738172701755,
				},
				16100.0: {
					totalVariance: 0.014157120158491795,
				},
				16200.0: {
					totalVariance: 0.014075735262587635,
				},
				16300.0: {
					totalVariance: 0.014046933374272217,
				},
				16400.0: {
					totalVariance: 0.014021413977601836,
				},
				16500.0: {
					totalVariance: 0.014029046485445324,
				},
				16600.0: {
					totalVariance: 0.014033616554549176,
				},
				16700.0: {
					totalVariance: 0.014094979149458429,
				},
				16800.0: {
					totalVariance: 0.014143418755291456,
				},
				16900.0: {
					totalVariance: 0.01421390521593589,
				},
				17000.0: {
					totalVariance: 0.014317945908665471,
				},
				17100.0: {
					totalVariance: 0.014398400071709064,
				},
				17200.0: {
					totalVariance: 0.01449263397518161,
				},
				17300.0: {
					totalVariance: 0.014609365515343068,
				},
				17400.0: {
					totalVariance: 0.01475820991049084,
				},
				17500.0: {
					totalVariance: 0.014859697644635999,
				},
				17600.0: {
					totalVariance: 0.015005967153249398,
				},
				17700.0: {
					totalVariance: 0.015160350924086132,
				},
				17800.0: {
					totalVariance: 0.015271283191398841,
				},
				17900.0: {
					totalVariance: 0.015454081261206445,
				},
				18000.0: {
					totalVariance: 0.01560025709954702,
				},
				18100.0: {
					totalVariance: 0.015705386590864512,
				},
				18200.0: {
					totalVariance: 0.015835953194311345,
				},
				18300.0: {
					totalVariance: 0.016006350094228853,
				},
			},
		},
		0.7397260274: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.07277233999791267,
				},
				10100.0: {
					totalVariance: 0.0714015305408616,
				},
				10200.0: {
					totalVariance: 0.07003003753739505,
				},
				10300.0: {
					totalVariance: 0.06871315347418612,
				},
				10400.0: {
					totalVariance: 0.06744444368994944,
				},
				10500.0: {
					totalVariance: 0.06616319882586295,
				},
				10600.0: {
					totalVariance: 0.0649658667086988,
				},
				10700.0: {
					totalVariance: 0.06375598024087872,
				},
				10800.0: {
					totalVariance: 0.06256867269237996,
				},
				10900.0: {
					totalVariance: 0.06140351285918982,
				},
				11000.0: {
					totalVariance: 0.0602561480158027,
				},
				11100.0: {
					totalVariance: 0.05912650350276686,
				},
				11200.0: {
					totalVariance: 0.05803792242424733,
				},
				11300.0: {
					totalVariance: 0.05692249645682665,
				},
				11400.0: {
					totalVariance: 0.05584737413165203,
				},
				11500.0: {
					totalVariance: 0.05477015051156004,
				},
				11600.0: {
					totalVariance: 0.05372960535548674,
				},
				11700.0: {
					totalVariance: 0.052680810262124636,
				},
				11800.0: {
					totalVariance: 0.05165601659829872,
				},
				11900.0: {
					totalVariance: 0.050650728820502894,
				},
				12000.0: {
					totalVariance: 0.04963623069209169,
				},
				12100.0: {
					totalVariance: 0.04865516153750193,
				},
				12200.0: {
					totalVariance: 0.047688218659810884,
				},
				12300.0: {
					totalVariance: 0.04672677070699539,
				},
				12400.0: {
					totalVariance: 0.04576873125019998,
				},
				12500.0: {
					totalVariance: 0.04483312902175973,
				},
				12600.0: {
					totalVariance: 0.043899516624349884,
				},
				12700.0: {
					totalVariance: 0.04298282188630291,
				},
				12800.0: {
					totalVariance: 0.04210179345164993,
				},
				12900.0: {
					totalVariance: 0.04120966300686691,
				},
				13000.0: {
					totalVariance: 0.04032572912695737,
				},
				13100.0: {
					totalVariance: 0.03944507349237776,
				},
				13200.0: {
					totalVariance: 0.03859028714741245,
				},
				13300.0: {
					totalVariance: 0.03773405516945315,
				},
				13400.0: {
					totalVariance: 0.036911471032212276,
				},
				13500.0: {
					totalVariance: 0.036100385520087784,
				},
				13600.0: {
					totalVariance: 0.0352968747350197,
				},
				13700.0: {
					totalVariance: 0.03453551108523835,
				},
				13800.0: {
					totalVariance: 0.0337919657021649,
				},
				13900.0: {
					totalVariance: 0.03309684812958393,
				},
				14000.0: {
					totalVariance: 0.03242956697138785,
				},
				14100.0: {
					totalVariance: 0.031786903686023736,
				},
				14200.0: {
					totalVariance: 0.031163895912447857,
				},
				14300.0: {
					totalVariance: 0.030575882684663776,
				},
				14400.0: {
					totalVariance: 0.030020284995906858,
				},
				14500.0: {
					totalVariance: 0.02946446928048357,
				},
				14600.0: {
					totalVariance: 0.028936815174509536,
				},
				14700.0: {
					totalVariance: 0.028438452344688663,
				},
				14800.0: {
					totalVariance: 0.02793548318658372,
				},
				14900.0: {
					totalVariance: 0.027458287257806906,
				},
				15000.0: {
					totalVariance: 0.0269907466709773,
				},
				15100.0: {
					totalVariance: 0.026550960980757,
				},
				15200.0: {
					totalVariance: 0.026105106615251648,
				},
				15300.0: {
					totalVariance: 0.02568551243652471,
				},
				15400.0: {
					totalVariance: 0.025277337910781766,
				},
				15500.0: {
					totalVariance: 0.024884038055244067,
				},
				15600.0: {
					totalVariance: 0.02451890371477293,
				},
				15700.0: {
					totalVariance: 0.0241714785911247,
				},
				15800.0: {
					totalVariance: 0.02386266245258886,
				},
				15900.0: {
					totalVariance: 0.02355693448764548,
				},
				16000.0: {
					totalVariance: 0.023297416665406523,
				},
				16100.0: {
					totalVariance: 0.02305057966462012,
				},
				16200.0: {
					totalVariance: 0.02284433709439653,
				},
				16300.0: {
					totalVariance: 0.02266072675825756,
				},
				16400.0: {
					totalVariance: 0.0224892757990255,
				},
				16500.0: {
					totalVariance: 0.02233266537377816,
				},
				16600.0: {
					totalVariance: 0.022219073535908438,
				},
				16700.0: {
					totalVariance: 0.022112227104184805,
				},
				16800.0: {
					totalVariance: 0.022042094155266558,
				},
				16900.0: {
					totalVariance: 0.021991937642308616,
				},
				17000.0: {
					totalVariance: 0.021943378207928892,
				},
				17100.0: {
					totalVariance: 0.021954884517335512,
				},
				17200.0: {
					totalVariance: 0.02195436366341533,
				},
				17300.0: {
					totalVariance: 0.02200490205753236,
				},
				17400.0: {
					totalVariance: 0.02205775992401907,
				},
				17500.0: {
					totalVariance: 0.022109969665794982,
				},
				17600.0: {
					totalVariance: 0.02220723088137946,
				},
				17700.0: {
					totalVariance: 0.02232274618766048,
				},
				17800.0: {
					totalVariance: 0.022423346563513476,
				},
				17900.0: {
					totalVariance: 0.022551955895980438,
				},
				18000.0: {
					totalVariance: 0.022673159280552076,
				},
				18100.0: {
					totalVariance: 0.022835415467145976,
				},
				18200.0: {
					totalVariance: 0.02295203550049166,
				},
				18300.0: {
					totalVariance: 0.023069540463634224,
				},
			},
		},
		0.9890410959: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.09728361646056904,
				},
				10100.0: {
					totalVariance: 0.0954410270655461,
				},
				10200.0: {
					totalVariance: 0.09366141822190263,
				},
				10300.0: {
					totalVariance: 0.09188295713241698,
				},
				10400.0: {
					totalVariance: 0.09015813606388283,
				},
				10500.0: {
					totalVariance: 0.0884768783037035,
				},
				10600.0: {
					totalVariance: 0.08684333563595344,
				},
				10700.0: {
					totalVariance: 0.08524473425241147,
				},
				10800.0: {
					totalVariance: 0.08363240834720792,
				},
				10900.0: {
					totalVariance: 0.08210075488096977,
				},
				11000.0: {
					totalVariance: 0.0805807028280646,
				},
				11100.0: {
					totalVariance: 0.0790499419208092,
				},
				11200.0: {
					totalVariance: 0.07757741218006216,
				},
				11300.0: {
					totalVariance: 0.07612019970453565,
				},
				11400.0: {
					totalVariance: 0.07467572849082092,
				},
				11500.0: {
					totalVariance: 0.07324455441304221,
				},
				11600.0: {
					totalVariance: 0.07181305540062462,
				},
				11700.0: {
					totalVariance: 0.07042949848909935,
				},
				11800.0: {
					totalVariance: 0.0690473981534979,
				},
				11900.0: {
					totalVariance: 0.06769756663808472,
				},
				12000.0: {
					totalVariance: 0.06637615005601671,
				},
				12100.0: {
					totalVariance: 0.06505298318425498,
				},
				12200.0: {
					totalVariance: 0.06374436440600575,
				},
				12300.0: {
					totalVariance: 0.06246221431316571,
				},
				12400.0: {
					totalVariance: 0.061195784016112025,
				},
				12500.0: {
					totalVariance: 0.05994285046348895,
				},
				12600.0: {
					totalVariance: 0.05870105922532427,
				},
				12700.0: {
					totalVariance: 0.057493019827687945,
				},
				12800.0: {
					totalVariance: 0.05629255713570964,
				},
				12900.0: {
					totalVariance: 0.05508872256194971,
				},
				13000.0: {
					totalVariance: 0.053915385271200815,
				},
				13100.0: {
					totalVariance: 0.05273977818601008,
				},
				13200.0: {
					totalVariance: 0.05160474189373377,
				},
				13300.0: {
					totalVariance: 0.05046310895919506,
				},
				13400.0: {
					totalVariance: 0.049352637563757434,
				},
				13500.0: {
					totalVariance: 0.04825722012907444,
				},
				13600.0: {
					totalVariance: 0.04720699946813628,
				},
				13700.0: {
					totalVariance: 0.046179342748210984,
				},
				13800.0: {
					totalVariance: 0.045190993473768655,
				},
				13900.0: {
					totalVariance: 0.04425692478578569,
				},
				14000.0: {
					totalVariance: 0.04335376840985675,
				},
				14100.0: {
					totalVariance: 0.042496972283725544,
				},
				14200.0: {
					totalVariance: 0.04167888105225641,
				},
				14300.0: {
					totalVariance: 0.04088260259833557,
				},
				14400.0: {
					totalVariance: 0.0401235363811174,
				},
				14500.0: {
					totalVariance: 0.039399465374632,
				},
				14600.0: {
					totalVariance: 0.03869088228775457,
				},
				14700.0: {
					totalVariance: 0.03801301555781679,
				},
				14800.0: {
					totalVariance: 0.03736759999198694,
				},
				14900.0: {
					totalVariance: 0.03671291939043348,
				},
				15000.0: {
					totalVariance: 0.03610484555753055,
				},
				15100.0: {
					totalVariance: 0.03548906430389778,
				},
				15200.0: {
					totalVariance: 0.03489895328431038,
				},
				15300.0: {
					totalVariance: 0.034340117133238854,
				},
				15400.0: {
					totalVariance: 0.03378834037039697,
				},
				15500.0: {
					totalVariance: 0.03326406820195677,
				},
				15600.0: {
					totalVariance: 0.03278592086653255,
				},
				15700.0: {
					totalVariance: 0.03231860049036582,
				},
				15800.0: {
					totalVariance: 0.031887441521993666,
				},
				15900.0: {
					totalVariance: 0.03150685559771298,
				},
				16000.0: {
					totalVariance: 0.031144730061278283,
				},
				16100.0: {
					totalVariance: 0.030825951778356647,
				},
				16200.0: {
					totalVariance: 0.030550883126516024,
				},
				16300.0: {
					totalVariance: 0.030286810647935695,
				},
				16400.0: {
					totalVariance: 0.030055838380440292,
				},
				16500.0: {
					totalVariance: 0.029867045125816862,
				},
				16600.0: {
					totalVariance: 0.029700729715948292,
				},
				16700.0: {
					totalVariance: 0.029588928786248005,
				},
				16800.0: {
					totalVariance: 0.02946159277916734,
				},
				16900.0: {
					totalVariance: 0.02940109616941148,
				},
				17000.0: {
					totalVariance: 0.02936504297275112,
				},
				17100.0: {
					totalVariance: 0.02933125609721131,
				},
				17200.0: {
					totalVariance: 0.02935886690533213,
				},
				17300.0: {
					totalVariance: 0.0294053490973062,
				},
				17400.0: {
					totalVariance: 0.02947175374203799,
				},
				17500.0: {
					totalVariance: 0.029565630725191704,
				},
				17600.0: {
					totalVariance: 0.02969234047373455,
				},
				17700.0: {
					totalVariance: 0.029827661940278714,
				},
				17800.0: {
					totalVariance: 0.029975268388474016,
				},
				17900.0: {
					totalVariance: 0.030139701956523518,
				},
				18000.0: {
					totalVariance: 0.030325873375402615,
				},
				18100.0: {
					totalVariance: 0.03050594052654439,
				},
				18200.0: {
					totalVariance: 0.030711440407189098,
				},
			},
		},
	},
	SortedTenors: []Tenor{
		0.4904109589,
		0.7397260274,
		0.9890410959,
	},
}

var (
	nasdaq21divCurve = marketdata.DividendYieldCurve{
		Dividends: []marketdata.DividendPoint{
			{YearFraction: 0.4904109589, DividendZeroRate: 0.003530},
			{YearFraction: 0.7397260274, DividendZeroRate: 0.002717},
			{YearFraction: 0.9890410959, DividendZeroRate: 0.002708},
		},
	}

	nasdaq21expectedSurface = populateKappaAndVegaValues(nasdaq21withoutKappas, nasdaq21spot, nasdaq21irCurve, nasdaq21divCurve)
)

// data for 2021-06-22

var nasdaq22optionChain = OptionChain{
	0.4876712329: SurfaceSlice{
		10000.0: OptionPair{Call: new(4334.75), Put: new(90.00)},
		10100.0: OptionPair{Call: new(4239.25), Put: new(94.75)},
		10200.0: OptionPair{Call: new(4144.25), Put: new(99.50)},
		10300.0: OptionPair{Call: new(4049.25), Put: new(104.75)},
		10400.0: OptionPair{Call: new(3954.75), Put: new(110.25)},
		10500.0: OptionPair{Call: new(3860.50), Put: new(115.75)},
		10600.0: OptionPair{Call: new(3766.50), Put: new(121.75)},
		10700.0: OptionPair{Call: new(3672.75), Put: new(128.00)},
		10800.0: OptionPair{Call: new(3579.50), Put: new(134.75)},
		10900.0: OptionPair{Call: new(3486.50), Put: new(141.75)},
		11000.0: OptionPair{Call: new(3393.75), Put: new(149.00)},
		11100.0: OptionPair{Call: new(3301.50), Put: new(156.75)},
		11200.0: OptionPair{Call: new(3209.75), Put: new(164.75)},
		11300.0: OptionPair{Call: new(3118.25), Put: new(173.50)},
		11400.0: OptionPair{Call: new(3027.25), Put: new(182.50)},
		11500.0: OptionPair{Call: new(2936.75), Put: new(192.00)},
		11600.0: OptionPair{Call: new(2846.75), Put: new(202.00)},
		11700.0: OptionPair{Call: new(2757.50), Put: new(212.50)},
		11800.0: OptionPair{Call: new(2668.50), Put: new(223.75)},
		11900.0: OptionPair{Call: new(2580.50), Put: new(235.50)},
		12000.0: OptionPair{Call: new(2493.00), Put: new(248.00)},
		12100.0: OptionPair{Call: new(2406.00), Put: new(261.00)},
		12200.0: OptionPair{Call: new(2320.00), Put: new(275.00)},
		12300.0: OptionPair{Call: new(2234.75), Put: new(289.75)},
		12400.0: OptionPair{Call: new(2150.50), Put: new(305.25)},
		12500.0: OptionPair{Call: new(2067.00), Put: new(321.75)},
		12600.0: OptionPair{Call: new(1984.50), Put: new(339.25)},
		12700.0: OptionPair{Call: new(1903.00), Put: new(357.75)},
		12800.0: OptionPair{Call: new(1822.50), Put: new(377.25)},
		12900.0: OptionPair{Call: new(1743.00), Put: new(397.75)},
		13000.0: OptionPair{Call: new(1664.50), Put: new(419.25)},
		13100.0: OptionPair{Call: new(1587.00), Put: new(442.00)},
		13200.0: OptionPair{Call: new(1511.00), Put: new(465.75)},
		13300.0: OptionPair{Call: new(1436.00), Put: new(490.75)},
		13400.0: OptionPair{Call: new(1362.50), Put: new(517.25)},
		13500.0: OptionPair{Call: new(1290.50), Put: new(545.25)},
		13600.0: OptionPair{Call: new(1220.00), Put: new(574.75)},
		13700.0: OptionPair{Call: new(1151.00), Put: new(605.75)},
		13800.0: OptionPair{Call: new(1083.75), Put: new(638.25)},
		13900.0: OptionPair{Call: new(1017.75), Put: new(672.25)},
		14000.0: OptionPair{Call: new(953.50), Put: new(708.00)},
		14100.0: OptionPair{Call: new(891.25), Put: new(745.75)},
		14200.0: OptionPair{Call: new(831.50), Put: new(786.00)},
		14300.0: OptionPair{Call: new(773.50), Put: new(828.00)},
		14400.0: OptionPair{Call: new(717.50), Put: new(872.00)},
		14500.0: OptionPair{Call: new(663.75), Put: new(918.00)},
		14600.0: OptionPair{Call: new(612.00), Put: new(966.50)},
		14700.0: OptionPair{Call: new(562.75), Put: new(1017.25)},
		14800.0: OptionPair{Call: new(516.25), Put: new(1070.50)},
		14900.0: OptionPair{Call: new(472.00), Put: new(1126.50)},
		15000.0: OptionPair{Call: new(430.50), Put: new(1184.75)},
		15100.0: OptionPair{Call: new(391.50), Put: new(1245.75)},
		15200.0: OptionPair{Call: new(355.00), Put: new(1309.25)},
		15300.0: OptionPair{Call: new(320.75), Put: new(1375.00)},
		15400.0: OptionPair{Call: new(289.25), Put: new(1443.50)},
		15500.0: OptionPair{Call: new(260.25), Put: new(1514.25)},
		15600.0: OptionPair{Call: new(233.50), Put: new(1587.75)},
		15700.0: OptionPair{Call: new(209.25), Put: new(1663.50)},
		15800.0: OptionPair{Call: new(187.25), Put: new(1741.50)},
		15900.0: OptionPair{Call: new(167.50), Put: new(1821.50)},
		16000.0: OptionPair{Call: new(149.50), Put: new(1903.75)},
		16100.0: OptionPair{Call: new(133.50), Put: new(1987.50)},
		16200.0: OptionPair{Call: new(119.25), Put: new(2073.25)},
		16300.0: OptionPair{Call: new(106.50), Put: new(2160.50)},
		16400.0: OptionPair{Call: new(95.25), Put: new(2249.25)},
		16500.0: OptionPair{Call: new(85.50), Put: new(2339.50)},
		16600.0: OptionPair{Call: new(76.75), Put: new(2430.75)},
		16700.0: OptionPair{Call: new(69.00), Put: new(2523.00)},
		16800.0: OptionPair{Call: new(62.00), Put: new(2616.00)},
		16900.0: OptionPair{Call: new(56.00), Put: new(2710.00)},
		17000.0: OptionPair{Call: new(50.50), Put: new(2804.50)},
		17100.0: OptionPair{Call: new(45.75), Put: new(2899.75)},
		17200.0: OptionPair{Call: new(41.50), Put: new(2995.25)},
		17300.0: OptionPair{Call: new(37.75), Put: new(3091.50)},
		17400.0: OptionPair{Call: new(34.25), Put: new(3188.00)},
		17500.0: OptionPair{Call: new(31.25), Put: new(3285.00)},
		17600.0: OptionPair{Call: new(28.50), Put: new(3382.25)},
		17700.0: OptionPair{Call: new(26.00), Put: new(3479.75)},
		17800.0: OptionPair{Call: new(23.75), Put: new(3577.50)},
		17900.0: OptionPair{Call: new(21.75), Put: new(3675.50)},
		18000.0: OptionPair{Call: new(19.75), Put: new(3773.50)},
		18100.0: OptionPair{Call: new(18.25), Put: new(3871.75)},
		18200.0: OptionPair{Call: new(16.50), Put: new(3970.25)},
		18300.0: OptionPair{Call: new(15.25), Put: new(4069.00)},
	},
	0.7369863014: SurfaceSlice{
		10000.0: OptionPair{Call: new(4388.25), Put: new(147.00)},
		10100.0: OptionPair{Call: new(4295.75), Put: new(154.25)},
		10200.0: OptionPair{Call: new(4203.50), Put: new(162.00)},
		10300.0: OptionPair{Call: new(4111.50), Put: new(170.25)},
		10400.0: OptionPair{Call: new(4020.25), Put: new(178.75)},
		10500.0: OptionPair{Call: new(3929.25), Put: new(187.75)},
		10600.0: OptionPair{Call: new(3838.50), Put: new(197.25)},
		10700.0: OptionPair{Call: new(3748.50), Put: new(207.00)},
		10800.0: OptionPair{Call: new(3658.75), Put: new(217.25)},
		10900.0: OptionPair{Call: new(3569.75), Put: new(228.25)},
		11000.0: OptionPair{Call: new(3481.00), Put: new(239.50)},
		11100.0: OptionPair{Call: new(3392.75), Put: new(251.25)},
		11200.0: OptionPair{Call: new(3305.00), Put: new(263.25)},
		11300.0: OptionPair{Call: new(3217.75), Put: new(276.00)},
		11400.0: OptionPair{Call: new(3131.00), Put: new(289.25)},
		11500.0: OptionPair{Call: new(3044.75), Put: new(303.00)},
		11600.0: OptionPair{Call: new(2959.00), Put: new(317.25)},
		11700.0: OptionPair{Call: new(2873.75), Put: new(332.00)},
		11800.0: OptionPair{Call: new(2789.25), Put: new(347.50)},
		11900.0: OptionPair{Call: new(2705.50), Put: new(363.50)},
		12000.0: OptionPair{Call: new(2622.25), Put: new(380.25)},
		12100.0: OptionPair{Call: new(2539.75), Put: new(397.75)},
		12200.0: OptionPair{Call: new(2457.75), Put: new(415.75)},
		12300.0: OptionPair{Call: new(2376.75), Put: new(434.75)},
		12400.0: OptionPair{Call: new(2296.50), Put: new(454.50)},
		12500.0: OptionPair{Call: new(2217.25), Put: new(475.00)},
		12600.0: OptionPair{Call: new(2138.75), Put: new(496.50)},
		12700.0: OptionPair{Call: new(2061.00), Put: new(519.00)},
		12800.0: OptionPair{Call: new(1984.50), Put: new(542.25)},
		12900.0: OptionPair{Call: new(1909.00), Put: new(566.75)},
		13000.0: OptionPair{Call: new(1834.75), Put: new(592.50)},
		13100.0: OptionPair{Call: new(1761.50), Put: new(619.00)},
		13200.0: OptionPair{Call: new(1689.50), Put: new(647.00)},
		13300.0: OptionPair{Call: new(1618.75), Put: new(676.25)},
		13400.0: OptionPair{Call: new(1549.25), Put: new(706.75)},
		13500.0: OptionPair{Call: new(1481.00), Put: new(738.75)},
		13600.0: OptionPair{Call: new(1414.25), Put: new(771.75)},
		13700.0: OptionPair{Call: new(1348.75), Put: new(806.25)},
		13800.0: OptionPair{Call: new(1284.75), Put: new(842.25)},
		13900.0: OptionPair{Call: new(1222.00), Put: new(879.25)},
		14000.0: OptionPair{Call: new(1160.75), Put: new(918.00)},
		14100.0: OptionPair{Call: new(1100.75), Put: new(958.00)},
		14200.0: OptionPair{Call: new(1042.50), Put: new(999.75)},
		14300.0: OptionPair{Call: new(985.75), Put: new(1043.00)},
		14400.0: OptionPair{Call: new(930.50), Put: new(1087.75)},
		14500.0: OptionPair{Call: new(877.00), Put: new(1134.25)},
		14600.0: OptionPair{Call: new(825.25), Put: new(1182.50)},
		14700.0: OptionPair{Call: new(775.25), Put: new(1232.50)},
		14800.0: OptionPair{Call: new(727.00), Put: new(1284.25)},
		14900.0: OptionPair{Call: new(680.75), Put: new(1337.75)},
		15000.0: OptionPair{Call: new(636.25), Put: new(1393.25)},
		15100.0: OptionPair{Call: new(593.75), Put: new(1450.75)},
		15200.0: OptionPair{Call: new(553.25), Put: new(1510.00)},
		15300.0: OptionPair{Call: new(514.50), Put: new(1571.25)},
		15400.0: OptionPair{Call: new(477.50), Put: new(1634.25)},
		15500.0: OptionPair{Call: new(442.50), Put: new(1699.25)},
		15600.0: OptionPair{Call: new(409.50), Put: new(1766.25)},
		15700.0: OptionPair{Call: new(378.25), Put: new(1835.00)},
		15800.0: OptionPair{Call: new(348.75), Put: new(1905.50)},
		15900.0: OptionPair{Call: new(321.00), Put: new(1977.75)},
		16000.0: OptionPair{Call: new(295.00), Put: new(2051.75)},
		16100.0: OptionPair{Call: new(271.00), Put: new(2127.50)},
		16200.0: OptionPair{Call: new(248.50), Put: new(2205.00)},
		16300.0: OptionPair{Call: new(228.00), Put: new(2284.50)},
		16400.0: OptionPair{Call: new(209.00), Put: new(2365.50)},
		16500.0: OptionPair{Call: new(191.50), Put: new(2448.00)},
		16600.0: OptionPair{Call: new(175.75), Put: new(2532.25)},
		16700.0: OptionPair{Call: new(161.25), Put: new(2617.75)},
		16800.0: OptionPair{Call: new(148.25), Put: new(2704.50)},
		16900.0: OptionPair{Call: new(136.00), Put: new(2792.50)},
		17000.0: OptionPair{Call: new(125.00), Put: new(2881.25)},
		17100.0: OptionPair{Call: new(114.50), Put: new(2970.75)},
		17200.0: OptionPair{Call: new(105.00), Put: new(3061.00)},
		17300.0: OptionPair{Call: new(95.75), Put: new(3152.00)},
		17400.0: OptionPair{Call: new(87.50), Put: new(3243.50)},
		17500.0: OptionPair{Call: new(79.75), Put: new(3335.75)},
		17600.0: OptionPair{Call: new(72.50), Put: new(3428.75)},
		17700.0: OptionPair{Call: new(66.25), Put: new(3522.25)},
		17800.0: OptionPair{Call: new(60.25), Put: new(3616.50)},
		17900.0: OptionPair{Call: new(55.25), Put: new(3711.25)},
		18000.0: OptionPair{Call: new(50.75), Put: new(3806.75)},
		18100.0: OptionPair{Call: new(47.00), Put: new(3903.00)},
		18200.0: OptionPair{Call: new(43.50), Put: new(3999.50)},
		18300.0: OptionPair{Call: new(40.25), Put: new(4096.25)},
	},
	0.9863013699: SurfaceSlice{
		10000.0: OptionPair{Call: new(4468.75), Put: new(236.50)},
		10100.0: OptionPair{Call: new(4378.00), Put: new(245.75)},
		10200.0: OptionPair{Call: new(4287.50), Put: new(255.25)},
		10300.0: OptionPair{Call: new(4197.50), Put: new(265.25)},
		10400.0: OptionPair{Call: new(4108.00), Put: new(275.75)},
		10500.0: OptionPair{Call: new(4019.00), Put: new(286.50)},
		10600.0: OptionPair{Call: new(3930.50), Put: new(298.00)},
		10700.0: OptionPair{Call: new(3842.25), Put: new(309.75)},
		10800.0: OptionPair{Call: new(3754.50), Put: new(322.00)},
		10900.0: OptionPair{Call: new(3667.25), Put: new(334.50)},
		11000.0: OptionPair{Call: new(3580.50), Put: new(347.75)},
		11100.0: OptionPair{Call: new(3494.25), Put: new(361.50)},
		11200.0: OptionPair{Call: new(3408.25), Put: new(375.50)},
		11300.0: OptionPair{Call: new(3323.00), Put: new(390.25)},
		11400.0: OptionPair{Call: new(3238.25), Put: new(405.25)},
		11500.0: OptionPair{Call: new(3154.00), Put: new(421.00)},
		11600.0: OptionPair{Call: new(3070.25), Put: new(437.25)},
		11700.0: OptionPair{Call: new(2987.00), Put: new(454.00)},
		11800.0: OptionPair{Call: new(2904.50), Put: new(471.25)},
		11900.0: OptionPair{Call: new(2822.50), Put: new(489.25)},
		12000.0: OptionPair{Call: new(2741.25), Put: new(508.00)},
		12100.0: OptionPair{Call: new(2660.50), Put: new(527.25)},
		12200.0: OptionPair{Call: new(2580.50), Put: new(547.25)},
		12300.0: OptionPair{Call: new(2501.25), Put: new(567.75)},
		12400.0: OptionPair{Call: new(2422.50), Put: new(589.25)},
		12500.0: OptionPair{Call: new(2344.75), Put: new(611.25)},
		12600.0: OptionPair{Call: new(2267.75), Put: new(634.00)},
		12700.0: OptionPair{Call: new(2191.25), Put: new(657.75)},
		12800.0: OptionPair{Call: new(2115.75), Put: new(682.25)},
		12900.0: OptionPair{Call: new(2041.25), Put: new(707.50)},
		13000.0: OptionPair{Call: new(1967.50), Put: new(733.50)},
		13100.0: OptionPair{Call: new(1894.50), Put: new(760.75)},
		13200.0: OptionPair{Call: new(1822.50), Put: new(788.50)},
		13300.0: OptionPair{Call: new(1751.50), Put: new(817.50)},
		13400.0: OptionPair{Call: new(1681.50), Put: new(847.25)},
		13500.0: OptionPair{Call: new(1612.50), Put: new(878.50)},
		13600.0: OptionPair{Call: new(1545.00), Put: new(910.75)},
		13700.0: OptionPair{Call: new(1478.75), Put: new(944.50)},
		13800.0: OptionPair{Call: new(1414.00), Put: new(979.75)},
		13900.0: OptionPair{Call: new(1350.75), Put: new(1016.50)},
		14000.0: OptionPair{Call: new(1289.25), Put: new(1054.75)},
		14100.0: OptionPair{Call: new(1229.25), Put: new(1094.75)},
		14200.0: OptionPair{Call: new(1171.00), Put: new(1136.50)},
		14300.0: OptionPair{Call: new(1114.25), Put: new(1179.75)},
		14400.0: OptionPair{Call: new(1059.25), Put: new(1224.75)},
		14500.0: OptionPair{Call: new(1005.75), Put: new(1271.25)},
		14600.0: OptionPair{Call: new(954.00), Put: new(1319.50)},
		14700.0: OptionPair{Call: new(904.00), Put: new(1369.25)},
		14800.0: OptionPair{Call: new(855.50), Put: new(1420.75)},
		14900.0: OptionPair{Call: new(808.50), Put: new(1473.75)},
		15000.0: OptionPair{Call: new(763.25), Put: new(1528.25)},
		15100.0: OptionPair{Call: new(719.50), Put: new(1584.50)},
		15200.0: OptionPair{Call: new(677.50), Put: new(1642.25)},
		15300.0: OptionPair{Call: new(637.00), Put: new(1701.75)},
		15400.0: OptionPair{Call: new(598.25), Put: new(1763.00)},
		15500.0: OptionPair{Call: new(561.25), Put: new(1826.00)},
		15600.0: OptionPair{Call: new(526.00), Put: new(1890.75)},
		15700.0: OptionPair{Call: new(492.50), Put: new(1957.25)},
		15800.0: OptionPair{Call: new(461.00), Put: new(2025.50)},
		15900.0: OptionPair{Call: new(431.00), Put: new(2095.75)},
		16000.0: OptionPair{Call: new(403.00), Put: new(2167.50)},
		16100.0: OptionPair{Call: new(376.75), Put: new(2241.25)},
		16200.0: OptionPair{Call: new(352.00), Put: new(2316.50)},
		16300.0: OptionPair{Call: new(329.00), Put: new(2393.25)},
		16400.0: OptionPair{Call: new(307.25), Put: new(2471.50)},
		16500.0: OptionPair{Call: new(287.00), Put: new(2551.25)},
		16600.0: OptionPair{Call: new(268.25), Put: new(2632.50)},
		16700.0: OptionPair{Call: new(250.75), Put: new(2715.00)},
		16800.0: OptionPair{Call: new(234.50), Put: new(2798.75)},
		16900.0: OptionPair{Call: new(219.50), Put: new(2883.50)},
		17000.0: OptionPair{Call: new(205.75), Put: new(2969.75)},
		17100.0: OptionPair{Call: new(192.75), Put: new(3056.75)},
		17200.0: OptionPair{Call: new(181.00), Put: new(3145.00)},
		17300.0: OptionPair{Call: new(170.00), Put: new(3234.00)},
		17400.0: OptionPair{Call: new(160.00), Put: new(3323.75)},
		17500.0: OptionPair{Call: new(150.75), Put: new(3414.50)},
		17600.0: OptionPair{Call: new(142.25), Put: new(3506.00)},
		17700.0: OptionPair{Call: new(134.25), Put: new(3598.00)},
		17800.0: OptionPair{Call: new(126.75), Put: new(3690.50)},
		17900.0: OptionPair{Call: new(120.00), Put: new(3783.50)},
		18000.0: OptionPair{Call: new(113.50), Put: new(3877.00)},
		18100.0: OptionPair{Call: new(107.50), Put: new(3971.00)},
		18200.0: OptionPair{Call: new(101.75), Put: new(4065.25)},
		18300.0: OptionPair{Call: new(96.50), Put: new(4159.75)},
	},
}

const nasdaq22spot = 14270.416

var nasdaq22irCurve = termstructure.TermStructure{
	Data: map[termstructure.Tenor]float64{
		"M1":  -5.403085386509094e-15,
		"M12": 0.0005183980014211633,
		"M18": 0.0012028041933882946,
		"M2":  0.00034480117275408984,
		"M3":  0.0002743677230967568,
		"M6":  0.0003887389340161192,
		"M9":  0.0004079257278307541,
		"ON":  0,
		"W1":  -1.1578040113948059e-14,
		"Y10": 0.01187225413711707,
		"Y11": 0.012444816510900795,
		"Y12": 0.012928364192477554,
		"Y15": 0.013957818312034865,
		"Y2":  0.001567297919533528,
		"Y20": 0.014785380298233803,
		"Y25": 0.01512345342461084,
		"Y3":  0.003487853641533987,
		"Y30": 0.01497721114915761,
		"Y35": 0.014848404936841426,
		"Y4":  0.005389314638308005,
		"Y40": 0.01475185755945731,
		"Y45": 0.014676762544095997,
		"Y5":  0.006985243251066744,
		"Y50": 0.014616684886970335,
		"Y6":  0.008377148800160758,
		"Y7":  0.009488743647542113,
		"Y8":  0.010490142984497018,
		"Y9":  0.011239961781115592,
	},
}

var nasdaq22withoutKappas = VolatilitySurface{
	Slices: map[Tenor]volatilitySurfaceSlice{
		0.4876712329: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.05805162741598437,
				},
				10100.0: {
					totalVariance: 0.056789283602915526,
				},
				10200.0: {
					totalVariance: 0.055482174912221405,
				},
				10300.0: {
					totalVariance: 0.05426465827647668,
				},
				10400.0: {
					totalVariance: 0.05306227298809033,
				},
				10500.0: {
					totalVariance: 0.0518144695242972,
				},
				10600.0: {
					totalVariance: 0.05063476589266068,
				},
				10700.0: {
					totalVariance: 0.049465462257603676,
				},
				10800.0: {
					totalVariance: 0.048350966039790166,
				},
				10900.0: {
					totalVariance: 0.04723543485157439,
				},
				11000.0: {
					totalVariance: 0.04611805788798036,
				},
				11100.0: {
					totalVariance: 0.04504063692272737,
				},
				11200.0: {
					totalVariance: 0.04395622192662161,
				},
				11300.0: {
					totalVariance: 0.04293874345411565,
				},
				11400.0: {
					totalVariance: 0.04191249063832568,
				},
				11500.0: {
					totalVariance: 0.0409041240434684,
				},
				11600.0: {
					totalVariance: 0.03991275896613952,
				},
				11700.0: {
					totalVariance: 0.03893452533232732,
				},
				11800.0: {
					totalVariance: 0.03799466941752285,
				},
				11900.0: {
					totalVariance: 0.0370621153771981,
				},
				12000.0: {
					totalVariance: 0.036157786784286314,
				},
				12100.0: {
					totalVariance: 0.03524842633009092,
				},
				12200.0: {
					totalVariance: 0.034390171496510635,
				},
				12300.0: {
					totalVariance: 0.03354350468641179,
				},
				12400.0: {
					totalVariance: 0.03270740603981847,
				},
				12500.0: {
					totalVariance: 0.03190062795954181,
				},
				12600.0: {
					totalVariance: 0.03111537962365973,
				},
				12700.0: {
					totalVariance: 0.03035065352944387,
				},
				12800.0: {
					totalVariance: 0.02959879699824631,
				},
				12900.0: {
					totalVariance: 0.02885656661967359,
				},
				13000.0: {
					totalVariance: 0.02811907238856763,
				},
				13100.0: {
					totalVariance: 0.027403626261005745,
				},
				13200.0: {
					totalVariance: 0.026686329692634687,
				},
				13300.0: {
					totalVariance: 0.025981291107170495,
				},
				13400.0: {
					totalVariance: 0.025300972328357915,
				},
				13500.0: {
					totalVariance: 0.024637570184413256,
				},
				13600.0: {
					totalVariance: 0.023990747472946647,
				},
				13700.0: {
					totalVariance: 0.023353961181209717,
				},
				13800.0: {
					totalVariance: 0.022724163560698427,
				},
				13900.0: {
					totalVariance: 0.022097025803406355,
				},
				14000.0: {
					totalVariance: 0.02148443065071447,
				},
				14100.0: {
					totalVariance: 0.020894153023009513,
				},
				14200.0: {
					totalVariance: 0.020347549167407292,
				},
				14300.0: {
					totalVariance: 0.019802418025475187,
				},
				14400.0: {
					totalVariance: 0.019267433214225565,
				},
				14500.0: {
					totalVariance: 0.01875265115415347,
				},
				14600.0: {
					totalVariance: 0.0182424504417691,
				},
				14700.0: {
					totalVariance: 0.017760242334729903,
				},
				14800.0: {
					totalVariance: 0.01731341331224408,
				},
				14900.0: {
					totalVariance: 0.016876759637524837,
				},
				15000.0: {
					totalVariance: 0.01647436811223627,
				},
				15100.0: {
					totalVariance: 0.01609232460828549,
				},
				15200.0: {
					totalVariance: 0.015731259164678577,
				},
				15300.0: {
					totalVariance: 0.015381005237478816,
				},
				15400.0: {
					totalVariance: 0.015064781421137508,
				},
				15500.0: {
					totalVariance: 0.014775525273076748,
				},
				15600.0: {
					totalVariance: 0.014504313388703819,
				},
				15700.0: {
					totalVariance: 0.014267525958257716,
				},
				15800.0: {
					totalVariance: 0.014057914039843243,
				},
				15900.0: {
					totalVariance: 0.013882470109762277,
				},
				16000.0: {
					totalVariance: 0.013719029927727508,
				},
				16100.0: {
					totalVariance: 0.013589489077495766,
				},
				16200.0: {
					totalVariance: 0.013489242693770201,
				},
				16300.0: {
					totalVariance: 0.01340836825842435,
				},
				16400.0: {
					totalVariance: 0.01335704965346786,
				},
				16500.0: {
					totalVariance: 0.013347081281058123,
				},
				16600.0: {
					totalVariance: 0.013347457202701031,
				},
				16700.0: {
					totalVariance: 0.013367619091088394,
				},
				16800.0: {
					totalVariance: 0.013393023829773783,
				},
				16900.0: {
					totalVariance: 0.013456338544696973,
				},
				17000.0: {
					totalVariance: 0.01351282170391597,
				},
				17100.0: {
					totalVariance: 0.013600800526130758,
				},
				17200.0: {
					totalVariance: 0.013697987954926154,
				},
				17300.0: {
					totalVariance: 0.013811868356434637,
				},
				17400.0: {
					totalVariance: 0.013912151054310784,
				},
				17500.0: {
					totalVariance: 0.014042242530492043,
				},
				17600.0: {
					totalVariance: 0.01416923499212746,
				},
				17700.0: {
					totalVariance: 0.014297918290605803,
				},
				17800.0: {
					totalVariance: 0.014431248363474087,
				},
				17900.0: {
					totalVariance: 0.014575297036284225,
				},
				18000.0: {
					totalVariance: 0.014676142296292811,
				},
				18100.0: {
					totalVariance: 0.014862297254151936,
				},
				18200.0: {
					totalVariance: 0.01494104950097799,
				},
				18300.0: {
					totalVariance: 0.015123877763352086,
				},
			},
		},
		0.7369863014: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.07405237711339654,
				},
				10100.0: {
					totalVariance: 0.07268486370040858,
				},
				10200.0: {
					totalVariance: 0.07138005105337307,
				},
				10300.0: {
					totalVariance: 0.0701286689524817,
				},
				10400.0: {
					totalVariance: 0.06886628105762337,
				},
				10500.0: {
					totalVariance: 0.06764758013514263,
				},
				10600.0: {
					totalVariance: 0.06646458762070759,
				},
				10700.0: {
					totalVariance: 0.06526002396792874,
				},
				10800.0: {
					totalVariance: 0.06409012708789667,
				},
				10900.0: {
					totalVariance: 0.0629858895876993,
				},
				11000.0: {
					totalVariance: 0.06185456944240145,
				},
				11100.0: {
					totalVariance: 0.0607389800463885,
				},
				11200.0: {
					totalVariance: 0.059592539544451685,
				},
				11300.0: {
					totalVariance: 0.05850276155427215,
				},
				11400.0: {
					totalVariance: 0.05741710513690725,
				},
				11500.0: {
					totalVariance: 0.056335029908469926,
				},
				11600.0: {
					totalVariance: 0.05525260639483205,
				},
				11700.0: {
					totalVariance: 0.054174942340787416,
				},
				11800.0: {
					totalVariance: 0.05312442923598245,
				},
				11900.0: {
					totalVariance: 0.05206879399537767,
				},
				12000.0: {
					totalVariance: 0.05103588004822763,
				},
				12100.0: {
					totalVariance: 0.050024941506078925,
				},
				12200.0: {
					totalVariance: 0.04899402897427407,
				},
				12300.0: {
					totalVariance: 0.0480080475337943,
				},
				12400.0: {
					totalVariance: 0.047030063136097075,
				},
				12500.0: {
					totalVariance: 0.04605784988966196,
				},
				12600.0: {
					totalVariance: 0.04510988767394575,
				},
				12700.0: {
					totalVariance: 0.04418944317366401,
				},
				12800.0: {
					totalVariance: 0.04326413396630419,
				},
				12900.0: {
					totalVariance: 0.04237624271732269,
				},
				13000.0: {
					totalVariance: 0.041520799545152684,
				},
				13100.0: {
					totalVariance: 0.040652596986125826,
				},
				13200.0: {
					totalVariance: 0.039827227058898504,
				},
				13300.0: {
					totalVariance: 0.03902691189102692,
				},
				13400.0: {
					totalVariance: 0.03824241603673277,
				},
				13500.0: {
					totalVariance: 0.03748953229950589,
				},
				13600.0: {
					totalVariance: 0.03672862829799491,
				},
				13700.0: {
					totalVariance: 0.03599166811737898,
				},
				13800.0: {
					totalVariance: 0.03527976507457432,
				},
				13900.0: {
					totalVariance: 0.034551742347082935,
				},
				14000.0: {
					totalVariance: 0.033857124648251954,
				},
				14100.0: {
					totalVariance: 0.0331600473081656,
				},
				14200.0: {
					totalVariance: 0.03249294733619097,
				},
				14300.0: {
					totalVariance: 0.03183014908289214,
				},
				14400.0: {
					totalVariance: 0.031174759141468167,
				},
				14500.0: {
					totalVariance: 0.030539730196871666,
				},
				14600.0: {
					totalVariance: 0.029922980527736964,
				},
				14700.0: {
					totalVariance: 0.029322161598266856,
				},
				14800.0: {
					totalVariance: 0.028737871704856466,
				},
				14900.0: {
					totalVariance: 0.02817926732403585,
				},
				15000.0: {
					totalVariance: 0.02763369678440466,
				},
				15100.0: {
					totalVariance: 0.02711386466877243,
				},
				15200.0: {
					totalVariance: 0.02662214071803521,
				},
				15300.0: {
					totalVariance: 0.026138065724859383,
				},
				15400.0: {
					totalVariance: 0.02566550219828346,
				},
				15500.0: {
					totalVariance: 0.02521900159206529,
				},
				15600.0: {
					totalVariance: 0.024798860305037664,
				},
				15700.0: {
					totalVariance: 0.024395035068578833,
				},
				15800.0: {
					totalVariance: 0.024004288284783296,
				},
				15900.0: {
					totalVariance: 0.023629450877936695,
				},
				16000.0: {
					totalVariance: 0.023276457286171944,
				},
				16100.0: {
					totalVariance: 0.02296233049732407,
				},
				16200.0: {
					totalVariance: 0.02265698939789471,
				},
				16300.0: {
					totalVariance: 0.022403531752074095,
				},
				16400.0: {
					totalVariance: 0.02216846715765553,
				},
				16500.0: {
					totalVariance: 0.021959284466595216,
				},
				16600.0: {
					totalVariance: 0.021801776794454917,
				},
				16700.0: {
					totalVariance: 0.02166338573282996,
				},
				16800.0: {
					totalVariance: 0.021572462726128366,
				},
				16900.0: {
					totalVariance: 0.021470398325808934,
				},
				17000.0: {
					totalVariance: 0.021408157460303126,
				},
				17100.0: {
					totalVariance: 0.02131929186620808,
				},
				17200.0: {
					totalVariance: 0.02125676820686986,
				},
				17300.0: {
					totalVariance: 0.02114537077034475,
				},
				17400.0: {
					totalVariance: 0.02107113702878987,
				},
				17500.0: {
					totalVariance: 0.020984461877940702,
				},
				17600.0: {
					totalVariance: 0.020884178891481576,
				},
				17700.0: {
					totalVariance: 0.020845795849213193,
				},
				17800.0: {
					totalVariance: 0.02077138262248852,
				},
				17900.0: {
					totalVariance: 0.02078195250276435,
				},
				18000.0: {
					totalVariance: 0.020812361004377673,
				},
				18100.0: {
					totalVariance: 0.020915576722372157,
				},
				18200.0: {
					totalVariance: 0.02101493100096431,
				},
				18300.0: {
					totalVariance: 0.021111533825269067,
				},
			},
		},
		0.9863013699: {
			data: map[Strike]volatilityDataPoint{
				10000.0: {
					totalVariance: 0.09701825983220824,
				},
				10100.0: {
					totalVariance: 0.09518918752365231,
				},
				10200.0: {
					totalVariance: 0.0933697479832882,
				},
				10300.0: {
					totalVariance: 0.09161462446309071,
				},
				10400.0: {
					totalVariance: 0.08991649129209084,
				},
				10500.0: {
					totalVariance: 0.08821672328013579,
				},
				10600.0: {
					totalVariance: 0.08660984442238603,
				},
				10700.0: {
					totalVariance: 0.08500342108160086,
				},
				10800.0: {
					totalVariance: 0.08343163584655963,
				},
				10900.0: {
					totalVariance: 0.0818471331956979,
				},
				11000.0: {
					totalVariance: 0.08034015097837989,
				},
				11100.0: {
					totalVariance: 0.0788509316757638,
				},
				11200.0: {
					totalVariance: 0.0773510802868039,
				},
				11300.0: {
					totalVariance: 0.07590822587648877,
				},
				11400.0: {
					totalVariance: 0.07444353379840243,
				},
				11500.0: {
					totalVariance: 0.07303108337969472,
				},
				11600.0: {
					totalVariance: 0.07162949052799411,
				},
				11700.0: {
					totalVariance: 0.07023239287713885,
				},
				11800.0: {
					totalVariance: 0.0688490138012967,
				},
				11900.0: {
					totalVariance: 0.06750121204671461,
				},
				12000.0: {
					totalVariance: 0.0661852533835586,
				},
				12100.0: {
					totalVariance: 0.06486735308269975,
				},
				12200.0: {
					totalVariance: 0.0635764674261314,
				},
				12300.0: {
					totalVariance: 0.062275507479626645,
				},
				12400.0: {
					totalVariance: 0.06102897937842382,
				},
				12500.0: {
					totalVariance: 0.05977089592153463,
				},
				12600.0: {
					totalVariance: 0.058527441978724316,
				},
				12700.0: {
					totalVariance: 0.05732145601115049,
				},
				12800.0: {
					totalVariance: 0.056124034313306356,
				},
				12900.0: {
					totalVariance: 0.054933264334174906,
				},
				13000.0: {
					totalVariance: 0.05374331532539023,
				},
				13100.0: {
					totalVariance: 0.052606345519559755,
				},
				13200.0: {
					totalVariance: 0.05144452726153447,
				},
				13300.0: {
					totalVariance: 0.05032324688219852,
				},
				13400.0: {
					totalVariance: 0.04919616176947013,
				},
				13500.0: {
					totalVariance: 0.04812622447804416,
				},
				13600.0: {
					totalVariance: 0.04705955407858393,
				},
				13700.0: {
					totalVariance: 0.04604305450847984,
				},
				13800.0: {
					totalVariance: 0.04506727873423092,
				},
				13900.0: {
					totalVariance: 0.04412891101200605,
				},
				14000.0: {
					totalVariance: 0.04322422480797005,
				},
				14100.0: {
					totalVariance: 0.042367898910484425,
				},
				14200.0: {
					totalVariance: 0.04155608081366991,
				},
				14300.0: {
					totalVariance: 0.040767740454059676,
				},
				14400.0: {
					totalVariance: 0.040014513597459105,
				},
				14500.0: {
					totalVariance: 0.03927964446027876,
				},
				14600.0: {
					totalVariance: 0.03857871775164252,
				},
				14700.0: {
					totalVariance: 0.03790987998362033,
				},
				14800.0: {
					totalVariance: 0.03725384624297661,
				},
				14900.0: {
					totalVariance: 0.036613060417234125,
				},
				15000.0: {
					totalVariance: 0.035994579123636204,
				},
				15100.0: {
					totalVariance: 0.03538882318727915,
				},
				15200.0: {
					totalVariance: 0.03480926526501601,
				},
				15300.0: {
					totalVariance: 0.0342378402682098,
				},
				15400.0: {
					totalVariance: 0.033695720229194266,
				},
				15500.0: {
					totalVariance: 0.033178003539739945,
				},
				15600.0: {
					totalVariance: 0.032687173371277724,
				},
				15700.0: {
					totalVariance: 0.032224067772709176,
				},
				15800.0: {
					totalVariance: 0.03180714293265422,
				},
				15900.0: {
					totalVariance: 0.031407078203233955,
				},
				16000.0: {
					totalVariance: 0.031057484445091488,
				},
				16100.0: {
					totalVariance: 0.03074516620421998,
				},
				16200.0: {
					totalVariance: 0.030458310241184013,
				},
				16300.0: {
					totalVariance: 0.030212181547135408,
				},
				16400.0: {
					totalVariance: 0.029978855812170104,
				},
				16500.0: {
					totalVariance: 0.029779189070400593,
				},
				16600.0: {
					totalVariance: 0.02962114700133654,
				},
				16700.0: {
					totalVariance: 0.02948527809188708,
				},
				16800.0: {
					totalVariance: 0.029378438577535828,
				},
				16900.0: {
					totalVariance: 0.029308671391667006,
				},
				17000.0: {
					totalVariance: 0.029279530848150544,
				},
				17100.0: {
					totalVariance: 0.02924860925411085,
				},
				17200.0: {
					totalVariance: 0.029275115377800677,
				},
				17300.0: {
					totalVariance: 0.029310168936493606,
				},
				17400.0: {
					totalVariance: 0.029388804956686065,
				},
				17500.0: {
					totalVariance: 0.02948802380031361,
				},
				17600.0: {
					totalVariance: 0.02961552527828327,
				},
				17700.0: {
					totalVariance: 0.0297472028168948,
				},
				17800.0: {
					totalVariance: 0.029884485717006845,
				},
				17900.0: {
					totalVariance: 0.03006607041946437,
				},
				18000.0: {
					totalVariance: 0.0302314586838368,
				},
				18100.0: {
					totalVariance: 0.030416633793285543,
				},
				18200.0: {
					totalVariance: 0.030590015031580403,
				},
				18300.0: {
					totalVariance: 0.03079589612130674,
				},
			},
		},
	},
	SortedTenors: []Tenor{
		0.4876712329,
		0.7369863014,
		0.9863013699,
	},
}

var (
	nasdaq22divCurve = marketdata.DividendYieldCurve{
		Dividends: []marketdata.DividendPoint{
			{YearFraction: 0.4876712329, DividendZeroRate: 0.004149},
			{YearFraction: 0.7369863014, DividendZeroRate: 0.003170},
			{YearFraction: 0.9863013699, DividendZeroRate: 0.003198},
		},
	}

	nasdaq22expectedSurface = populateKappaAndVegaValues(nasdaq22withoutKappas, nasdaq22spot, nasdaq22irCurve, nasdaq22divCurve)
)
