package surfacecalibration

import (
	"math"
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func testHestonParams() marketdata.HestonParameters {
	return marketdata.HestonParameters{
		V0:    0.04,
		Kappa: 1.5,
		Theta: 0.04,
		Rho:   -0.5,
		Sigma: 0.6,
	}
}

func testExplodingHestonParams() marketdata.HestonParameters {
	return marketdata.HestonParameters{
		V0:    0.04,
		Kappa: 1.5,
		Theta: 0.04,
		Rho:   -0.5,
		Sigma: 10000.0,
	}
}

func testZeroSigmaHestonParams() marketdata.HestonParameters {
	return marketdata.HestonParameters{
		V0:    0.04,
		Kappa: 1.5,
		Theta: 0.04,
		Rho:   -0.5,
		Sigma: 0.0,
	}
}

func Test_hestonCFLogS(t *testing.T) {
	t.Parallel()

	const tol = 1e-10

	t.Run("valid values", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			u        complex128
			expected complex128
		}{
			"zero returns one": {
				u:        complex(0.0, 0.0),
				expected: complex(1.0, 0.0),
			},
			"real u 1": {
				u:        complex(1.0, 0.0),
				expected: complex(-0.10229461700565956, -0.9732115878980442),
			},
			"real u 10": {
				u:        complex(10.0, 0.0),
				expected: complex(-0.32492490583213585, 0.16386416259399908),
			},
			"u minus i": {
				u:        complex(1.0, -1.0),
				expected: complex(-6.8008826115966485, -100.11845868918951),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				actual, err := hestonCFLogS(
					tc.u,
					100.0,
					1.0,
					0.03,
					0.01,
					testHestonParams(),
				)
				require.NoError(t, err)

				assert.InDelta(t, real(tc.expected), real(actual), tol)
				assert.InDelta(t, imag(tc.expected), imag(actual), tol)
			})
		}
	})

	t.Run("finite values", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			u complex128
		}{
			"small real u": {
				u: complex(0.1, 0.0),
			},
			"real u": {
				u: complex(1.0, 0.0),
			},
			"large real u": {
				u: complex(10.0, 0.0),
			},
			"complex u": {
				u: complex(1.0, -1.0),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				actual, err := hestonCFLogS(
					tc.u,
					100.0,
					1.0,
					0.03,
					0.01,
					testHestonParams(),
				)
				require.NoError(t, err)

				require.False(t, math.IsNaN(real(actual)))
				require.False(t, math.IsNaN(imag(actual)))
				require.False(t, math.IsInf(real(actual), 0))
				require.False(t, math.IsInf(imag(actual), 0))
			})
		}
	})

	t.Run("invalid inputs return error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			S      float64
			T      float64
			params marketdata.HestonParameters
		}{
			"negative spot": {
				S:      -100.0,
				T:      1.0,
				params: testHestonParams(),
			},
			"zero spot": {
				S:      0.0,
				T:      1.0,
				params: testHestonParams(),
			},
			"zero sigma": {
				S:      100.0,
				T:      1.0,
				params: testZeroSigmaHestonParams(),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := hestonCFLogS(
					complex(1.0, 0.0),
					tc.S,
					tc.T,
					0.03,
					0.01,
					tc.params,
				)
				require.Error(t, err)
			})
		}
	})
}

func Test_hestonProbabilities(t *testing.T) {
	t.Parallel()

	const tol = 1e-10

	t.Run("valid probabilities", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		P1, P2, err := hestonProbabilities(
			100.0,
			100.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		assert.GreaterOrEqual(t, P1, 0.0)
		assert.LessOrEqual(t, P1, 1.0)
		assert.GreaterOrEqual(t, P2, 0.0)
		assert.LessOrEqual(t, P2, 1.0)
	})

	t.Run("finite probabilities", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		P1, P2, err := hestonProbabilities(
			100.0,
			110.0,
			2.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)
		require.False(t, math.IsNaN(P1))
		require.False(t, math.IsNaN(P2))
		require.False(t, math.IsInf(P1, 0))
		require.False(t, math.IsInf(P2, 0))
	})

	t.Run("exact reference values", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		P1, P2, err := hestonProbabilities(
			100.0,
			100.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		assert.InDelta(t, 0.6672864960191073, P1, tol)
		assert.InDelta(t, 0.5987806329948125, P2, tol)
	})

	t.Run("invalid inputs return non finite", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		for name, tc := range map[string]struct {
			S      float64
			K      float64
			T      float64
			params marketdata.HestonParameters
		}{
			"negative spot": {
				S:      -100.0,
				K:      100.0,
				T:      1.0,
				params: testHestonParams(),
			},
			"zero sigma": {
				S:      100.0,
				K:      100.0,
				T:      1.0,
				params: testZeroSigmaHestonParams(),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := hestonProbabilities(
					tc.S,
					tc.K,
					tc.T,
					0.03,
					0.01,
					tc.params,
					lag,
				)

				require.Error(t, err)
			})
		}
	})
}

func BenchmarkHestonCallPrice(b *testing.B) {
	b.ResetTimer()

	for b.Loop() {
		_, err := hestonCallPrice(
			100.0,
			100.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			defaultLaguerre32(),
		)
		if err != nil {
			b.Fatal(err)
		}
	}
}

func Test_hestonCallPrice(t *testing.T) {
	t.Parallel()

	const (
		tol        = 1e-10
		relaxedTol = 1e-7
	)

	t.Run("valid prices", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		for name, tc := range map[string]struct {
			S             float64
			K             float64
			T             float64
			r             float64
			q             float64
			expectedPrice float64
		}{
			"atm one year": {
				S:             100.0,
				K:             100.0,
				T:             1.0,
				r:             0.03,
				q:             0.01,
				expectedPrice: 7.956289358161776,
			},
			"itm one year": {
				S:             100.0,
				K:             90.0,
				T:             1.0,
				r:             0.03,
				q:             0.01,
				expectedPrice: 14.746977945875159,
			},
			"otm one year": {
				S:             100.0,
				K:             110.0,
				T:             1.0,
				r:             0.03,
				q:             0.01,
				expectedPrice: 3.4190455742580568,
			},
			"longer maturity": {
				S:             100.0,
				K:             100.0,
				T:             2.0,
				r:             0.03,
				q:             0.01,
				expectedPrice: 11.726493369238206,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				actual, err := hestonCallPrice(
					tc.S,
					tc.K,
					tc.T,
					tc.r,
					tc.q,
					testHestonParams(),
					lag,
				)

				require.NoError(t, err)
				require.False(t, math.IsNaN(actual))
				require.False(t, math.IsInf(actual, 0))
				assert.Greater(t, actual, 0.0)
				assert.InDelta(t, tc.expectedPrice, actual, tol)
			})
		}
	})

	t.Run("respects intrinsic lower bound", func(t *testing.T) {
		t.Parallel()

		const (
			S = 120.0
			K = 100.0
			T = 1.0
			r = 0.03
			q = 0.01
		)

		lag := defaultLaguerre96()

		price, err := hestonCallPrice(S, K, T, r, q, testHestonParams(), lag)
		require.NoError(t, err)

		lowerBound := math.Max(
			0.0,
			S*math.Exp(-q*T)-K*math.Exp(-r*T),
		)

		assert.GreaterOrEqual(t, price, lowerBound-tol)
	})

	t.Run("decreases with strike", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		priceLowStrike, err := hestonCallPrice(
			100.0,
			90.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		priceHighStrike, err := hestonCallPrice(
			100.0,
			110.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		assert.Greater(t, priceLowStrike, priceHighStrike)
	})

	t.Run("increases with spot", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		priceLowSpot, err := hestonCallPrice(
			90.0,
			100.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		priceHighSpot, err := hestonCallPrice(
			110.0,
			100.0,
			1.0,
			0.03,
			0.01,
			testHestonParams(),
			lag,
		)
		require.NoError(t, err)

		assert.Greater(t, priceHighSpot, priceLowSpot)
	})

	t.Run("laguerre32 close to laguerre96", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			S float64
			K float64
			T float64
			r float64
			q float64
		}{
			"atm": {
				S: 100.0, K: 100.0, T: 1.0, r: 0.03, q: 0.01,
			},
			"itm": {
				S: 100.0, K: 90.0, T: 1.0, r: 0.03, q: 0.01,
			},
			"otm": {
				S: 100.0, K: 110.0, T: 1.0, r: 0.03, q: 0.01,
			},
			"long maturity": {
				S: 100.0, K: 100.0, T: 2.0, r: 0.03, q: 0.01,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				price96, err := hestonCallPrice(
					tc.S, tc.K, tc.T, tc.r, tc.q,
					testHestonParams(),
					defaultLaguerre96(),
				)
				require.NoError(t, err)

				price32, err := hestonCallPrice(
					tc.S, tc.K, tc.T, tc.r, tc.q,
					testHestonParams(),
					defaultLaguerre32(),
				)
				require.NoError(t, err)

				assert.InDelta(t, price96, price32, relaxedTol)
			})
		}
	})

	t.Run("invalid inputs return non finite", func(t *testing.T) {
		t.Parallel()

		lag := defaultLaguerre96()

		for name, tc := range map[string]struct {
			S      float64
			K      float64
			T      float64
			params marketdata.HestonParameters
		}{
			"negative spot": {
				S:      -100.0,
				K:      100.0,
				T:      1.0,
				params: testHestonParams(),
			},
			"exploding params": {
				S:      100.0,
				K:      100.0,
				T:      1.0,
				params: testExplodingHestonParams(),
			},
			"zero sigma": {
				S:      100.0,
				K:      100.0,
				T:      1.0,
				params: testZeroSigmaHestonParams(),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := hestonCallPrice(
					tc.S,
					tc.K,
					tc.T,
					0.03,
					0.01,
					tc.params,
					lag,
				)
				require.Error(t, err)
			})
		}
	})
}

func Fuzz_hestonCallPrice(f *testing.F) {
	const tol = 1e-10

	for _, tc := range []struct {
		S float64
		K float64
		T float64
		r float64
		q float64
	}{
		{100.0, 100.0, 1.0, 0.03, 0.01},
		{100.0, 90.0, 1.0, 0.03, 0.01},
		{100.0, 110.0, 1.0, 0.03, 0.01},
		{100.0, 100.0, 2.0, 0.03, 0.01},
		{120.0, 100.0, 1.0, 0.03, 0.01},
		{80.0, 100.0, 1.0, 0.03, 0.01},
		{100.0, 100.0, 0.25, 0.03, 0.01},
		{100.0, 100.0, 5.0, 0.03, 0.01},
		{100.0, 100.0, 1.0, -0.01, 0.00},
		{100.0, 100.0, 1.0, 0.10, 0.05},
	} {
		f.Add(tc.S, tc.K, tc.T, tc.r, tc.q)
	}

	f.Fuzz(func(t *testing.T, S, K, T, r, q float64) {
		S = bound(S, 50.0, 150.0)
		K = S * bound(K, 0.8, 1.2)
		T = bound(T, 0.25, 3.0)
		r = bound(r, 0.0, 0.10)
		q = bound(q, 0.0, 0.05)

		_, err := hestonCallPrice(
			S,
			K,
			T,
			r,
			q,
			testHestonParams(),
			defaultLaguerre96(),
		)
		require.NoError(t, err)
	})
}

func bound(x, lo, hi float64) float64 {
	if math.IsNaN(x) {
		return lo
	}

	if math.IsInf(x, -1) {
		return lo
	}

	if math.IsInf(x, 1) {
		return hi
	}

	return math.Max(lo, math.Min(x, hi))
}
