package surfacecalibration

import (
	"fmt"
	"math"
	"math/rand/v2"
	"sort"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/interpolator"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	log "github.com/sirupsen/logrus"
	"gonum.org/v1/gonum/optimize"
)

const (
	kappaMax         = 0.06
	heavyPenalty     = 1e10
	minGamma         = -2.0
	maxEta           = 2.0
	defaultNumStarts = 1
	simplexSize      = 2e2
	epsilon          = 1e-14
)

var DefaultInitialParams = []float64{-0.5, 0.8, 0.49}

// ssviParameters represents the parameters of the SSVI surface model (Gatheral & Jacquier, 2014).
// It parameterizes total variance w(κ,θ) as:
// w(κ,θ) = θ/2 * (1 + ρ*φ(θ)*κ + sqrt[(φ(θ)*κ + ρ)² + (1-ρ²)])
// where φ(θ) is arbitrary and κ = log(K/F).
type ssviParameters struct {
	// varBackbone is the ATM-forward total variance theta(t) = w(0,t) for each tenor t.
	varBackbone varianceBackbone
	// rho in (-1, 1) is the correlation parameter.
	rho float64
	// eta in (0, 2) controls the level of skew.
	eta float64
	// gamma < 0.5 controls the power law behavior of φ(θ).
	gamma float64
}

// SSVICalibrationResult contains the calibration results and diagnostics.
type SSVICalibrationResult struct {
	Parameters ssviParameters
	RMSE       float64
	Status     optimize.Status
}

// extractVarianceBackbone extracts the ATM-forward variance backbone from the volatility surface and initializes the interpolator.
// For each tenor, it finds the two strikes with smallest kappa and interpolates to get ATM-forward (i.e. kappa = 0) variance.
// Applies PAVA to ensure non-decreasing backbone.
func extractVarianceBackbone(surface VolatilitySurface) (varianceBackbone, error) {
	varBackbone := varianceBackbone{
		data: make(map[Tenor]volatilityDataPoint),
	}

	for t, slice := range surface.Slices {
		dataPoints := make([]volatilityDataPoint, 0, len(slice.data))
		for _, dp := range slice.data {
			dataPoints = append(dataPoints, dp)
		}

		sort.Slice(dataPoints, func(i, j int) bool {
			return math.Abs(dataPoints[i].kappa) < math.Abs(dataPoints[j].kappa)
		})

		dp0, dp1 := dataPoints[0], dataPoints[1]

		if math.Abs(dp0.kappa) > kappaMax || math.Abs(dp1.kappa) > kappaMax {
			log.Warnf("Interpolation unreliable to find ATM-forward variance: skipping tenor %f", t)
			continue
		}

		// for a univariate function f, linear interpolation at 0 gives f(0) = f(x) + slope * (0 - x).
		slope := (dp1.totalVariance - dp0.totalVariance) / (dp1.kappa - dp0.kappa)
		atmVariance := dp0.totalVariance - dp0.kappa*slope

		varBackbone.data[t] = volatilityDataPoint{
			iv:            math.Sqrt(atmVariance / float64(t)),
			totalVariance: atmVariance,
			strike:        slice.forward,
		}
	}

	if len(varBackbone.data) == 0 {
		return varianceBackbone{}, errors.Bug("no valid variance backbone points extracted from surface")
	}

	increasingBackbone := pavaBackbone(varBackbone, surface.SortedTenors)

	err := increasingBackbone.buildInterpolator()
	if err != nil {
		return varianceBackbone{}, fmt.Errorf("could not build variance backbone interpolator: %w", err)
	}

	return increasingBackbone, nil
}

// pava implements the Pool Adjacent Violators Algorithm for isotonic regression.
// Ensures the output array is non-decreasing while minimizing squared distance from input.
func pava(values []float64) []float64 {
	n := len(values)
	if n == 0 {
		return nil
	}

	// block maintains [start, start+count) indices, sum of values, and count.
	type block struct {
		start int
		count int
		sum   float64
	}

	stack := make([]block, n)
	top := 0

	for i, v := range values {
		stack[top] = block{
			start: i,
			count: 1,
			sum:   v,
		}
		top++

		// Merge backwards with previous blocks that violate monotonicity
		for top >= 2 {
			prevBlock := &stack[top-2]
			newBlock := &stack[top-1]

			if prevBlock.sum/float64(prevBlock.count) <= newBlock.sum/float64(newBlock.count) {
				break
			}

			// Merge prevBlock and newBlock
			prevBlock.count += newBlock.count
			prevBlock.sum += newBlock.sum
			top--
		}
	}

	// Reconstruct result from stack
	result := make([]float64, n)

	for i := range top {
		block := stack[i]
		avg := block.sum / float64(block.count)
		end := block.start + block.count

		for j := block.start; j < end; j++ {
			result[j] = avg
		}
	}

	return result
}

// pavaBackbone applies PAVA to a variance backbone map.
// Assumes the tenors are sorted.
func pavaBackbone(varBackbone varianceBackbone, tenors []Tenor) varianceBackbone {
	n := len(varBackbone.data)

	values := make([]float64, n)
	validTenors := make([]Tenor, n)
	i := 0

	for _, t := range tenors {
		if dp, ok := varBackbone.data[t]; ok {
			values[i] = dp.totalVariance
			validTenors[i] = t
			i++
		}
	}

	increasingValues := pava(values)

	increasingVarBackbone := varianceBackbone{
		data: make(map[Tenor]volatilityDataPoint),
	}

	for i, t := range validTenors {
		increasingVarBackbone.data[t] = volatilityDataPoint{
			iv:            math.Sqrt(increasingValues[i] / float64(t)),
			totalVariance: increasingValues[i],
			strike:        varBackbone.data[t].strike,
		}
	}

	return increasingVarBackbone
}

// objectiveFunctionWrapper returns the objective (loss) function for SSVI calibration, which computes the vega weighted sum of squared errors between the model and the surface.
func objectiveFunctionWrapper(surface VolatilitySurface, varBackbone varianceBackbone) func(unregParams []float64) float64 {
	return func(unregParams []float64) float64 {
		rho, eta, gamma := regularizeParameters(unregParams)

		if !checkSSVIconstraints(rho, eta, gamma) {
			return heavyPenalty
		}

		var (
			weightedSumSquaredError float64
			diff                    float64
			modelVariance           float64
			totalWeight             float64
		)

		for t, slice := range surface.Slices {
			for _, dp := range slice.data {
				modelVariance = computeModelVariance(dp.kappa, varBackbone.value(float64(t)), rho, eta, gamma)
				diff = dp.totalVariance - modelVariance
				weightedSumSquaredError += dp.vega * diff * diff
				totalWeight += dp.vega
			}
		}

		if totalWeight > 0.0 {
			weightedSumSquaredError /= totalWeight
		}

		return weightedSumSquaredError
	}
}

func CalibrateHeston(_ VolatilitySurface, _ marketdata.HestonParameters) (*HestonCalibrationResult, error) {
	return nil, errors.Unimplemented("Heston calibration is not implemented yet")
}

// CalibrateSSVI calibrates the SSVI model to a given volatility surface.
// It first extracts and regularizes the ATM-forward variance backbone, then calibrates the parameters of the SSVI model.
func CalibrateSSVI(surface VolatilitySurface, initialParams []float64) (*SSVICalibrationResult, error) {
	varBackbone, err := extractVarianceBackbone(surface)
	if err != nil {
		return nil, fmt.Errorf("failed to extract variance backbone: %w", err)
	}

	if len(varBackbone.data) <= 2 {
		log.Warnf("only %d points in variance backbone, calibration may be unreliable", len(varBackbone.data))
	}

	problem := optimize.Problem{
		Func: objectiveFunctionWrapper(surface, varBackbone),
	}

	bestResult, err := bestResultOverRandomStarts(problem, defaultNumStarts, initialParams)
	if err != nil {
		return nil, fmt.Errorf("optimization failed: %w", err)
	}

	if bestResult.F < epsilon {
		log.Warnf("optimization converged to a very small vega weighted error: %e, results may be unreliable.", bestResult.F)
	}

	rho, eta, gamma := regularizeParameters(bestResult.X)

	return &SSVICalibrationResult{
		Parameters: ssviParameters{
			varBackbone: varBackbone,
			rho:         rho,
			eta:         eta,
			gamma:       gamma,
		},
		RMSE:   math.Sqrt(bestResult.F),
		Status: bestResult.Status,
	}, nil
}

type initialParamBuilder struct {
	rng *rand.Rand
}

func newInitialParamBuilder() *initialParamBuilder {
	const (
		seed1 = 42
		seed2 = 1024
	)

	return &initialParamBuilder{
		//nolint:gosec
		rng: rand.New(rand.NewPCG(seed1, seed2)),
	}
}

func (b *initialParamBuilder) values() []float64 {
	return []float64{
		b.value(),
		b.value(),
		b.value(),
	}
}

func (b *initialParamBuilder) value() float64 {
	const (
		bound = 1e5
		scale = 1e3
	)

	x := b.rng.NormFloat64() * scale

	if x > bound {
		return bound
	}

	if x < -bound {
		return -bound
	}

	return x
}

func bestResultOverRandomStarts(problem optimize.Problem, numStarts int, initialParams []float64) (*optimize.Result, error) {
	var (
		bestResult         *optimize.Result
		bestRMSE           = math.Inf(1)
		initialUnregParams []float64
	)

	if !isInitialParamsValid(initialParams[0], initialParams[1], initialParams[2]) {
		return nil, errors.Bug("provided initial parameters rho: %f, eta: %f, gamma: %f are not within valid ranges", initialParams[0], initialParams[1], initialParams[2])
	}

	initialUnregParams = unregularizeParameters(initialParams)

	result, err := optimize.Minimize(problem, initialUnregParams, nil, &optimize.NelderMead{
		SimplexSize: simplexSize,
	})
	if err != nil {
		log.Warnf("optimization failed with default initial guess: %v", err)
	}

	if result != nil {
		rho, eta, gamma := regularizeParameters(result.X)
		if checkSSVIconstraints(rho, eta, gamma) {
			bestRMSE = result.F
			bestResult = result
		}
	}

	initialParamsBuilder := newInitialParamBuilder()

	for i := range numStarts - 1 {
		initialUnregParams = initialParamsBuilder.values()

		result, err := optimize.Minimize(problem, initialUnregParams, nil, &optimize.NelderMead{
			SimplexSize: simplexSize,
		})
		if err != nil {
			log.Warnf("optimization failed with random initial guess %d: %v", i, err)
			continue
		}

		rho, eta, gamma := regularizeParameters(result.X)

		if result.F < bestRMSE && checkSSVIconstraints(rho, eta, gamma) {
			bestRMSE = result.F
			bestResult = result
		}
	}

	if bestResult == nil {
		return nil, errors.Bug("all optimization attempts failed")
	}

	return bestResult, nil
}

// regularizeParameters transforms unconstrained optimization parameters into valid SSVI parameters.
// After regularization, eta is in (0, maxEta), rho is in (-1,1) and gamma is in (minGamma, 0.5), exclusive.
func regularizeParameters(unregParams []float64) (float64, float64, float64) {
	rho := mapValueToOneMinusOne(unregParams[0])
	eta := maxEta * 0.5 * (1 + mapValueToOneMinusOne(unregParams[1]))
	gamma := 0.5 + (minGamma-0.5)*0.5*(1+mapValueToOneMinusOne(unregParams[2]))

	return rho, eta, gamma
}

// unregularizeParameters transforms valid SSVI parameters back to the unconstrained space for optimization.
func unregularizeParameters(params []float64) []float64 {
	unregRho := mapValueToInfMinusInf(params[0])
	unregEta := mapValueToInfMinusInf(2.0*params[1]/maxEta - 1.0)
	unregGamma := mapValueToInfMinusInf(2.0*(params[2]-0.5)/(minGamma-0.5) - 1.0)

	return []float64{unregRho, unregEta, unregGamma}
}

func mapValueToOneMinusOne(x float64) float64 {
	return x / (1.0 + math.Abs(x))
}

func mapValueToInfMinusInf(y float64) float64 {
	return y / (1.0 - math.Abs(y))
}

// computePhi computes φ(θ) = η * θ^(-γ) * (1+θ)^(γ-1).
// This parametric form for φ(θ) is used in (Gatheral & Jacquier, 2014, p.16-17) to ensure flexibility while satisfying necessary conditions for no-arbitrage.
func computePhi(theta, eta, gamma float64) float64 {
	return eta * math.Pow(theta, -gamma) * math.Pow(1.0+theta, gamma-1.0)
}

func computeModelVariance(kappa, theta, rho, eta, gamma float64) float64 {
	phi := computePhi(theta, eta, gamma)
	phiKappa := phi*kappa + rho

	return (theta / 2.0) * (1.0 + rho*phi*kappa + math.Sqrt(phiKappa*phiKappa+1.0-rho*rho))
}

// checkSSVIconstraints verifies that SSVI parameters satisfy arbitrage-free constraints.
func checkSSVIconstraints(rho, eta, gamma float64) bool {
	absRho := math.Abs(rho)

	if eta*eta*(1.0+absRho) > 4.0 {
		return false
	}

	if absRho > 1e-14 && 1.0-gamma > 1.0/(rho*rho)*(1.0+math.Sqrt(1.0-rho*rho)) {
		return false
	}

	return true
}

// isInitialParamsValid verifies that SSVI parameters are within valid ranges.
// rho must be in (-1, 1), eta in (0, maxEta) and gamma in (minGamma, 0.5), exclusive.
func isInitialParamsValid(rho, eta, gamma float64) bool {
	absRho := math.Abs(rho)

	if absRho >= 1.0 {
		return false
	}

	if eta <= 0.0 || eta >= maxEta {
		return false
	}

	if gamma <= minGamma || gamma >= 0.5 {
		return false
	}

	return true
}

// ComputeSSVIsurfaceOnGrid computes the SSVI surface on a specified grid of tenors and strikes given the calibrated parameters.
func ComputeSSVIsurfaceOnGrid(params ssviParameters, spot float64, tenors, strikes []float64, irCurve termstructure.TermStructure, divCurve marketdata.DividendYieldCurve) (marketdata.VolatilitySurface, error) {
	Data := make([][]float64, len(tenors))

	var (
		r             float64
		q             float64
		fwd           float64
		err           error
		theta         float64
		modelVariance float64
		divInterp     *interpolator.PiecewiseLinearThreshold
	)

	if params.varBackbone.interpolator == nil {
		return marketdata.VolatilitySurface{}, errors.Bug("backbone interpolator is missing")
	}

	divInterp, err = marketdata.NewZeroDividendInterpolator(divCurve)
	if err != nil {
		return marketdata.VolatilitySurface{}, fmt.Errorf("could not create dividend interpolator: %w", err)
	}

	for i, t := range tenors {
		Data[i] = make([]float64, len(strikes))

		r = irCurve.Value(t)

		q = divInterp.Value(t)
		fwd = spot * math.Exp((r-q)*t)
		theta = params.varBackbone.value(t)

		for j, k := range strikes {
			kappa := math.Log(k / fwd)
			modelVariance = computeModelVariance(kappa, theta, params.rho, params.eta, params.gamma)
			Data[i][j] = math.Sqrt(modelVariance / t)
		}
	}

	return marketdata.VolatilitySurface{
		Data:               Data,
		TenorYearFractions: tenors,
		Strikes:            strikes,
	}, nil
}
