package surfacecalibration

import (
	"math"
	"testing"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	log "github.com/sirupsen/logrus"
	"github.com/stretchr/testify/require"
)

func Test_pava(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	for name, tc := range map[string]struct {
		input    []float64
		expected []float64
	}{
		"Long already non-decreasing": {
			input:    []float64{0.5, 1.2, 2.0, 2.8, 3.1, 3.9, 4.2, 5.0},
			expected: []float64{0.5, 1.2, 2.0, 2.8, 3.1, 3.9, 4.2, 5.0},
		},
		"Late single violation": {
			input:    []float64{0.0, 1.0, 2.0, 3.5, 3.2, 4.0, 5.0, 5.5, 6.0},
			expected: []float64{0.0, 1.0, 2.0, 3.35, 3.35, 4.0, 5.0, 5.5, 6.0},
		},
		"Three-element pooled block": {
			input:    []float64{2.0, 2.5, 3.0, 2.8, 2.6, 3.4, 3.8, 4.1, 4.5},
			expected: []float64{2.0, 2.5, 2.8, 2.8, 2.8, 3.4, 3.8, 4.1, 4.5},
		},
		"Middle valley requiring back-merge": {
			input:    []float64{1.0, 2.0, 4.0, 3.0, 2.0, 5.0, 6.0, 7.0},
			expected: []float64{1.0, 2.0, 3.0, 3.0, 3.0, 5.0, 6.0, 7.0},
		},
		"Large prefix collapse": {
			input:    []float64{5.0, 4.5, 4.0, 3.5, 4.2, 4.8, 5.1, 5.4, 5.8},
			expected: []float64{4.24, 4.24, 4.24, 4.24, 4.24, 4.8, 5.1, 5.4, 5.8},
		},
		"Deep dip spanning five points": {
			input:    []float64{1.0, 1.8, 2.6, 3.4, 2.0, 1.5, 2.2, 3.0, 3.8},
			expected: []float64{1.0, 1.8, 2.34, 2.34, 2.34, 2.34, 2.34, 3.0, 3.8},
		},
		"Alternating violations": {
			input:    []float64{3.0, 1.0, 2.0, 4.0, 3.0, 5.0, 4.0, 6.0, 7.0},
			expected: []float64{2.0, 2.0, 2.0, 3.5, 3.5, 4.5, 4.5, 6.0, 7.0},
		},
		"Nested merges with fractional averages": {
			input:    []float64{0.5, 1.5, 2.5, 3.5, 2.5, 2.0, 4.0, 4.5, 4.2, 5.0},
			expected: []float64{0.5, 1.5, 2.5, 2.6666666667, 2.6666666667, 2.6666666667, 4.0, 4.35, 4.35, 5.0},
		},
		"Long descending prefix then recovery": {
			input:    []float64{10.0, 9.0, 8.0, 7.0, 6.0, 7.0, 8.0, 9.0, 10.0},
			expected: []float64{7.8333333333, 7.8333333333, 7.8333333333, 7.8333333333, 7.8333333333, 7.8333333333, 8.0, 9.0, 10.0},
		},
		"Repeated pairwise violations": {
			input:    []float64{1.0, 3.0, 2.0, 4.0, 3.5, 5.0, 4.5, 6.0, 5.5, 7.0},
			expected: []float64{1.0, 2.5, 2.5, 3.75, 3.75, 4.75, 4.75, 5.75, 5.75, 7.0},
		},
		"Cascading back-merges with final dip": {
			input:    []float64{1.0, 2.0, 3.0, 4.0, 3.2, 2.8, 3.1, 3.6, 3.4, 3.3, 3.5, 3.7, 3.6, 3.5, 3.4},
			expected: []float64{1.0, 2.0, 3.0, 3.275, 3.275, 3.275, 3.275, 3.433333333333333, 3.433333333333333, 3.433333333333333, 3.5, 3.55, 3.55, 3.55, 3.55},
		},
		"Massive late dip causing cascade across most of array": {
			input:    []float64{1.0, 2.0, 3.0, 4.0, 5.0, 4.6, 4.2, 4.8, 5.1, 5.4, 5.2, 5.0, 4.9, 4.7, 4.5, 4.3},
			expected: []float64{1.0, 2.0, 3.0, 4.0, 4.6, 4.6, 4.6, 4.8, 4.8875, 4.8875, 4.8875, 4.8875, 4.8875, 4.8875, 4.8875, 4.8875},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			result := pava(tc.input)
			require.Len(t, result, len(tc.expected))

			for i := range result {
				require.InDelta(t, tc.expected[i], result[i], tol)
			}

			for i := 1; i < len(result); i++ {
				require.GreaterOrEqual(t, result[i], result[i-1])
			}
		})
	}
}

func Test_checkSSVIconstraints(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		rho      float64
		eta      float64
		gamma    float64
		expected bool
	}{
		"Valid parameters": {
			rho:      -0.3,
			eta:      1.0,
			gamma:    0.2,
			expected: true,
		},
		"Eta*(1+|rho|) too large": {
			rho:      0.5,
			eta:      3.0,
			gamma:    0.2,
			expected: false,
		},
		"Valid with negative gamma": {
			rho:      -0.5,
			eta:      1.5,
			gamma:    -0.1,
			expected: true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			result := checkSSVIconstraints(tc.rho, tc.eta, tc.gamma)
			require.Equal(t, tc.expected, result)
		})
	}
}

// makeDP is a helper function to construct a volatilityDataPoint.
func makeDP(spot, k, r, q, iv, tf float64) volatilityDataPoint {
	fwd := spot * math.Exp((r-q)*tf)
	kappa := math.Log(k / fwd)
	d1 := vanillaoptionpricer.DPlus(spot, k, iv, tf, tf, r, q)

	return volatilityDataPoint{
		iv:            iv,
		totalVariance: iv * iv * tf,
		kappa:         kappa,
		strike:        k,
		vega:          vanillaoptionpricer.EuropeanBlackScholesVega(spot, q, tf, d1),
	}
}

// buildSlice is a helper function to construct a volatilitySurfaceSlice.
func buildSlice(spot, r, q, tf float64, strikes []float64, vols []float64) volatilitySurfaceSlice {
	data := make(map[Strike]volatilityDataPoint)

	for i, k := range strikes {
		if !math.IsNaN(vols[i]) {
			data[Strike(k)] = makeDP(spot, k, r, q, vols[i], tf)
		}
	}

	return volatilitySurfaceSlice{
		data:    data,
		tenor:   tf,
		forward: spot * math.Exp((r-q)*tf),
	}
}

// buildSurface is a helper function to convert a marketdata.VolatilitySurface into a volatilitySurface.
func buildSurface(sd *marketdata.VolatilitySurface, spot float64, irCurve termstructure.TermStructure, dividendCurve marketdata.DividendYieldCurve) VolatilitySurface {
	Tenors := make([]Tenor, len(sd.TenorYearFractions))
	for i, t := range sd.TenorYearFractions {
		Tenors[i] = Tenor(t)
	}

	divInterp, err := marketdata.NewZeroDividendInterpolator(dividendCurve)
	if err != nil {
		log.Warnf("could not create dividend interpolator: %v", err)
		return VolatilitySurface{}
	}

	slices := make(map[Tenor]volatilitySurfaceSlice)

	for i, tn := range Tenors {
		tf := float64(tn)

		r := irCurve.Value(tf)

		slices[tn] = buildSlice(spot, r, divInterp.Value(tf), tf, sd.Strikes, sd.Data[i])
	}

	return VolatilitySurface{
		Slices:       slices,
		SortedTenors: Tenors,
	}
}

func Test_extractVarianceBackbone(t *testing.T) {
	t.Parallel()

	const spot = 100.0

	var (
		testIRcurve = termstructure.TermStructure{
			Data: map[termstructure.Tenor]float64{
				"Y1": 0.02,
			},
		}
		testDivCurve = marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{YearFraction: 1.0, Dividend: 0.01},
			},
		}
	)

	err := testIRcurve.BuildInterpolator()
	require.NoError(t, err)

	for name, tc := range map[string]struct {
		expectedBackboneData map[Tenor]float64
		surfaceData          *marketdata.VolatilitySurface
		surface              *VolatilitySurface
	}{
		"Two Tenors with volatility smile": {
			expectedBackboneData: map[Tenor]float64{
				0.25: 0.010258804042683195,
				0.50: 0.02645000,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.25, 0.22, 0.20, 0.21, 0.23},
					{0.28, 0.24, 0.23, 0.23, 0.25},
				},
			},
		},
		"Three Tenors with skew": {
			expectedBackboneData: map[Tenor]float64{
				0.25: 0.010258804042683195,
				0.50: 0.02645000,
				1.00: 0.0625,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.25, 0.22, 0.20, 0.21, 0.23},
					{0.28, 0.24, 0.23, 0.23, 0.25},
					{0.30, 0.26, 0.25, 0.25, 0.27},
				},
			},
		},
		"Single Tenor": {
			expectedBackboneData: map[Tenor]float64{
				0.50: 0.02645000,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.28, 0.24, 0.23, 0.23, 0.25},
				},
			},
		},
		"Four Tenors with increasing term structure": {
			expectedBackboneData: map[Tenor]float64{
				0.25: 0.010258804042683195,
				0.50: 0.025998544950101624,
				1.00: 0.06765083167876808,
				2.00: 0.2009791831772695,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00, 2.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.22, 0.21, 0.20, 0.21, 0.22},
					{0.24, 0.23, 0.226, 0.23, 0.24},
					{0.27, 0.26, 0.25, 0.26, 0.27},
					{0.32, 0.31, 0.30, 0.31, 0.32},
				},
			},
		},
		"Wide Strike range": {
			expectedBackboneData: map[Tenor]float64{
				0.50: 0.02645000,
				1.00: 0.0625,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50, 1.00},
				Strikes:            []float64{80.0, 90.0, 95.0, 98.0, 100.0, 102.0, 105.0, 110.0, 120.0},
				Data: [][]float64{
					{0.35, 0.30, 0.28, 0.24, 0.23, 0.23, 0.25, 0.27, 0.32},
					{0.38, 0.32, 0.30, 0.26, 0.25, 0.25, 0.27, 0.29, 0.34},
				},
			},
		},
		"Backbone extraction fails at one tenor": {
			expectedBackboneData: map[Tenor]float64{
				0.50: 0.02645000,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50, 1.00},
				Strikes:            []float64{80.0, 90.0, 95.0, 98.0, 100.0, 102.0, 105.0, 110.0, 120.0},
				Data: [][]float64{
					{0.35, 0.30, 0.28, 0.24, 0.23, 0.23, 0.25, 0.27, 0.32},
					{0.38, 0.32, math.NaN(), math.NaN(), math.NaN(), math.NaN(), math.NaN(), 0.29, 0.34},
				},
			},
		},
		"Non-monotonic backbone requiring PAVA": {
			expectedBackboneData: map[Tenor]float64{
				0.25: 0.010258804042683195,
				0.50: 0.039132891086261716,
				1.00: 0.039132891086261716,
				2.00: 0.1502500283038906,
			},
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00, 2.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.22, 0.21, 0.20, 0.21, 0.22},
					{0.32, 0.30, 0.28, 0.30, 0.32},
					{0.20, 0.19, 0.18, 0.19, 0.20},
					{0.28, 0.26, 0.255, 0.26, 0.28},
				},
			},
		},
		"nasdaq 2021-06-21": {
			expectedBackboneData: map[Tenor]float64{
				0.4904109589: 0.021133,
				0.7397260274: 0.031699,
				0.9890410959: 0.042434,
			},
			surface: &nasdaq21expectedSurface,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			if tc.surface == nil {
				volSurface := buildSurface(tc.surfaceData, spot, testIRcurve, testDivCurve)
				tc.surface = &volSurface
			}

			backbone, err := extractVarianceBackbone(*tc.surface)
			require.NoError(t, err)
			require.NotEmpty(t, backbone.data)
			require.Len(t, backbone.data, len(tc.expectedBackboneData))

			for tn, expectedVar := range tc.expectedBackboneData {
				actualDP, ok := backbone.data[tn]
				require.True(t, ok)
				require.InDelta(t, expectedVar, actualDP.totalVariance, 1e-6)
			}
		})
	}
}

func Test_CalibrateSSVI(t *testing.T) {
	t.Parallel()

	const (
		testSpot = 100.0
		tol      = 1e-4
	)

	var (
		testIRcurve = termstructure.TermStructure{
			Data: map[termstructure.Tenor]float64{
				"Y1": 0.02,
			},
		}
		testDivCurve = marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{YearFraction: 1.0, Dividend: 0.01},
			},
		}
	)

	for name, tc := range map[string]struct {
		surfaceData     *marketdata.VolatilitySurface
		irCurve         termstructure.TermStructure
		dividendCurve   marketdata.DividendYieldCurve
		spot            float64
		surface         *VolatilitySurface
		expectedResults *SSVICalibrationResult
		expectError     bool
	}{
		"Two Tenors with volatility smile": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.25, 0.22, 0.20, 0.21, 0.23},
					{0.28, 0.24, 0.23, 0.23, 0.25},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
		},
		"Three Tenors with skew": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.25, 0.22, 0.20, 0.21, 0.23},
					{0.28, 0.24, 0.23, 0.23, 0.25},
					{0.30, 0.26, 0.25, 0.25, 0.27},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
		},
		"Single Tenor": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.28, 0.24, 0.23, 0.23, 0.25},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
		},
		"Four Tenors with increasing term structure": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00, 2.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.22, 0.21, 0.20, 0.21, 0.22},
					{0.24, 0.23, 0.226, 0.23, 0.24},
					{0.27, 0.26, 0.25, 0.26, 0.27},
					{0.32, 0.31, 0.30, 0.31, 0.32},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
		},
		"Wide Strike range": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50, 1.00},
				Strikes:            []float64{80.0, 90.0, 95.0, 98.0, 100.0, 102.0, 105.0, 110.0, 120.0},
				Data: [][]float64{
					{0.35, 0.30, 0.28, 0.24, 0.23, 0.23, 0.25, 0.27, 0.32},
					{0.38, 0.32, 0.30, 0.26, 0.25, 0.25, 0.27, 0.29, 0.34},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
			expectedResults: &SSVICalibrationResult{
				Parameters: ssviParameters{
					rho:   2.144592e-11,
					eta:   1.999999,
					gamma: 0.499999,
				},
				RMSE: 0.017599,
			},
		},
		"Backbone extraction fails at one tenor": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.50, 1.00},
				Strikes:            []float64{80.0, 90.0, 95.0, 98.0, 100.0, 102.0, 105.0, 110.0, 120.0},
				Data: [][]float64{
					{0.35, 0.30, 0.28, 0.24, 0.23, 0.23, 0.25, 0.27, 0.32},
					{0.38, 0.32, math.NaN(), math.NaN(), math.NaN(), math.NaN(), math.NaN(), 0.29, 0.34},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
			expectedResults: &SSVICalibrationResult{
				Parameters: ssviParameters{
					rho:   1.909661e-11,
					eta:   1.999999,
					gamma: 0.499999,
				},
				RMSE: 0.026137,
			},
		},
		"Non-monotonic backbone requiring PAVA": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{0.25, 0.50, 1.00, 2.00},
				Strikes:            []float64{95.0, 98.0, 100.0, 102.0, 105.0},
				Data: [][]float64{
					{0.22, 0.21, 0.20, 0.21, 0.22},
					{0.32, 0.30, 0.28, 0.30, 0.32},
					{0.20, 0.19, 0.18, 0.19, 0.20},
					{0.28, 0.26, 0.255, 0.26, 0.28},
				},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
		},
		"Empty surface should error": {
			surfaceData: &marketdata.VolatilitySurface{
				TenorYearFractions: []float64{},
				Strikes:            []float64{},
				Data:               [][]float64{},
			},
			irCurve:       testIRcurve,
			dividendCurve: testDivCurve,
			spot:          testSpot,
			expectError:   true,
		},
		"nasdaq 2021-06-21": {
			surface:       &nasdaq21expectedSurface,
			spot:          nasdaq21spot,
			irCurve:       nasdaq21irCurve,
			dividendCurve: nasdaq21divCurve,
			expectedResults: &SSVICalibrationResult{
				Parameters: ssviParameters{
					rho:   -0.553492,
					eta:   1.604631,
					gamma: 0.377890,
				},
				RMSE: 0.000898,
			},
		},
		"nasdaq 2021-06-22": {
			surface:       &nasdaq22expectedSurface,
			spot:          nasdaq22spot,
			irCurve:       nasdaq22irCurve,
			dividendCurve: nasdaq22divCurve,
			expectedResults: &SSVICalibrationResult{
				Parameters: ssviParameters{
					rho:   -0.554403,
					eta:   1.604220,
					gamma: 0.376878,
				},
				RMSE: 0.001106,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			var surface VolatilitySurface
			if tc.surface == nil {
				err := tc.irCurve.BuildInterpolator()
				require.NoError(t, err)

				surface = buildSurface(tc.surfaceData, tc.spot, tc.irCurve, tc.dividendCurve)
			} else {
				surface = *tc.surface
			}

			result, err := CalibrateSSVI(surface, DefaultInitialParams)

			if tc.expectError {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.NotNil(t, result)
			require.True(t, checkSSVIconstraints(result.Parameters.rho, result.Parameters.eta, result.Parameters.gamma))
			require.Greater(t, result.RMSE, 0.0)

			if tc.expectedResults != nil {
				require.InDelta(t, tc.expectedResults.Parameters.rho, result.Parameters.rho, tol)
				require.InDelta(t, tc.expectedResults.Parameters.eta, result.Parameters.eta, tol)
				require.InDelta(t, tc.expectedResults.Parameters.gamma, result.Parameters.gamma, tol)
				require.InDelta(t, tc.expectedResults.RMSE, result.RMSE, tol)
				require.False(t, result.Status.Early())
			}
		})
	}
}

func Test_computePhi(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		theta float64
		eta   float64
		gamma float64
	}{
		"Standard parameters": {
			theta: 0.04,
			eta:   1.0,
			gamma: 0.2,
		},
		"Negative gamma": {
			theta: 0.05,
			eta:   1.5,
			gamma: -0.1,
		},
		"Gamma near limit": {
			theta: 0.06,
			eta:   0.8,
			gamma: 0.49,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			phi := computePhi(tc.theta, tc.eta, tc.gamma)

			require.Greater(t, phi, 0.0, "phi should be positive for positive theta and eta")
			require.False(t, math.IsNaN(phi), "phi should not be NaN")
			require.False(t, math.IsInf(phi, 0), "phi should not be infinite")
		})
	}
}

func Test_ComputeSSVIsurfaceOnGrid(t *testing.T) {
	t.Parallel()

	const (
		testSpot = 100.0
		tol      = 1e-6
	)

	var (
		testIRcurve = termstructure.TermStructure{
			Data: map[termstructure.Tenor]float64{
				"Y1": 0.02,
			},
		}
		testDivCurve = marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{YearFraction: 1.0, Dividend: 0.01},
			},
		}
	)

	for name, tc := range map[string]struct {
		params   ssviParameters
		spot     float64
		tenors   []float64
		strikes  []float64
		irCurve  termstructure.TermStructure
		divCurve marketdata.DividendYieldCurve
	}{
		"Standard grid": {
			params: ssviParameters{
				varBackbone: varianceBackbone{
					data: map[Tenor]volatilityDataPoint{
						Tenor(0.25): {totalVariance: 0.01, strike: 100.0},
						Tenor(0.50): {totalVariance: 0.0264, strike: 100.0},
						Tenor(1.00): {totalVariance: 0.0625, strike: 100.0},
					},
				},
				rho:   -0.5,
				eta:   1.5,
				gamma: 0.3,
			},
			spot:     testSpot,
			tenors:   []float64{0.25, 0.50, 1.00},
			strikes:  []float64{95.0, 100.0, 105.0},
			irCurve:  testIRcurve,
			divCurve: testDivCurve,
		},
		"Single tenor and strike": {
			params: ssviParameters{
				varBackbone: varianceBackbone{
					data: map[Tenor]volatilityDataPoint{
						Tenor(1.00): {totalVariance: 0.0625, strike: 100.0},
					},
				},
				rho:   -0.3,
				eta:   1.0,
				gamma: 0.2,
			},
			spot:     testSpot,
			tenors:   []float64{1.00},
			strikes:  []float64{100.0},
			irCurve:  testIRcurve,
			divCurve: testDivCurve,
		},
		"Wide strike range": {
			params: ssviParameters{
				varBackbone: varianceBackbone{
					data: map[Tenor]volatilityDataPoint{
						Tenor(0.50): {totalVariance: 0.0264, strike: 100.0},
						Tenor(1.00): {totalVariance: 0.0625, strike: 100.0},
					},
				},
				rho:   -0.6,
				eta:   2.0,
				gamma: 0.4,
			},
			spot:     testSpot,
			tenors:   []float64{0.50, 1.00},
			strikes:  []float64{80.0, 90.0, 100.0, 110.0, 120.0},
			irCurve:  testIRcurve,
			divCurve: testDivCurve,
		},
		"Multiple tenors": {
			params: ssviParameters{
				varBackbone: varianceBackbone{
					data: map[Tenor]volatilityDataPoint{
						Tenor(0.25): {totalVariance: 0.01, strike: 100.0},
						Tenor(0.50): {totalVariance: 0.0264, strike: 100.0},
						Tenor(1.00): {totalVariance: 0.0625, strike: 100.0},
						Tenor(2.00): {totalVariance: 0.18, strike: 100.0},
					},
				},
				rho:   -0.4,
				eta:   1.2,
				gamma: 0.25,
			},
			spot:     testSpot,
			tenors:   []float64{0.25, 0.50, 1.00, 2.00},
			strikes:  []float64{95.0, 98.0, 100.0, 102.0, 105.0},
			irCurve:  testIRcurve,
			divCurve: testDivCurve,
		},
		"Positive rho": {
			params: ssviParameters{
				varBackbone: varianceBackbone{
					data: map[Tenor]volatilityDataPoint{
						Tenor(0.50): {totalVariance: 0.0264, strike: 100.0},
						Tenor(1.00): {totalVariance: 0.0625, strike: 100.0},
					},
				},
				rho:   0.3,
				eta:   0.8,
				gamma: 0.15,
			},
			spot:     testSpot,
			tenors:   []float64{0.50, 1.00},
			strikes:  []float64{95.0, 100.0, 105.0},
			irCurve:  testIRcurve,
			divCurve: testDivCurve,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			err := tc.irCurve.BuildInterpolator()
			require.NoError(t, err)

			err = tc.params.varBackbone.buildInterpolator()
			require.NoError(t, err)

			surface, err := ComputeSSVIsurfaceOnGrid(tc.params, tc.spot, tc.tenors, tc.strikes, tc.irCurve, tc.divCurve)
			require.NoError(t, err)
			require.NotNil(t, surface)
			require.Len(t, surface.TenorYearFractions, len(tc.tenors))
			require.Len(t, surface.Strikes, len(tc.strikes))
			require.Len(t, surface.Data, len(tc.tenors))

			for i := range surface.Data {
				require.Len(t, surface.Data[i], len(tc.strikes))
			}

			for i, tn := range tc.tenors {
				require.InDelta(t, tn, surface.TenorYearFractions[i], tol)
			}

			for i, k := range tc.strikes {
				require.InDelta(t, k, surface.Strikes[i], tol)
			}

			for i := range tc.tenors {
				for j := range tc.strikes {
					iv := surface.Data[i][j]
					require.Greater(t, iv, 0.0)
					require.False(t, math.IsNaN(iv))
					require.False(t, math.IsInf(iv, 0))
				}
			}
		})
	}
}
