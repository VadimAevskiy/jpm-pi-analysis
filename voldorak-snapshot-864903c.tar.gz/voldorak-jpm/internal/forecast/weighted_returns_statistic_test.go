package forecast

import (
	"crypto/rand"
	"math/big"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_weightedReturnsStatistic(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		weights  []float64
		returns  marketdata.ReturnEntries
		expected float64
	}{
		"four uniform weights/five matching dates": {
			weights: []float64{0.25, 0.25, 0.25, 0.25},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 6),
					Value: 0.02,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 7),
					Value: 0.0,
					Days:  1,
				},
			},
			expected: 1.5e-4,
		},
		"five uniform weights/three matching dates": {
			weights: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.01,
					Days:  1,
				},
			},
			expected: 1.0e-4,
		},
		"five uniform weights/missing return on business day": {
			weights: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: -0.02,
					Days:  1,
				},
			},
			expected: 2.5e-4,
		},
		"five uniform weights/returns applied on multiple business days": {
			weights: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  2,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.02,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: -0.01,
					Days:  1,
				},
			},
			expected: 1.5e-4,
		},
		"four non-uniform weights/return on multiple days": {
			weights: []float64{0.5, 0.25, 0.125, 0.125},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.02,
					Days:  3,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.01,
					Days:  1,
				},
			},
			expected: 7.0e-4 / 6.0,
		},
		"four non-uniform weights/missing data on day": {
			weights: []float64{0.5, 0.25, 0.125, 0.125},
			returns: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: -0.02,
					Days:  2,
				},
			},
			expected: 13.0e-4 / 7.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			estimator := &sampleSecondMomentEstimator{}
			got := weightedReturnsStatistic(tc.weights, tc.returns, estimator)
			assert.InDelta(t, tc.expected, got, 1.0e-15)
		})
	}
}

func Benchmark_weightedReturnsStatistic(b *testing.B) {
	var (
		start     = date.New(2006, time.January, 1)
		end       = date.New(2020, time.January, 1)
		cal       = calendar.New(calendar.BusinessDays)
		weights   = NewMovingAverage().ComputeWeights(30)
		returns   = make(marketdata.ReturnEntries, 0, end.Sub(start))
		estimator = &sampleSecondMomentEstimator{}
	)

	// Generate random returns for all dates in range
	for date := cal.Add(start, 0); !date.After(end); date = cal.Add(date, 1) {
		nBig, err := rand.Int(rand.Reader, big.NewInt(1<<53))
		require.NoError(b, err)

		returns = append(returns, &marketdata.ReturnEntry{
			Date:  date,
			Value: float64(nBig.Int64()) / (1 << 53),
			Days:  1,
		})
	}

	b.ResetTimer()

	for b.Loop() {
		_ = weightedReturnsStatistic(weights, returns, estimator)
	}
}
