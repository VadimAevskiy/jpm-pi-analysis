package forecast

import (
	"fmt"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

type parameters struct {
	from       *date.Date
	to         *date.Date
	conditions []ReturnsValidityCondition
}

func buildDefaultParameters() *parameters {
	p := &parameters{}
	for _, opt := range []Option{
		WithConditionsOnReturns(
			ReturnsNotEmpty,
		),
	} {
		opt(p)
	}

	return p
}

// Option allows to configure the forecast parameters.
type Option func(*parameters)

// WithFrom sets the from date of the time window.
func WithFrom(from date.Date) Option {
	return func(p *parameters) {
		p.from = &from
	}
}

// WithTo sets the to date of the time window.
func WithTo(to date.Date) Option {
	return func(p *parameters) {
		p.to = &to
	}
}

// WithConditionsOnReturns sets further conditions on input returns
// to be verified before estimating a volatility forecast.
func WithConditionsOnReturns(conditions ...ReturnsValidityCondition) Option {
	return func(p *parameters) {
		p.conditions = append(p.conditions, conditions...)
	}
}

// ReturnsValidityCondition defines a condition the input returns must verify.
type ReturnsValidityCondition func(*marketdata.ReturnsTimeseries) error

var (
	// ReturnsNotEmpty returns an error if there are no input returns.
	ReturnsNotEmpty ReturnsValidityCondition = func(returns *marketdata.ReturnsTimeseries) error {
		if len(returns.Entries) == 0 {
			return errors.SetTag(errors.NotFound("returns cannot be empty"), tag.NotEnoughData)
		}

		return nil
	}

	// AtLeastNReturns verifies that there are at least N returns.
	// Once restrictions are available on returns time series, this check
	// may be improved by counting how many returns there are in a time window.
	AtLeastNReturns = func(n int) ReturnsValidityCondition {
		return func(returns *marketdata.ReturnsTimeseries) error {
			if len(returns.Entries) < n {
				return errors.SetTag(errors.NotFound("expecting at least %d returns, but got %d", n, len(returns.Entries)), tag.NotEnoughData)
			}

			return nil
		}
	}
)

// ComputeVolatility computes a volatility forecast timeseries from an input spot timeseries
// and an input set of forecast parameters.
func ComputeVolatility(
	returns *marketdata.ReturnsTimeseries,
	forecaster Forecaster,
	horizoner Horizoner,
	opts ...Option,
) (*marketdata.Timeseries, error) {
	p := buildDefaultParameters()
	for _, opt := range opts {
		opt(p)
	}

	for _, condition := range p.conditions {
		if err := condition(returns); err != nil {
			return nil, fmt.Errorf("violated condition on input returns: %w", err)
		}
	}

	from, to := computeTimeWindow(returns, p)

	return weightedVolatilityTimeseries(forecaster, returns, from, to, horizoner(returns.Calendar))
}

// computeTimeWindow computes the forecast time window:
//
// - if any of from and to were optionally set, they will be used
// once constrained to the returns calendar;
//
// - the natural from-to window of the input returns will be used
// otherwise.
func computeTimeWindow(returns *marketdata.ReturnsTimeseries, p *parameters) (date.Date, date.Date) {
	from := returns.At(0).Date
	if p.from != nil {
		from = returns.Calendar.LatestBefore(*p.from)
	}

	to := returns.Last().Date
	if p.to != nil {
		to = returns.Calendar.LatestBefore(*p.to)
	}

	return from, to
}
