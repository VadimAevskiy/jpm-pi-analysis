package forecast

import "gonum.org/v1/gonum/floats"

// normalize scales the input slice by its sum:
// x_i <-- x_i / (sum_j x_j).
//
// The input slice must be non-empty and constituted
// by positive entries. If x is empty, the function
// has no effect.
func normalize(x []float64) {
	floats.Scale(1.0/floats.Sum(x), x)
}
