package forecast

import (
	"testing"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/stretchr/testify/assert"
)

func Test_computeAnnualization(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		cal        *calendar.Calendar
		forecaster Forecaster
		expected   float64
	}{
		"business days/moving average": {
			cal:        calendar.New(calendar.BusinessDays),
			forecaster: NewMovingAverage(),
			expected:   252.0,
		},
		"business days/lm-arch": {
			cal:        calendar.New(calendar.BusinessDays),
			forecaster: NewLongMemoryARCH(),
			expected:   252.0,
		},
		"business days/lm-arch with deltaT": {
			cal: calendar.New(calendar.BusinessDays),
			forecaster: NewLongMemoryARCH(
				WithDeltaT(1.0 / 24.0),
			),
			expected: 252.0 * 24.0,
		},
		"calendar days/moving average": {
			cal:        calendar.New(calendar.CalendarDays),
			forecaster: NewMovingAverage(),
			expected:   365.0,
		},
		"calendar days/lm-arch": {
			cal:        calendar.New(calendar.CalendarDays),
			forecaster: NewLongMemoryARCH(),
			expected:   365.0,
		},
		"calendar days/lm-arch with deltaT": {
			cal: calendar.New(calendar.CalendarDays),
			forecaster: NewLongMemoryARCH(
				WithDeltaT(1.0 / 24.0),
			),
			expected: 365.0 * 24.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := computeAnnualization(tc.cal, tc.forecaster)
			assert.InDelta(t, tc.expected, got, 1.0e-15)
		})
	}
}
