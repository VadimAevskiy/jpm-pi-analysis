package forecast

import (
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
)

// Horizoner is a constructor of time horizons as daily time lags
// based on an input calendar.
type Horizoner func(*calendar.Calendar) int

// NewRelativeHorizon is a horizon specified by a number of days
// relative to the origin (to date).
func NewRelativeHorizon(days int) Horizoner {
	return func(*calendar.Calendar) int {
		return days
	}
}

// NewAbsoluteHorizon is a horizon identified by the absolute time lag
// between the to and the until date.
func NewAbsoluteHorizon(to, until date.Date) Horizoner {
	return func(c *calendar.Calendar) int {
		return c.DaysBetween(
			c.LatestBefore(to),
			c.LatestBefore(until),
		)
	}
}
