/*
Package forecast exposes a set of utilities to compute weighted volatility time series
from an input time series.

The type of returns to compute and the methodology to apply are user-specified.
Returns are computed in a time frame of business days ranging from a starting and en ending date
with given deltaT and horizon. These parameters define completely the chosen weighting
scheme used to compute returns.

The supported forecast methods exposed by the module are:
* (rectangular) moving average
* long-memory autoregressive conditional heteroskedasticity (LM-ARCH) model

References:
* Volatility Processes and Volatility Forecast with Long Memory, Gilles O. Zumbach, 2002
https://papers.ssrn.com/sol3/papers.cfm?abstract_id=306000
* The Riskmetrics 2006 Methodology, Gilles O. Zumbach, 2007
https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1420185

Returns are computed only at the specified input dates and only when the input values are valid:
* NaNs and Infs are filtered out
* for logarithmic and relative returns, the input values must be strictly positive
* for simple returns, any real value is well defined
Notice that these condititions apply stricter constraints to the input time series than what
mathematically required, but allow for a better management of missing or invalid data.

Such exceptions are managed as follows:
* normally, returns are computed between two consecutive business days belonging to the
specified time frame
* missing and invalid data are skipped and the next valid return accounts for as many business
days as the ones between the last valid time value and the next
As an example, consider the following time frame with valid (V), weekend (W) and invalid (N)
time series inputs. Below the points at which returns are computed (o: yes, x: no) and the
corresponding business days associated to such returns are reported.

-- start ------------------------------------------- end --	(time frame)
-- V -- V -- N -- V -- V -- W -- W -- V -- N -- N -- V --	(input value)
-- x -- o -- x -- o -- o -- x -- x -- o -- x -- x -- o --	(has return)
-- x -- 1 -- x -- 2 -- 1 -- x -- x -- 1 -- x -- x -- 3 --	(days).
*/
package forecast
