package forecast

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_NewMovingAverage(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		opts     []MovingAverageOption
		expected *MovingAverage
	}{
		"default": {
			opts: nil,
			expected: &MovingAverage{
				timeWindow: 260,
			},
		},
		"custom time window": {
			opts: []MovingAverageOption{
				WithTimeWindow(90),
			},
			expected: &MovingAverage{
				timeWindow: 90,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := NewMovingAverage(tc.opts...)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_MovingAverage_ComputeWeights(t *testing.T) {
	t.Parallel()

	mov := NewMovingAverage()

	w := 1.0 / 260.0

	expected := make([]float64, 260)
	for k := range expected {
		expected[k] = w
	}

	const horizon = 30

	got := mov.ComputeWeights(horizon)
	assert.Equal(t, expected, got)

	sumW := 0.0
	for _, w := range got {
		sumW += w
	}

	assert.InDelta(t, 1.0, sumW, 1.0e-14)
}
