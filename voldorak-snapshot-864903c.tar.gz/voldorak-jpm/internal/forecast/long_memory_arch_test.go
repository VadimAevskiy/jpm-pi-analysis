package forecast

import (
	"math"
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_NewLongMemoryARCH(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		opts     []LongMemoryARCHOption
		expected *LongMemoryARCH
	}{
		"default": {
			opts: nil,
			expected: &LongMemoryARCH{
				maximumReturnLag:       1040,
				lowerCutoff:            4.0,
				upperCutoff:            512.0,
				progression:            math.Sqrt(2.0),
				logarithmicDecayFactor: 1560.0,
				deltaT:                 deltaT,
			},
		},
		"custom options": {
			opts: []LongMemoryARCHOption{
				WithLowerCutoff(9.0),
				WithUpperCutoff(19683.0),
				WithProgression(math.Sqrt(3.0)),
				WithLogarithmicDecayFactor(5265.0),
				WithDeltaT(1.0 / 24.0),
			},
			expected: &LongMemoryARCH{
				maximumReturnLag:       1040,
				lowerCutoff:            9.0,
				upperCutoff:            19683.0,
				progression:            math.Sqrt(3.0),
				logarithmicDecayFactor: 5265.0,
				deltaT:                 1.0 / 24.0,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := NewLongMemoryARCH(tc.opts...)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_LongMemoryARCH_computeTaus(t *testing.T) {
	t.Parallel()

	var (
		sqrt2        = math.Sqrt(2.0)
		expectedTaus = []float64{
			4.0, 4.0 * sqrt2, 8.0, 8.0 * sqrt2, 16.0,
			16.0 * sqrt2, 32.0, 32.0 * sqrt2, 64.0, 64.0 * sqrt2,
			128.0, 128.0 * sqrt2, 256.0, 256.0 * sqrt2, 512.0,
		}
	)

	lmARCH := NewLongMemoryARCH()
	taus := lmARCH.computeTaus()
	assert.Len(t, taus, len(expectedTaus))

	for k, v := range taus {
		assert.InDelta(t, expectedTaus[k], v, 1.0e-12)
	}
}

func Test_LongMemoryARCH_computeInternalStates(t *testing.T) {
	t.Parallel()

	// Compute the expected results
	var (
		deltaT          = 1.0 / 365.0
		n               = 15
		beta            = math.Log(2.0) / math.Log(1560.0)
		expectedSumW    = 15.0 * (1.0 - 5.5*beta)
		expectedWeights = make([]float64, n)
		expectedMuEma   = make([]float64, n)
	)
	for k := range n {
		tau := math.Pow(2, 2.0+0.5*float64(k))
		expectedMuEma[k] = math.Exp(-deltaT / tau)
		expectedWeights[k] = math.Max(0.0, 1.0-(0.5*float64(k)+2.0)*beta) / expectedSumW
	}

	lmARCH := NewLongMemoryARCH(
		WithDeltaT(deltaT),
	)

	weights, muEma := lmARCH.computeInternalStates()
	for k, w := range weights {
		assert.InDelta(t, expectedWeights[k], w, 1.0e-15)
		assert.InDelta(t, expectedMuEma[k], muEma[k], 1.0e-15)
	}
}

func Test_LongMemoryARCH_computeWeightVolComponents(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		weights  []float64
		muEma    []float64
		horizon  int
		expected []float64
	}{
		"constant weights/constant mu": {
			weights:  []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			muEma:    []float64{math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0)},
			horizon:  100,
			expected: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
		},
		"triangular weights/constant mu": {
			weights:  []float64{1.0 / 3.0, 4.0 / 15.0, 1.0 / 5.0, 2.0 / 15.0, 1.0 / 15.0},
			muEma:    []float64{math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0)},
			horizon:  100,
			expected: []float64{1.0 / 3.0, 4.0 / 15.0, 1.0 / 5.0, 2.0 / 15.0, 1.0 / 15.0},
		},
		"constant weights/power law mu": {
			weights: []float64{1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0},
			muEma:   []float64{1.0, math.Exp(-0.5), math.Exp(-1.0)},
			horizon: 2,
			expected: func() []float64 {
				res := make([]float64, 3)

				invN := 1.0 / 3.0
				for i := range 3 {
					res[i] = 0.5 * invN * (2.0 + math.Exp(-0.5*float64(i)) - invN*(1.0-math.Exp(-1.5))/(1.0-math.Exp(-0.5)))
				}

				return res
			}(),
		},
		"constant weights/constant mu/horizon 0": {
			weights:  []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			muEma:    []float64{math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0)},
			horizon:  0,
			expected: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
		},
		"constant weights/constant mu/horizon 1": {
			weights:  []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			muEma:    []float64{math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0), math.Exp(-1.0)},
			horizon:  1,
			expected: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := NewLongMemoryARCH().computeWeightVolComponents(tc.weights, tc.muEma, tc.horizon)
			for k, w := range got {
				assert.InDelta(t, tc.expected[k], w, 1.0e-15)
			}
		})
	}
}

func Test_LongMemoryARCH_ComputeWeights(t *testing.T) {
	t.Parallel()

	// The data of the first test case are chosen in such a way that
	// there are only 2 components with:
	// * tau_k = 4, 8
	// * w_k = 2/3, 1/3
	// * mu_k = 1/4, 1/2
	// Within a horizon of 2 time units, the weight vol components are
	// equal to 23/36 and 13/36
	// The forecast weights before normalization are equal to 95/144
	// and 121/576, so that their normalization leads to 380/501 and 121/501

	for name, tc := range map[string]struct {
		opts     []LongMemoryARCHOption
		horizon  int
		expected []float64
	}{
		"two components": {
			opts: []LongMemoryARCHOption{
				WithMaximumReturnLag(2),
				WithLowerCutoff(1.0 / (2.0 * math.Log(2.0))),
				WithUpperCutoff(1.0 / math.Log(2.0)),
				WithProgression(2.0),
				WithLogarithmicDecayFactor(2.0 / math.Log(2.0)),
			},
			horizon:  2,
			expected: []float64{380.0 / 501.0, 121.0 / 501.0},
		},
		"benchmark": {
			opts: []LongMemoryARCHOption{
				WithMaximumReturnLag(10),
				WithLowerCutoff(4.0),
				WithUpperCutoff(512.0),
				WithProgression(math.Sqrt(2.0)),
				WithLogarithmicDecayFactor(1560.0),
			},
			horizon: 30,
			expected: []float64{
				0.1517200034762939, 0.135097736763895, 0.1210473612196736, 0.1091069659420882, 0.0989041958367939,
				0.0901381042278588, 0.0825647854329473, 0.0759859856396758, 0.0702400625285727, 0.0651947989322008,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := NewLongMemoryARCH(tc.opts...).ComputeWeights(tc.horizon)
			assert.Len(t, got, len(tc.expected))

			for k, want := range tc.expected {
				assert.InDelta(t, want, got[k], 1.0e-15)
			}
			// Verify that the weights sum up to 1
			sumW := 0.0
			for _, w := range got {
				sumW += w
			}

			assert.InDelta(t, 1.0, sumW, 1.0e-15)
		})
	}
}

func Test_LongMemoryARCH_timeScale(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	for name, tc := range map[string]struct {
		lmARCH   *LongMemoryARCH
		expected float64
	}{
		"default": {
			lmARCH:   NewLongMemoryARCH(),
			expected: deltaT,
		},
		"hourly": {
			lmARCH: NewLongMemoryARCH(
				WithDeltaT(1.0 / 24.0),
			),
			expected: 1.0 / 24.0,
		},
		"double day": {
			lmARCH: NewLongMemoryARCH(
				WithDeltaT(2.0),
			),
			expected: 2.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := tc.lmARCH.timeScale()
			assert.InDelta(t, tc.expected, got, tol)
		})
	}
}
