package forecast

import "github.com/edgelaboratories/go-libraries/calendar"

// timeScaler returns the natural time scale of the forecast process.
type timeScaler interface {
	timeScale() float64
}

// computeAnnualization computes the factor that converts a variance forecast computed
// in a DeltaT-business time scale to a business-yearly time scale.
// The formula follows from the fact that the total variance = volatility^2 * time
// is non-dimensional and must thus be invariant under changes of measure unit.
func computeAnnualization(calendar *calendar.Calendar, forecaster Forecaster) float64 {
	return float64(calendar.DaysInYear()) / computeForecastTimeScale(forecaster)
}

// computeForecastTimeScale returns the natural time scale of the forecast
// process. When undefined, the related time scale is assumed to be
// equal to the default deltaT (1 day).
func computeForecastTimeScale(forecaster Forecaster) float64 {
	if timeScaler, ok := forecaster.(timeScaler); ok {
		return timeScaler.timeScale()
	}

	return deltaT
}
