package forecast

// deltaT represents the time scale (in days) used by default to compute
// forecast weights. We set it to one day.
const deltaT = 1.0

// Forecaster computes the forecast weights up to a daily horizon.
type Forecaster interface {
	ComputeWeights(horizon int) []float64
}

// Check rawWeights is a Forecaster at compile time.
var _ Forecaster = rawWeights{}

// rawWeights is an internal set of static weights with
// no horizon dependence. It is used for testing only.
type rawWeights []float64

func (ws rawWeights) ComputeWeights( /* horizon */ int) []float64 {
	return ws
}
