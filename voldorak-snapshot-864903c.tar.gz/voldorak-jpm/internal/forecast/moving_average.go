package forecast

// MovingAverage computes forecast weights based on a rectangular
// time window of length defined by the maximum return lag.
type MovingAverage struct {
	timeWindow int
}

// Check movingAverage is a Forecaster at compile time.
var _ Forecaster = MovingAverage{}

func defaultMovingAverage() *MovingAverage {
	const defaultTimeWindow = 260

	return &MovingAverage{
		timeWindow: defaultTimeWindow,
	}
}

// MovingAverageOption is a user option that allows to customize
// the default moving average configuration.
type MovingAverageOption func(*MovingAverage)

// WithTimeWindow sets the time window.
func WithTimeWindow(timeWindow int) MovingAverageOption {
	return func(m *MovingAverage) {
		m.timeWindow = timeWindow
	}
}

// NewMovingAverage returns a moving-average Forecaster.
func NewMovingAverage(opts ...MovingAverageOption) *MovingAverage {
	movAvg := defaultMovingAverage()
	for _, opt := range opts {
		opt(movAvg)
	}

	return movAvg
}

func (mov MovingAverage) ComputeWeights( /* horizon */ int) []float64 {
	w := 1.0 / float64(mov.timeWindow)

	weights := make([]float64, mov.timeWindow)
	for k := range weights {
		weights[k] = w
	}

	return weights
}
