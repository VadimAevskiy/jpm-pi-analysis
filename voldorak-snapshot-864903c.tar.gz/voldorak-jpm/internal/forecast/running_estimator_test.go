package forecast

import (
	"math/rand"
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_newRunningVarianceEstimator(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			returnType marketdata.ReturnType
			expected   runningEstimator
		}{
			"logarithmic return": {
				returnType: marketdata.LogarithmicReturn,
				expected:   &sampleVarianceEstimator{},
			},
			"simple return": {
				returnType: marketdata.SimpleReturn,
				expected:   &sampleVarianceEstimator{},
			},
			"relative return": {
				returnType: marketdata.RelativeReturn,
				expected:   &sampleSecondMomentEstimator{},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := newRunningVarianceEstimator(tc.returnType)
				require.NoError(t, err)
				assert.Equal(t, tc.expected, got)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := newRunningVarianceEstimator(marketdata.ReturnType("Unsupported"))
		require.Error(t, err)
	})
}

func Test_newRunningEstimator(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	for name, tc := range map[string]struct {
		estimator runningEstimator
		weights   []float64
		values    []float64
		expected  float64
	}{
		"sample mean/single input": {
			estimator: &sampleMeanEstimator{},
			weights:   []float64{1.0},
			values:    []float64{5.0},
			expected:  5.0,
		},
		"sample mean/uniform weights": {
			estimator: &sampleMeanEstimator{},
			weights:   []float64{1.0, 1.0, 1.0, 1.0, 1.0},
			values:    []float64{0.0, 0.25, 0.5, 0.75, 1.0},
			expected:  0.5,
		},
		"sample second moment/single input": {
			estimator: &sampleSecondMomentEstimator{},
			weights:   []float64{1.0},
			values:    []float64{5.0},
			expected:  25.0,
		},
		"sample second moment/uniform weights": {
			estimator: &sampleSecondMomentEstimator{},
			weights:   []float64{1.0, 1.0, 1.0, 1.0, 1.0},
			values:    []float64{0.0, 0.25, 0.5, 0.75, 1.0},
			expected:  0.375,
		},
		"sample variance/single input": {
			estimator: &sampleVarianceEstimator{},
			weights:   []float64{1.0},
			values:    []float64{5.0},
			expected:  0.0,
		},
		"sample variance/uniform weights": {
			estimator: &sampleVarianceEstimator{},
			weights:   []float64{1.0, 1.0, 1.0, 1.0, 1.0},
			values:    []float64{0.0, 0.25, 0.5, 0.75, 1.0},
			expected:  5.0 / 32.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			// Create a fresh estimator to avoid state sharing
			var estimator runningEstimator
			switch tc.estimator.(type) {
			case *sampleMeanEstimator:
				estimator = &sampleMeanEstimator{}
			case *sampleSecondMomentEstimator:
				estimator = &sampleSecondMomentEstimator{}
			case *sampleVarianceEstimator:
				estimator = &sampleVarianceEstimator{}
			}

			for k, v := range tc.values {
				estimator.add(v, tc.weights[k])
			}

			got := estimator.evaluate()
			assert.InDelta(t, tc.expected, got, tol)

			// Verify that the reset is effective.
			estimator.reset()
			assert.InDelta(t, 0.0, estimator.evaluate(), tol)
		})
	}
}

func Test_sampleVarianceEstimator_PositivityCheck(t *testing.T) {
	t.Parallel()

	t.Run("random input", func(t *testing.T) {
		t.Parallel()

		// This test populates input samples repeatedly and checks
		// for the positivity of the variance estimator.
		var (
			gen      = rand.New(rand.NewSource(int64(1))) // #nosec G404
			n        = 100
			x        = make([]float64, n)
			w        = make([]float64, n)
			nbChecks = 100
		)

		for range nbChecks {
			for k := range x {
				x[k] = gen.NormFloat64()
				w[k] = gen.Float64()
			}

			e := sampleVarianceEstimator{}
			for k, v := range x {
				e.add(v, w[k])
			}

			assert.GreaterOrEqual(t, e.evaluate(), 0.0)
		}
	})

	t.Run("ill conditioned input", func(t *testing.T) {
		t.Parallel()

		// This test verifies that the estimated sample variance is positive
		// for some ill-conditioned input, for which a naive approach would fail
		// with floating-point number IEEE arithmetic.
		var (
			gen = rand.New(rand.NewSource(int64(1))) // #nosec G404
			n   = 1000000
			x   = make([]float64, n)
			w   = make([]float64, n)
		)
		for k := range x {
			x[k] = 1.0e+9 + gen.Float64()
			w[k] = gen.Float64()
		}

		e := sampleVarianceEstimator{}
		for k, v := range x {
			e.add(v, w[k])
		}

		assert.GreaterOrEqual(t, e.evaluate(), 0.0)
	})
}
