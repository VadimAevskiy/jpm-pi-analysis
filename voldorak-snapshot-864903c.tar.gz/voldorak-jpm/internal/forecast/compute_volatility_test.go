package forecast

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/validation"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_ReturnsValidityCondition(t *testing.T) {
	t.Parallel()

	ts := &marketdata.ReturnsTimeseries{
		Entries: marketdata.ReturnEntries{
			{
				Date:  date.New(2021, time.September, 23),
				Value: (103.0 - 101.0) / 101.0,
				Days:  1,
			},
		},
	}

	t.Run("ReturnsNotEmpty", func(t *testing.T) {
		t.Parallel()

		t.Run("valid", func(t *testing.T) {
			t.Parallel()

			require.NoError(t, ReturnsNotEmpty(ts))
		})

		t.Run("error", func(t *testing.T) {
			t.Parallel()

			err := ReturnsNotEmpty(&marketdata.ReturnsTimeseries{})
			require.Error(t, err)
			errors.AssertStatus(t, errors.StatusCodeNotFound, err)
			errors.AssertTag(t, tag.NotEnoughData, err)
		})
	})

	t.Run("AtLeastNReturns", func(t *testing.T) {
		t.Parallel()

		t.Run("valid", func(t *testing.T) {
			t.Parallel()

			require.NoError(t, AtLeastNReturns(1)(ts))
		})

		t.Run("error", func(t *testing.T) {
			t.Parallel()

			err := AtLeastNReturns(2)(ts)
			require.Error(t, err)
			errors.AssertStatus(t, errors.StatusCodeNotFound, err)
			errors.AssertTag(t, tag.NotEnoughData, err)
		})
	})
}

func Test_ComputeVolatility(t *testing.T) { //nolint:gocognit,cyclop,maintidx
	t.Parallel()

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		var (
			cal        = calendar.New(calendar.BusinessDays)
			returnType = marketdata.RelativeReturn
			forecaster = NewMovingAverage()
		)

		for name, tc := range map[string]struct {
			entries   marketdata.ReturnEntries
			from      date.Date
			to        date.Date
			horizoner Horizoner
		}{
			"empty returns timeseries": {
				entries:   nil,
				from:      date.Today().AddDate(-1, 0, 0),
				to:        date.Today(),
				horizoner: NewRelativeHorizon(10),
			},
			"no returns in timewindow": {
				entries: marketdata.ReturnEntries{
					{
						Date:  date.New(2021, time.September, 23),
						Value: (103.0 - 101.0) / 101.0,
						Days:  1,
					},
				},
				from:      date.New(2021, time.September, 1),
				to:        date.New(2021, time.September, 20),
				horizoner: NewRelativeHorizon(10),
			},
			"no dates in time window": {
				entries: marketdata.ReturnEntries{
					{
						Date:  date.New(2021, time.September, 23),
						Value: (103.0 - 101.0) / 101.0,
						Days:  1,
					},
				},
				from:      date.New(2021, time.September, 1),
				to:        date.New(2021, time.September, 1),
				horizoner: NewRelativeHorizon(10),
			},
			"no active days in time window": {
				entries: marketdata.ReturnEntries{
					{
						Date:  date.New(2021, time.September, 22),
						Value: (101.0 - 100.0) / 100.0,
						Days:  1,
					},
					{
						Date:  date.New(2021, time.September, 23),
						Value: (103.0 - 101.0) / 101.0,
						Days:  1,
					},
				},
				from: date.New(2021, time.September, 24),
				to:   date.New(2021, time.September, 25),
				horizoner: NewAbsoluteHorizon(
					date.New(2021, time.September, 25),
					date.New(2021, time.September, 26),
				),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := ComputeVolatility(&marketdata.ReturnsTimeseries{
					Calendar:   cal,
					ReturnType: returnType,
					Entries:    tc.entries,
				}, forecaster, tc.horizoner,
					WithFrom(tc.from),
					WithTo(tc.to),
				)
				require.Error(t, err)
			})
		}
	})

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		// Define time series from 27th to 31st July, 2020
		ts := &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 28),
					Value: (12.0 - 10.0) / 10.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 29),
					Value: (14.0 - 12.0) / 12.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 30),
					Value: (16.0 - 14.0) / 14.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 31),
					Value: (18.0 - 16.0) / 16.0,
					Days:  1,
				},
			},
		}

		// For the LM-ARCH case, the input is chosen in such a way that there are only
		// two weight components, equal to 380/501 and 121/501 respectively.
		for name, tc := range map[string]struct {
			forecaster Forecaster
			horizon    int
			expectedW0 float64
			expectedW1 float64
		}{
			"moving average": {
				forecaster: NewMovingAverage(
					WithTimeWindow(2),
				),
				horizon:    1,
				expectedW0: 0.5,
				expectedW1: 0.5,
			},
			"long-memory arch": {
				forecaster: NewLongMemoryARCH(
					WithMaximumReturnLag(2),
					WithLowerCutoff(1.0/(2.0*math.Log(2.0))),
					WithUpperCutoff(1.0/math.Log(2.0)),
					WithProgression(2.0),
					WithLogarithmicDecayFactor(2.0/math.Log(2.0)),
				),
				horizon:    2,
				expectedW0: 380.0 / 501.0,
				expectedW1: 121.0 / 501.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				annualization := computeAnnualization(ts.Calendar, tc.forecaster)
				expected := &marketdata.Timeseries{
					Entries: []*marketdata.Entry{
						{
							Date:  date.New(2020, time.July, 28),
							Value: math.Sqrt(annualization * 0.04),
						},
						{
							Date:  date.New(2020, time.July, 29),
							Value: math.Sqrt(annualization * (tc.expectedW0/36.0 + tc.expectedW1/25.0)),
						},
						{
							Date:  date.New(2020, time.July, 30),
							Value: math.Sqrt(annualization * (tc.expectedW0/49.0 + tc.expectedW1/36.0)),
						},
						{
							Date:  date.New(2020, time.July, 31),
							Value: math.Sqrt(annualization * (tc.expectedW0/64.0 + tc.expectedW1/49.0)),
						},
					},
				}

				res, err := ComputeVolatility(
					ts,
					tc.forecaster,
					NewRelativeHorizon(tc.horizon),
				)
				require.NoError(t, err)

				resEntries := res.Entries
				assert.Len(t, resEntries, len(expected.Entries))

				for k, v := range expected.Entries {
					assert.Equal(t, v.Date, resEntries[k].Date)
					assert.InDelta(t, v.Value, resEntries[k].Value, 1.0e-15)
				}
			})
		}
	})

	t.Run("time window consistency", func(t *testing.T) {
		t.Parallel()

		// Choose the test input as follows:
		// - observe 3 returns from Wednesday to Friday;
		// - adopt a business calendar for (relative) returns;
		// - use LM-ARCH forecast to induce horizon effects.
		// A LM-ARCH forecast on 3 returns with standard return lag
		// will produce 3 valid values.

		var (
			cal        = calendar.New(calendar.BusinessDays)
			forecaster = NewLongMemoryARCH()
			returns    = &marketdata.ReturnsTimeseries{
				ReturnType: marketdata.RelativeReturn,
				Calendar:   cal,
				Entries: marketdata.ReturnEntries{
					{
						Date:  date.New(2021, time.September, 29),
						Value: 0.01,
						Days:  1,
					},
					{
						Date:  date.New(2021, time.September, 30),
						Value: -0.01,
						Days:  1,
					},
					{
						Date:  date.New(2021, time.October, 1),
						Value: 0.01,
						Days:  1,
					},
				},
			}
		)

		for name, tc := range map[string]struct {
			from          date.Date
			to            date.Date
			horizoner     Horizoner
			expectedDates []date.Date
		}{
			"horizon across weekend": {
				from: date.New(2021, time.September, 29),
				to:   date.New(2021, time.October, 1),
				horizoner: NewAbsoluteHorizon(
					date.New(2021, time.October, 1),
					date.New(2021, time.October, 4),
				),
				expectedDates: []date.Date{
					date.New(2021, time.September, 29),
					date.New(2021, time.September, 30),
					date.New(2021, time.October, 1),
				},
			},
			"horizon at weekend": {
				from: date.New(2021, time.September, 29),
				to:   date.New(2021, time.October, 1),
				horizoner: NewAbsoluteHorizon(
					date.New(2021, time.October, 1),
					date.New(2021, time.October, 1),
				),
				expectedDates: []date.Date{
					date.New(2021, time.September, 29),
					date.New(2021, time.September, 30),
					date.New(2021, time.October, 1),
				},
			},
			"two returns in window": {
				from: date.New(2021, time.September, 30),
				to:   date.New(2021, time.October, 1),
				horizoner: NewAbsoluteHorizon(
					date.New(2021, time.October, 1),
					date.New(2021, time.October, 4),
				),
				expectedDates: []date.Date{
					date.New(2021, time.September, 30),
					date.New(2021, time.October, 1),
				},
			},
			"from one year before to": {
				from: date.New(2020, time.October, 1),
				to:   date.New(2021, time.October, 1),
				horizoner: NewAbsoluteHorizon(
					date.New(2021, time.October, 1),
					date.New(2021, time.October, 1),
				),
				expectedDates: []date.Date{
					date.New(2021, time.September, 29),
					date.New(2021, time.September, 30),
					date.New(2021, time.October, 1),
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				res, err := ComputeVolatility(returns, forecaster, tc.horizoner,
					WithFrom(tc.from),
					WithTo(tc.to),
				)
				require.NoError(t, err)

				assert.Len(t, res.Entries, len(tc.expectedDates))

				for k, v := range res.Entries {
					assert.Equal(t, tc.expectedDates[k], v.Date)
					assert.True(t, validation.IsFinite(v.Value))
				}
			})
		}
	})

	t.Run("constant timeseries", func(t *testing.T) {
		t.Parallel()

		// Verify that, in case of a constant time series, the output
		// volatility is floored to sqrt(year * minimumVariance).

		ts := &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.January, 2),
					Value: 0.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.January, 3),
					Value: 0.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.January, 4),
					Value: 0.0,
					Days:  1,
				},
			},
		}

		cal := calendar.New(calendar.BusinessDays)

		res, err := ComputeVolatility(
			ts,
			NewMovingAverage(),
			NewRelativeHorizon(cal.DaysInYear()),
			WithFrom(ts.At(0).Date.Add(-1)),
		)
		require.NoError(t, err)
		assert.Len(t, res.Entries, 2)

		for _, v := range res.Entries {
			assert.InDelta(t, math.Sqrt(float64(cal.DaysInYear())*tol), v.Value, 1.0e-15)
		}
	})

	t.Run("forecast horizon consistency over window", func(t *testing.T) {
		t.Parallel()

		// This functional test assesses important properties of the
		// volatility forecast depending on horizon and window computation.
		// They strongly rely on:
		// - how the horizon computation via DaysBetween works (from excluded,
		// to included)
		// - the relation between the input time window and the number of
		// available returns and weights.

		var (
			returns = newTestReturns(t, "euro_stoxx_50")
			from    = date.New(2020, time.January, 2)
		)

		// The horizon computation should yield the same result using
		// the following to dates:
		// - Friday 26th June 2020
		// - Saturday 27th June 2020
		// - Sunday 28th June 2020
		// with Friday 3rd July as (absolute) horizon date.
		// The From date is chosen as of Monday 1st January 2020.

		t.Run("check horizon", func(t *testing.T) {
			t.Parallel()

			// This test checks that the horizon computation is fully
			// consistent with the intuition.

			for _, to := range []date.Date{
				date.New(2020, time.June, 26),
				date.New(2020, time.June, 27),
				date.New(2020, time.June, 28),
			} {
				p := buildDefaultParameters()
				for _, opt := range []Option{
					WithFrom(from),
					WithTo(to),
				} {
					opt(p)
				}

				actualFrom, actualTo := computeTimeWindow(returns, p)
				assert.Equal(t, from, actualFrom)
				assert.Equal(t, returns.Calendar.LatestBefore(to), actualTo)

				// Expect exactly 5 business days until 2020-07-03.
				horizonDate := date.New(2020, time.July, 3)
				days := 5

				assert.Equal(t, days, NewAbsoluteHorizon(to, horizonDate)(returns.Calendar))

				// Now do the opposite: apply 5 days to a relative horizon
				// computed from the to date and verify it coincides with
				// 2020-07-03 according to the returns calendar.
				assert.Equal(t, horizonDate, returns.Calendar.Add(
					to,
					NewRelativeHorizon(days)(returns.Calendar),
				))
			}
		})

		t.Run("same forecast across weekend", func(t *testing.T) {
			t.Parallel()

			// Now verify that the volatility forecast estimate
			// is the same across a weekend, including the horizon:
			// - the return dates must be exactly the same;
			// - also the volatility values must stay consistent.
			// As long as there are enough returns to use up all of
			// the forecast weights, this property must be satisfied
			// by the WHOLE TIMESERIES.

			ref, err := ComputeVolatility(returns,
				NewLongMemoryARCH(
					WithMaximumReturnLag(22), // business days in a month
				),
				NewAbsoluteHorizon(
					date.New(2020, time.June, 26),
					date.New(2020, time.July, 3)),
				WithFrom(from),
				WithTo(date.New(2020, time.June, 26)),
			)
			require.NoError(t, err)

			for _, to := range []date.Date{
				date.New(2020, time.June, 27),
				date.New(2020, time.June, 28),
			} {
				res, err := ComputeVolatility(returns,
					NewLongMemoryARCH(
						WithMaximumReturnLag(22), // business days in a month
					),
					NewAbsoluteHorizon(to, date.New(2020, time.July, 3)),
					WithFrom(from),
					WithTo(to),
				)
				require.NoError(t, err)

				for k, v := range res.Entries {
					assert.Equal(t, ref.Entries[k].Date, v.Date)
					assert.InDelta(t, ref.Entries[k].Value, v.Value, 1.0e-15)
				}
			}
		})

		t.Run("same forecast at date fixed relative horizon", func(t *testing.T) {
			t.Parallel()

			// This test is even stronger. It verifies that, fixed a RELATIVE
			// horizon and when there are more returns than weights, the
			// volatility forecast estimate at some date stays the same
			// even when sliding the input time window (from and to together).

			t.Run("returns > weights", func(t *testing.T) {
				t.Parallel()

				// We hereby use a LM-ARCH process of 22 business days (30 calendar days)
				// so that we're sure that there are more weights than returns
				// (from: 2020-01-02, so there's one full year backwards at the
				// start of the input time series).

				var (
					originFrom = from
					originTo   = date.New(2020, time.June, 26)
					forecaster = NewLongMemoryARCH(
						WithMaximumReturnLag(22),
					)
					horizoner = NewRelativeHorizon(5)
				)

				// Start from 2020-06-26 and add one business day until 2020-07-01.

				ref, err := ComputeVolatility(returns, forecaster, horizoner,
					WithFrom(originFrom),
					WithTo(originTo),
				)
				require.NoError(t, err)

				expected := ref.Last()

				for day := 1; day < 4; day++ {
					// Slide the time window on both ends.
					from := returns.Calendar.Add(originFrom, day)
					to := returns.Calendar.Add(originTo, day)

					res, err := ComputeVolatility(returns, forecaster, horizoner,
						WithFrom(from),
						WithTo(to),
					)
					require.NoError(t, err)

					// Get the entry at the origin date and verify it coincides
					// with the last entry of the reference result.
					atOrigin := res.To(originTo).Last()
					assert.Equal(t, expected.Date, atOrigin.Date)
					assert.InDelta(t, expected.Value, atOrigin.Value, 1.0e-15)
				}
			})

			t.Run("returns < weights", func(t *testing.T) {
				t.Parallel()

				// This test verifies that the condition returns > weights
				// in cardinality is necessary to get consistent results.
				// On a broader perspective, it shows how important it is
				// to get enough returns data behind the requested time window
				// (i.e. to let volatilities "warm up").

				// Truncate returns within one month and define a 3-months
				// LM-ARCH process (it will reveal the backbone effect).
				// The following require statement ensures the test will not
				// segfault in case the data set changes.

				const window = 22

				n := len(returns.Entries)
				require.Greater(t, n, window)

				var (
					originFrom = from
					originTo   = date.New(2020, time.June, 26)
					forecaster = NewLongMemoryARCH(
						WithMaximumReturnLag(66),
					)
					horizoner        = NewRelativeHorizon(5)
					truncatedReturns = &marketdata.ReturnsTimeseries{
						Calendar:   returns.Calendar,
						ReturnType: returns.ReturnType,
						Entries:    returns.Entries[n-window:],
					}
				)

				// Start from 2020-06-26 and add one business day until 2020-07-01.

				ref, err := ComputeVolatility(truncatedReturns, forecaster, horizoner,
					WithFrom(originFrom),
					WithTo(originTo),
				)
				require.NoError(t, err)

				expected := ref.Last()

				for day := 1; day < 4; day++ {
					// Slide the time window on both ends.
					from := returns.Calendar.Add(originFrom, day)
					to := returns.Calendar.Add(originTo, day)

					res, err := ComputeVolatility(returns, forecaster, horizoner,
						WithFrom(from),
						WithTo(to),
					)
					require.NoError(t, err)

					// Get the entry at the origin date and verify it
					// DOES NOT coincide with the reference one in value.
					atOrigin := res.To(originTo).Last()
					assert.Equal(t, expected.Date, atOrigin.Date)
					assert.Greater(t, math.Abs(expected.Value-atOrigin.Value), 1.0e-15)
				}
			})
		})
	})
}

func newTestReturns(tb testing.TB, name string) *marketdata.ReturnsTimeseries {
	tb.Helper()

	in, err := os.ReadFile(fmt.Sprintf("testdata/%s.json", name))
	require.NoError(tb, err)

	var input map[date.Date]float64
	require.NoError(tb, json.Unmarshal(in, &input))

	entries := make([]*marketdata.Entry, 0, len(input))
	for k, v := range input {
		entries = append(entries, &marketdata.Entry{
			Date:  date.New(k.Year(), k.Month(), k.Day()),
			Value: v,
		})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Date.Before(entries[j].Date)
	})

	returns, err := marketdata.NewReturnsTimeseries(tb.Context(), &marketdata.Timeseries{
		Type:    marketdata.Index,
		ID:      name,
		Entries: entries,
	})
	require.NoError(tb, err)

	return returns
}

func Benchmark_ComputeVolatility(b *testing.B) {
	const horizon = 30

	for _, bc := range []struct {
		method     string
		forecaster Forecaster
	}{
		{
			"moving_average",
			NewMovingAverage(),
		},
		{
			"long_memory_arch",
			NewLongMemoryARCH(),
		},
	} {
		b.Run(bc.method, func(b *testing.B) {
			ts := newTestReturns(b, "testdata/euro_stoxx_50.json")
			horizoner := NewRelativeHorizon(horizon)

			b.ResetTimer()

			for b.Loop() {
				_, err := ComputeVolatility(ts,
					bc.forecaster,
					horizoner,
				)
				require.NoError(b, err)
			}
		})
	}
}

func Test_computeTimeWindow(t *testing.T) {
	t.Parallel()

	returns := newTestReturns(t, "euro_stoxx_50")

	for name, tc := range map[string]struct {
		opts         []Option
		expectedFrom date.Date
		expectedTo   date.Date
	}{
		"returns windowing dates": {
			opts:         nil,
			expectedFrom: returns.At(0).Date,
			expectedTo:   returns.Last().Date,
		},
		"specify window/within returns calendar": {
			opts: []Option{
				WithFrom(returns.At(0).Date),
				WithTo(returns.Last().Date),
			},
			expectedFrom: returns.At(0).Date,
			expectedTo:   returns.Last().Date,
		},
		"specify window/outside returns calendar": {
			opts: []Option{
				WithFrom(date.New(2019, time.January, 5)),
				WithTo(date.New(2020, time.June, 27)),
			},
			expectedFrom: date.New(2019, time.January, 4),
			expectedTo:   date.New(2020, time.June, 26),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			p := buildDefaultParameters()
			for _, opt := range tc.opts {
				opt(p)
			}

			from, to := computeTimeWindow(returns, p)
			assert.Equal(t, tc.expectedFrom, from)
			assert.Equal(t, tc.expectedTo, to)
		})
	}
}
