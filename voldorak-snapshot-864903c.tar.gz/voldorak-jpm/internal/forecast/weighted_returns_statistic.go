package forecast

import (
	"math"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// tol defines the minimum tol returned by a weighted statistic based on returns.
// It is equal to the machine epsilon and has been obtained as math.NextAfter(1, 2) - 1.
// Notice that an annualized volatility corresponding to such variance would be equal to
// 2.36548601e-7, which is small but far away from the machine epsilon.
const tol = 2.220446049250313e-16

// weightedReturnsStatistic computes a weighted statistic on input returns.
// Weights are applied to returns backwards in time.
// Returns over n (> 0) days are treated as n returns over 1 day each and
// absorb as many weights, which accounts for missing data.
func weightedReturnsStatistic(weights []float64, returns []*marketdata.ReturnEntry, estimator runningEstimator) float64 {
	estimator.reset()

	// Advance the state backward in time.
	nbWeights := len(weights)
	for it, wIt := len(returns)-1, 0; it >= 0 && wIt < nbWeights; it-- {
		current := returns[it]

		nextWIt := min(wIt+current.Days, nbWeights)

		localWeight := 0.0
		for _, w := range weights[wIt:nextWIt] {
			localWeight += w
		}

		// Normalize the return by the square root of its horizon
		// in order to estimate its variance.
		estimator.add(current.Value/math.Sqrt(float64(current.Days)), localWeight)

		// Advance the weight iterator.
		wIt = nextWIt
	}

	return math.Max(tol, estimator.evaluate())
}
