package forecast

import (
	"fmt"
	"math"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/validation"
)

// weightedVolatilityTimeseries computes the timeseries of weighted volatilities between
// a start and an end date according to the input weights.
func weightedVolatilityTimeseries(forecaster Forecaster, returns *marketdata.ReturnsTimeseries, from, to date.Date, horizon int) (*marketdata.Timeseries, error) {
	entries := returns.Entries
	volEntries := make([]*marketdata.Entry, 0, len(entries))

	estimator, err := newRunningVarianceEstimator(returns.ReturnType)
	if err != nil {
		return nil, fmt.Errorf("could not define the running variance estimator: %w", err)
	}

	weights := forecaster.ComputeWeights(horizon)
	annualization := computeAnnualization(returns.Calendar, forecaster)

	// Loop through the returns and the time window simultaneously.
	// The actual dates of the time window depend on the returns calendar.
	for it, date := 0, returns.Calendar.Add(from, 0); it < len(entries) && !date.After(to); {
		currentReturn := entries[it]

		if date.Before(currentReturn.Date) {
			date = returns.Calendar.Add(date, 1)

			continue
		}

		if date.After(currentReturn.Date) {
			it++

			continue
		}

		// Check for ill-defined values: this should never happen.
		variance := weightedReturnsStatistic(weights, entries[:it+1], estimator)
		if !validation.IsNonNegative(variance) {
			return nil, errors.Bug("computed invalid variance %v at date %s", variance, date)
		}

		// Scale the variance up to a business year
		volEntries = append(volEntries, &marketdata.Entry{
			Date:  date,
			Value: math.Sqrt(annualization * variance),
		})

		it++
		date = returns.Calendar.Add(date, 1)
	}

	if len(volEntries) == 0 {
		return nil, errors.SetTag(errors.NotFound("no volatility timeseries points were computed"), tag.NotEnoughData)
	}

	return &marketdata.Timeseries{
		Entries: volEntries,
	}, nil
}
