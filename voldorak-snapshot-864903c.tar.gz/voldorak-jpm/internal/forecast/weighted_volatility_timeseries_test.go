package forecast

import (
	"math"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/validation"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_weightedVolatilityTimeseries_UniformWeights(t *testing.T) {
	t.Parallel()

	var (
		weights = rawWeights{0.25, 0.25, 0.25, 0.25}
		from    = date.New(2020, time.July, 1)
		to      = date.New(2020, time.July, 10)
		horizon = 10
		returns = &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.02,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 6),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 7),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 8),
					Value: -0.02,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 9),
					Value: 0.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 10),
					Value: 0.01,
					Days:  1,
				},
			},
		}
		yearDuration = float64(returns.Calendar.DaysInYear())
		expected     = []*marketdata.Entry{
			{
				Date:  date.New(2020, time.July, 1),
				Value: math.Sqrt(yearDuration * 1.0e-4),
			},
			{
				Date:  date.New(2020, time.July, 2),
				Value: math.Sqrt(yearDuration * 1.0e-4),
			},
			{
				Date:  date.New(2020, time.July, 3),
				Value: 0.01 * math.Sqrt(yearDuration*2.0),
			},
			{
				Date:  date.New(2020, time.July, 6),
				Value: 0.01 * math.Sqrt(yearDuration*1.75),
			},
			{
				Date:  date.New(2020, time.July, 7),
				Value: 0.01 * math.Sqrt(yearDuration*1.75),
			},
			{
				Date:  date.New(2020, time.July, 8),
				Value: 0.01 * math.Sqrt(yearDuration*2.5),
			},
			{
				Date:  date.New(2020, time.July, 9),
				Value: 0.01 * math.Sqrt(yearDuration*1.5),
			},
			{
				Date:  date.New(2020, time.July, 10),
				Value: 0.01 * math.Sqrt(yearDuration*1.5),
			},
		}
	)

	vol, err := weightedVolatilityTimeseries(weights, returns, from, to, horizon)
	require.NoError(t, err)
	assert.Len(t, vol.Entries, len(expected))

	for k, v := range vol.Entries {
		assert.Equal(t, expected[k].Date, v.Date)
		assert.InDelta(t, expected[k].Value, v.Value, 1.0e-15)
	}
}

func Test_weightedVolatilityTimeseries_UniformWeights_NonMatchingTimes(t *testing.T) {
	t.Parallel()

	// Notice that the data on 8th July are missing, so that the corresponding
	// weight is skipped when computing the volatility on 9th July.
	var (
		weights = rawWeights{0.25, 0.25, 0.25, 0.25}
		from    = date.New(2020, time.July, 1)
		to      = date.New(2020, time.July, 9)
		horizon = 10
		returns = &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 2),
					Value: -0.01,
					Days:  2,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.02,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 6),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 7),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 9),
					Value: 0.0,
					Days:  2,
				},
				{
					Date:  date.New(2020, time.July, 10),
					Value: 0.01,
					Days:  1,
				},
			},
		}
		yearDuration = float64(returns.Calendar.DaysInYear())
		expected     = []*marketdata.Entry{
			{
				Date:  date.New(2020, time.July, 2),
				Value: math.Sqrt(yearDuration * 5.0e-5),
			},
			{
				Date:  date.New(2020, time.July, 3),
				Value: math.Sqrt(yearDuration * 5.0e-4 / 3.0),
			},
			{
				Date:  date.New(2020, time.July, 6),
				Value: math.Sqrt(yearDuration * 1.5e-4),
			},
			{
				Date:  date.New(2020, time.July, 7),
				Value: math.Sqrt(yearDuration * 1.625e-4),
			},
			{
				Date:  date.New(2020, time.July, 9),
				Value: math.Sqrt(yearDuration * 1.0e-4 / 2.0),
			},
		}
	)

	vol, err := weightedVolatilityTimeseries(weights, returns, from, to, horizon)
	require.NoError(t, err)
	assert.Len(t, vol.Entries, len(expected))

	for k, v := range vol.Entries {
		assert.Equal(t, expected[k].Date, v.Date)
		assert.InDelta(t, expected[k].Value, v.Value, 1.0e-15)
	}
}

func Test_weightedVolatilityTimeseries_NonUniformWeights(t *testing.T) {
	t.Parallel()

	// Notice that the data on 7th July are missing, so that the corresponding
	// weight is skipped when computing the volatility on 8th July.
	var (
		weights = rawWeights{4.0 / 7.0, 2.0 / 7.0, 1.0 / 7.0}
		from    = date.New(2020, time.July, 1)
		to      = date.New(2020, time.July, 8)
		horizon = 10
		returns = &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2020, time.July, 1),
					Value: 0.01,
					Days:  2,
				},
				{
					Date:  date.New(2020, time.July, 2),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 6),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 8),
					Value: 0.01,
					Days:  2,
				},
			},
		}
		yearDuration = float64(returns.Calendar.DaysInYear())
		expected     = []*marketdata.Entry{
			{
				Date:  date.New(2020, time.July, 1),
				Value: math.Sqrt(yearDuration * 5.0e-5),
			},
			{
				Date:  date.New(2020, time.July, 2),
				Value: math.Sqrt(yearDuration * 11.0e-4 / 14.0),
			},
			{
				Date:  date.New(2020, time.July, 3),
				Value: math.Sqrt(yearDuration * 13.0e-4 / 14.0),
			},
			{
				Date:  date.New(2020, time.July, 6),
				Value: math.Sqrt(yearDuration * 1.0e-4),
			},
			{
				Date:  date.New(2020, time.July, 8),
				Value: math.Sqrt(yearDuration * 4.0e-4 / 7.0),
			},
		}
	)

	vol, err := weightedVolatilityTimeseries(weights, returns, from, to, horizon)
	require.NoError(t, err)
	assert.Len(t, vol.Entries, len(expected))

	for k, v := range vol.Entries {
		assert.Equal(t, expected[k].Date, v.Date)
		assert.InDelta(t, expected[k].Value, v.Value, 1.0e-15)
	}
}

func Test_weightedVolatilityTimeseries_BenchmarkReferenceCase(t *testing.T) {
	t.Parallel()

	var (
		weights = NewMovingAverage()
		from    = date.New(2018, time.August, 20)
		to      = date.New(2018, time.August, 27)
		horizon = 10
		returns = &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2018, time.August, 20),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 21),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 22),
					Value: 0.001,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 23),
					Value: 0.02,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 24),
					Value: -0.005,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 27),
					Value: -0.016,
					Days:  1,
				},
			},
		}
		yearDuration = float64(returns.Calendar.DaysInYear())
		expected     = []*marketdata.Entry{
			{
				Date:  date.New(2018, time.August, 20),
				Value: math.Sqrt(yearDuration * 1.0e-4),
			},
			{
				Date:  date.New(2018, time.August, 21),
				Value: math.Sqrt(yearDuration * 1.0e-4),
			},
			{
				Date:  date.New(2018, time.August, 22),
				Value: math.Sqrt(yearDuration * 6.7e-5),
			},
			{
				Date:  date.New(2018, time.August, 23),
				Value: math.Sqrt(yearDuration * 1.5025e-04),
			},
			{
				Date:  date.New(2018, time.August, 24),
				Value: math.Sqrt(yearDuration * 1.252e-04),
			},
			{
				Date:  date.New(2018, time.August, 27),
				Value: math.Sqrt(yearDuration * 1.47e-04),
			},
		}
	)

	vol, err := weightedVolatilityTimeseries(weights, returns, from, to, horizon)
	require.NoError(t, err)
	assert.Len(t, vol.Entries, len(expected))

	const tol = 1.0e-7

	for k, v := range vol.Entries {
		assert.Equal(t, expected[k].Date, v.Date)
		assert.InDelta(t, expected[k].Value, v.Value, tol)
	}
}

func Test_weightedVolatilityTimeseries_EmptyOutput(t *testing.T) {
	t.Parallel()

	// This case should never be triggered when computing the weighted
	// volatility timeseries through the exposes function ComputeVolatility
	// This test just ensures
	// * internal consistency with the expected behavior
	// * safety check against bad usage of the code
	// * alert in case of unforeseen exceptions
	var (
		weights = NewMovingAverage()
		from    = date.New(2018, time.August, 23)
		to      = date.New(2018, time.August, 27)
		horizon = 10
		returns = &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2018, time.August, 20),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 21),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 22),
					Value: 0.001,
					Days:  1,
				},
			},
		}
	)

	_, err := weightedVolatilityTimeseries(weights, returns, from, to, horizon)
	require.Error(t, err)
}

func Test_weightedVolatilityTimeseries_InvalidReturnType(t *testing.T) {
	t.Parallel()

	_, err := weightedVolatilityTimeseries(
		NewMovingAverage(),
		&marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.ReturnType("Unsupported"),
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2018, time.August, 20),
					Value: 0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 21),
					Value: -0.01,
					Days:  1,
				},
				{
					Date:  date.New(2018, time.August, 22),
					Value: 0.001,
					Days:  1,
				},
			},
		},
		date.New(2018, time.August, 20),
		date.New(2018, time.August, 22),
		10,
	)
	require.Error(t, err)
}

func Test_weightedVolatilityTimeseries_VanishingWindow(t *testing.T) {
	t.Parallel()

	// The internal algorithm requirements allow a volatility forecast
	// to be computed for a zero-amplitude time window, when a single
	// return is available. Notice that this situation is invalidated
	// by the public ComputeVolatility function.

	var (
		cal          = calendar.New(calendar.BusinessDays)
		expectedDate = date.New(2021, time.October, 1)
	)

	res, err := weightedVolatilityTimeseries(
		NewMovingAverage(WithTimeWindow(5)),
		&marketdata.ReturnsTimeseries{
			Calendar:   cal,
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2021, time.October, 1),
					Value: 0.01,
					Days:  1,
				},
			},
		},
		expectedDate,
		expectedDate,
		1,
	)
	require.NoError(t, err)
	assert.Len(t, res.Entries, 1)

	v := res.Entries[0]
	assert.Equal(t, expectedDate, v.Date)
	assert.True(t, validation.IsFinite(v.Value))
}
