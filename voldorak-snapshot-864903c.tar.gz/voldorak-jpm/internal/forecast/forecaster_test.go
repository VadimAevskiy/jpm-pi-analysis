package forecast

import (
	"testing"

	fuzz "github.com/google/gofuzz"
	"github.com/stretchr/testify/assert"
)

func Test_New(t *testing.T) {
	t.Parallel()

	t.Run("moving average", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			opts     []MovingAverageOption
			expected Forecaster
		}{
			"default": {
				opts:     nil,
				expected: defaultMovingAverage(),
			},
			"custom": {
				opts: []MovingAverageOption{
					WithTimeWindow(90),
				},
				expected: &MovingAverage{
					timeWindow: 90,
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got := NewMovingAverage(tc.opts...)
				assert.Equal(t, tc.expected, got)
			})
		}
	})

	t.Run("long memory arch", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			opts     []LongMemoryARCHOption
			expected Forecaster
		}{
			"default": {
				opts:     nil,
				expected: defaultLongMemoryARCH(),
			},
			"custom": {
				opts: []LongMemoryARCHOption{
					WithMaximumReturnLag(90),
					WithLowerCutoff(4.0),
					WithUpperCutoff(512.0),
					WithProgression(2),
					WithLogarithmicDecayFactor(16.0),
				},
				expected: &LongMemoryARCH{
					maximumReturnLag:       90,
					lowerCutoff:            4.0,
					upperCutoff:            512.0,
					progression:            2.0,
					logarithmicDecayFactor: 16.0,
					deltaT:                 deltaT,
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got := NewLongMemoryARCH(tc.opts...)
				assert.Equal(t, tc.expected, got)
			})
		}
	})
}

func Test_rawWeights_ComputeWeights(t *testing.T) {
	t.Parallel()

	const (
		n       = 100
		horizon = 30
	)

	var ws rawWeights
	fuzz.NewWithSeed(0).Funcs(
		func(ws *rawWeights, c fuzz.Continue) {
			// Generate strictly positive weights.
			*ws = make(rawWeights, c.Intn(n))
			for i := range *ws {
				(*ws)[i] = c.ExpFloat64()
			}

			normalize(*ws)
		},
	).Fuzz(&ws)

	got := ws.ComputeWeights(horizon)
	assert.EqualValues(t, ws, got)
}
