package forecast

import (
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// runningEstimator handles the computation of a generic running quantity.
// It implements the following methods:
// - reset resets the internal state of the estimator;
// - add updates the internal estimator variables;
// - evaluate computes the value of the estimator.
// A running estimator is NOT safe for concurrent use and should be always
// reset after usage.
type runningEstimator interface {
	reset()
	add(value, weight float64)
	evaluate() float64
}

// newRunningVarianceEstimator returns the running variance estimator
// depending on the input market data return type.
func newRunningVarianceEstimator(returnType marketdata.ReturnType) (runningEstimator, error) {
	switch returnType {
	case marketdata.LogarithmicReturn,
		marketdata.SimpleReturn:
		return &sampleVarianceEstimator{}, nil

	case marketdata.RelativeReturn:
		return &sampleSecondMomentEstimator{}, nil

	default:
		return nil, errors.Bug("return type %s not supported", returnType)
	}
}

// sampleMeanEstimator estimates the average of a sample.
type sampleMeanEstimator struct {
	average    float64
	sumWeights float64
}

func (sm *sampleMeanEstimator) reset() {
	sm.average = 0.0
	sm.sumWeights = 0.0
}

func (sm *sampleMeanEstimator) add(value, weight float64) {
	sm.sumWeights += weight
	sm.average += weight / sm.sumWeights * (value - sm.average)
}

func (sm sampleMeanEstimator) evaluate() float64 {
	return sm.average
}

// sampleSecondMomentEstimator estimates the second moment of a sample.
type sampleSecondMomentEstimator struct {
	moment     float64
	sumWeights float64
}

func (ssm *sampleSecondMomentEstimator) reset() {
	ssm.moment = 0.0
	ssm.sumWeights = 0.0
}

func (ssm *sampleSecondMomentEstimator) add(value, weight float64) {
	ssm.sumWeights += weight
	ssm.moment += weight / ssm.sumWeights * (value*value - ssm.moment)
}

func (ssm sampleSecondMomentEstimator) evaluate() float64 {
	return ssm.moment
}

// sampleVarianceEstimator satisfies the following properties:
// - its result is guaranteed not be nonnegative in floating-point arithmetic;
// - for single-observation samples it returns a zero variance.
type sampleVarianceEstimator struct {
	average         float64
	sumWeights      float64
	sumCrossWeights float64
	sumSquares      float64
}

func (sv *sampleVarianceEstimator) reset() {
	sv.average = 0.0
	sv.sumCrossWeights = 0.0
	sv.sumSquares = 0.0
	sv.sumWeights = 0.0
}

func (sv *sampleVarianceEstimator) add(value, weight float64) {
	const crossWeightsAmount = 2.0

	sv.sumCrossWeights += crossWeightsAmount * sv.sumWeights * weight
	sv.sumWeights += weight

	d := value - sv.average
	newAvg := sv.average + weight/sv.sumWeights*d
	sv.sumSquares += weight * d * (value - newAvg)
	sv.average = newAvg
}

func (sv sampleVarianceEstimator) evaluate() float64 {
	if sv.sumCrossWeights == 0.0 {
		// This occurs with a single observation: treat it as constant
		return 0.0
	}

	return sv.sumWeights / sv.sumCrossWeights * sv.sumSquares
}
