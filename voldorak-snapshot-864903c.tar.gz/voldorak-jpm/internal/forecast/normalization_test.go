package forecast

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"gonum.org/v1/gonum/floats"
)

func Test_normalize(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			x        []float64
			expected []float64
		}{
			"5 elements": {
				x:        []float64{1.0, 1.0, 1.0, 1.0, 1.0},
				expected: []float64{0.2, 0.2, 0.2, 0.2, 0.2},
			},
			"4 elements": {
				x:        []float64{1.0, 1.0, 1.0, 1.0},
				expected: []float64{0.25, 0.25, 0.25, 0.25},
			},
			"3 elements": {
				x:        []float64{1.0, 1.0, 1.0},
				expected: []float64{1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				// Make a copy to avoid mutating the original
				x := make([]float64, len(tc.x))
				copy(x, tc.x)
				normalize(x)
				assert.InDeltaSlice(t, tc.expected, x, 1.0e-15)
			})
		}
	})

	t.Run("empty slice", func(t *testing.T) {
		t.Parallel()

		// In this case:
		// - the inverse sum of weights of an empty slice is +Inf;
		// - however, since the slice is empty the function takes no effect.

		var ws []float64
		normalize(ws)

		assert.Nil(t, ws)
	})
}

func Benchmark_normalize(b *testing.B) {
	// This test demonstrates the advantage in using gonum/floats.
	// We hereby compare the performances of normalization among:
	// - manual implementation;
	// - manual sum computation and gonum/floats normalization;
	// - sum and normalization reyling on gonum/floats.
	// Weights creation is part of the benchmark to make sure
	// the computation is fully reproducible, otherwise the
	// same slice will be reused and normalization will differ.
	const (
		n       = 10000
		horizon = 100
	)

	// makeWeights is a helper function that returns the testing weights.
	makeWeights := func() []float64 {
		return NewMovingAverage(
			WithTimeWindow(n),
		).ComputeWeights(horizon)
	}

	b.Run("manual sum/manual normalization", func(b *testing.B) {
		for b.Loop() {
			ws := makeWeights()

			sumW := 0.0
			for _, w := range ws {
				sumW += w
			}

			invSumW := 1.0 / sumW
			for i := range ws {
				ws[i] *= invSumW
			}
		}
	})

	b.Run("manual sum/floats normalization", func(b *testing.B) {
		for b.Loop() {
			ws := makeWeights()

			sumW := 0.0
			for _, w := range ws {
				sumW += w
			}

			floats.Scale(1.0/sumW, ws)
		}
	})

	b.Run("floats sum/floats normalization", func(b *testing.B) {
		for b.Loop() {
			normalize(makeWeights())
		}
	})
}
