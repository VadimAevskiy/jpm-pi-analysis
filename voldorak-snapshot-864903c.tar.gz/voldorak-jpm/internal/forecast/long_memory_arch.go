package forecast

import "math"

// LongMemoryARCH provides long-memory autoregressive.
// conditional heteroskedasticity (ARCH) forecast weights.
type LongMemoryARCH struct {
	maximumReturnLag       int
	lowerCutoff            float64
	upperCutoff            float64
	progression            float64
	logarithmicDecayFactor float64
	deltaT                 float64
}

// Check LongMemoryARCH is a Forecaster at compile time.
var _ Forecaster = LongMemoryARCH{}

func defaultLongMemoryARCH() *LongMemoryARCH {
	const (
		defaultMaximumReturnLag       = 1040
		defaultLowerCutoff            = 4.0
		defaultUpperCutoff            = 512.0
		defaultLogarithmicDecayFactor = 1560.0
		defaultSquaredProgression     = 2.0
	)

	lmARCH := &LongMemoryARCH{}
	for _, opt := range []LongMemoryARCHOption{
		WithMaximumReturnLag(defaultMaximumReturnLag),
		WithLowerCutoff(defaultLowerCutoff),
		WithUpperCutoff(defaultUpperCutoff),
		WithProgression(math.Sqrt(defaultSquaredProgression)),
		WithLogarithmicDecayFactor(defaultLogarithmicDecayFactor),
		WithDeltaT(deltaT),
	} {
		opt(lmARCH)
	}

	return lmARCH
}

// LongMemoryARCHOption is a user option that allows to customize
// the default long-memory ARCH configuration.
type LongMemoryARCHOption func(*LongMemoryARCH)

// WithMaximumReturnLag sets the maximum return lag.
func WithMaximumReturnLag(maximumReturnLag int) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.maximumReturnLag = maximumReturnLag
	}
}

// WithUpperCutoff sets the upper cutoff.
func WithUpperCutoff(upperCutoff float64) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.upperCutoff = upperCutoff
	}
}

// WithLowerCutoff sets the lower cutoff.
func WithLowerCutoff(lowerCutoff float64) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.lowerCutoff = lowerCutoff
	}
}

// WithProgression sets the progression coefficient.
func WithProgression(progression float64) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.progression = progression
	}
}

// WithLogarithmicDecayFactor sets the logarithmic decay factor.
func WithLogarithmicDecayFactor(logarithmicDecayFactor float64) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.logarithmicDecayFactor = logarithmicDecayFactor
	}
}

// WithDeltaT sets the process's time scale, expressed as fraction of a day.
func WithDeltaT(deltaT float64) LongMemoryARCHOption {
	return func(m *LongMemoryARCH) {
		m.deltaT = deltaT
	}
}

// NewLongMemoryARCH returns a Long-Memory-ARCH Forecaster.
func NewLongMemoryARCH(opts ...LongMemoryARCHOption) *LongMemoryARCH {
	lmARCH := defaultLongMemoryARCH()
	for _, opt := range opts {
		opt(lmARCH)
	}

	return lmARCH
}

func (lmARCH LongMemoryARCH) ComputeWeights(horizon int) []float64 {
	weights, muEma := lmARCH.computeInternalStates()
	nbComponents := len(weights)

	powersMuk := make([]float64, nbComponents)
	for k := range powersMuk {
		powersMuk[k] = 1.0
	}

	forecastWeights := make([]float64, lmARCH.maximumReturnLag)
	weightsVolComponents := lmARCH.computeWeightVolComponents(weights, muEma, horizon)

	for i := range lmARCH.maximumReturnLag {
		w := 0.0
		for k, mu := range muEma {
			w += (1.0 - mu) * powersMuk[k] * weightsVolComponents[k]
			powersMuk[k] *= mu
		}

		forecastWeights[i] = w
	}

	normalize(forecastWeights)

	return forecastWeights
}

// computeTaus computes the time constants (taus) of the LM-ARCH process.
func (lmARCH LongMemoryARCH) computeTaus() []float64 {
	// Round to the closest integer
	const roundAdjustment = 0.5

	nbComponents := 1 + int(roundAdjustment+math.Log(lmARCH.upperCutoff/lmARCH.lowerCutoff)/math.Log(lmARCH.progression))

	taus := make([]float64, nbComponents)

	tau := lmARCH.lowerCutoff

	for k := range nbComponents {
		taus[k] = tau
		tau *= lmARCH.progression
	}

	return taus
}

// computeInternalStates computes the LM-ARCH and exponential moving average weights.
func (lmARCH LongMemoryARCH) computeInternalStates() ([]float64, []float64) {
	taus := lmARCH.computeTaus()
	nbComponents := len(taus)
	logDecayFactor := math.Log(lmARCH.logarithmicDecayFactor)

	muEma := make([]float64, nbComponents)
	weights := make([]float64, nbComponents)

	for k, tau := range taus {
		w := math.Max(0.0, 1.0-math.Log(tau)/logDecayFactor)
		weights[k] = w
		muEma[k] = math.Exp(-lmARCH.deltaT / tau)
	}

	normalize(weights)

	return weights, muEma
}

func (lmARCH LongMemoryARCH) computeWeightVolComponents(weights, muEma []float64, horizon int) []float64 {
	nbComponents := len(weights)

	// Initialize weight volatility components with the original weights
	effWeightVolComponents := make([]float64, nbComponents)
	sumEffWeightVolComponents := make([]float64, nbComponents)

	for k, w := range weights {
		effWeightVolComponents[k] = w
		sumEffWeightVolComponents[k] = w
	}

	// Run the recursion up to forecast horizon in deltaT steps.
	for iDt := lmARCH.deltaT; iDt < float64(horizon); {
		p := 0.0
		for k, e := range muEma {
			p += (1.0 - e) * effWeightVolComponents[k]
		}

		// Early-advance the loop variable for efficient running average.
		iDt += lmARCH.deltaT

		for k, w := range effWeightVolComponents {
			cmp := muEma[k]*w + p*weights[k]
			effWeightVolComponents[k] = cmp

			// The summed weighted vol components are averaged over the forecast horizon.
			sumEffWeightVolComponents[k] += (cmp - sumEffWeightVolComponents[k]) / iDt
		}
	}

	return sumEffWeightVolComponents
}

func (lmARCH LongMemoryARCH) timeScale() float64 {
	return lmARCH.deltaT
}
