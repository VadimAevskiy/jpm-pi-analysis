package forecast

import (
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/stretchr/testify/assert"
)

func Test_Horizoner(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		horizoner Horizoner
		calendar  *calendar.Calendar
		expected  int
	}{
		"relative horizon/calendar days": {
			horizoner: NewRelativeHorizon(30),
			calendar:  calendar.New(calendar.CalendarDays),
			expected:  30,
		},
		"relative horizon/business days": {
			horizoner: NewRelativeHorizon(22),
			calendar:  calendar.New(calendar.BusinessDays),
			expected:  22,
		},
		"absolute horizon/calendar days": {
			horizoner: NewAbsoluteHorizon(
				date.New(2021, time.September, 1),
				date.New(2021, time.October, 1),
			),
			calendar: calendar.New(calendar.CalendarDays),
			expected: 30,
		},
		"absolute horizon/business days": {
			horizoner: NewAbsoluteHorizon(
				date.New(2021, time.September, 1),
				date.New(2021, time.October, 1),
			),
			calendar: calendar.New(calendar.BusinessDays),
			expected: 22,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := tc.horizoner(tc.calendar)
			assert.Equal(t, tc.expected, got)
		})
	}
}
