package marketdata

import (
	"fmt"
	"strconv"
	"strings"

	errors "github.com/edgelaboratories/go-errors/goerror"
)

// Tenor represents a tenor.
type Tenor string

const (
	daysPerWeek   = 7.0
	monthsPerYear = 12.0
	daysPerYear   = 365.0
)

const (
	overnightKey = "ON"
	weekKey      = "W"
	monthKey     = "M"
	yearKey      = "Y"
)

// ToYearFraction converts a tenor into its equivalent year fraction.
func (t Tenor) ToYearFraction() (float64, error) {
	switch {
	case t.isON():
		return 1.0 / daysPerYear, nil
	case t.isWeek():
		return t.weekTenorToYearFraction()
	case t.isMonth():
		return t.monthTenorToYearFraction()
	case t.isYear():
		return t.yearTenorToYearFraction()
	default:
		return 0.0, errors.Bug("could not parse the type of tenor %s", t)
	}
}

// isON tests whether the tenor is the ON (Over Night) tenor.
func (t Tenor) isON() bool {
	return strings.HasSuffix(string(t), overnightKey)
}

// isWeek tests whether the tenor is a week tenor.
func (t Tenor) isWeek() bool {
	return strings.HasSuffix(string(t), weekKey)
}

// isMonth tests whether the tenor is a month tenor.
func (t Tenor) isMonth() bool {
	return strings.HasSuffix(string(t), monthKey)
}

// isYear tests whether the tenor is a year tenor.
func (t Tenor) isYear() bool {
	return strings.HasSuffix(string(t), yearKey)
}

// weekTenorToYearFraction converts a week tenor to a year fraction.
func (t Tenor) weekTenorToYearFraction() (float64, error) {
	nbDays := strings.TrimSuffix(string(t), weekKey)

	d, err := strconv.ParseUint(nbDays, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of weeks for tenor %s: %w", t, err)
	}

	return float64(d) * daysPerWeek / daysPerYear, nil
}

// monthTenorToYearFraction converts a month tenor to a year fraction.
func (t Tenor) monthTenorToYearFraction() (float64, error) {
	nbMonths := strings.TrimSuffix(string(t), monthKey)

	m, err := strconv.ParseUint(nbMonths, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of months for tenor %s: %w", t, err)
	}

	return float64(m) / monthsPerYear, nil
}

// yearTenorToYearFraction converts a year tenor to a year fraction.
func (t Tenor) yearTenorToYearFraction() (float64, error) {
	nbYears := strings.TrimSuffix(string(t), yearKey)

	y, err := strconv.ParseUint(nbYears, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of years for tenor %s: %w", t, err)
	}

	return float64(y), nil
}
