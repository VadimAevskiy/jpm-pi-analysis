package marketdata

import (
	"math"
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_returner_returnType(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		returner returner
		expected ReturnType
	}{
		"logarithmic": {
			returner: &logarithmicReturn{},
			expected: LogarithmicReturn,
		},
		"relative": {
			returner: &relativeReturn{},
			expected: RelativeReturn,
		},
		"simple": {
			returner: &simpleReturn{},
			expected: SimpleReturn,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := tc.returner.returnType()
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_returner_compute(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	var (
		previous = 1.0
		current  = 2.0
	)

	for name, tc := range map[string]struct {
		returner returner
		expected float64
	}{
		"logarithmic": {
			returner: &logarithmicReturn{},
			expected: math.Log(2.0),
		},
		"relative": {
			returner: &relativeReturn{},
			expected: 1.0,
		},
		"simple": {
			returner: &simpleReturn{},
			expected: 1.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := tc.returner.compute(previous, current)
			assert.InDelta(t, tc.expected, got, tol)
		})
	}
}

func Test_returner_isValid(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		returner returner
		value    float64
		expected bool
	}{
		"logarithmic/positive": {
			returner: &logarithmicReturn{},
			value:    1.0,
			expected: true,
		},
		"logarithmic/negative": {
			returner: &logarithmicReturn{},
			value:    -1.0,
			expected: false,
		},
		"logarithmic/zero": {
			returner: &logarithmicReturn{},
			value:    0.0,
			expected: false,
		},
		"relative/positive": {
			returner: &relativeReturn{},
			value:    1.0,
			expected: true,
		},
		"relative/negative": {
			returner: &relativeReturn{},
			value:    -2.0,
			expected: false,
		},
		"relative/zero": {
			returner: &relativeReturn{},
			value:    0.0,
			expected: false,
		},
		"simple/negative": {
			returner: &simpleReturn{},
			value:    -1.0,
			expected: true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := tc.returner.isValid(tc.value)
			assert.Equal(t, tc.expected, got)
		})
	}
}
