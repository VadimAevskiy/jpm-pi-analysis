package marketdata

import (
	"math"
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_NewReturnsTimeseries(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		expected := &ReturnsTimeseries{
			Entries: ReturnEntries{
				{
					Date:  date.New(2020, time.July, 3),
					Value: 0.2,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 6),
					Value: 1.0 / 6.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 7),
					Value: 1.0 / 7.0,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 8),
					Value: 0.125,
					Days:  1,
				},
				{
					Date:  date.New(2020, time.July, 10),
					Value: 1.0 / 9.0,
					Days:  2,
				},
				{
					Date:  date.New(2020, time.July, 15),
					Value: 0.1,
					Days:  3,
				},
			},
		}

		got, err := NewReturnsTimeseries(t.Context(), newTestTimeseries())
		require.NoError(t, err)

		assert.Len(t, got.Entries, len(expected.Entries))

		for k, v := range expected.Entries {
			assert.True(t, v.Date.Equal(got.At(k).Date))
			assert.Equal(t, v.Days, got.At(k).Days)
			assert.InDelta(t, v.Value, got.At(k).Value, 1.0e-15)
		}

		expectedLast, last := expected.Last(), got.Last()
		assert.True(t, expectedLast.Date.Equal(last.Date))
		assert.Equal(t, expectedLast.Days, last.Days)
		assert.InDelta(t, expectedLast.Value, last.Value, 1.0e-15)
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			ts           *Timeseries
			expectStatus errors.StatusCode
			expectTag    errors.Tag
		}{
			"invalid type": {
				ts:           &Timeseries{Type: Type("Unsupported")},
				expectStatus: 0, // not checked
				expectTag:    "",
			},
			"empty timeseries": {
				ts:           &Timeseries{Type: Stock, ID: "some-id"},
				expectStatus: errors.StatusCodeNotFound,
				expectTag:    tag.NotEnoughData,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := NewReturnsTimeseries(t.Context(), tc.ts)
				require.Error(t, err)

				if tc.expectStatus != 0 {
					errors.AssertStatus(t, tc.expectStatus, err)
					errors.AssertTag(t, tc.expectTag, err)
				}
			})
		}
	})
}

func Test_computeReturnEntries_EmptyReturns(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input *Timeseries
	}{
		"empty timeseries": {
			input: &Timeseries{},
		},
		"single-point timeseries": {
			input: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2020, time.July, 1), Value: 10.0},
				},
			},
		},
		"timeseries with repeated timestamps": {
			input: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2020, time.July, 1), Value: 10.0},
					{Date: date.New(2020, time.July, 1), Value: 12.0},
				},
			},
		},
		"invalid data": {
			input: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2020, time.July, 1), Value: math.NaN()},
					{Date: date.New(2020, time.July, 2), Value: math.NaN()},
					{Date: date.New(2020, time.July, 3), Value: 10.0},
					{Date: date.New(2020, time.July, 4), Value: math.NaN()},
					{Date: date.New(2020, time.July, 5), Value: math.NaN()},
				},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			_, err := computeReturnEntries(t.Context(), tc.input, calendar.New(calendar.BusinessDays), &relativeReturn{})
			require.Error(t, err)
			errors.AssertStatus(t, errors.StatusCodeNotFound, err)
			errors.AssertTag(t, tag.NotEnoughData, err)
		})
	}
}

func Test_computeReturnEntries(t *testing.T) {
	t.Parallel()

	// Notice that:
	// * the input timeseries window ranges from 28-06-2020 to 15-07-2020
	// * the points until 01-07-2020 are zero, so logarithmic and relative returns are not computed
	// * the points at 04/05-07-2020 are on weekends, so the next point (06-07-2020) accounts for three days
	// in calendar convention
	// * the input at 09-07-2020 is missing, so the next point (10-07-2020) accounts for two days
	// in any convention
	// * the inputs at 13/14-07-2020 are invalid, so the next point (15-07-2020) accounts for three days
	// in business convention and for five days in calendar convention.

	input := newTestTimeseries()

	for name, tc := range map[string]struct {
		returner       returner
		expectedDates  []date.Date
		expectedDays   []int
		expectedValues []float64
		convention     calendar.Convention
	}{
		"logarithmic return/business days": {
			returner: &logarithmicReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 1, 1, 1, 2, 3},
			expectedValues: []float64{
				math.Log(12.0 / 10.0),
				math.Log(14.0 / 12.0),
				math.Log(16.0 / 14.0),
				math.Log(18.0 / 16.0),
				math.Log(20.0 / 18.0),
				math.Log(22.0 / 20.0),
			},
			convention: calendar.BusinessDays,
		},
		"relative return/business days": {
			returner: &relativeReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 1, 1, 1, 2, 3},
			expectedValues: []float64{
				0.2,
				1.0 / 6.0,
				1.0 / 7.0,
				0.125,
				1.0 / 9.0,
				0.1,
			},
			convention: calendar.BusinessDays,
		},
		"simple return/business days": {
			returner: &simpleReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.June, 30),
				date.New(2020, time.July, 1),
				date.New(2020, time.July, 2),
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 1, 1, 1, 1, 1, 1, 2, 3},
			expectedValues: []float64{
				0.0,
				0.0,
				10.0,
				2.0,
				2.0,
				2.0,
				2.0,
				2.0,
				2.0,
			},
			convention: calendar.BusinessDays,
		},
		"logarithmic return/calendar days": {
			returner: &logarithmicReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 3, 1, 1, 2, 5},
			expectedValues: []float64{
				math.Log(12.0 / 10.0),
				math.Log(14.0 / 12.0),
				math.Log(16.0 / 14.0),
				math.Log(18.0 / 16.0),
				math.Log(20.0 / 18.0),
				math.Log(22.0 / 20.0),
			},
			convention: calendar.CalendarDays,
		},
		"relative return/calendar days": {
			returner: &relativeReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 3, 1, 1, 2, 5},
			expectedValues: []float64{
				0.2,
				1.0 / 6.0,
				1.0 / 7.0,
				0.125,
				1.0 / 9.0,
				0.1,
			},
			convention: calendar.CalendarDays,
		},
		"simple return/calendar days": {
			returner: &simpleReturn{},
			expectedDates: []date.Date{
				date.New(2020, time.June, 29),
				date.New(2020, time.June, 30),
				date.New(2020, time.July, 1),
				date.New(2020, time.July, 2),
				date.New(2020, time.July, 3),
				date.New(2020, time.July, 6),
				date.New(2020, time.July, 7),
				date.New(2020, time.July, 8),
				date.New(2020, time.July, 10),
				date.New(2020, time.July, 15),
			},
			expectedDays: []int{1, 1, 1, 1, 1, 3, 1, 1, 2, 5},
			expectedValues: []float64{
				0.0,
				0.0,
				0.0,
				10.0,
				2.0,
				2.0,
				2.0,
				2.0,
				2.0,
				2.0,
			},
			convention: calendar.CalendarDays,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got, err := computeReturnEntries(t.Context(), input, calendar.New(tc.convention), tc.returner)
			require.NoError(t, err)

			assert.Len(t, got, len(tc.expectedDates))

			for k, v := range got {
				assert.True(t, tc.expectedDates[k].Equal(v.Date))
				assert.Equal(t, tc.expectedDays[k], v.Days)
				assert.InDelta(t, tc.expectedValues[k], v.Value, 1.0e-15)
			}
		})
	}
}

func Test_newReturnerMarketdataType(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tp Type
		}{
			"fund":          {tp: Fund},
			"fx":            {tp: FX},
			"index":         {tp: Index},
			"stock":         {tp: Stock},
			"private asset": {tp: PrivateAsset},
			"swap rate":     {tp: SwapRate},
			"ois rate":      {tp: OISRate},
			"fx forward":    {tp: FXForwardRate},
			"interest rate": {tp: InterestRate},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				r, err := newReturnerMarketdataType(tc.tp)
				require.NoError(t, err)

				_, ok := r.(*relativeReturn)
				assert.True(t, ok)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := newReturnerMarketdataType(Type("Invalid"))
		require.Error(t, err)
	})
}
