package marketdata

import (
	"math"

	"github.com/edgelaboratories/voldorak/internal/validation"
)

// ReturnType defines the type of return.
type ReturnType string

const (
	// LogarithmicReturn defines a logarithmic return.
	LogarithmicReturn ReturnType = "LogarithmicReturn"
	// RelativeReturn defines a relative return.
	RelativeReturn ReturnType = "RelativeReturn"
	// SimpleReturn defines a simple return.
	SimpleReturn ReturnType = "SimpleReturn"
)

// returner takes care of the computation of the return between
// a current and a next observation. It also possesses a method
// to check the validity of either of the two operands.
// Notice that this check may be stricter than the one ensuring
// the mathematical correctness of the return computation.
type returner interface {
	returnType() ReturnType
	compute(current, next float64) float64
	isValid(current float64) bool
}

// logarithmicReturn computes logarithmic returns.
type logarithmicReturn struct{}

func (r *logarithmicReturn) returnType() ReturnType {
	return LogarithmicReturn
}

func (r *logarithmicReturn) compute(current, next float64) float64 {
	return math.Log(next / current)
}

func (r *logarithmicReturn) isValid(current float64) bool {
	return validation.IsPositive(current)
}

// relativeReturn computes relative returns.
type relativeReturn struct{}

func (r *relativeReturn) returnType() ReturnType {
	return RelativeReturn
}

func (r *relativeReturn) compute(current, next float64) float64 {
	return next/current - 1.0
}

func (r *relativeReturn) isValid(current float64) bool {
	return validation.IsPositive(current)
}

// simpleReturn computes simple returns.
type simpleReturn struct{}

func (r *simpleReturn) returnType() ReturnType {
	return SimpleReturn
}

func (r *simpleReturn) compute(current, next float64) float64 {
	return next - current
}

func (r *simpleReturn) isValid(current float64) bool {
	return validation.IsFinite(current)
}
