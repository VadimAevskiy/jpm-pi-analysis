package marketdata

import (
	"slices"
	"sort"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
)

// Entry defines a time series entry as a date-value pair.
type Entry struct {
	Date  date.Date
	Value float64
}

// Entries is a chronologically sorted set of entries.
type Entries []*Entry

// Timeseries represents a time series as a collection of entries
// characterized by an ID and a market data type.
type Timeseries struct {
	ID      string
	Type    Type
	Entries Entries
}

// IsEmpty returns true if the time series has got no entries.
// This includes the case when the time series itself is nil.
func (ts *Timeseries) IsEmpty() bool {
	return ts == nil || ts.NumEntries() == 0
}

// Last returns the (chornologically) last return entry.
func (ts Timeseries) Last() *Entry {
	return ts.At(ts.NumEntries() - 1)
}

// At returns the i-th timeseries entry. If i is not within
// the returns entries index span, At will panic.
func (ts Timeseries) At(i int) *Entry {
	return ts.Entries[i]
}

// NumEntries returns the number of entries.
func (ts Timeseries) NumEntries() int {
	return len(ts.Entries)
}

// From returns a time series holding only the entries
// starting not earlier than from.
func (ts *Timeseries) From(from date.Date) *Timeseries {
	if ts.IsEmpty() || !ts.At(0).Date.Before(from) {
		// Nothing to do if the time series is empty
		// or it starts already later than from.
		return ts
	}

	// Use binary search on the (sorted) entries
	// to find the new starting entry.
	// Notice that in this case we're looking for
	// the first entry not before the from date.
	if k := sort.Search(ts.NumEntries(), func(i int) bool {
		return !ts.Entries[i].Date.Before(from)
	}); k < ts.NumEntries() {
		return &Timeseries{
			ID:      ts.ID,
			Type:    ts.Type,
			Entries: ts.Entries[k:],
		}
	}

	// If no such entry could be found, the restriction
	// yields an empty time series.
	return &Timeseries{
		ID:   ts.ID,
		Type: ts.Type,
	}
}

// To returns a time series holding only the entries
// starting not later than to.
func (ts *Timeseries) To(to date.Date) *Timeseries {
	if ts.IsEmpty() || !ts.Last().Date.After(to) {
		// Nothing to do if the time series is empty
		// or it starts already earlier than to.
		return ts
	}

	// Use binary search on the (sorted) entries
	// to find the new ending entry.
	// Notice that in this case we're looking for
	// the first entry strictly after the to date.
	if k := sort.Search(ts.NumEntries(), func(i int) bool {
		return ts.Entries[i].Date.After(to)
	}); k < ts.NumEntries() && k > 0 {
		return &Timeseries{
			ID:      ts.ID,
			Type:    ts.Type,
			Entries: ts.Entries[:k],
		}
	}

	// If no such entry could be found, the restriction
	// yields an empty time series.
	return &Timeseries{
		ID:   ts.ID,
		Type: ts.Type,
	}
}

// CalendarConvention returns the calendar convention associated
// with the time series market data type.
//
// By default, a calendar-days convention is returned.
func (ts *Timeseries) CalendarConvention() calendar.Convention {
	switch ts.Type {
	case Fund, FX, Index, Stock, PrivateAsset, SwapRate, OISRate, FXForwardRate, InterestRate:
		return calendar.BusinessDays

	default:
		return calendar.CalendarDays
	}
}

// FillGapsMonthlyEndLinearly fills the time series gaps by linearly interpolating the timeseries at the end of each month.
// It seeks for the last business date of each month (up to 'to')
// if the entry at that date is missing, then it interpolates it.
func (ts *Timeseries) FillGapsMonthlyEndLinearly(to date.Date) {
	if ts.IsEmpty() || !to.After(ts.At(0).Date) {
		return
	}

	// Iterate over each month end date in the time series range.
	from := ts.At(0).Date
	currentIndex := 0

	calendar := calendar.New(ts.CalendarConvention())
	nextDate := nextEndOfMonthDate(from, calendar)

	for ; !nextDate.After(to); nextDate = nextEndOfMonthDate(nextDate, calendar) {
		for currentIndex < ts.NumEntries() && ts.At(currentIndex).Date.Before(nextDate) {
			currentIndex++
		}

		if currentIndex < ts.NumEntries() {
			if ts.At(currentIndex).Date == nextDate {
				continue
			}

			// Interpolate linearly between the previous and next known entries.
			prevEntry := ts.At(currentIndex - 1)
			currentEntry := ts.At(currentIndex)

			// Linear interpolation formula
			interpolatedValue := prevEntry.Value + (currentEntry.Value-prevEntry.Value)*
				float64(calendar.DaysBetween(prevEntry.Date, nextDate))/float64(calendar.DaysBetween(prevEntry.Date, currentEntry.Date))

			// Insert the interpolated entry into the time series.
			newEntry := &Entry{
				Date:  nextDate,
				Value: interpolatedValue,
			}

			// Insert newEntry at currentIndex
			ts.Entries = append(ts.Entries[:currentIndex], append([]*Entry{newEntry}, ts.Entries[currentIndex:]...)...)

			currentIndex++

			continue
		}

		// Flat extrapolation after the end of the time series.
		lastEntry := ts.Last()

		newEntry := &Entry{
			Date:  nextDate,
			Value: lastEntry.Value,
		}

		ts.Entries = append(ts.Entries, newEntry)
	}
}

func nextEndOfMonthDate(currentDate date.Date, calendar *calendar.Calendar) date.Date {
	shiftedDate := calendar.Next(currentDate)

	return calendar.LatestBefore(date.New(shiftedDate.Year(), shiftedDate.Month()+1, 1).Add(-1))
}

// ShiftToCalendarDay shifts each entry date to the previous calendar date
// if this entry date is not in the associated underlying calendar convention.
// In case of conflictual dates, the first entry is kept and the other one(s) removed.
func (ts *Timeseries) ShiftToCalendarDay() {
	calendar := calendar.New(ts.CalendarConvention())

	for i := range ts.Entries {
		ts.Entries[i].Date = calendar.LatestBefore(ts.Entries[i].Date)
	}

	ts.Entries = slices.CompactFunc(ts.Entries, func(a, b *Entry) bool {
		return a.Date == b.Date
	})
}
