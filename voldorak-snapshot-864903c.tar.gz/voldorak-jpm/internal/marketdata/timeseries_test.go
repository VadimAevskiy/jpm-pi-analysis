package marketdata

import (
	"math"
	"math/rand"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/leanovate/gopter"
	"github.com/leanovate/gopter/gen"
	"github.com/leanovate/gopter/prop"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func newTestTimeseries() *Timeseries {
	return &Timeseries{
		ID:   "cd641ed3",
		Type: Index,
		Entries: []*Entry{
			{Date: date.New(2020, time.June, 28), Value: 0.0},
			{Date: date.New(2020, time.June, 29), Value: 0.0},
			{Date: date.New(2020, time.June, 30), Value: 0.0},
			{Date: date.New(2020, time.July, 1), Value: 0.0},
			{Date: date.New(2020, time.July, 2), Value: 10.0},
			{Date: date.New(2020, time.July, 3), Value: 12.0},
			{Date: date.New(2020, time.July, 6), Value: 14.0},
			{Date: date.New(2020, time.July, 7), Value: 16.0},
			{Date: date.New(2020, time.July, 8), Value: 18.0},
			{Date: date.New(2020, time.July, 10), Value: 20.0},
			{Date: date.New(2020, time.July, 13), Value: math.NaN()},
			{Date: date.New(2020, time.July, 14), Value: math.NaN()},
			{Date: date.New(2020, time.July, 15), Value: 22.0},
		},
	}
}

func Test_Timeseries_Last(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	e := newTestTimeseries().Last()
	assert.Equal(t, date.New(2020, time.July, 15), e.Date)
	assert.InDelta(t, 22.0, e.Value, tol)
}

func Test_Timeseries_At(t *testing.T) {
	t.Parallel()

	ts := newTestTimeseries()

	for k, expected := range ts.Entries {
		assert.Equal(t, expected, ts.At(k))
	}
}

func Test_Timeseries_IsEmpty(t *testing.T) {
	t.Parallel()

	t.Run("not empty", func(t *testing.T) {
		t.Parallel()

		assert.False(t, newTestTimeseries().IsEmpty())
	})

	t.Run("empty", func(t *testing.T) {
		t.Parallel()

		for _, ts := range []*Timeseries{
			{},
			nil,
		} {
			assert.True(t, ts.IsEmpty())
		}
	})
}

// newTestEntriesFromToWithSkippingProb is a helper function that returns
// entries with dates between from and to (both included) with an input
// skipping probability function.
// Values are not set by simplicity and should not be used.
// From is assumed to be not after to, and p must lie in [0,1).
func newTestEntriesFromToWithSkippingProb(from, to date.Date, p float64) Entries {
	rng := rand.New(rand.NewSource(0)) //nolint:gosec

	entries := make(Entries, 0, to.Sub(from)+1)
	for current := from; !current.After(to); current = current.Add(1) {
		if rng.Float64() < p {
			continue
		}

		entries = append(entries, &Entry{
			Date: current,
		})
	}

	return entries
}

func Test_Timeseries_FromTo(t *testing.T) {
	t.Parallel()

	// This battery of tests checks that the From and To
	// restrictions satisfy intuitive consistency properties.
	// The test time series has 50% probability of missing data.

	var (
		origin = date.New(2022, time.January, 1)
		ts     = &Timeseries{
			ID:      "bbbb",
			Type:    Index,
			Entries: newTestEntriesFromToWithSkippingProb(origin, origin.Add(365), 0.5),
		}
	)

	props := gopter.NewProperties(gopter.DefaultTestParametersWithSeed(1234))

	props.Property("restriction on empty time series", prop.ForAll(
		func(fromDays, toDays int) bool {
			// Restriction on an empty time series is ineffective.
			var ts *Timeseries

			return ts.From(origin.Add(fromDays)) == ts &&
				ts.To(origin.Add(toDays)) == ts
		},
		gen.IntRange(-750, 750),
		gen.IntRange(-750, 750),
	))

	props.Property("from and to commute", prop.ForAll(
		func(fromDays, daysDiff int) bool {
			from, to := origin.Add(fromDays), origin.Add(fromDays+daysDiff)

			return ts.From(from).To(to).NumEntries() == ts.To(to).From(from).NumEntries()
		},
		gen.IntRange(-180, 180),
		gen.IntRange(1, 365),
	))

	props.Property("restriction lies within input window", prop.ForAll(
		func(fromDays, toDays int) bool {
			restricted := ts.
				From(origin.Add(fromDays)).
				To(origin.Add(toDays))

			// If the restricted time series is not empty,
			// the restriction must not lie out of (from, to).

			return restricted.IsEmpty() ||
				!restricted.At(0).Date.Before(ts.At(0).Date) &&
					!restricted.Last().Date.After(ts.Last().Date)
		},
		gen.IntRange(-750, 750),
		gen.IntRange(-750, 750),
	))

	props.Property("empty restriction", prop.ForAll(
		func(fromDays, daysDiff int) bool {
			return ts.
				From(origin.Add(fromDays)).
				To(origin.Add(fromDays - daysDiff)).
				IsEmpty()
		},
		gen.IntRange(-180, 180),
		gen.IntRange(1, 365),
	))

	props.Property("no more entries than original", prop.ForAll(
		func(fromDays, toDays int) bool {
			return ts.
				From(origin.Add(fromDays)).
				To(origin.Add(toDays)).
				NumEntries() <= ts.NumEntries()
		},
		gen.IntRange(-750, 750),
		gen.IntRange(-750, 750),
	))

	props.Property("preserves original", prop.ForAll(
		func(fromDays, toDays int) bool {
			before := ts.NumEntries()

			_ = ts.
				From(origin.Add(fromDays)).
				To(origin.Add(toDays))

			return ts.NumEntries() == before
		},
		gen.IntRange(-750, 750),
		gen.IntRange(-750, 750),
	))

	props.TestingRun(t)
}

func Test_Timeseries_Calendar(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name     string
		t        Type
		expected calendar.Convention
	}{
		{
			"fund",
			Fund,
			calendar.BusinessDays,
		},
		{
			"fx",
			FX,
			calendar.BusinessDays,
		},
		{
			"index",
			Index,
			calendar.BusinessDays,
		},
		{
			"stock",
			Stock,
			calendar.BusinessDays,
		},
		{
			"SwapRate",
			SwapRate,
			calendar.BusinessDays,
		},
		{
			"OISRate",
			OISRate,
			calendar.BusinessDays,
		},
		{
			"FXForwardRate",
			FXForwardRate,
			calendar.BusinessDays,
		},
		{
			"InterestRate",
			InterestRate,
			calendar.BusinessDays,
		},
		{
			"unknown",
			Type("Unknown"),
			calendar.CalendarDays,
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, (&Timeseries{
				Type: tc.t,
			}).CalendarConvention())
		})
	}
}

func Test_Timeseries_FillGapsMonthlyEndLinearly(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	for name, tc := range map[string]struct {
		ts       *Timeseries
		to       date.Date
		expected *Timeseries
	}{
		"empty timeseries": {
			ts:       &Timeseries{},
			to:       date.New(2025, time.December, 31),
			expected: &Timeseries{},
		},
		"to before first date": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.March, 15), Value: 50.0},
				},
			},
			to: date.New(2025, time.February, 28),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.March, 15), Value: 50.0},
				},
			},
		},
		"single value timeseries": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 15), Value: 100.0},
				},
			},
			to: date.New(2025, time.March, 31),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 15), Value: 100.0},
					{Date: date.New(2025, time.January, 31), Value: 100.0},
					{Date: date.New(2025, time.February, 28), Value: 100.0},
					{Date: date.New(2025, time.March, 31), Value: 100.0},
				},
			},
		},
		"single value timeseries/end of month": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 31), Value: 100.0},
				},
			},
			to: date.New(2025, time.February, 28),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 31), Value: 100.0},
					{Date: date.New(2025, time.February, 28), Value: 100.0},
				},
			},
		},
		"multiple values with gaps": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.February, 10), Value: 200.0},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
				},
			},
			to: date.New(2025, time.March, 31),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.January, 31), Value: 152.38095238095238},
					{Date: date.New(2025, time.February, 10), Value: 200.0},
					{Date: date.New(2025, time.February, 28), Value: 278.2608695652174},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
					{Date: date.New(2025, time.March, 31), Value: 300.0},
				},
			},
		},
		"multiple values with gaps/date at end of month": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.February, 28), Value: 200.0},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
				},
			},
			to: date.New(2025, time.March, 31),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.January, 31), Value: 128.2051282051282},
					{Date: date.New(2025, time.February, 28), Value: 200.0},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
					{Date: date.New(2025, time.March, 31), Value: 300.0},
				},
			},
		},
		"multiple values with gaps/private asset, business days": {
			ts: &Timeseries{
				Type: PrivateAsset,
				Entries: []*Entry{
					{Date: date.New(2025, time.July, 20), Value: 100.0},
					{Date: date.New(2025, time.August, 28), Value: 200.0},
					{Date: date.New(2025, time.September, 5), Value: 300.0},
				},
			},
			to: date.New(2025, time.September, 30),
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.July, 20), Value: 100.0},
					{Date: date.New(2025, time.July, 31), Value: 131.0344827586207},
					{Date: date.New(2025, time.August, 28), Value: 200.0},
					{Date: date.New(2025, time.August, 29), Value: 216.66666666666666},
					{Date: date.New(2025, time.September, 5), Value: 300.0},
					{Date: date.New(2025, time.September, 30), Value: 300.0},
				},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			tc.ts.FillGapsMonthlyEndLinearly(tc.to)

			require.Len(t, tc.expected.Entries, len(tc.ts.Entries))

			for k, expectedEntry := range tc.expected.Entries {
				actualEntry := tc.ts.Entries[k]
				assert.Equal(t, expectedEntry.Date, actualEntry.Date)
				assert.InDelta(t, expectedEntry.Value, actualEntry.Value, tol)
			}
		})
	}
}

func Test_nextEndOfMonthDate(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		currentDate date.Date
		convention  calendar.Convention
		expected    date.Date
	}{
		"current month/business days": {
			currentDate: date.New(2025, time.August, 15),
			convention:  calendar.BusinessDays,
			expected:    date.New(2025, time.August, 29),
		},
		"current month/calendar days": {
			currentDate: date.New(2025, time.August, 15),
			convention:  calendar.CalendarDays,
			expected:    date.New(2025, time.August, 31),
		},
		"end of month/business days": {
			currentDate: date.New(2025, time.August, 29),
			convention:  calendar.BusinessDays,
			expected:    date.New(2025, time.September, 30),
		},
		"end of month/calendar days": {
			currentDate: date.New(2025, time.August, 31),
			convention:  calendar.CalendarDays,
			expected:    date.New(2025, time.September, 30),
		},
		"two days before end of month/business days": {
			currentDate: date.New(2025, time.August, 27),
			convention:  calendar.BusinessDays,
			expected:    date.New(2025, time.August, 29),
		},
		"just before end of month/business days": {
			currentDate: date.New(2025, time.August, 28),
			convention:  calendar.BusinessDays,
			expected:    date.New(2025, time.August, 29),
		},
		"two days before end of month/calendar days": {
			currentDate: date.New(2025, time.August, 29),
			convention:  calendar.CalendarDays,
			expected:    date.New(2025, time.August, 31),
		},
		"just before end of month/calendar days": {
			currentDate: date.New(2025, time.August, 30),
			convention:  calendar.CalendarDays,
			expected:    date.New(2025, time.August, 31),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			nextDate := nextEndOfMonthDate(tc.currentDate, calendar.New(tc.convention))
			assert.Equal(t, tc.expected, nextDate)
		})
	}
}

func Test_Timeseries_ShiftToCalendarDay(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	for name, tc := range map[string]struct {
		ts       *Timeseries
		expected *Timeseries
	}{
		"empty timeseries": {
			ts:       &Timeseries{},
			expected: &Timeseries{},
		},
		"calendar days": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.February, 10), Value: 200.0},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
				},
			},
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.January, 20), Value: 100.0},
					{Date: date.New(2025, time.February, 10), Value: 200.0},
					{Date: date.New(2025, time.March, 5), Value: 300.0},
				},
			},
		},
		"business days/private asset": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.October, 15), Value: 100.0},
					{Date: date.New(2025, time.October, 19), Value: 300.0},
				},
				Type: PrivateAsset,
			},
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.October, 15), Value: 100.0},
					{Date: date.New(2025, time.October, 17), Value: 300.0},
				},
			},
		},
		"business days/private asset/duplicates": {
			ts: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.October, 15), Value: 100.0},
					{Date: date.New(2025, time.October, 17), Value: 200.0},
					{Date: date.New(2025, time.October, 19), Value: 300.0},
				},
				Type: PrivateAsset,
			},
			expected: &Timeseries{
				Entries: []*Entry{
					{Date: date.New(2025, time.October, 15), Value: 100.0},
					{Date: date.New(2025, time.October, 17), Value: 200.0},
				},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			tc.ts.ShiftToCalendarDay()

			require.Len(t, tc.expected.Entries, len(tc.ts.Entries))

			for k, expectedEntry := range tc.expected.Entries {
				actualEntry := tc.ts.Entries[k]
				assert.Equal(t, expectedEntry.Date, actualEntry.Date)
				assert.InDelta(t, expectedEntry.Value, actualEntry.Value, tol)
			}
		})
	}
}
