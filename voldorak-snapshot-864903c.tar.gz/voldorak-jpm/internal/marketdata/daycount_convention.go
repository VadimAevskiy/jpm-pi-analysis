package marketdata

import (
	"github.com/edgelaboratories/go-libraries/daycount"
)

type DaycountConvention string

const (
	actAct            DaycountConvention = "ActAct"
	actThreeSixty     DaycountConvention = "ActThreeSixty"
	thirtyThreeSixty  DaycountConvention = "ThirtyThreeSixty"
	actThreeSixtyFive DaycountConvention = "ActThreeSixtyFive"
)

// parseDaycountConventionWithDefault converts the a provider daycount convention
// into a supported internal daycount convention.
// If the input convention is nil or not supported, the defaultConvention is returned.
func parseDaycountConventionWithDefault(convention DaycountConvention, defaultConvention daycount.Convention) daycount.Convention {
	switch convention {
	case actAct:
		return daycount.ActualActual
	case actThreeSixty:
		return daycount.ActualThreeSixty
	case thirtyThreeSixty:
		return daycount.ThirtyThreeSixtyEuropean
	case actThreeSixtyFive:
		return daycount.ActualThreeSixtyFiveFixed
	default:
		return defaultConvention
	}
}
