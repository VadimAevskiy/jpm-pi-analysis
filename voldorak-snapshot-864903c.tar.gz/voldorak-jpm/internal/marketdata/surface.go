package marketdata

type VolatilitySurface struct {
	Data               [][]float64 `json:"surface"`
	TenorYearFractions []float64   `json:"tenors"`
	Strikes            []float64   `json:"strikes"`
}

// HestonParameters represents the parameters of the Heston model.
// V0 is the initial variance.
// Kappa is the mean reversion speed.
// Theta is the long-term variance.
// Rho is the correlation between the asset price and variance.
// Sigma is the volatility of volatility.
type HestonParameters struct {
	V0    float64
	Kappa float64
	Theta float64
	Rho   float64
	Sigma float64
}
