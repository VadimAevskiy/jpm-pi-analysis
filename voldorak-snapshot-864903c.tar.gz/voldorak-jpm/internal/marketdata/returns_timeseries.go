package marketdata

import (
	"context"
	"fmt"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

// ReturnEntry defines a return time series entry as
// defined by a date-value pair and the number of days
// the return is applied to.
// Days should be interpreted according to the implicit
// calendar convention holding based on the market data type.
type ReturnEntry struct {
	Date  date.Date
	Value float64
	Days  int
}

// ReturnEntries is a chronologically sorted set of return entries.
type ReturnEntries = []*ReturnEntry

// ReturnsTimeseries represents a time series of returns.
// As opposed to a Timeseries, it also exposes:
// - the calendar convention
// - the return type
// associated to the market data type.
type ReturnsTimeseries struct {
	Entries    ReturnEntries
	Calendar   *calendar.Calendar
	ReturnType ReturnType
}

// NewReturnsTimeseries constructs a time series of returns from an input timeseries
// with a given return type. The input time series must be chronologically sorted.
func NewReturnsTimeseries(ctx context.Context, timeseries *Timeseries) (*ReturnsTimeseries, error) {
	calendar := calendar.New(timeseries.CalendarConvention())

	returner, err := newReturnerMarketdataType(timeseries.Type)
	if err != nil {
		return nil, fmt.Errorf("could not define calendar and returner from type: %w", err)
	}

	entries, err := computeReturnEntries(ctx, timeseries, calendar, returner)
	if err != nil {
		return nil, fmt.Errorf("could not compute returns time series: %w", err)
	}

	return &ReturnsTimeseries{
		Entries:    entries,
		Calendar:   calendar,
		ReturnType: returner.returnType(),
	}, nil
}

// Last returns the (chornologically) last return entry.
func (r ReturnsTimeseries) Last() *ReturnEntry {
	return r.At(len(r.Entries) - 1)
}

// At returns the i-th timeseries entry. If i is not within
// the returns entries index span, At will panic.
func (r ReturnsTimeseries) At(i int) *ReturnEntry {
	return r.Entries[i]
}

// computeReturnEntries constructs the return entries of an input time series
// based on the input calendar and returner.
func computeReturnEntries(ctx context.Context, timeseries *Timeseries, calendar *calendar.Calendar, returner returner) (ReturnEntries, error) {
	const minEntries = 2

	logger := logger.FromContext(ctx)

	entries := timeseries.Entries

	n := len(entries)
	if n < minEntries {
		// At least two points are necessary to compute a returns time series
		return nil, errors.SetTag(errors.NotFound("at least two points are required to compute returns, but got %d", n), tag.NotEnoughData)
	}

	// There are at most n-1 returns, where n is the number of time series entries
	returns := make(ReturnEntries, 0, n-1)

	// Define two iterators for current and next time to handle exceptions
	currentIt, nextIt := 0, 1
	for currentIt < n-1 && nextIt < n {
		current, next := entries[currentIt], entries[nextIt]

		if !calendar.IsActive(current.Date) {
			logger.Debugf("skipping date %s", current.Date)

			// Advance both iterators to compute the return on a following date.
			currentIt, nextIt = nextIt, nextIt+1

			continue
		}

		if !calendar.IsActive(next.Date) {
			logger.Debugf("skipping date %s", next.Date)

			// Retain the current date as valid and compute the return for a following date
			nextIt++

			continue
		}

		if next.Date.Equal(current.Date) {
			// This case should not happen.
			// Advance the next iterator to prevent returns over zero days.
			logger.Debugf("double value at date %s", next.Date)

			nextIt++

			continue
		}

		currentValue, nextValue := current.Value, next.Value
		// Invalid data count as missing returns, so that the next valid return shall be applied to more days.
		if !returner.isValid(currentValue) {
			// Advance both indices
			logger.Debugf("value %v at date %s cannot be used to compute %s", currentValue, current.Date, returner.returnType())

			currentIt, nextIt = nextIt, nextIt+1

			continue
		}

		if !returner.isValid(nextValue) {
			// Advance only the next index
			logger.Debugf("value %v at date %s cannot be used to compute %s", nextValue, next.Date, returner.returnType())

			nextIt++

			continue
		}

		returns = append(returns, &ReturnEntry{
			Date:  next.Date,
			Value: returner.compute(currentValue, nextValue),
			Days:  calendar.DaysBetween(current.Date, next.Date),
		})
		currentIt, nextIt = nextIt, nextIt+1
	}

	if len(returns) == 0 {
		return nil, errors.SetTag(errors.NotFound("no valid %s was computed", returner.returnType()), tag.NotEnoughData)
	}

	return returns, nil
}

// newReturnInfoFromMarketdataType maps an input marketdata type into
// return-related information, namely:
// - time series return;
// - calendar convention.
func newReturnerMarketdataType(t Type) (returner, error) {
	switch t {
	case Fund, FX, Index, Stock, PrivateAsset, SwapRate, OISRate, FXForwardRate, InterestRate:
		// The above marketdata types are:
		// - modeled by a geometric Brownian motion, so use relative returns;
		// - quoted (usually) on working days only.
		return &relativeReturn{}, nil

	default:
		return nil, errors.Bug("market data type %s not associated to return", t)
	}
}
