package marketdata

import (
	"testing"

	"github.com/edgelaboratories/go-libraries/daycount"
	"github.com/stretchr/testify/assert"
)

func Test_parseDaycountConvention(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    DaycountConvention
		expected daycount.Convention
	}{
		"ActualActual": {
			actAct,
			daycount.ActualActual,
		},
		"ActualThreeSixty": {
			actThreeSixty,
			daycount.ActualThreeSixty,
		},
		"ThirtyThreeSixty": {
			thirtyThreeSixty,
			daycount.ThirtyThreeSixtyEuropean,
		},
		"ActualThreeSixtyFiveFixed": {
			actThreeSixtyFive,
			daycount.ActualThreeSixtyFiveFixed,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, parseDaycountConventionWithDefault(tc.input, daycount.ThirtyThreeSixtyEuropean))
		})
	}
}

func Test_parseDaycountConvention_Fallback(t *testing.T) {
	t.Parallel()

	assert.Equal(t, daycount.ThirtyThreeSixtyEuropean, parseDaycountConventionWithDefault("", daycount.ThirtyThreeSixtyEuropean))
}

func Test_parseDaycountConvention_Unsupported(t *testing.T) {
	t.Parallel()

	var convention DaycountConvention = "ThirtyThreeSixtyItalian"
	assert.Equal(t, daycount.ThirtyThreeSixtyEuropean, parseDaycountConventionWithDefault(convention, daycount.ThirtyThreeSixtyEuropean))
}
