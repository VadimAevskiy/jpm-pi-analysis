package marketdata

import (
	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	"github.com/edgelaboratories/go-libraries/date"
)

type Currency struct {
	ID string `json:"id" valid:"required,isocurrency"`
}

type Issuer struct {
	ID string `json:"id" valid:"required,uuid"`
}

type Status string

const (
	Active  Status = "Active"
	Invalid Status = "Invalid"
)

type underlyingInput struct {
	Underlying   underlyingData `json:"underlying"   valid:"required"`
	InitialValue *float64       `json:"initialValue" valid:"-"`
	Weight       *float64       `json:"weight"       valid:"-"`
	Quantity     *float64       `json:"quantity"     valid:"-"`
	FxSpotRate   *float64       `json:"fxSpotRate"   valid:"-"`
}

type underlyingData struct {
	ID               string    `json:"id"               valid:"optional"`
	Type             string    `json:"type"             valid:"required,in(Bond|Cash|Equity|Fund|Fx|Index|PerpetualBond)"`
	Currency         *Currency `json:"currency"         valid:"-"`
	ForeignCurrency  *Currency `json:"foreignCurrency"  valid:"-"`
	DomesticCurrency *Currency `json:"domesticCurrency" valid:"-"`
	Status           Status    `json:"assetStatus"      valid:"-"`
}

type ExerciseType string

const (
	American ExerciseType = "American"
	European ExerciseType = "European"
)

type Strike struct {
	Level float64 `json:"strike" valid:"required,positive"`
}

type VanillaOptionDescriptions map[string]VanillaOptionDescription

type VanillaOptionDescription struct {
	ID                 string                         `json:"id"                 valid:"required"`
	Currency           *Currency                      `json:"currency"           valid:"required"`
	Issuer             *Issuer                        `json:"issuer"             valid:"required"`
	OptionType         vanillaoptionpricer.OptionType `json:"callPut"            valid:"required,in(Call|Put)"`
	FinalFixing        date.Date                      `json:"finalFixing"        valid:"required"`
	Underlyings        map[string]*underlyingInput    `json:"underlyings"        valid:"required"`
	Strikes            map[string]*Strike             `json:"strikes"            valid:"required"`
	DaycountConvention DaycountConvention             `json:"daycountConvention" valid:"-"`
	ExerciseType       ExerciseType                   `json:"exerciseType"       valid:"optional,in(American|European)"`
}

type VanillaQuotes map[string]VanillaOptionQuotes

type VanillaOptionQuotes struct {
	Quotes map[date.Date]float64 `json:"values"`
}
