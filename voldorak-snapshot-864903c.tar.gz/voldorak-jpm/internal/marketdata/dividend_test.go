package marketdata

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_NewZeroDividendInterpolator(t *testing.T) {
	t.Parallel()

	const tol = 1e-10

	for name, tc := range map[string]struct {
		dividendCurve DividendYieldCurve
		testPoints    []struct {
			x        float64
			expected float64
		}
		expectError bool
	}{
		"simple curve with three points": {
			dividendCurve: DividendYieldCurve{
				Dividends: []DividendPoint{
					{DividendZeroRate: 0.02, YearFraction: 0.5},
					{DividendZeroRate: 0.03, YearFraction: 1.0},
					{DividendZeroRate: 0.04, YearFraction: 2.0},
				},
			},
			testPoints: []struct {
				x        float64
				expected float64
			}{
				{x: 0.05, expected: 0.02},
				{x: 0.5, expected: 0.02},
				{x: 1.0, expected: 0.03},
				{x: 0.75, expected: 0.025},
				{x: 3.0, expected: 0.04},
			},
			expectError: false,
		},
		"single point curve": {
			dividendCurve: DividendYieldCurve{
				Dividends: []DividendPoint{
					{DividendZeroRate: 0.025, YearFraction: 1.0},
				},
			},
			testPoints: []struct {
				x        float64
				expected float64
			}{
				{x: 1.0, expected: 0.025},
				{x: 0.5, expected: 0.025},
				{x: 2.0, expected: 0.025},
			},
			expectError: false,
		},
		"empty curve": {
			dividendCurve: DividendYieldCurve{
				Dividends: []DividendPoint{},
			},
			expectError: true,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			interp, err := NewZeroDividendInterpolator(tc.dividendCurve)

			if tc.expectError {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.NotNil(t, interp)

			for _, tp := range tc.testPoints {
				got := interp.Value(tp.x)
				assert.InDelta(t, tp.expected, got, tol)
			}
		})
	}
}

func Test_AverageDividendYield(t *testing.T) {
	t.Parallel()

	const tol = 1e-10

	for name, tc := range map[string]struct {
		dividendCurve DividendYieldCurve
		expected      float64
		expectError   bool
	}{
		"constant yield": {
			dividendCurve: DividendYieldCurve{
				Dividends: []DividendPoint{
					{DividendZeroRate: 0.02, YearFraction: 0.5},
					{DividendZeroRate: 0.02, YearFraction: 1.0},
					{DividendZeroRate: 0.02, YearFraction: 2.0},
				},
			},
			expected:    0.02,
			expectError: false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got, err := tc.dividendCurve.AverageDividendYield()

			if tc.expectError {
				require.Error(t, err)
				return
			}

			require.NoError(t, err)
			assert.InDelta(t, tc.expected, got, tol)
		})
	}
}
