package marketdata

import (
	"fmt"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/interpolator"
)

type DividendPoint struct {
	DividendZeroRate float64   `json:"dividendZeroRate"`
	Dividend         float64   `json:"dividend"`
	CashDividend     float64   `json:"cashDividend"`
	ExDividendDate   date.Date `json:"exDividendDate"`
	YearFraction     float64   `json:"yearFraction"`
}

type DividendYieldCurve struct {
	Dividends []DividendPoint `json:"dividends"`
}

// NewZeroDividendInterpolator returns a piecewise linear interpolator with flat extrapolation for the zero dividend yield curve.
// It assumes that the dividend points are sorted by year fraction in ascending order.
func NewZeroDividendInterpolator(dividendCurve DividendYieldCurve) (*interpolator.PiecewiseLinearThreshold, error) {
	xys := dividendCurve.ToXYs()

	interp, err := interpolator.NewPiecewiseLinearThreshold(xys)
	if err != nil {
		return nil, fmt.Errorf("failed to create piecewise linear interpolator: %w", err)
	}

	return interp, nil
}

func (d DividendYieldCurve) ToXYs() interpolator.XYs {
	xys := make(interpolator.XYs, len(d.Dividends))
	for i, point := range d.Dividends {
		xys[i].X = point.YearFraction
		xys[i].Y = point.DividendZeroRate
	}

	return xys
}

// ToDividendYieldMap converts the dividend yield curve to a map with year fraction as key and dividend as value.
func (d DividendYieldCurve) ToDividendYieldMap() map[float64]float64 {
	result := make(map[float64]float64, len(d.Dividends))
	for _, point := range d.Dividends {
		result[point.YearFraction] = point.DividendZeroRate
	}

	return result
}

// AverageDividendYield returns the average dividend yield across all dividend points in the curve.
// This is equivalent to flattening the yield curve, while being agnostic to the maturity date of the option
// (and analytically assuming that the maturity dates of assets are uniformly distributed).
// The dividend term structure is assumed to be sorted by year fraction in ascending order.
func (d DividendYieldCurve) AverageDividendYield() (float64, error) {
	if len(d.Dividends) == 0 {
		return 0.0, errors.Bug("dividend term structure is empty")
	}

	total := d.Dividends[0].YearFraction * d.Dividends[0].DividendZeroRate

	// Compute the area under the dividend yield curve using the trapezoidal rule and divide by the total time to get the average dividend yield.
	for i := range len(d.Dividends) - 1 {
		total += 0.5 * (d.Dividends[i+1].DividendZeroRate + d.Dividends[i].DividendZeroRate) * (d.Dividends[i+1].YearFraction - d.Dividends[i].YearFraction)
	}

	return total / d.Dividends[len(d.Dividends)-1].YearFraction, nil
}
