package marketdata

// Type defines the marketdata observable type.
type Type string

const (
	// Fund is a fund.
	Fund Type = "Fund"
	// FX is a foreign exchange.
	FX Type = "FX"
	// Index is an index.
	Index Type = "Index"
	// Stock is a stock.
	Stock Type = "Stock"
	// PrivateAsset is a private asset.
	PrivateAsset Type = "PrivateAsset"
	// SwapRate is a swap rate.
	SwapRate Type = "SwapRate"
	// OISRate is an OIS rate.
	OISRate Type = "OISRate"
	// FXForwardRate is a FX forward rate.
	FXForwardRate Type = "FXForwardRate"
	// InterestRate is an interest rate.
	InterestRate Type = "InterestRate"
)
