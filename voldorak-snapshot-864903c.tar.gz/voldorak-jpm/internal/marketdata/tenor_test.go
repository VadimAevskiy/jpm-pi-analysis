package marketdata

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Tenor_toYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			yf    float64
		}{
			"ON": {
				tenor: Tenor("ON"),
				yf:    1.0 / 365.0,
			},
			"1W": {
				tenor: Tenor("1W"),
				yf:    1.0 * 7.0 / 365.0,
			},
			"2W": {
				tenor: Tenor("2W"),
				yf:    2.0 * 7.0 / 365.0,
			},
			"3W": {
				tenor: Tenor("3W"),
				yf:    3.0 * 7.0 / 365.0,
			},
			"4W": {
				tenor: Tenor("4W"),
				yf:    4.0 * 7.0 / 365.0,
			},
			"1M": {
				tenor: Tenor("1M"),
				yf:    1.0 / 12.0,
			},
			"2M": {
				tenor: Tenor("2M"),
				yf:    2.0 / 12.0,
			},
			"3M": {
				tenor: Tenor("3M"),
				yf:    3.0 / 12.0,
			},
			"4M": {
				tenor: Tenor("4M"),
				yf:    4.0 / 12.0,
			},
			"5M": {
				tenor: Tenor("5M"),
				yf:    5.0 / 12.0,
			},
			"6M": {
				tenor: Tenor("6M"),
				yf:    6.0 / 12.0,
			},
			"7M": {
				tenor: Tenor("7M"),
				yf:    7.0 / 12.0,
			},
			"8M": {
				tenor: Tenor("8M"),
				yf:    8.0 / 12.0,
			},
			"9M": {
				tenor: Tenor("9M"),
				yf:    9.0 / 12.0,
			},
			"10M": {
				tenor: Tenor("10M"),
				yf:    10.0 / 12.0,
			},
			"11M": {
				tenor: Tenor("11M"),
				yf:    11.0 / 12.0,
			},
			"12M": {
				tenor: Tenor("12M"),
				yf:    1.0,
			},
			"1Y": {
				tenor: Tenor("1Y"),
				yf:    1.0,
			},
			"2Y": {
				tenor: Tenor("2Y"),
				yf:    2.0,
			},
			"3Y": {
				tenor: Tenor("3Y"),
				yf:    3.0,
			},
			"4Y": {
				tenor: Tenor("4Y"),
				yf:    4.0,
			},
			"5Y": {
				tenor: Tenor("5Y"),
				yf:    5.0,
			},
			"6Y": {
				tenor: Tenor("6Y"),
				yf:    6.0,
			},
			"7Y": {
				tenor: Tenor("7Y"),
				yf:    7.0,
			},
			"8Y": {
				tenor: Tenor("8Y"),
				yf:    8.0,
			},
			"9Y": {
				tenor: Tenor("9Y"),
				yf:    9.0,
			},
			"10Y": {
				tenor: Tenor("10Y"),
				yf:    10.0,
			},
			"11Y": {
				tenor: Tenor("11Y"),
				yf:    11.0,
			},
			"12Y": {
				tenor: Tenor("12Y"),
				yf:    12.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.ToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.yf, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"OMG":       {tenor: Tenor("OMG")},
			"W-1":       {tenor: Tenor("W-1")},
			"-1M":       {tenor: Tenor("-1M")},
			"-1Y":       {tenor: Tenor("-1Y")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.ToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_Tenor_isON(t *testing.T) {
	t.Parallel()

	assert.True(t, Tenor("ON").isON())
	assert.False(t, Tenor("Some bad stuff").isON())
}

func Test_Tenor_isWeek(t *testing.T) {
	t.Parallel()

	t.Run("true", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"1W": {tenor: Tenor("1W")},
			"2W": {tenor: Tenor("2W")},
			"3W": {tenor: Tenor("3W")},
			"4W": {tenor: Tenor("4W")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.True(t, tc.tenor.isWeek())
			})
		}
	})

	t.Run("false", func(t *testing.T) {
		t.Parallel()

		assert.False(t, Tenor("Some bad stuff").isWeek())
	})
}

func Test_Tenor_isMonth(t *testing.T) {
	t.Parallel()

	t.Run("true", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"1M":  {tenor: Tenor("1M")},
			"2M":  {tenor: Tenor("2M")},
			"3M":  {tenor: Tenor("3M")},
			"4M":  {tenor: Tenor("4M")},
			"5M":  {tenor: Tenor("5M")},
			"6M":  {tenor: Tenor("6M")},
			"7M":  {tenor: Tenor("7M")},
			"8M":  {tenor: Tenor("8M")},
			"9M":  {tenor: Tenor("9M")},
			"10M": {tenor: Tenor("10M")},
			"11M": {tenor: Tenor("11M")},
			"12M": {tenor: Tenor("12M")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.True(t, tc.tenor.isMonth())
			})
		}
	})

	t.Run("false", func(t *testing.T) {
		t.Parallel()

		assert.False(t, Tenor("Some bad stuff").isMonth())
	})
}

func Test_Tenor_isYear(t *testing.T) {
	t.Parallel()

	t.Run("true", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"1Y": {tenor: Tenor("1Y")},
			"2Y": {tenor: Tenor("2Y")},
			"3Y": {tenor: Tenor("3Y")},
			"4Y": {tenor: Tenor("4Y")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.True(t, tc.tenor.isYear())
			})
		}
	})

	t.Run("false", func(t *testing.T) {
		t.Parallel()

		assert.False(t, Tenor("Some bad stuff").isYear())
	})
}

func Test_Tenor_weekTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			yf    float64
		}{
			"1W": {
				tenor: Tenor("1W"),
				yf:    1.0 * 7.0 / 365.0,
			},
			"2W": {
				tenor: Tenor("2W"),
				yf:    2.0 * 7.0 / 365.0,
			},
			"3W": {
				tenor: Tenor("3W"),
				yf:    3.0 * 7.0 / 365.0,
			},
			"4W": {
				tenor: Tenor("4W"),
				yf:    4.0 * 7.0 / 365.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.weekTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.yf, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"-1W":       {tenor: Tenor("-1W")},
			"1M":        {tenor: Tenor("1M")},
			"1Y":        {tenor: Tenor("1Y")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.weekTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_Tenor_monthTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			yf    float64
		}{
			"1M": {
				tenor: Tenor("1M"),
				yf:    1.0 / 12.0,
			},
			"2M": {
				tenor: Tenor("2M"),
				yf:    2.0 / 12.0,
			},
			"3M": {
				tenor: Tenor("3M"),
				yf:    3.0 / 12.0,
			},
			"4M": {
				tenor: Tenor("4M"),
				yf:    4.0 / 12.0,
			},
			"5M": {
				tenor: Tenor("5M"),
				yf:    5.0 / 12.0,
			},
			"6M": {
				tenor: Tenor("6M"),
				yf:    6.0 / 12.0,
			},
			"7M": {
				tenor: Tenor("7M"),
				yf:    7.0 / 12.0,
			},
			"8M": {
				tenor: Tenor("8M"),
				yf:    8.0 / 12.0,
			},
			"9M": {
				tenor: Tenor("9M"),
				yf:    9.0 / 12.0,
			},
			"10M": {
				tenor: Tenor("10M"),
				yf:    10.0 / 12.0,
			},
			"11M": {
				tenor: Tenor("11M"),
				yf:    11.0 / 12.0,
			},
			"12M": {
				tenor: Tenor("12M"),
				yf:    1.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.monthTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.yf, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"1W":        {tenor: Tenor("1W")},
			"-1W":       {tenor: Tenor("-1W")},
			"1Y":        {tenor: Tenor("1Y")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.monthTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_Tenor_yearTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			yf    float64
		}{
			"1Y": {
				tenor: Tenor("1Y"),
				yf:    1.0,
			},
			"2Y": {
				tenor: Tenor("2Y"),
				yf:    2.0,
			},
			"3Y": {
				tenor: Tenor("3Y"),
				yf:    3.0,
			},
			"4Y": {
				tenor: Tenor("4Y"),
				yf:    4.0,
			},
			"5Y": {
				tenor: Tenor("5Y"),
				yf:    5.0,
			},
			"6Y": {
				tenor: Tenor("6Y"),
				yf:    6.0,
			},
			"7Y": {
				tenor: Tenor("7Y"),
				yf:    7.0,
			},
			"8Y": {
				tenor: Tenor("8Y"),
				yf:    8.0,
			},
			"9Y": {
				tenor: Tenor("9Y"),
				yf:    9.0,
			},
			"10Y": {
				tenor: Tenor("10Y"),
				yf:    10.0,
			},
			"11Y": {
				tenor: Tenor("11Y"),
				yf:    11.0,
			},
			"12Y": {
				tenor: Tenor("12Y"),
				yf:    12.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.yearTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.yf, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"1W":        {tenor: Tenor("1W")},
			"1M":        {tenor: Tenor("1M")},
			"-1Y":       {tenor: Tenor("-1Y")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.yearTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}
