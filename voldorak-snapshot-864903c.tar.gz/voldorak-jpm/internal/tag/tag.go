package tag

import (
	errors "github.com/edgelaboratories/go-errors/goerror"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
)

var (
	InvalidScenarioData        = errors.Tag(pb.Error_INVALID_SCENARIO_DATA.String())
	NotEnoughData              = errors.Tag(pb.Error_NOT_ENOUGH_DATA.String())
	ScenarioDataNotFound       = errors.Tag(pb.Error_MISSING_SCENARIO_DATA.String())
	TimeSeriesDataNotFound     = errors.Tag(pb.Error_TIMESERIES_DATA_NOT_FOUND.String())
	TimeSeriesDataTooOld       = errors.Tag(pb.Error_TIMESERIES_DATA_TOO_OLD.String())
	TimeSeriesValueNonPositive = errors.Tag(pb.Error_TIMESERIES_VALUE_NON_POSITIVE.String())
)
