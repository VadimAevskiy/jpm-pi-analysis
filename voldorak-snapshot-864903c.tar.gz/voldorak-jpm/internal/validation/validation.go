package validation

import "math"

func isFloat64IllFormed(v float64) bool {
	return math.IsNaN(v) || math.IsInf(v, 0)
}

func IsFinite(v float64) bool {
	return !isFloat64IllFormed(v)
}

func IsPositive(v float64) bool {
	return IsFinite(v) && v > 0.0
}

func IsNonNegative(v float64) bool {
	return IsFinite(v) && v >= 0.0
}
