package validation

import (
	"math"
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_isFloat64IllFormed(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    float64
		expected bool
	}{
		"NaN":          {input: math.NaN(), expected: true},
		"positive inf": {input: math.Inf(1), expected: true},
		"negative inf": {input: math.Inf(-1), expected: true},
		"positive":     {input: 10.0, expected: false},
		"zero":         {input: 0.0, expected: false},
		"negative":     {input: -10.0, expected: false},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := isFloat64IllFormed(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_IsFinite(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    float64
		expected bool
	}{
		"NaN":          {input: math.NaN(), expected: false},
		"positive inf": {input: math.Inf(1), expected: false},
		"negative inf": {input: math.Inf(-1), expected: false},
		"positive":     {input: 10.0, expected: true},
		"zero":         {input: 0.0, expected: true},
		"negative":     {input: -10.0, expected: true},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := IsFinite(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_IsPositive(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    float64
		expected bool
	}{
		"NaN":          {input: math.NaN(), expected: false},
		"positive inf": {input: math.Inf(1), expected: false},
		"negative inf": {input: math.Inf(-1), expected: false},
		"positive":     {input: 10.0, expected: true},
		"zero":         {input: 0.0, expected: false},
		"negative":     {input: -10.0, expected: false},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := IsPositive(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_IsNonNegative(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    float64
		expected bool
	}{
		"NaN":          {input: math.NaN(), expected: false},
		"positive inf": {input: math.Inf(1), expected: false},
		"negative inf": {input: math.Inf(-1), expected: false},
		"positive":     {input: 10.0, expected: true},
		"zero":         {input: 0.0, expected: true},
		"negative":     {input: -10.0, expected: false},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := IsNonNegative(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}
