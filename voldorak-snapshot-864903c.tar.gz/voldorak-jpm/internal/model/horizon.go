package model

// ReferenceScenarioHorizon defines the universal horizon in
// (business) days scenario realizations will be estimated at.
const ReferenceScenarioHorizon = 33
