/*
Package model defines the available volatility models Voldorak offers.
*/
package model
