package model

// VolatilityBackboneModel defines the model for the volatility (time-dependent) backbone.
type VolatilityBackboneModel string

const (
	// MovingAverage90Days is a 90-days moving average historical
	// volatility. Its value at date t is used as forecast of the
	// volatility at all future times (flat backbone).
	MovingAverage90Days VolatilityBackboneModel = "MovingAverage90Days"

	// LongMemoryARCHForecast is a long-memory ARCH (auto-regressive
	// conditional heteroskedasticity) volatility forecast at time t
	// up to a future horizon.
	LongMemoryARCHForecast VolatilityBackboneModel = "LongMemoryARCHForecast"
)

// DefaultVolatilityBackboneModel defines the universal default volatility
// backbone model the service will consistently used when none is specified.
var DefaultVolatilityBackboneModel = LongMemoryARCHForecast
