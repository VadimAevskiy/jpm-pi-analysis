package yield

import (
	"context"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
)

// InterestRateProvider defines the interface for fetching the interest rate data, which is required to compute the yield curve values.
type InterestRateProvider interface {
	Yield(ctx context.Context, snapshot time.Time, currency marketdata.Currency, to date.Date) (termstructure.TermStructure, error)
}
