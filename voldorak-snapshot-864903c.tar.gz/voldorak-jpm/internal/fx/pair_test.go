package fx

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Pair_String(t *testing.T) {
	t.Parallel()

	const (
		domestic = "CAD"
		foreign  = "USD"
	)

	expected := fmt.Sprintf("%s-%s", foreign, domestic)
	got := Pair{
		Foreign:  foreign,
		Domestic: domestic,
	}.String()
	assert.Equal(t, expected, got)
}

func Test_Pair_Inverse(t *testing.T) {
	t.Parallel()

	const (
		domestic = "CAD"
		foreign  = "USD"
	)

	expected := &Pair{
		Foreign:  domestic,
		Domestic: foreign,
	}
	got := Pair{
		Foreign:  foreign,
		Domestic: domestic,
	}.Inverse()
	assert.Equal(t, expected, got)
}

func Test_NewPair(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		expected := &Pair{
			Foreign:  "EUR",
			Domestic: "USD",
		}
		got, err := NewPair("EUR-USD")
		require.NoError(t, err)
		assert.Equal(t, expected, got)
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := NewPair(`¯\_(ツ)_/¯`)
		require.Error(t, err)
	})
}
