package fx

import (
	"fmt"
	"regexp"
	"strings"

	errors "github.com/edgelaboratories/go-errors/goerror"
)

// ReferenceCurrency is the FX pivot currency.
const ReferenceCurrency = "USD"

var pattern = regexp.MustCompile("^[A-Z]{3}-[A-Z]{3}$")

// Pair represents an FX currency pair.
type Pair struct {
	Foreign  string
	Domestic string
}

// NewPair parses and return a pair from an id.
func NewPair(id string) (*Pair, error) {
	if !pattern.MatchString(id) {
		return nil, errors.Bug("FX id has invalid format: expecting ABC-XYZ, received %s", id)
	}

	res := strings.Split(id, "-")

	return &Pair{
		Foreign:  res[0],
		Domestic: res[1],
	}, nil
}

// String specialization for pair.
func (p Pair) String() string {
	return fmt.Sprintf("%s-%s", p.Foreign, p.Domestic)
}

// Inverse returns the inverse perspective of a pair.
func (p Pair) Inverse() *Pair {
	return &Pair{
		Foreign:  p.Domestic,
		Domestic: p.Foreign,
	}
}
