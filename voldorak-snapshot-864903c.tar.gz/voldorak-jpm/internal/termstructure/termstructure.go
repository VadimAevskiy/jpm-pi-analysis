package termstructure

import (
	"encoding/json"
	"fmt"
	"slices"

	interp "github.com/edgelaboratories/go-libraries/interpolator"
)

type TermStructure struct {
	Data         map[Tenor]float64
	interpolator *interp.PiecewiseLinearThreshold
}

// UnmarshalJSON unmarshals a TermStructure from JSON.
// It ignores interpolated data.
func (termStructure *TermStructure) UnmarshalJSON(b []byte) error {
	if err := json.Unmarshal(b, &termStructure.Data); err != nil {
		return fmt.Errorf("unmarshal raw term structure: %w", err)
	}

	if err := termStructure.BuildInterpolator(); err != nil {
		return fmt.Errorf("could not build the interpolator: %w", err)
	}

	return nil
}

// Value returns the value of the term structure interpolated at a given year fraction.
func (termStructure *TermStructure) Value(yf float64) float64 {
	return termStructure.interpolator.Value(yf)
}

// BuildInterpolator builds the interpolator for the term structure.
func (termStructure *TermStructure) BuildInterpolator() error {
	data, err := termStructure.toInterpolatorData()
	if err != nil {
		return fmt.Errorf("could not convert the term structure data into raw data: %w", err)
	}

	interpolator, err := interp.NewPiecewiseLinearThreshold(data)
	if err != nil {
		return fmt.Errorf("could not create the piecewise linear threshold interpolator: %w", err)
	}

	termStructure.interpolator = interpolator

	return nil
}

// toInterpolatorData converts the term structure data into raw data for the interpolator.
func (termStructure TermStructure) toInterpolatorData() (interp.XYs, error) {
	output := make(interp.XYs, 0, len(termStructure.Data))
	for tenor, value := range termStructure.Data {
		yf, err := tenor.ToYearFraction()
		if err != nil {
			return nil, fmt.Errorf("could not convert the tenor to year fraction: %w", err)
		}

		output = append(output, interp.XY{
			X: yf,
			Y: value,
		})
	}

	slices.SortFunc(output, func(a, b interp.XY) int {
		if a.X < b.X {
			return -1
		}

		return 1
	})

	return output, nil
}
