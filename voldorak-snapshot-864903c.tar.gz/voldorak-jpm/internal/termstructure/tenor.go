package termstructure

import (
	"fmt"
	"strconv"
	"strings"

	errors "github.com/edgelaboratories/go-errors/goerror"
)

// Tenor represents a time to maturity.
type Tenor string

// As the yield termstructures are calibrated over calendar days, the evaluation of
// the termstructure will also be done on calendar days.
const (
	daysPerWeek   = 7.0
	monthsPerYear = 12.0
	daysPerYear   = 365.0
)

const (
	overnightKey = "ON"
	weekKey      = "W"
	monthKey     = "M"
	yearKey      = "Y"
)

const (
	M12 Tenor = "M12"
	M6  Tenor = "M6"
	M3  Tenor = "M3"
	M1  Tenor = "M1"
	W1  Tenor = "W1"
	ON  Tenor = "ON"
)

// ToYearFraction converts a tenor into its equivalent year fraction.
func (t Tenor) ToYearFraction() (float64, error) {
	switch {
	case t.isON():
		return 1.0 / daysPerYear, nil
	case t.isWeek():
		return t.weekTenorToYearFraction()
	case t.isMonth():
		return t.monthTenorToYearFraction()
	case t.isYear():
		return t.yearTenorToYearFraction()
	default:
		return 0.0, errors.Bug("could not parse the type of tenor %s", t)
	}
}

// isON tests whether the tenor is the ON (Over Night) tenor.
func (t Tenor) isON() bool {
	return strings.HasPrefix(string(t), overnightKey)
}

// isWeek tests whether the tenor is a week tenor.
func (t Tenor) isWeek() bool {
	return strings.HasPrefix(string(t), weekKey)
}

// isMonth tests whether the tenor is a month tenor.
func (t Tenor) isMonth() bool {
	return strings.HasPrefix(string(t), monthKey)
}

// isYear tests whether the tenor is a year tenor.
func (t Tenor) isYear() bool {
	return strings.HasPrefix(string(t), yearKey)
}

// weekTenorToYearFraction converts a week tenor to a year fraction.
func (t Tenor) weekTenorToYearFraction() (float64, error) {
	nbDays := strings.TrimPrefix(string(t), weekKey)

	d, err := strconv.ParseUint(nbDays, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of weeks for tenor %s: %w", t, err)
	}

	return float64(d) * daysPerWeek / daysPerYear, nil
}

// monthTenorToYearFraction converts a month tenor to a year fraction.
func (t Tenor) monthTenorToYearFraction() (float64, error) {
	nbMonths := strings.TrimPrefix(string(t), monthKey)

	m, err := strconv.ParseUint(nbMonths, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of months for tenor %s: %w", t, err)
	}

	return float64(m) / monthsPerYear, nil
}

// yearTenorToYearFraction converts a year tenor to a year fraction.
func (t Tenor) yearTenorToYearFraction() (float64, error) {
	nbYears := strings.TrimPrefix(string(t), yearKey)

	y, err := strconv.ParseUint(nbYears, 10, 64)
	if err != nil {
		return 0.0, fmt.Errorf("failed to parse the number of years for tenor %s: %w", t, err)
	}

	return float64(y), nil
}
