package termstructure

import (
	"encoding/json"
	"fmt"
	"testing"

	interp "github.com/edgelaboratories/go-libraries/interpolator"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_UnmarshalJSON(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid payloads", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			json []byte
			want map[Tenor]float64
		}{
			"two tenors": {
				json: []byte(`{"M1":1,"M3":2}`),
				want: map[Tenor]float64{
					M1: 1,
					M3: 2,
				},
			},
			"multiple tenors": {
				json: []byte(`{"M1":1,"M3":2,"M6":3}`),
				want: map[Tenor]float64{
					M1: 1,
					M3: 2,
					M6: 3,
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				var got TermStructure

				err := json.Unmarshal(tc.json, &got)
				require.NoError(t, err)

				require.Equal(t, tc.want, got.Data)
				require.NotNil(t, got.interpolator)

				for tenor, value := range got.Data {
					yf, err := tenor.ToYearFraction()
					require.NoError(t, err)

					assert.InDelta(t, value, got.Value(yf), tol)
				}
			})
		}
	})

	t.Run("invalid payloads", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			json    []byte
			wantErr string
		}{
			"invalid json": {
				json:    []byte(`{"M1":1`),
				wantErr: "unexpected end",
			},
			"invalid tenor": {
				json:    []byte(`{"BAD":1}`),
				wantErr: "could not parse the type of tenor",
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				var got TermStructure

				err := json.Unmarshal(tc.json, &got)
				require.Error(t, err)

				if tc.wantErr != "" {
					require.ErrorContains(t, err, tc.wantErr)
				}
			})
		}
	})
}

func Test_TermStructure_Value(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	TermStructure := MustNewTermStructure(
		ON, -0.001,
		M1, -0.01,
		M3, 0.003,
		M6, 0.01,
		M12, 0.01,
		Tenor("Y2"), 0.008,
	)

	for tenor, wantValue := range TermStructure.Data {
		t.Run(string(tenor), func(t *testing.T) {
			t.Parallel()

			yf, err := tenor.ToYearFraction()
			require.NoError(t, err)

			assert.InDelta(t, wantValue, TermStructure.Value(yf), tol)
		})
	}

	for yf, wantValue := range map[float64]float64{
		0.1:  -0.0087,
		0.7:  0.01,
		2.5:  0.008,
		10.0: 0.008,
	} {
		t.Run(fmt.Sprintf("%f", yf), func(t *testing.T) {
			t.Parallel()

			assert.InDelta(t, wantValue, TermStructure.Value(yf), tol)
		})
	}
}

func Test_TermStructure_toInterpolatorData(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	for name, tc := range map[string]struct {
		TermStructure TermStructure
		want          interp.XYs
	}{
		"single tenor": {
			TermStructure: TermStructure{
				Data: map[Tenor]float64{
					"M3": 0.05,
				},
			},
			want: interp.XYs{
				{X: 0.25, Y: 0.05},
			},
		},
		"multiple tenors": {
			TermStructure: TermStructure{
				Data: map[Tenor]float64{
					"M3": 0.05,
					"Y2": 0.06,
					"M6": 0.07,
					"ON": 0.08,
				},
			},
			want: interp.XYs{
				{X: 1.0 / 365.0, Y: 0.08},
				{X: 0.25, Y: 0.05},
				{X: 0.5, Y: 0.07},
				{X: 2.0, Y: 0.06},
			},
		},
		"usual yield tenors": {
			TermStructure: TermStructure{
				Data: map[Tenor]float64{
					"Y50": 0.05,
					"Y20": 0.06,
					"M12": 0.07,
					"Y7":  0.08,
				},
			},
			want: interp.XYs{
				{X: 1.0, Y: 0.07},
				{X: 7.0, Y: 0.08},
				{X: 20.0, Y: 0.06},
				{X: 50.0, Y: 0.05},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			data, err := tc.TermStructure.toInterpolatorData()
			require.NoError(t, err)
			require.Len(t, data, len(tc.want))

			for i, xy := range tc.want {
				assert.InDelta(t, xy.X, data[i].X, tol)
				assert.InDelta(t, xy.Y, data[i].Y, tol)
			}
		})
	}
}

func Benchmark_Value(b *testing.B) {
	var (
		TermStructure = MustNewTermStructure(
			ON, -0.001,
			W1, -0.01,
			M1, 0.001,
			M3, 0.003,
			M6, 0.01,
			M12, 0.01,
		)

		yf = 0.05
	)

	b.ResetTimer()

	for b.Loop() {
		_ = TermStructure.Value(yf)
	}
}
