package termstructure

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_MustNewTermStructure(t *testing.T) {
	t.Parallel()

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, args := range map[string][]any{
			"empty":                   {},
			"odd number of arguments": {M1},
			"key not a Tenor":         {1, 1.2},
			"value not a float64":     {M1, "1.2"},
			"invalid tenor":           {Tenor("GreatScott"), 1.2},
		} {
			if name != "unknown tenor" {
				continue
			}

			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.Panics(t, func() {
					MustNewTermStructure(args...)
				})
			})
		}
	})

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, args := range map[string][]any{
			"single":                  {M1, 1.2},
			"multiple tenors":         {M1, 1.2, M3, 2.3},
			"multiple dates":          {M1, 1.2, M3, 2.3, M6, 3.4},
			"mixing tenor and string": {M1, 1.2, "M3", 2.3},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				assert.NotPanics(t, func() {
					MustNewTermStructure(args...)
				})
			})
		}
	})
}
