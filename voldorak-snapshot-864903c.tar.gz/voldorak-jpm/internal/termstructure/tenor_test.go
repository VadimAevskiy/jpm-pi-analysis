package termstructure

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_tenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			want  float64
		}{
			"ON":  {tenor: Tenor("ON"), want: 1.0 / 365.0},
			"W1":  {tenor: Tenor("W1"), want: 1.0 * 7.0 / 365.0},
			"W2":  {tenor: Tenor("W2"), want: 2.0 * 7.0 / 365.0},
			"W3":  {tenor: Tenor("W3"), want: 3.0 * 7.0 / 365.0},
			"W4":  {tenor: Tenor("W4"), want: 4.0 * 7.0 / 365.0},
			"M1":  {tenor: Tenor("M1"), want: 1.0 / 12.0},
			"M2":  {tenor: Tenor("M2"), want: 2.0 / 12.0},
			"M3":  {tenor: Tenor("M3"), want: 3.0 / 12.0},
			"M4":  {tenor: Tenor("M4"), want: 4.0 / 12.0},
			"M5":  {tenor: Tenor("M5"), want: 5.0 / 12.0},
			"M6":  {tenor: Tenor("M6"), want: 6.0 / 12.0},
			"M7":  {tenor: Tenor("M7"), want: 7.0 / 12.0},
			"M8":  {tenor: Tenor("M8"), want: 8.0 / 12.0},
			"M9":  {tenor: Tenor("M9"), want: 9.0 / 12.0},
			"M10": {tenor: Tenor("M10"), want: 10.0 / 12.0},
			"M11": {tenor: Tenor("M11"), want: 11.0 / 12.0},
			"M12": {tenor: Tenor("M12"), want: 1.0},
			"Y1":  {tenor: Tenor("Y1"), want: 1.0},
			"Y2":  {tenor: Tenor("Y2"), want: 2.0},
			"Y3":  {tenor: Tenor("Y3"), want: 3.0},
			"Y4":  {tenor: Tenor("Y4"), want: 4.0},
			"Y5":  {tenor: Tenor("Y5"), want: 5.0},
			"Y6":  {tenor: Tenor("Y6"), want: 6.0},
			"Y7":  {tenor: Tenor("Y7"), want: 7.0},
			"Y8":  {tenor: Tenor("Y8"), want: 8.0},
			"Y9":  {tenor: Tenor("Y9"), want: 9.0},
			"Y10": {tenor: Tenor("Y10"), want: 10.0},
			"Y11": {tenor: Tenor("Y11"), want: 11.0},
			"Y12": {tenor: Tenor("Y12"), want: 12.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.ToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"OMG":       {tenor: Tenor("OMG")},
			"W-1":       {tenor: Tenor("W-1")},
			"M-1":       {tenor: Tenor("M-1")},
			"Y-1":       {tenor: Tenor("Y-1")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.ToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_isON(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()
		assert.True(t, Tenor("ON").isON())
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()
		assert.False(t, Tenor("Some bad stuff").isON())
	})
}

func Test_isWeek(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for _, tenor := range []Tenor{
			"W1", "W2", "W3", "W4",
		} {
			assert.True(t, tenor.isWeek())
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()
		assert.False(t, Tenor("Some bad stuff").isWeek())
	})
}

func Test_isMonth(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for _, tenor := range []Tenor{
			"M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12",
		} {
			assert.True(t, tenor.isMonth())
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()
		assert.False(t, Tenor("Some bad stuff").isMonth())
	})
}

func Test_isYear(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for _, tenor := range []Tenor{
			"Y1", "Y2", "Y3", "Y4",
		} {
			assert.True(t, tenor.isYear())
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()
		assert.False(t, Tenor("Some bad stuff").isYear())
	})
}

func Test_weekTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			want  float64
		}{
			"W1": {tenor: Tenor("W1"), want: 1.0 * 7.0 / 365.0},
			"W2": {tenor: Tenor("W2"), want: 2.0 * 7.0 / 365.0},
			"W3": {tenor: Tenor("W3"), want: 3.0 * 7.0 / 365.0},
			"W4": {tenor: Tenor("W4"), want: 4.0 * 7.0 / 365.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.weekTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"W-1":       {tenor: Tenor("W-1")},
			"M1":        {tenor: Tenor("M1")},
			"Y1":        {tenor: Tenor("Y1")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.weekTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_monthTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			want  float64
		}{
			"M1":  {tenor: Tenor("M1"), want: 1.0 / 12.0},
			"M2":  {tenor: Tenor("M2"), want: 2.0 / 12.0},
			"M3":  {tenor: Tenor("M3"), want: 3.0 / 12.0},
			"M4":  {tenor: Tenor("M4"), want: 4.0 / 12.0},
			"M5":  {tenor: Tenor("M5"), want: 5.0 / 12.0},
			"M6":  {tenor: Tenor("M6"), want: 6.0 / 12.0},
			"M7":  {tenor: Tenor("M7"), want: 7.0 / 12.0},
			"M8":  {tenor: Tenor("M8"), want: 8.0 / 12.0},
			"M9":  {tenor: Tenor("M9"), want: 9.0 / 12.0},
			"M10": {tenor: Tenor("M10"), want: 10.0 / 12.0},
			"M11": {tenor: Tenor("M11"), want: 11.0 / 12.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.monthTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"W1":        {tenor: Tenor("W1")},
			"M-1":       {tenor: Tenor("M-1")},
			"Y1":        {tenor: Tenor("Y1")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.monthTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}

func Test_yearTenorToYearFraction(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
			want  float64
		}{
			"Y1":  {tenor: Tenor("Y1"), want: 1.0},
			"Y2":  {tenor: Tenor("Y2"), want: 2.0},
			"Y3":  {tenor: Tenor("Y3"), want: 3.0},
			"Y4":  {tenor: Tenor("Y4"), want: 4.0},
			"Y5":  {tenor: Tenor("Y5"), want: 5.0},
			"Y6":  {tenor: Tenor("Y6"), want: 6.0},
			"Y7":  {tenor: Tenor("Y7"), want: 7.0},
			"Y8":  {tenor: Tenor("Y8"), want: 8.0},
			"Y9":  {tenor: Tenor("Y9"), want: 9.0},
			"Y10": {tenor: Tenor("Y10"), want: 10.0},
			"Y11": {tenor: Tenor("Y11"), want: 11.0},
			"Y12": {tenor: Tenor("Y12"), want: 12.0},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := tc.tenor.yearTenorToYearFraction()
				require.NoError(t, err)
				assert.InDelta(t, tc.want, got, tol)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			tenor Tenor
		}{
			"ON":        {tenor: Tenor("ON")},
			"W1":        {tenor: Tenor("W1")},
			"M1":        {tenor: Tenor("M1")},
			"Y-1":       {tenor: Tenor("Y-1")},
			"something": {tenor: Tenor("something")},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := tc.tenor.yearTenorToYearFraction()
				require.Error(t, err)
			})
		}
	})
}
