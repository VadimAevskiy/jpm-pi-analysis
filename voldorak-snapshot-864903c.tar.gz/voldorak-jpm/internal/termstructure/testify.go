package termstructure

import (
	"fmt"
)

// MustNewTermStructure creates a new term structure from a list of keys and values.
// It panics if the input is not valid.
// It is meant for tests only.
func MustNewTermStructure(keysAndValues ...any) TermStructure {
	nbInputs := len(keysAndValues)
	if nbInputs%2 != 0 {
		panic("NewTermStructure: odd number of arguments")
	}

	nbEntries := nbInputs / 2

	TermStructure := TermStructure{
		Data: make(map[Tenor]float64, nbEntries),
	}

	for i := 1; i < len(keysAndValues); i += 2 {
		anyKey, anyValue := keysAndValues[i-1], keysAndValues[i]

		key, ok := anyKey.(Tenor)
		if !ok {
			keyString, ok := anyKey.(string)
			if !ok {
				panic(fmt.Sprintf("NewTermStructure: key %v is not a Tenor (nor a string)", anyKey))
			}

			key = Tenor(keyString)
		}

		value, ok := anyValue.(float64)
		if !ok {
			panic(fmt.Sprintf("NewTermStructure: value %v is not a float64", anyValue))
		}

		TermStructure.Data[key] = value
	}

	if err := TermStructure.BuildInterpolator(); err != nil {
		panic(fmt.Sprintf("NewTermStructure: could not build the interpolator: %v", err))
	}

	return TermStructure
}
