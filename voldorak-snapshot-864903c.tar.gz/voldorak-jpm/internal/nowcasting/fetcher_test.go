package nowcasting

import (
	"encoding/csv"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_MakeMappingFetcher(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		fetcher, err := MakeMappingFetcher("testdata/mappings.csv")

		require.NoError(t, err)
		require.NotNil(t, fetcher)
		assert.NotNil(t, fetcher.mappingTable)
		assert.Len(t, fetcher.mappingTable, 4)
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			filePath    string
			errContains string
		}{
			"CSV with only headers": {
				filePath:    "testdata/headers_only.csv",
				errContains: "cannot build rate table",
			},
			"malformed structure": {
				filePath:    "testdata/malformed.csv",
				errContains: "cannot build rate table",
			},
			"file not found": {
				filePath:    "testdata/nonexistent.csv",
				errContains: "could not open CSV file",
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				fetcher, err := MakeMappingFetcher(tc.filePath)

				require.Error(t, err)
				assert.Contains(t, err.Error(), tc.errContains)
				assert.Nil(t, fetcher)
			})
		}
	})
}

func Test_MappingFetcher_Fetch(t *testing.T) {
	t.Parallel()

	fetcher, err := MakeMappingFetcher("testdata/mappings.csv")
	require.NoError(t, err)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id       string
			expected AssetMapping
		}{
			"fetch PE Fund 1": {
				id: "a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2",
				expected: AssetMapping{
					Label:                "PE Fund 1",
					FundType:             FundTypePrivateEquity,
					AssetID:              "a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2",
					IdiosyncraticProxyID: "b2c3d4e5-f6a7-44b8-c9d0-e1f2a3b4c5d6",
					MarketProxyID:        "2b3c4d5e-6f7a-458b-9c0d-1e2f3a4b5c6d",
				},
			},
			"fetch PC Fund 2": {
				id: "b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3",
				expected: AssetMapping{
					Label:                "PC Fund 2",
					FundType:             FundTypePrivateCredit,
					AssetID:              "b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3",
					IdiosyncraticProxyID: "c3d4e5f6-a7b8-45c9-d0e1-f2a3b4c5d6e7",
					MarketProxyID:        "3c4d5e6f-7a8b-469c-0d1e-2f3a4b5c6d7e",
				},
			},
			"fetch RE Fund": {
				id: "c9d0e1f2-a3b4-45c6-d7e8-f9a0b1c2d3e4",
				expected: AssetMapping{
					Label:                "RE Fund",
					FundType:             FundTypePrivateRealEstate,
					AssetID:              "c9d0e1f2-a3b4-45c6-d7e8-f9a0b1c2d3e4",
					IdiosyncraticProxyID: "d4e5f6a7-b8c9-46d0-e1f2-a3b4c5d6e7f8",
					MarketProxyID:        "4d5e6f7a-8b9c-470d-1e2f-3a4b5c6d7e8f",
				},
			},
			"fetch RA Fund": {
				id: "d0e1f2a3-b4c5-46d7-e8f9-a0b1c2d3e4f5",
				expected: AssetMapping{
					Label:                "RA Fund",
					FundType:             FundTypePrivateRealAssets,
					AssetID:              "d0e1f2a3-b4c5-46d7-e8f9-a0b1c2d3e4f5",
					IdiosyncraticProxyID: "e5f6a7b8-c9d0-47e1-f2a3-b4c5d6e7f8a9",
					MarketProxyID:        "5e6f7a8b-9c0d-481e-2f3a-4b5c6d7e8f9a",
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				output, err := fetcher.Fetch(tc.id)

				require.NoError(t, err)
				require.NotNil(t, output)
				assert.Equal(t, tc.expected, *output)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, id := range map[string]string{
			"non-existent id": "00000000-0000-0000-0000-000000000000",
			"empty string":    "",
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := fetcher.Fetch(id)
				require.Error(t, err)
			})
		}
	})
}

func Test_readCsv(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			csvContent string
			want       []mappingTableCSVEntry
		}{
			"valid CSV with all fields": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
PE Fund 1,Private Equity,a1b2c3d4-e5f6-47a8-b9c0-d1e2f3a4b5c6,f7e8d9c0-b1a2-4b3c-8d9e-0f1a2b3c4d5e,6f7e8d9c-0b1a-4b3c-8d9e-0f1a2b3c4d5e
PC Fund 2,Private Credit,b2c3d4e5-f6a7-48b9-c0d1-e2f3a4b5c6d7,e8d9c0b1-a2f3-4c5d-9e0f-1a2b3c4d5e6f,7e8d9c0b-1a2f-4c5d-9e0f-1a2b3c4d5e6f`,
				want: []mappingTableCSVEntry{
					{
						Label:    "PE Fund 1",
						FundType: FundTypePrivateEquity,
						NavID:    "a1b2c3d4-e5f6-47a8-b9c0-d1e2f3a4b5c6",
						ProxyID:  "f7e8d9c0-b1a2-4b3c-8d9e-0f1a2b3c4d5e",
						BroadID:  "6f7e8d9c-0b1a-4b3c-8d9e-0f1a2b3c4d5e",
					},
					{
						Label:    "PC Fund 2",
						FundType: FundTypePrivateCredit,
						NavID:    "b2c3d4e5-f6a7-48b9-c0d1-e2f3a4b5c6d7",
						ProxyID:  "e8d9c0b1-a2f3-4c5d-9e0f-1a2b3c4d5e6f",
						BroadID:  "7e8d9c0b-1a2f-4c5d-9e0f-1a2b3c4d5e6f",
					},
				},
			},
			"valid CSV with different fund types": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
RE Fund,Private Real Estate,c3d4e5f6-a7b8-49c0-d1e2-f3a4b5c6d7e8,d9c0b1a2-f3e4-4d5e-0f1a-2b3c4d5e6f7a,8d9c0b1a-2f3e-4d5e-0f1a-2b3c4d5e6f7a
RA Fund,Private Real Assets,d4e5f6a7-b8c9-40d1-e2f3-a4b5c6d7e8f9,c0b1a2f3-e4d5-4e6f-1a2b-3c4d5e6f7a8b,9c0b1a2f-3e4d-4e6f-1a2b-3c4d5e6f7a8b`,
				want: []mappingTableCSVEntry{
					{
						Label:    "RE Fund",
						FundType: FundTypePrivateRealEstate,
						NavID:    "c3d4e5f6-a7b8-49c0-d1e2-f3a4b5c6d7e8",
						ProxyID:  "d9c0b1a2-f3e4-4d5e-0f1a-2b3c4d5e6f7a",
						BroadID:  "8d9c0b1a-2f3e-4d5e-0f1a-2b3c4d5e6f7a",
					},
					{
						Label:    "RA Fund",
						FundType: FundTypePrivateRealAssets,
						NavID:    "d4e5f6a7-b8c9-40d1-e2f3-a4b5c6d7e8f9",
						ProxyID:  "c0b1a2f3-e4d5-4e6f-1a2b-3c4d5e6f7a8b",
						BroadID:  "9c0b1a2f-3e4d-4e6f-1a2b-3c4d5e6f7a8b",
					},
				},
			},
			"valid CSV with empty nav_asset_id": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
Incomplete Fund,Private Equity,,e5f6a7b8-c9d0-41e2-f3a4-b5c6d7e8f9a0,0b1a2f3e-4d5e-46f7-a8b9-c0d1e2f3a4b5`,
				want: []mappingTableCSVEntry{
					{
						Label:    "Incomplete Fund",
						FundType: FundTypePrivateEquity,
						NavID:    "",
						ProxyID:  "e5f6a7b8-c9d0-41e2-f3a4-b5c6d7e8f9a0",
						BroadID:  "0b1a2f3e-4d5e-46f7-a8b9-c0d1e2f3a4b5",
					},
				},
			},
			"empty CSV file": {
				csvContent: "",
				want:       []mappingTableCSVEntry{},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				reader := csv.NewReader(strings.NewReader(tc.csvContent))
				got, err := readCsv(reader)

				require.NoError(t, err)
				assert.Equal(t, tc.want, got)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, csvContent := range map[string]string{
			"CSV with only headers": `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid`,
			"malformed structure": `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
PE Fund 1,Private Equity,nav123,proxy456`,
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				reader := csv.NewReader(strings.NewReader(csvContent))
				_, err := readCsv(reader)

				require.Error(t, err)
			})
		}
	})
}

func Test_formatMappingTable(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		mappings []mappingTableCSVEntry
		expected mappingTable
	}{
		"single entry": {
			mappings: []mappingTableCSVEntry{
				{
					Label:    "PE Fund 1",
					FundType: FundTypePrivateEquity,
					NavID:    "f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1",
					ProxyID:  "a1b2c3d4-e5f6-43a7-b8c9-d0e1f2a3b4c5",
					BroadID:  "1a2b3c4d-5e6f-447a-8b9c-0d1e2f3a4b5c",
				},
			},
			expected: mappingTable{
				"f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1": AssetMapping{
					Label:                "PE Fund 1",
					FundType:             FundTypePrivateEquity,
					AssetID:              "f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1",
					IdiosyncraticProxyID: "a1b2c3d4-e5f6-43a7-b8c9-d0e1f2a3b4c5",
					MarketProxyID:        "1a2b3c4d-5e6f-447a-8b9c-0d1e2f3a4b5c",
				},
			},
		},
		"multiple entries": {
			mappings: []mappingTableCSVEntry{
				{
					Label:    "PE Fund 1",
					FundType: FundTypePrivateEquity,
					NavID:    "a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2",
					ProxyID:  "b2c3d4e5-f6a7-44b8-c9d0-e1f2a3b4c5d6",
					BroadID:  "2b3c4d5e-6f7a-458b-9c0d-1e2f3a4b5c6d",
				},
				{
					Label:    "PC Fund 2",
					FundType: FundTypePrivateCredit,
					NavID:    "b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3",
					ProxyID:  "c3d4e5f6-a7b8-45c9-d0e1-f2a3b4c5d6e7",
					BroadID:  "3c4d5e6f-7a8b-469c-0d1e-2f3a4b5c6d7e",
				},
			},
			expected: mappingTable{
				"a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2": AssetMapping{
					Label:                "PE Fund 1",
					FundType:             FundTypePrivateEquity,
					AssetID:              "a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2",
					IdiosyncraticProxyID: "b2c3d4e5-f6a7-44b8-c9d0-e1f2a3b4c5d6",
					MarketProxyID:        "2b3c4d5e-6f7a-458b-9c0d-1e2f3a4b5c6d",
				},
				"b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3": AssetMapping{
					Label:                "PC Fund 2",
					FundType:             FundTypePrivateCredit,
					AssetID:              "b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3",
					IdiosyncraticProxyID: "c3d4e5f6-a7b8-45c9-d0e1-f2a3b4c5d6e7",
					MarketProxyID:        "3c4d5e6f-7a8b-469c-0d1e-2f3a4b5c6d7e",
				},
			},
		},
		"all fund types": {
			mappings: []mappingTableCSVEntry{
				{
					Label:    "PE Fund",
					FundType: FundTypePrivateEquity,
					NavID:    "c9d0e1f2-a3b4-45c6-d7e8-f9a0b1c2d3e4",
					ProxyID:  "d4e5f6a7-b8c9-46d0-e1f2-a3b4c5d6e7f8",
					BroadID:  "4d5e6f7a-8b9c-470d-1e2f-3a4b5c6d7e8f",
				},
				{
					Label:    "PC Fund",
					FundType: FundTypePrivateCredit,
					NavID:    "d0e1f2a3-b4c5-46d7-e8f9-a0b1c2d3e4f5",
					ProxyID:  "e5f6a7b8-c9d0-47e1-f2a3-b4c5d6e7f8a9",
					BroadID:  "5e6f7a8b-9c0d-481e-2f3a-4b5c6d7e8f9a",
				},
				{
					Label:    "RE Fund",
					FundType: FundTypePrivateRealEstate,
					NavID:    "e1f2a3b4-c5d6-47e8-f9a0-b1c2d3e4f5a6",
					ProxyID:  "f6a7b8c9-d0e1-48f2-a3b4-c5d6e7f8a9b0",
					BroadID:  "6f7a8b9c-0d1e-492f-3a4b-5c6d7e8f9a0b",
				},
				{
					Label:    "RA Fund",
					FundType: FundTypePrivateRealAssets,
					NavID:    "f2a3b4c5-d6e7-48f9-a0b1-c2d3e4f5a6b7",
					ProxyID:  "a7b8c9d0-e1f2-49a3-b4c5-d6e7f8a9b0c1",
					BroadID:  "7a8b9c0d-1e2f-4a3a-4b5c-6d7e8f9a0b1c",
				},
			},
			expected: mappingTable{
				"c9d0e1f2-a3b4-45c6-d7e8-f9a0b1c2d3e4": AssetMapping{
					Label:                "PE Fund",
					FundType:             FundTypePrivateEquity,
					AssetID:              "c9d0e1f2-a3b4-45c6-d7e8-f9a0b1c2d3e4",
					IdiosyncraticProxyID: "d4e5f6a7-b8c9-46d0-e1f2-a3b4c5d6e7f8",
					MarketProxyID:        "4d5e6f7a-8b9c-470d-1e2f-3a4b5c6d7e8f",
				},
				"d0e1f2a3-b4c5-46d7-e8f9-a0b1c2d3e4f5": AssetMapping{
					Label:                "PC Fund",
					FundType:             FundTypePrivateCredit,
					AssetID:              "d0e1f2a3-b4c5-46d7-e8f9-a0b1c2d3e4f5",
					IdiosyncraticProxyID: "e5f6a7b8-c9d0-47e1-f2a3-b4c5d6e7f8a9",
					MarketProxyID:        "5e6f7a8b-9c0d-481e-2f3a-4b5c6d7e8f9a",
				},
				"e1f2a3b4-c5d6-47e8-f9a0-b1c2d3e4f5a6": AssetMapping{
					Label:                "RE Fund",
					FundType:             FundTypePrivateRealEstate,
					AssetID:              "e1f2a3b4-c5d6-47e8-f9a0-b1c2d3e4f5a6",
					IdiosyncraticProxyID: "f6a7b8c9-d0e1-48f2-a3b4-c5d6e7f8a9b0",
					MarketProxyID:        "6f7a8b9c-0d1e-492f-3a4b-5c6d7e8f9a0b",
				},
				"f2a3b4c5-d6e7-48f9-a0b1-c2d3e4f5a6b7": AssetMapping{
					Label:                "RA Fund",
					FundType:             FundTypePrivateRealAssets,
					AssetID:              "f2a3b4c5-d6e7-48f9-a0b1-c2d3e4f5a6b7",
					IdiosyncraticProxyID: "a7b8c9d0-e1f2-49a3-b4c5-d6e7f8a9b0c1",
					MarketProxyID:        "7a8b9c0d-1e2f-4a3a-4b5c-6d7e8f9a0b1c",
				},
			},
		},
		"empty nav_asset_id": {
			mappings: []mappingTableCSVEntry{
				{
					Label:    "Incomplete Fund",
					FundType: FundTypePrivateEquity,
					NavID:    "",
					ProxyID:  "a3b4c5d6-e7f8-4aa0-b1c2-d3e4f5a6b7c8",
					BroadID:  "8b9c0d1e-2f3a-4b4b-5c6d-7e8f9a0b1c2d",
				},
			},
			expected: mappingTable{
				"": AssetMapping{
					Label:                "Incomplete Fund",
					FundType:             FundTypePrivateEquity,
					AssetID:              "",
					IdiosyncraticProxyID: "a3b4c5d6-e7f8-4aa0-b1c2-d3e4f5a6b7c8",
					MarketProxyID:        "8b9c0d1e-2f3a-4b4b-5c6d-7e8f9a0b1c2d",
				},
			},
		},
		"empty slice": {
			mappings: []mappingTableCSVEntry{},
			expected: mappingTable{},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, formatMappingTable(tc.mappings))
		})
	}
}

func Test_buildMappingTable(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			csvContent string
			expected   mappingTable
		}{
			"single entry": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
PE Fund 1,Private Equity,f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1,a1b2c3d4-e5f6-43a7-b8c9-d0e1f2a3b4c5,1a2b3c4d-5e6f-447a-8b9c-0d1e2f3a4b5c`,
				expected: mappingTable{
					"f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1": AssetMapping{
						Label:                "PE Fund 1",
						FundType:             FundTypePrivateEquity,
						AssetID:              "f6a7b8c9-d0e1-42f3-a4b5-c6d7e8f9a0b1",
						IdiosyncraticProxyID: "a1b2c3d4-e5f6-43a7-b8c9-d0e1f2a3b4c5",
						MarketProxyID:        "1a2b3c4d-5e6f-447a-8b9c-0d1e2f3a4b5c",
					},
				},
			},
			"multiple entries": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
PE Fund 1,Private Equity,a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2,b2c3d4e5-f6a7-44b8-c9d0-e1f2a3b4c5d6,2b3c4d5e-6f7a-458b-9c0d-1e2f3a4b5c6d
PC Fund 2,Private Credit,b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3,c3d4e5f6-a7b8-45c9-d0e1-f2a3b4c5d6e7,3c4d5e6f-7a8b-469c-0d1e-2f3a4b5c6d7e`,
				expected: mappingTable{
					"a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2": AssetMapping{
						Label:                "PE Fund 1",
						FundType:             FundTypePrivateEquity,
						AssetID:              "a7b8c9d0-e1f2-43a4-b5c6-d7e8f9a0b1c2",
						IdiosyncraticProxyID: "b2c3d4e5-f6a7-44b8-c9d0-e1f2a3b4c5d6",
						MarketProxyID:        "2b3c4d5e-6f7a-458b-9c0d-1e2f3a4b5c6d",
					},
					"b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3": AssetMapping{
						Label:                "PC Fund 2",
						FundType:             FundTypePrivateCredit,
						AssetID:              "b8c9d0e1-f2a3-44b5-c6d7-e8f9a0b1c2d3",
						IdiosyncraticProxyID: "c3d4e5f6-a7b8-45c9-d0e1-f2a3b4c5d6e7",
						MarketProxyID:        "3c4d5e6f-7a8b-469c-0d1e-2f3a4b5c6d7e",
					},
				},
			},
			"empty nav_asset_id": {
				csvContent: `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
Incomplete Fund,Private Equity,,a3b4c5d6-e7f8-4aa0-b1c2-d3e4f5a6b7c8,8b9c0d1e-2f3a-4b4b-5c6d-7e8f9a0b1c2d`,
				expected: mappingTable{
					"": AssetMapping{
						Label:                "Incomplete Fund",
						FundType:             FundTypePrivateEquity,
						AssetID:              "",
						IdiosyncraticProxyID: "a3b4c5d6-e7f8-4aa0-b1c2-d3e4f5a6b7c8",
						MarketProxyID:        "8b9c0d1e-2f3a-4b4b-5c6d-7e8f9a0b1c2d",
					},
				},
			},
			"empty CSV file": {
				csvContent: "",
				expected:   mappingTable{},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				reader := csv.NewReader(strings.NewReader(tc.csvContent))
				got, err := buildMappingTable(reader)

				require.NoError(t, err)
				assert.Equal(t, tc.expected, got)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, csvContent := range map[string]string{
			"CSV with only headers": `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid`,
			"malformed structure": `label,fund_type,nav_asset_id,proxy_uuid,broad_uuid
PE Fund 1,Private Equity,c4d5e6f7-a8b9-44c0-d1e2-f3a4b5c6d7e8,d5e6f7a8`,
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				reader := csv.NewReader(strings.NewReader(csvContent))
				_, err := buildMappingTable(reader)

				require.Error(t, err)
			})
		}
	})
}
