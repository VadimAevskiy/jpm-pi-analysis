package nowcasting

import (
	"encoding/csv"
	"fmt"
	"io"
	"os"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/jszwec/csvutil"
)

// AssetMapping represents the mapping of a private asset label to its associated identifiers and fund type.
type AssetMapping struct {
	Label                string
	FundType             FundType
	AssetID              string
	IdiosyncraticProxyID string
	MarketProxyID        string
}

// Fetcher defines the interface for fetching an AssetMapping by ID.
type Fetcher interface {
	Fetch(id string) (*AssetMapping, error)
}

// Compile-time check.
var _ Fetcher = MappingFetcher{}

// MappingFetcher fetches an AssetMapping by ID.
type MappingFetcher struct {
	mappingTable mappingTable
}

// MakeMappingFetcher constructs a MappingFetcher by reading and parsing the provided CSV data.
func MakeMappingFetcher(path string) (*MappingFetcher, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("could not open CSV file: %w", err)
	}
	defer file.Close()

	mappingTable, err := buildMappingTable(csv.NewReader(file))
	if err != nil {
		return nil, fmt.Errorf("cannot build rate table: %w", err)
	}

	return &MappingFetcher{mappingTable: mappingTable}, nil
}

// Fetch retrieves the AssetMapping associated with the given ID (label). It returns an error if no mapping is found.
func (mf MappingFetcher) Fetch(id string) (*AssetMapping, error) {
	mapping, ok := mf.mappingTable[id]
	if !ok {
		return nil, errors.NotFound("mapping not found for id: %s", id)
	}

	return &mapping, nil
}

// mappingTable is a helper type for efficient lookups of AssetMappings by label.
type mappingTable map[string]AssetMapping

// buildMappingTable reads the CSV data and constructs a mappingTable for efficient lookups.
func buildMappingTable(reader *csv.Reader) (mappingTable, error) {
	records, err := readCsv(reader)
	if err != nil {
		return nil, fmt.Errorf("could not read CSV file: %w", err)
	}

	return formatMappingTable(records), nil
}

// mappingTableCSVEntry represents a single row in the CSV mapping table.
type mappingTableCSVEntry struct {
	Label    string   `csv:"label"`
	FundType FundType `csv:"fund_type"`
	NavID    string   `csv:"nav_asset_id"`
	ProxyID  string   `csv:"proxy_uuid"`
	BroadID  string   `csv:"broad_uuid"`
}

func readCsv(reader *csv.Reader) ([]mappingTableCSVEntry, error) {
	dec, err := csvutil.NewDecoder(reader)
	if err != nil {
		if errors.Is(err, io.EOF) {
			// file is empty and that's ok
			return []mappingTableCSVEntry{}, nil
		}

		return nil, fmt.Errorf("unable to create cvsutil decoder: %w", err)
	}

	var records []mappingTableCSVEntry
	if err := dec.Decode(&records); err != nil {
		return nil, fmt.Errorf("unable to parse CSV: %w", err)
	}

	return records, nil
}

func formatMappingTable(mappings []mappingTableCSVEntry) mappingTable {
	out := make(mappingTable, len(mappings))

	for _, m := range mappings {
		out[m.NavID] = AssetMapping{
			Label:                m.Label,
			FundType:             m.FundType,
			AssetID:              m.NavID,
			IdiosyncraticProxyID: m.ProxyID,
			MarketProxyID:        m.BroadID,
		}
	}

	return out
}
