//go:build local

// Local test that exercises the production SSM pipeline against the real
// cerberus service. Requires Tailscale + working *.service.consul DNS.
//
// Skipped in CI by the `local` build tag.
//
// This test reproduces production fetchSpotTimeseriesWithSSMPipeline
// (internal/service/v1/provider.go, post-PR-819 on main) call for call:
//
//     mapping  := privateAssetMappingFetcher.Fetch(id)
//     calibFrom := to.AddDate(0, 0, -CalibrationWeeks*7)            // 1428 weeks
//     nav      := provider.FetchSpotTimeseries(PrivateAsset, id, calibFrom, to)
//     idio     := provider.FetchSpotTimeseries(Fund,         mapping.IdiosyncraticProxyID, calibFrom, to)
//     market   := provider.FetchSpotTimeseries(Index,        mapping.MarketProxyID,        calibFrom, to)
//     config   := nowcasting.SSMConfigForFundType(mapping.FundType)
//     prices, ssmOut, err := nowcasting.RunPipeline(nav, idio, market, config)
//
// Everything written to the summary CSV is a direct property of either the
// inputs to the pipeline or of the pipeline's own output (prices + ssmOut).
// No test-side window / vol / correlation diagnostics — those are downstream
// consumer concerns, not pipeline correctness signals.
//
// Usage:
//   SSM_TEST_ASSET="USD | Eq - Buyout + Expansion - USD" \
//     go test -tags local -v ./internal/nowcasting/... -run TestLocalPipeline_Single
//
//   go test -tags local -v ./internal/nowcasting/... -run TestLocalPipeline_All -timeout 30m
//
//   SSM_AS_OF_DATE=2026-02-28 go test -tags local ...
//
// Environment:
//   SSM_OUTPUT_DIR    where to write summary + per-asset prices (default: ~/Desktop/cerberus_extract)
//   SSM_AS_OF_DATE    truncate input series upper bound to this date (YYYY-MM-DD)
//   SSM_TEST_ASSET    run only this asset by label (Single test only)

package nowcasting

import (
	"context"
	"encoding/csv"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/stretchr/testify/require"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
)

// Production-aligned constants. Keep in sync with
// deployment/{dev,prod,testdata}/infra-config.yml.
const (
	cerberusHost    = "http://cerberus.service.consul"
	cerberusTimeout = "30s"

	// Matches private_asset.calibration_weeks on main (post PR #819).
	calibrationWeeks = 1428
)

func newCerberusClient(t *testing.T) *cerberus.Client {
	t.Helper()
	client, err := cerberus.NewClient(&cerberus.Config{
		Host:    cerberusHost,
		Timeout: cerberusTimeout,
		Retry:   3,
	})
	require.NoError(t, err)
	return client
}

// newMappingFetcher returns the production fetcher (MakeMappingFetcher) —
// same code path voldorak_server.go uses on main.
func newMappingFetcher(t *testing.T) Fetcher {
	t.Helper()
	fetcher, err := MakeMappingFetcher(resolveMappingPath(t))
	require.NoError(t, err)
	return fetcher
}

func resolveOutputDir(t *testing.T) string {
	t.Helper()
	out := os.Getenv("SSM_OUTPUT_DIR")
	if out == "" {
		home, err := os.UserHomeDir()
		require.NoError(t, err)
		out = filepath.Join(home, "Desktop", "cerberus_extract")
	}
	require.NoError(t, os.MkdirAll(out, 0o755))
	return out
}

func resolveRepoRoot(t *testing.T) string {
	t.Helper()
	wd, err := os.Getwd()
	require.NoError(t, err)
	dir := wd
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		require.NotEqual(t, parent, dir, "could not locate go.mod ancestor")
		dir = parent
	}
}

func resolveMappingPath(t *testing.T) string {
	t.Helper()
	return filepath.Join(resolveRepoRoot(t), "deployment", "private_asset_mapping.csv")
}

func resolveAsOfDate(t *testing.T) date.Date {
	t.Helper()
	s := os.Getenv("SSM_AS_OF_DATE")
	if s == "" {
		return date.Date{}
	}
	d, err := date.Parse("2006-01-02", s)
	require.NoError(t, err)
	return d
}

// ----- mapping enumeration (test-only) -----
//
// Production Fetcher exposes only Fetch(id); the test enumerates the CSV
// directly to drive the per-asset loop. The CSV is the same file the
// production fetcher reads (column names from internal/nowcasting/fetcher.go).

type mappingRow struct {
	label     string
	fundType  string
	navUUID   string
	proxyUUID string
	broadUUID string
}

func loadMappingRows(t *testing.T) []mappingRow {
	t.Helper()
	f, err := os.Open(resolveMappingPath(t))
	require.NoError(t, err)
	defer f.Close()
	r := csv.NewReader(f)
	r.FieldsPerRecord = -1
	records, err := r.ReadAll()
	require.NoError(t, err)
	if len(records) == 0 {
		return nil
	}
	header := records[0]
	colIdx := make(map[string]int, len(header))
	for i, h := range header {
		colIdx[strings.TrimSpace(h)] = i
	}
	col := func(name string) int {
		i, ok := colIdx[name]
		if !ok {
			t.Fatalf("mapping CSV missing column %q (have: %v)", name, header)
		}
		return i
	}
	li, fti, ai, pi, bi := col("label"), col("fund_type"),
		col("nav_asset_id"), col("proxy_uuid"), col("broad_uuid")

	out := make([]mappingRow, 0, len(records)-1)
	for _, row := range records[1:] {
		if len(row) <= bi {
			continue
		}
		label := strings.TrimSpace(row[li])
		if label == "" || strings.HasPrefix(label, "#") {
			continue
		}
		out = append(out, mappingRow{
			label:     label,
			fundType:  strings.TrimSpace(row[fti]),
			navUUID:   strings.TrimSpace(row[ai]),
			proxyUUID: strings.TrimSpace(row[pi]),
			broadUUID: strings.TrimSpace(row[bi]),
		})
	}
	return out
}

func mappingRowByLabel(t *testing.T, label string) mappingRow {
	t.Helper()
	if label == "" {
		t.Fatal("SSM_TEST_ASSET must be set for TestLocalPipeline_Single")
	}
	for _, r := range loadMappingRows(t) {
		if r.label == label {
			return r
		}
	}
	t.Fatalf("asset label %q not found in mapping CSV", label)
	return mappingRow{}
}

// ----- tests -----

func TestLocalPipeline_Single(t *testing.T) {
	outDir := resolveOutputDir(t)
	wanted := os.Getenv("SSM_TEST_ASSET")
	m := mappingRowByLabel(t, wanted)
	asOf := resolveAsOfDate(t)

	t.Logf("asset: %s | fund_type: %s", m.label, m.fundType)
	if !asOf.IsZero() {
		t.Logf("as-of date: %s", asOf)
	}

	// Verify the production fetcher can resolve the same id; this is the
	// same call production makes inside fetchSpotTimeseriesWithSSMPipeline.
	fetcher := newMappingFetcher(t)
	prodMapping, err := fetcher.Fetch(m.navUUID)
	require.NoError(t, err, "production fetcher.Fetch")
	require.NotNil(t, prodMapping)

	client := newCerberusClient(t)
	result := runOneAsset(t, client, m, asOf, outDir)
	logResult(t, result)
}

func TestLocalPipeline_All(t *testing.T) {
	outDir := resolveOutputDir(t)
	mappings := loadMappingRows(t)
	asOf := resolveAsOfDate(t)
	if !asOf.IsZero() {
		t.Logf("as-of date: %s (every asset truncated to this date)", asOf)
	}
	t.Logf("running production SSM pipeline on %d assets via real cerberus", len(mappings))

	// Construct the production fetcher once; verifies the CSV parses cleanly.
	_ = newMappingFetcher(t)
	client := newCerberusClient(t)

	summaryPath := filepath.Join(outDir, "ssm_summary.csv")
	summaryFile, err := os.Create(summaryPath)
	require.NoError(t, err)
	defer summaryFile.Close()
	w := csv.NewWriter(summaryFile)
	defer w.Flush()
	require.NoError(t, w.Write(summaryHeader()))

	var (
		mu             sync.Mutex
		nOK, nErrored int
	)
	start := time.Now()

	for i, m := range mappings {
		i, m := i, m
		t.Run(m.label, func(t *testing.T) {
			defer func() {
				if r := recover(); r != nil {
					t.Logf("[%d/%d] %s: PANIC %v", i+1, len(mappings), m.label, r)
					mu.Lock()
					nErrored++
					mu.Unlock()
				}
			}()
			result, err := runOneAssetSafe(client, m, asOf, outDir)
			mu.Lock()
			defer mu.Unlock()
			if err != nil {
				t.Logf("[%d/%d] %s: ERROR %v", i+1, len(mappings), m.label, err)
				nErrored++
				_ = w.Write(summaryRowError(m, err.Error()))
				return
			}
			nOK++
			t.Logf("[%d/%d] %s: beta=%.3f lambda=%.3f F=%.4f sigmaNAV=%.4f NLL=%.2f maxMove=%.1f%%",
				i+1, len(mappings), m.label,
				result.beta, result.lambda, result.f, result.sigmaNAV, result.negLogLik, result.maxDailyMovePct)
			_ = w.Write(summaryRowSuccess(m, result))
		})
	}

	t.Logf("done in %s. completed=%d errored=%d", time.Since(start), nOK, nErrored)
	t.Logf("summary CSV: %s", summaryPath)
}

// assetResult is the per-asset summary: production return values plus
// statistical aggregations (std and corr) of production-produced arrays.
// Every derived field is computed from values returned by exported
// production functions (AlignWeekly, AlignDaily, RunPipeline / SSMOutput);
// the test does not invent thresholds or classify outcomes.
type assetResult struct {
	// Input series sizes (from cerberus fetches).
	numNAV, numIdio, numMarket int

	// Output price series properties (from RunPipeline's `prices`).
	numPrices           int
	firstDate, lastDate string
	firstPrice          float64
	lastPrice           float64
	maxDailyMovePct     float64

	// OLS step (from ssmOut.AlphaOLS / BetaOLS + Diagnostics).
	alphaOLS, betaOLS               float64
	alphaOLSRaw, betaOLSRaw         float64
	alphaOLSClamped, betaOLSClamped bool

	// MLE step (from ssmOut.Params; alpha/beta equal alpha_ols/beta_ols
	// because production locks them with FixAlphaOLS=true, FixBetaOLS=true).
	alpha, beta, lambda, psi float64
	f, sigmaNAV, fc, betaC   float64

	// Likelihood.
	negLogLik float64

	// Diagnostics from ssmOut.Diagnostics.
	calibWeeks  int
	navObsCount int
	navFrac     float64

	// Derived weekly aggregations on the SSM output window (length = len(WeeklyRStar)).
	// `r*` is ssmOut.WeeklyRStar; weekly proxy and market returns come from
	// production's AlignWeekly call (same call RunPipeline makes internally).
	wkVolSSM, wkVolMkt, wkVolPrx             float64
	wkCorrSsmMkt, wkCorrSsmPrx, wkCorrPrxMkt float64

	// Derived calibration-window weekly aggregations (full alignment window,
	// not just the trailing OutputWindowWeeks).
	calibVolMkt, calibVolPrx, calibCorrPM float64

	// Derived daily aggregations on the Chow-Lin disaggregated output.
	// Daily SSM returns are log diff of `prices.Values`; proxy + market come
	// from AlignDaily on the same trailing-Friday grid the pipeline uses.
	dyVolSSM, dyVolMkt, dyVolPrx             float64
	dyCorrSsmMkt, dyCorrSsmPrx, dyCorrPrxMkt float64

	outPath string
}

func runOneAsset(t *testing.T, client *cerberus.Client, m mappingRow, asOf date.Date, outDir string) assetResult {
	t.Helper()
	r, err := runOneAssetSafe(client, m, asOf, outDir)
	require.NoError(t, err)
	return r
}

// runOneAssetSafe reproduces production fetchSpotTimeseriesWithSSMPipeline
// step for step and captures the direct production output for the summary.
func runOneAssetSafe(client *cerberus.Client, m mappingRow, asOf date.Date, outDir string) (assetResult, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()

	to := asOf
	if to.IsZero() {
		to = date.Today()
	}

	// Production calibration-window calculation.
	calibFrom := to.UTC().AddDate(0, 0, -calibrationWeeks*7)

	nav, err := client.FetchSpotTimeseries(ctx, marketdata.PrivateAsset, m.navUUID, calibFrom, to.UTC())
	if err != nil {
		return assetResult{}, fmt.Errorf("fetch nav: %w", err)
	}
	idio, err := client.FetchSpotTimeseries(ctx, marketdata.Fund, m.proxyUUID, calibFrom, to.UTC())
	if err != nil {
		return assetResult{}, fmt.Errorf("fetch idio: %w", err)
	}
	market, err := client.FetchSpotTimeseries(ctx, marketdata.Index, m.broadUUID, calibFrom, to.UTC())
	if err != nil {
		return assetResult{}, fmt.Errorf("fetch market: %w", err)
	}

	if nav == nil || len(nav.Entries) == 0 {
		return assetResult{}, fmt.Errorf("nav empty")
	}
	if idio == nil || len(idio.Entries) == 0 {
		return assetResult{}, fmt.Errorf("idio empty")
	}
	if market == nil || len(market.Entries) == 0 {
		return assetResult{}, fmt.Errorf("market empty")
	}

	config := SSMConfigForFundType(FundType(m.fundType))
	prices, ssmOut, err := RunPipeline(nav, idio, market, config)
	if err != nil {
		return assetResult{}, fmt.Errorf("RunPipeline: %w", err)
	}

	// Recompute the production weekly + daily alignment to extract the
	// proxy/market series the pipeline used internally. AlignWeekly and
	// AlignDaily are the same exported functions production calls.
	idioFrom := idio.At(0).Date
	idioTo := idio.Last().Date
	weekly, alignErr := AlignWeekly(idio, market, nav, idioFrom, idioTo)
	if alignErr != nil {
		return assetResult{}, fmt.Errorf("AlignWeekly: %w", alignErr)
	}

	// Trailing OutputWindowWeeks of the weekly alignment matches the SSM
	// window WeeklyRStar lives on. Pipeline takes the same trailing slice.
	rStar := ssmOut.WeeklyRStar
	nWk := len(rStar)
	wkProxyOut := tail(weekly.ProxyReturns, nWk)
	wkMarketOut := tail(weekly.MarketReturns, nWk)

	// Daily alignment is built on the trailing (nWk+1) Fridays of the weekly
	// grid (one extra Friday to bound the leading week segment) — same as
	// disaggregateToDaily in pipeline.go.
	dailyAligned := AlignDaily(idio, market, weekly.Dates[len(weekly.Dates)-(nWk+1):])
	dailyRStar := logDiff(pricesValues(prices))

	res := assetResult{
		numNAV:          len(nav.Entries),
		numIdio:         len(idio.Entries),
		numMarket:       len(market.Entries),
		numPrices:       len(prices.Entries),
		firstDate:       prices.At(0).Date.String(),
		lastDate:        prices.Last().Date.String(),
		firstPrice:      prices.At(0).Value,
		lastPrice:       prices.Last().Value,
		maxDailyMovePct: maxDailyMovePct(prices),
		alphaOLS:        ssmOut.AlphaOLS,
		betaOLS:         ssmOut.BetaOLS,
		alphaOLSRaw:     ssmOut.Diagnostics.AlphaOLSRaw,
		betaOLSRaw:      ssmOut.Diagnostics.BetaOLSRaw,
		alphaOLSClamped: ssmOut.Diagnostics.AlphaOLSClamped,
		betaOLSClamped:  ssmOut.Diagnostics.BetaOLSClamped,
		alpha:           ssmOut.Params.Alpha,
		beta:            ssmOut.Params.Beta,
		lambda:          ssmOut.Params.Lambda,
		psi:             ssmOut.Params.Psi,
		f:               ssmOut.Params.F,
		sigmaNAV:        ssmOut.Params.SigmaNAV,
		fc:              ssmOut.Params.Fc,
		betaC:           ssmOut.Params.BetaC,
		negLogLik:       ssmOut.NegLogLik,
		calibWeeks:      ssmOut.Diagnostics.CalibrationWeeks,
		navObsCount:     ssmOut.Diagnostics.NAVObservationCount,
		navFrac:         ssmOut.Diagnostics.NAVObservationFraction,

		// Weekly aggregations on the SSM output window.
		wkVolSSM:     annualWeekly(rStar),
		wkVolMkt:     annualWeekly(wkMarketOut),
		wkVolPrx:     annualWeekly(wkProxyOut),
		wkCorrSsmMkt: pearson(rStar, wkMarketOut),
		wkCorrSsmPrx: pearson(rStar, wkProxyOut),
		wkCorrPrxMkt: pearson(wkProxyOut, wkMarketOut),

		// Calibration-window weekly aggregations.
		calibVolMkt: annualWeekly(weekly.MarketReturns),
		calibVolPrx: annualWeekly(weekly.ProxyReturns),
		calibCorrPM: pearson(weekly.ProxyReturns, weekly.MarketReturns),

		// Daily aggregations on the Chow-Lin output window.
		dyVolSSM:     annualDaily(dailyRStar),
		dyVolMkt:     annualDaily(dailyAligned.MarketReturns),
		dyVolPrx:     annualDaily(dailyAligned.ProxyReturns),
		dyCorrSsmMkt: pearson(dailyRStar, dailyAligned.MarketReturns),
		dyCorrSsmPrx: pearson(dailyRStar, dailyAligned.ProxyReturns),
		dyCorrPrxMkt: pearson(dailyAligned.ProxyReturns, dailyAligned.MarketReturns),
	}

	perAssetCSV := filepath.Join(outDir, "prices_"+sanitizeFilename(m.label)+".csv")
	if err := writePricesCSV(perAssetCSV, prices); err != nil {
		return res, fmt.Errorf("write prices csv: %w", err)
	}
	res.outPath = perAssetCSV

	return res, nil
}

// ----- CSV output -----

func writePricesCSV(path string, prices *marketdata.Timeseries) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	w := csv.NewWriter(f)
	defer w.Flush()
	if err := w.Write([]string{"date", "price"}); err != nil {
		return err
	}
	for i := 0; i < len(prices.Entries); i++ {
		e := prices.At(i)
		if err := w.Write([]string{e.Date.String(), strconv.FormatFloat(e.Value, 'g', -1, 64)}); err != nil {
			return err
		}
	}
	return nil
}

func summaryHeader() []string {
	return []string{
		// identity
		"label", "fund_type", "nav_uuid", "proxy_uuid", "broad_uuid",
		// input sizes
		"num_nav", "num_idio", "num_market",
		// output series
		"num_prices", "first_date", "last_date", "first_price", "last_price", "max_daily_move_pct",
		// OLS step
		"alpha_ols", "beta_ols", "alpha_ols_raw", "beta_ols_raw", "alpha_ols_clamped", "beta_ols_clamped",
		// MLE step. `alpha_mle` / `beta_mle` are aliases written for audit-script
		// compatibility (production locks them to OLS so they equal alpha_ols /
		// beta_ols).
		"alpha", "beta", "alpha_mle", "beta_mle",
		"lambda", "psi", "f", "sigma_nav", "fc", "beta_c",
		// likelihood + diagnostics
		"neg_log_lik", "calib_weeks", "nav_obs_count", "nav_frac",
		// weekly aggregations on the SSM output window (std × sqrt(52), pearson)
		"wk_vol_ssm", "wk_vol_mkt", "wk_vol_prx",
		"wk_corr_ssm_mkt", "wk_corr_ssm_prx", "wk_corr_prx_mkt",
		// weekly aggregations on the full calibration window
		"calib_vol_mkt", "calib_vol_prx", "calib_corr_pm",
		// daily aggregations on the Chow-Lin output window (std × sqrt(252), pearson)
		"dy_vol_ssm", "dy_vol_mkt", "dy_vol_prx",
		"dy_corr_ssm_mkt", "dy_corr_ssm_prx", "dy_corr_prx_mkt",
		// error (populated only when the pipeline fails for this asset)
		"error",
	}
}

func summaryRowSuccess(m mappingRow, r assetResult) []string {
	f := func(x float64) string { return strconv.FormatFloat(x, 'g', -1, 64) }
	return []string{
		m.label, m.fundType, m.navUUID, m.proxyUUID, m.broadUUID,
		strconv.Itoa(r.numNAV), strconv.Itoa(r.numIdio), strconv.Itoa(r.numMarket),
		strconv.Itoa(r.numPrices), r.firstDate, r.lastDate, f(r.firstPrice), f(r.lastPrice), f(r.maxDailyMovePct),
		f(r.alphaOLS), f(r.betaOLS), f(r.alphaOLSRaw), f(r.betaOLSRaw),
		strconv.FormatBool(r.alphaOLSClamped), strconv.FormatBool(r.betaOLSClamped),
		f(r.alpha), f(r.beta), f(r.alpha), f(r.beta), // alpha_mle / beta_mle aliases
		f(r.lambda), f(r.psi), f(r.f), f(r.sigmaNAV), f(r.fc), f(r.betaC),
		f(r.negLogLik), strconv.Itoa(r.calibWeeks), strconv.Itoa(r.navObsCount), f(r.navFrac),
		f(r.wkVolSSM), f(r.wkVolMkt), f(r.wkVolPrx),
		f(r.wkCorrSsmMkt), f(r.wkCorrSsmPrx), f(r.wkCorrPrxMkt),
		f(r.calibVolMkt), f(r.calibVolPrx), f(r.calibCorrPM),
		f(r.dyVolSSM), f(r.dyVolMkt), f(r.dyVolPrx),
		f(r.dyCorrSsmMkt), f(r.dyCorrSsmPrx), f(r.dyCorrPrxMkt),
		"",
	}
}

func summaryRowError(m mappingRow, errStr string) []string {
	row := make([]string, len(summaryHeader()))
	row[0] = m.label
	row[1] = m.fundType
	row[2] = m.navUUID
	row[3] = m.proxyUUID
	row[4] = m.broadUUID
	row[len(row)-1] = errStr
	return row
}

// ----- helpers (only what's needed for production-output diagnostics) -----

func maxDailyMovePct(ts *marketdata.Timeseries) float64 {
	var mx float64
	for i := 1; i < len(ts.Entries); i++ {
		p0 := ts.At(i - 1).Value
		p1 := ts.At(i).Value
		if p0 <= 0 {
			continue
		}
		m := math.Abs(p1/p0-1.0) * 100
		if m > mx {
			mx = m
		}
	}
	return mx
}

func sanitizeFilename(s string) string {
	r := strings.NewReplacer("/", "_", " ", "_", "|", "_", "+", "p", ":", "_")
	return r.Replace(s)
}

func logResult(t *testing.T, r assetResult) {
	t.Helper()
	t.Logf("nav points: %d | idio points: %d | market points: %d", r.numNAV, r.numIdio, r.numMarket)
	t.Logf("daily prices: %d points (%s to %s)", r.numPrices, r.firstDate, r.lastDate)
	t.Logf("OLS: alpha=%.6f beta=%.6f", r.alphaOLS, r.betaOLS)
	t.Logf("MLE: alpha=%.6f beta=%.6f lambda=%.6f psi=%.6f", r.alpha, r.beta, r.lambda, r.psi)
	t.Logf("MLE: F=%.6f sigmaNAV=%.6f Fc=%.6f betaC=%.6f", r.f, r.sigmaNAV, r.fc, r.betaC)
	t.Logf("NLL: %.6f | calibration weeks: %d | NAV obs: %d (%.1f%%)",
		r.negLogLik, r.calibWeeks, r.navObsCount, r.navFrac*100)
	t.Logf("first price: %.4f | last price: %.4f | max daily move: %.2f%%",
		r.firstPrice, r.lastPrice, r.maxDailyMovePct)
	t.Logf("vol weekly:  ssm=%.4f mkt=%.4f prx=%.4f", r.wkVolSSM, r.wkVolMkt, r.wkVolPrx)
	t.Logf("vol daily :  ssm=%.4f mkt=%.4f prx=%.4f", r.dyVolSSM, r.dyVolMkt, r.dyVolPrx)
	t.Logf("corr weekly: ssmMkt=%.4f ssmPrx=%.4f prxMkt=%.4f", r.wkCorrSsmMkt, r.wkCorrSsmPrx, r.wkCorrPrxMkt)
	t.Logf("corr daily : ssmMkt=%.4f ssmPrx=%.4f prxMkt=%.4f", r.dyCorrSsmMkt, r.dyCorrSsmPrx, r.dyCorrPrxMkt)
	t.Logf("calib weekly: vol_mkt=%.4f vol_prx=%.4f corr_pm=%.4f", r.calibVolMkt, r.calibVolPrx, r.calibCorrPM)
	t.Logf("wrote prices CSV: %s", r.outPath)
}
