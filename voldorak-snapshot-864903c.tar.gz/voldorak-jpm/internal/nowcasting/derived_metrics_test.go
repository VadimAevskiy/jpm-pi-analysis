//go:build local

// Statistical helpers that turn the production pipeline's output arrays
// (SSMOutput.WeeklyRStar, AlignedData.{ProxyReturns,MarketReturns}) into the
// summary metrics the validation report cites. Nothing here is "test-side
// invention" — every input is a value the production pipeline computes; the
// helpers are just std() and corr() on those arrays, annualised on the
// canonical convention (sqrt(52) for weekly, sqrt(252) for daily).

package nowcasting

import (
	"math"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// timeseries is a local alias to keep the helper signature short.
type timeseries = marketdata.Timeseries

const (
	weeksPerYear = 52.0
	daysPerYear  = 252.0
)

// std returns the sample standard deviation. Skips NaNs.
func std(xs []float64) float64 {
	var sum, count float64
	for _, x := range xs {
		if math.IsNaN(x) {
			continue
		}
		sum += x
		count++
	}
	if count < 2 {
		return 0
	}
	mean := sum / count
	var ssq float64
	for _, x := range xs {
		if math.IsNaN(x) {
			continue
		}
		d := x - mean
		ssq += d * d
	}
	return math.Sqrt(ssq / (count - 1))
}

// pearson returns the Pearson correlation between xs and ys, ignoring index
// positions where either is NaN. Returns 0 if fewer than 2 paired values.
func pearson(xs, ys []float64) float64 {
	n := len(xs)
	if n > len(ys) {
		n = len(ys)
	}
	var xs2, ys2 []float64
	for i := 0; i < n; i++ {
		if math.IsNaN(xs[i]) || math.IsNaN(ys[i]) {
			continue
		}
		xs2 = append(xs2, xs[i])
		ys2 = append(ys2, ys[i])
	}
	if len(xs2) < 2 {
		return 0
	}
	var sx, sy float64
	for i := range xs2 {
		sx += xs2[i]
		sy += ys2[i]
	}
	mx := sx / float64(len(xs2))
	my := sy / float64(len(ys2))
	var num, dxsq, dysq float64
	for i := range xs2 {
		dx := xs2[i] - mx
		dy := ys2[i] - my
		num += dx * dy
		dxsq += dx * dx
		dysq += dy * dy
	}
	den := math.Sqrt(dxsq * dysq)
	if den == 0 {
		return 0
	}
	return num / den
}

// annualVol = sample std × sqrt(periodsPerYear). Convention used everywhere.
func annualWeekly(xs []float64) float64 { return std(xs) * math.Sqrt(weeksPerYear) }
func annualDaily(xs []float64) float64  { return std(xs) * math.Sqrt(daysPerYear) }

// logDiff returns log(x_{t+1}) - log(x_t) for a price-like slice.
func logDiff(xs []float64) []float64 {
	if len(xs) < 2 {
		return nil
	}
	out := make([]float64, len(xs)-1)
	for i := 0; i < len(xs)-1; i++ {
		out[i] = math.Log(xs[i+1]) - math.Log(xs[i])
	}
	return out
}

// tail returns the last n entries of xs (or all if len(xs) <= n).
func tail(xs []float64, n int) []float64 {
	if n >= len(xs) {
		return xs
	}
	return xs[len(xs)-n:]
}

// pricesValues extracts the value column from a marketdata.Timeseries.
func pricesValues(ts *timeseries) []float64 {
	if ts == nil {
		return nil
	}
	out := make([]float64, ts.NumEntries())
	for i := 0; i < ts.NumEntries(); i++ {
		out[i] = ts.At(i).Value
	}
	return out
}
