package nowcasting

import (
	"math"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/biz"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_priceAtBothSync(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			proxyDates   []date.Date
			proxyValues  []float64
			marketDates  []date.Date
			marketValues []float64
			d            date.Date
			lookback     int
			wantProxy    float64
			wantMarket   float64
		}{
			"exact match same day": {
				proxyDates:   []date.Date{date.New(2024, 1, 1)},
				proxyValues:  []float64{100.0},
				marketDates:  []date.Date{date.New(2024, 1, 1)},
				marketValues: []float64{200.0},
				d:            date.New(2024, 1, 1),
				lookback:     5,
				wantProxy:    100.0,
				wantMarket:   200.0,
			},
			"resolve via lookback when both available on previous shared date": {
				proxyDates:   []date.Date{date.New(2024, 1, 3)},
				proxyValues:  []float64{101.0},
				marketDates:  []date.Date{date.New(2024, 1, 3)},
				marketValues: []float64{201.0},
				d:            date.New(2024, 1, 5),
				lookback:     5,
				wantProxy:    101.0,
				wantMarket:   201.0,
			},
			"prefer most recent shared date": {
				proxyDates:   []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 3)},
				proxyValues:  []float64{100.0, 102.0},
				marketDates:  []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 3)},
				marketValues: []float64{200.0, 202.0},
				d:            date.New(2024, 1, 5),
				lookback:     5,
				wantProxy:    102.0,
				wantMarket:   202.0,
			},
			"skip date where only one is available": {
				proxyDates:   []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 4)},
				proxyValues:  []float64{100.0, 103.0},
				marketDates:  []date.Date{date.New(2024, 1, 1)},
				marketValues: []float64{200.0},
				d:            date.New(2024, 1, 4),
				lookback:     5,
				wantProxy:    100.0,
				wantMarket:   200.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				proxy := buildTS(tc.proxyDates, tc.proxyValues)
				market := buildTS(tc.marketDates, tc.marketValues)

				got, ok := priceAtBothSync(proxy, market, tc.d, tc.lookback)

				require.True(t, ok)
				assert.InDelta(t, tc.wantProxy, got.ProxyPrice, 1e-15)
				assert.InDelta(t, tc.wantMarket, got.MarketPrice, 1e-15)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			proxyDates   []date.Date
			proxyValues  []float64
			marketDates  []date.Date
			marketValues []float64
			d            date.Date
			lookback     int
		}{
			"no shared date within lookback": {
				proxyDates:   []date.Date{date.New(2024, 1, 1)},
				proxyValues:  []float64{100.0},
				marketDates:  []date.Date{date.New(2024, 1, 5)},
				marketValues: []float64{200.0},
				d:            date.New(2024, 1, 5),
				lookback:     2,
			},
			"both empty": {
				d:        date.New(2024, 1, 1),
				lookback: 5,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				proxy := buildTS(tc.proxyDates, tc.proxyValues)
				market := buildTS(tc.marketDates, tc.marketValues)

				_, ok := priceAtBothSync(proxy, market, tc.d, tc.lookback)

				assert.False(t, ok)
			})
		}
	})
}

func Test_buildNAVLookup(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		nav  *marketdata.Timeseries
		want map[biz.Date]float64
	}{
		"all valid": {
			nav: buildTS(
				[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
				[]float64{100.0, 101.0},
			),
			want: map[biz.Date]float64{
				biz.At(date.New(2024, 1, 1)): 100.0,
				biz.At(date.New(2024, 1, 8)): 101.0,
			},
		},
		"skip NaN entries": {
			nav: buildTS(
				[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
				[]float64{math.NaN(), 101.0},
			),
			want: map[biz.Date]float64{
				biz.At(date.New(2024, 1, 8)): 101.0,
			},
		},
		"skip non-positive entries": {
			nav: buildTS(
				[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8), date.New(2024, 1, 15)},
				[]float64{0.0, -1.0, 102.0},
			),
			want: map[biz.Date]float64{
				biz.At(date.New(2024, 1, 15)): 102.0,
			},
		},
		"weekend NAV shifted to next business day": {
			// Sept 30 2023 is a Saturday. Quarter-end NAVs frequently land
			// on weekends; biz.AtOrAfter shifts them forward to Monday.
			nav: buildTS(
				[]date.Date{date.New(2023, 9, 30)},
				[]float64{100.0},
			),
			want: map[biz.Date]float64{
				biz.AtOrAfter(date.New(2023, 9, 30)): 100.0,
			},
		},
		"business day NAV preferred over shifted Saturday on same Monday": {
			// 2023-09-30 (Sat) shifts to 2023-10-02 (Mon). 2023-10-02
			// already has its own NAV. The Monday entry must win.
			nav: buildTS(
				[]date.Date{date.New(2023, 9, 30), date.New(2023, 10, 2)},
				[]float64{100.0, 200.0},
			),
			want: map[biz.Date]float64{
				biz.At(date.New(2023, 10, 2)): 200.0,
			},
		},
		"business day NAV preferred over shifted Sunday on same Monday": {
			// 2023-10-01 (Sun) shifts to 2023-10-02 (Mon). 2023-10-02
			// already has its own NAV. The Monday entry must win.
			nav: buildTS(
				[]date.Date{date.New(2023, 10, 1), date.New(2023, 10, 2)},
				[]float64{150.0, 200.0},
			),
			want: map[biz.Date]float64{
				biz.At(date.New(2023, 10, 2)): 200.0,
			},
		},
		"weekend NAVs colliding on same Monday first wins": {
			// 2023-09-30 (Sat) and 2023-10-01 (Sun) both shift to
			// 2023-10-02 (Mon). Neither is a business day, so the
			// earlier entry (Sat, 100.0) wins.
			nav: buildTS(
				[]date.Date{date.New(2023, 9, 30), date.New(2023, 10, 1)},
				[]float64{100.0, 150.0},
			),
			want: map[biz.Date]float64{
				biz.AtOrAfter(date.New(2023, 9, 30)): 100.0,
			},
		},
		"empty timeseries": {
			nav:  &marketdata.Timeseries{},
			want: map[biz.Date]float64{},
		},
		"nil timeseries": {
			nav:  nil,
			want: map[biz.Date]float64{},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.want, buildNAVLookup(tc.nav))
		})
	}
}

func Test_buildMondayNAVGrid(t *testing.T) {
	t.Parallel()

	t.Run("includes Mondays in range", func(t *testing.T) {
		t.Parallel()

		// 2024-01-01 is a Monday. Range covers two weeks.
		grid := buildMondayNAVGrid(date.New(2024, 1, 1), date.New(2024, 1, 14), nil)

		require.Len(t, grid, 2)
		assert.Equal(t, biz.At(date.New(2024, 1, 1)), grid[0])
		assert.Equal(t, biz.At(date.New(2024, 1, 8)), grid[1])
	})

	t.Run("includes weekend NAV shifted to next business day", func(t *testing.T) {
		t.Parallel()

		// 2023-09-30 is a Saturday quarter-end NAV. It must appear in the
		// grid shifted forward to Monday 2023-10-02 (preserving the NAV).
		nav := buildTS(
			[]date.Date{date.New(2023, 9, 30)},
			[]float64{100.0},
		)
		grid := buildMondayNAVGrid(date.New(2023, 9, 25), date.New(2023, 10, 6), nav)

		assert.Contains(t, grid, biz.AtOrAfter(date.New(2023, 9, 30)))
	})

	t.Run("nil nav produces only Mondays", func(t *testing.T) {
		t.Parallel()

		grid := buildMondayNAVGrid(date.New(2024, 1, 1), date.New(2024, 1, 14), nil)

		for _, d := range grid {
			assert.Equal(t, time.Monday, d.Weekday())
		}
	})

	t.Run("from advances to next Monday when not already one", func(t *testing.T) {
		t.Parallel()

		// 2024-01-03 is a Wednesday; anchor must advance to Monday 2024-01-08.
		grid := buildMondayNAVGrid(date.New(2024, 1, 3), date.New(2024, 1, 14), nil)

		require.NotEmpty(t, grid)
		assert.Equal(t, biz.At(date.New(2024, 1, 8)), grid[0])
	})

	t.Run("NAV on Sunday merges with Monday already in grid", func(t *testing.T) {
		t.Parallel()

		// 2024-01-07 is a Sunday; biz.AtOrAfter shifts it to Monday 2024-01-08
		// which is already a Monday in the grid. The merge must dedupe to a
		// single entry.
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 7)},
			[]float64{100.0},
		)
		grid := buildMondayNAVGrid(date.New(2024, 1, 1), date.New(2024, 1, 14), nav)

		count := 0

		for _, d := range grid {
			if d.Equal(biz.At(date.New(2024, 1, 8))) {
				count++
			}
		}

		assert.Equal(t, 1, count)
	})

	t.Run("NAV after last Monday is appended to grid", func(t *testing.T) {
		t.Parallel()

		// Range covers Monday 2024-01-01 only. NAV on 2024-01-10 (Wed) is
		// after the last Monday, so the merge must drain the NAV stream.
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 10)},
			[]float64{100.0},
		)
		grid := buildMondayNAVGrid(date.New(2024, 1, 1), date.New(2024, 1, 7), nav)

		assert.Contains(t, grid, biz.At(date.New(2024, 1, 10)))
	})
}

func Test_findFirstValidGridPoint(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			grid    []biz.Date
			proxy   *marketdata.Timeseries
			market  *marketdata.Timeseries
			wantIdx int
		}{
			"first grid point resolves": {
				grid: []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				proxy: buildTS(
					[]date.Date{date.New(2024, 1, 1)},
					[]float64{100.0},
				),
				market: buildTS(
					[]date.Date{date.New(2024, 1, 1)},
					[]float64{200.0},
				),
				wantIdx: 0,
			},
			"second grid point resolves": {
				grid: []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				proxy: buildTS(
					[]date.Date{date.New(2024, 1, 8)},
					[]float64{100.0},
				),
				market: buildTS(
					[]date.Date{date.New(2024, 1, 8)},
					[]float64{200.0},
				),
				wantIdx: 1,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, ok := findFirstValidGridPoint(tc.grid, tc.proxy, tc.market)

				require.True(t, ok)
				assert.Equal(t, tc.wantIdx, got)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			grid   []biz.Date
			proxy  *marketdata.Timeseries
			market *marketdata.Timeseries
		}{
			"empty grid": {
				grid:   []biz.Date{},
				proxy:  &marketdata.Timeseries{},
				market: &marketdata.Timeseries{},
			},
			"no shared date within lookback": {
				grid: []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				proxy: buildTS(
					[]date.Date{date.New(2023, 12, 1)},
					[]float64{100.0},
				),
				market: buildTS(
					[]date.Date{date.New(2023, 12, 1)},
					[]float64{200.0},
				),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, ok := findFirstValidGridPoint(tc.grid, tc.proxy, tc.market)

				assert.False(t, ok)
			})
		}
	})
}

func Test_findNAVReference(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			grid       []biz.Date
			firstValid int
			navValues  map[biz.Date]float64
			wantValue  float64
		}{
			"NAV on first grid point": {
				grid:       []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				firstValid: 0,
				navValues: map[biz.Date]float64{
					biz.At(date.New(2024, 1, 1)): 100.0,
				},
				wantValue: 100.0,
			},
			"NAV on later grid point": {
				grid:       []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8)), biz.At(date.New(2024, 1, 15))},
				firstValid: 0,
				navValues: map[biz.Date]float64{
					biz.At(date.New(2024, 1, 15)): 102.0,
				},
				wantValue: 102.0,
			},
			"start search from firstValid": {
				grid:       []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8)), biz.At(date.New(2024, 1, 15))},
				firstValid: 1,
				navValues: map[biz.Date]float64{
					biz.At(date.New(2024, 1, 1)):  100.0,
					biz.At(date.New(2024, 1, 15)): 102.0,
				},
				wantValue: 102.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, ok := findNAVReference(tc.grid, tc.firstValid, tc.navValues)

				require.True(t, ok)
				assert.InDelta(t, tc.wantValue, got, 1e-15)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			grid       []biz.Date
			firstValid int
			navValues  map[biz.Date]float64
		}{
			"empty NAV map": {
				grid:       []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				firstValid: 0,
				navValues:  map[biz.Date]float64{},
			},
			"NAV exists only before firstValid": {
				grid:       []biz.Date{biz.At(date.New(2024, 1, 1)), biz.At(date.New(2024, 1, 8))},
				firstValid: 1,
				navValues: map[biz.Date]float64{
					biz.At(date.New(2024, 1, 1)): 100.0,
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, ok := findNAVReference(tc.grid, tc.firstValid, tc.navValues)

				assert.False(t, ok)
			})
		}
	})
}

func Test_AlignWeekly(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		priceDates := businessDays(date.New(2024, 1, 1), date.New(2024, 1, 29))
		proxyVals := make([]float64, len(priceDates))

		marketVals := make([]float64, len(priceDates))
		for i := range priceDates {
			proxyVals[i] = 100.0 + float64(i)
			marketVals[i] = 200.0 + float64(i)
		}

		proxy := buildTS(priceDates, proxyVals)
		market := buildTS(priceDates, marketVals)
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 12), date.New(2024, 1, 26)},
			[]float64{1000, 1050},
		)

		got, err := AlignWeekly(proxy, market, nav, date.New(2024, 1, 1), date.New(2024, 1, 30))
		require.NoError(t, err)

		require.Len(t, got.Dates, 6)
		assert.Equal(t, date.New(2024, 1, 8), got.Dates[0])
		assert.Equal(t, date.New(2024, 1, 12), got.Dates[1])
		assert.Equal(t, date.New(2024, 1, 26), got.Dates[4])

		assert.True(t, math.IsNaN(got.LogNAV[0]))
		assert.InDelta(t, 0.0, got.LogNAV[1], 1e-10)
		assert.InDelta(t, math.Log(1050.0/1000.0), got.LogNAV[4], 1e-10)
	})

	t.Run("error on insufficient range", func(t *testing.T) {
		t.Parallel()

		empty := &marketdata.Timeseries{}
		_, err := AlignWeekly(empty, empty, empty, date.New(2024, 1, 6), date.New(2024, 1, 8))
		require.Error(t, err)
	})

	t.Run("error on no valid grid point", func(t *testing.T) {
		t.Parallel()

		// Grid in 2024 but proxy/market data is way back in 2020,
		// so no grid point can resolve to valid prices.
		proxy := buildTS(
			[]date.Date{date.New(2020, 1, 1)},
			[]float64{100.0},
		)
		market := buildTS(
			[]date.Date{date.New(2020, 1, 1)},
			[]float64{200.0},
		)
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 1)},
			[]float64{100.0},
		)

		_, err := AlignWeekly(proxy, market, nav, date.New(2024, 1, 1), date.New(2024, 2, 1))

		require.Error(t, err)
	})

	t.Run("error on no NAV on grid", func(t *testing.T) {
		t.Parallel()

		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
			[]float64{100.0, 101.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
			[]float64{200.0, 202.0},
		)

		_, err := AlignWeekly(proxy, market, &marketdata.Timeseries{}, date.New(2024, 1, 1), date.New(2024, 1, 8))

		require.Error(t, err)
	})

	t.Run("skip grid points where prices do not resolve", func(t *testing.T) {
		t.Parallel()

		// Three Mondays in the grid. Proxy has data only on the first
		// and third Mondays (gap of 14 days exceeds the 5-day lookback
		// for the middle Monday). Market has data on all three.
		// Expect: middle Monday is skipped, output has 1 return entry
		// (third Monday, anchored against first).
		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 15)},
			[]float64{100.0, 102.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8), date.New(2024, 1, 15)},
			[]float64{200.0, 201.0, 202.0},
		)
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 1)},
			[]float64{100.0},
		)

		got, err := AlignWeekly(proxy, market, nav, date.New(2024, 1, 1), date.New(2024, 1, 15))

		require.NoError(t, err)
		require.Len(t, got.Dates, 1)
		assert.Equal(t, date.New(2024, 1, 15), got.Dates[0])
	})

	t.Run("NAV remapped to next valid grid point", func(t *testing.T) {
		t.Parallel()

		// Grid: Mondays 1, 8, 15 January.
		// NAV is on January 8, but proxy/market do not resolve on January 8
		// because proxy data is missing in that whole 5-day lookback window.
		// Expectation: NAV's value is remapped to grid[2] = January 15.
		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 15)},
			[]float64{100.0, 102.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 15)},
			[]float64{200.0, 202.0},
		)
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
			[]float64{100.0, 110.0},
		)

		got, err := AlignWeekly(proxy, market, nav, date.New(2024, 1, 1), date.New(2024, 1, 15))

		require.NoError(t, err)
		require.Len(t, got.Dates, 1)
		assert.Equal(t, date.New(2024, 1, 15), got.Dates[0])

		// LogNAV at grid[2] should reflect the NAV originally on January 8
		// (value 110), not NaN.
		assert.False(t, math.IsNaN(got.LogNAV[0]))
		assert.InDelta(t, math.Log(110.0/100.0), got.LogNAV[0], 1e-15)
	})
}

func Test_pendingNAV(t *testing.T) {
	t.Parallel()

	t.Run("take without set returns false", func(t *testing.T) {
		t.Parallel()

		var p pendingNAV

		_, ok := p.take()

		assert.False(t, ok)
	})

	t.Run("set then take returns value once", func(t *testing.T) {
		t.Parallel()

		var p pendingNAV
		p.set(100.0)

		v, ok := p.take()

		require.True(t, ok)
		assert.InDelta(t, 100.0, v, 1e-15)

		_, ok = p.take()

		assert.False(t, ok)
	})

	t.Run("set overwrites previous pending", func(t *testing.T) {
		t.Parallel()

		var p pendingNAV
		p.set(100.0)
		p.set(110.0)

		v, ok := p.take()

		require.True(t, ok)
		assert.InDelta(t, 110.0, v, 1e-15)
	})
}

func Test_computeWeeklyReturn(t *testing.T) {
	t.Parallel()

	prev := syncedPrices{ProxyPrice: 100.0, MarketPrice: 200.0}
	curr := syncedPrices{ProxyPrice: 102.0, MarketPrice: 204.0}

	proxy, market := computeWeeklyReturn(prev, curr)

	assert.InDelta(t, math.Log(102.0/100.0), proxy, 1e-15)
	assert.InDelta(t, math.Log(204.0/200.0), market, 1e-15)
}

func Test_mondaysSeq(t *testing.T) {
	t.Parallel()

	t.Run("yields all Mondays in range", func(t *testing.T) {
		t.Parallel()

		got := make([]biz.Date, 0)
		for d := range mondaysSeq(date.New(2024, 1, 1), date.New(2024, 1, 14)) {
			got = append(got, d)
		}

		require.Len(t, got, 2)
		assert.Equal(t, biz.At(date.New(2024, 1, 1)), got[0])
		assert.Equal(t, biz.At(date.New(2024, 1, 8)), got[1])
	})

	t.Run("early exit via break stops the sequence", func(t *testing.T) {
		t.Parallel()

		got := make([]biz.Date, 0)
		for d := range mondaysSeq(date.New(2024, 1, 1), date.New(2024, 1, 28)) {
			got = append(got, d)

			break
		}

		assert.Len(t, got, 1)
	})
}

func Test_navDatesSeq(t *testing.T) {
	t.Parallel()

	t.Run("nil input yields nothing", func(t *testing.T) {
		t.Parallel()

		got := make([]biz.Date, 0)
		for d := range navDatesSeq(nil) {
			got = append(got, d)
		}

		assert.Empty(t, got)
	})

	t.Run("yields shifted NAV dates", func(t *testing.T) {
		t.Parallel()

		// 2024-01-06 is a Saturday; biz.AtOrAfter shifts it to Monday
		// 2024-01-08. 2024-01-15 is the following Monday and is left
		// in place. Two distinct entries, no collapsing.
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 6), date.New(2024, 1, 15)},
			[]float64{100.0, 101.0},
		)

		got := make([]biz.Date, 0)
		for d := range navDatesSeq(nav) {
			got = append(got, d)
		}

		require.Len(t, got, 2)
		assert.Equal(t, biz.AtOrAfter(date.New(2024, 1, 6)), got[0])
		assert.Equal(t, biz.AtOrAfter(date.New(2024, 1, 15)), got[1])
	})

	t.Run("early exit via break stops the sequence", func(t *testing.T) {
		t.Parallel()

		nav := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8)},
			[]float64{100.0, 101.0},
		)

		got := make([]biz.Date, 0)
		for d := range navDatesSeq(nav) {
			got = append(got, d)

			break
		}

		assert.Len(t, got, 1)
	})

	t.Run("early exit on later emission stops the sequence", func(t *testing.T) {
		t.Parallel()

		// Three distinct shifted dates. Break after appending the
		// second one, exercising the yield refused path inside the
		// for loop (not the first one before the loop).
		nav := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 8), date.New(2024, 1, 15)},
			[]float64{100.0, 101.0, 102.0},
		)

		got := make([]biz.Date, 0)
		for d := range navDatesSeq(nav) {
			got = append(got, d)

			if len(got) == 2 {
				break
			}
		}

		assert.Len(t, got, 2)
	})

	t.Run("consecutive shifted duplicates collapsed", func(t *testing.T) {
		t.Parallel()

		// 2023-09-30 (Sat) and 2023-10-01 (Sun) both shift forward to
		// 2023-10-02 (Mon). The sequence must yield Monday only once.
		nav := buildTS(
			[]date.Date{date.New(2023, 9, 30), date.New(2023, 10, 1)},
			[]float64{100.0, 150.0},
		)

		got := make([]biz.Date, 0)
		for d := range navDatesSeq(nav) {
			got = append(got, d)
		}

		require.Len(t, got, 1)
		assert.Equal(t, biz.AtOrAfter(date.New(2023, 9, 30)), got[0])
	})
}

func Test_mondaysUpperBound(t *testing.T) {
	t.Parallel()

	t.Run("from before to gives weeks plus margin", func(t *testing.T) {
		t.Parallel()

		// Two weeks span: 14/7 + 2 = 4.
		assert.Equal(t, 4, mondaysUpperBound(date.New(2024, 1, 1), date.New(2024, 1, 15)))
	})

	t.Run("from equal to gives 1", func(t *testing.T) {
		t.Parallel()

		assert.Equal(t, 1, mondaysUpperBound(date.New(2024, 1, 1), date.New(2024, 1, 1)))
	})

	t.Run("from after to returns 1", func(t *testing.T) {
		t.Parallel()

		assert.Equal(t, 1, mondaysUpperBound(date.New(2024, 1, 8), date.New(2024, 1, 1)))
	})
}

func Test_isValidNAV(t *testing.T) {
	t.Parallel()

	t.Run("positive value is valid", func(t *testing.T) {
		t.Parallel()

		assert.True(t, isValidNAV(100.0))
	})

	t.Run("zero is not valid", func(t *testing.T) {
		t.Parallel()

		assert.False(t, isValidNAV(0.0))
	})

	t.Run("negative is not valid", func(t *testing.T) {
		t.Parallel()

		assert.False(t, isValidNAV(-1.0))
	})

	t.Run("NaN is not valid", func(t *testing.T) {
		t.Parallel()

		assert.False(t, isValidNAV(math.NaN()))
	})
}

func Test_writeIfAbsent(t *testing.T) {
	t.Parallel()

	t.Run("writes when key absent", func(t *testing.T) {
		t.Parallel()

		m := map[biz.Date]float64{}
		key := biz.At(date.New(2024, 1, 8))

		writeIfAbsent(m, key, 100.0)

		assert.InDelta(t, 100.0, m[key], 1e-15)
	})

	t.Run("does not overwrite existing", func(t *testing.T) {
		t.Parallel()

		key := biz.At(date.New(2024, 1, 8))
		m := map[biz.Date]float64{key: 100.0}

		writeIfAbsent(m, key, 200.0)

		assert.InDelta(t, 100.0, m[key], 1e-15)
	})
}
