//go:build local

// Local rolling-window SSM pipeline test.
//
// For each (asset, as_of_date) pair, runs the production SSM pipeline and
// records only direct production output: SSM parameters, OLS estimates,
// likelihood, calibration diagnostics, and output series properties.
//
// No test-side window / vol / correlation diagnostics — those are downstream
// consumer concerns, not pipeline correctness signals. Earlier versions of
// this test emitted weekly/daily vols and correlations on arbitrary tail
// windows; those columns have been removed.
//
// Pipeline call path is identical to production
// (internal/service/v1/provider.go on main, post-PR-819):
//
//     calibFrom := asOf - calibrationWeeks*7 days       // 1428 weeks
//     mapping   := privateAssetMappingFetcher.Fetch(id)
//     nav       := provider.FetchSpotTimeseries(PrivateAsset, id,                 calibFrom, asOf)
//     idio      := provider.FetchSpotTimeseries(Fund,         IdiosyncraticProxyID, calibFrom, asOf)
//     market    := provider.FetchSpotTimeseries(Index,        MarketProxyID,        calibFrom, asOf)
//     config    := nowcasting.SSMConfigForFundType(mapping.FundType)
//     prices, ssmOut, _ := nowcasting.RunPipeline(nav, idio, market, config)
//
// The full input history is fetched once per asset and sliced per as_of for
// performance; the slicing uses exactly the same [calibFrom, asOf] window
// production computes.
//
// Env vars:
//   SSM_ROLLING_START  YYYY-MM-DD (e.g. 2006-01-31). REQUIRED.
//   SSM_ROLLING_END    YYYY-MM-DD (e.g. 2026-02-28). REQUIRED.
//   SSM_OUTPUT_DIR     output root (default ~/Desktop/cerberus_extract).
//   SSM_ASSETS         comma-separated asset labels to filter (optional).
//   SSM_WORKERS        worker count (default = max(2, NumCPU - 2)).
//
// Outputs land under <SSM_OUTPUT_DIR>/rolling/{stats,params}/.

package nowcasting

import (
	"context"
	"encoding/csv"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/gapfilling"
	"github.com/stretchr/testify/require"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
)

var pipelineErrOnce sync.Once

func TestLocalRolling(t *testing.T) {
	rollStartStr := os.Getenv("SSM_ROLLING_START")
	rollEndStr := os.Getenv("SSM_ROLLING_END")
	if rollStartStr == "" || rollEndStr == "" {
		t.Skip("Set SSM_ROLLING_START and SSM_ROLLING_END (YYYY-MM-DD) to run")
	}
	rollStart, err := time.Parse("2006-01-02", rollStartStr)
	require.NoError(t, err, "parse SSM_ROLLING_START")
	rollEnd, err := time.Parse("2006-01-02", rollEndStr)
	require.NoError(t, err, "parse SSM_ROLLING_END")

	asOfDates := biweeklyAsOfDates(rollStart, rollEnd)

	workers := runtime.NumCPU() - 2
	if workers < 2 {
		workers = 2
	}
	if w := os.Getenv("SSM_WORKERS"); w != "" {
		if n, err := strconv.Atoi(w); err == nil && n > 0 {
			workers = n
		}
	}

	outDir := resolveOutputDir(t)
	rollDir := filepath.Join(outDir, "rolling")
	statsDir := filepath.Join(rollDir, "stats")
	paramsDir := filepath.Join(rollDir, "params")
	require.NoError(t, os.MkdirAll(statsDir, 0o755))
	require.NoError(t, os.MkdirAll(paramsDir, 0o755))

	allMappings := loadMappingRows(t)

	if filter := os.Getenv("SSM_ASSETS"); filter != "" {
		wanted := make(map[string]bool)
		for _, a := range strings.Split(filter, ",") {
			wanted[strings.TrimSpace(a)] = true
		}
		var filtered []mappingRow
		for _, m := range allMappings {
			if wanted[m.label] {
				filtered = append(filtered, m)
			}
		}
		allMappings = filtered
		t.Logf("Filtered to %d assets via SSM_ASSETS env var", len(allMappings))
	}

	totalRuns := len(allMappings) * len(asOfDates)
	t.Logf("Rolling: %d assets x %d as_of dates = %d total runs",
		len(allMappings), len(asOfDates), totalRuns)
	t.Logf("Workers: %d (NumCPU=%d)", workers, runtime.NumCPU())
	t.Logf("Range: %s to %s", rollStart.Format("2006-01-02"), rollEnd.Format("2006-01-02"))
	t.Logf("Pipeline: production nowcasting.RunPipeline (identical to fetchSpotTimeseriesWithSSMPipeline path on main)")

	statsFile, err := os.Create(filepath.Join(statsDir, "rolling_stats_by_asset.csv"))
	require.NoError(t, err)
	defer statsFile.Close()
	paramsFile, err := os.Create(filepath.Join(paramsDir, "rolling_params_by_asset.csv"))
	require.NoError(t, err)
	defer paramsFile.Close()

	statsW := csv.NewWriter(statsFile)
	paramsW := csv.NewWriter(paramsFile)
	defer statsW.Flush()
	defer paramsW.Flush()
	require.NoError(t, statsW.Write(rollingStatsHeader()))
	require.NoError(t, paramsW.Write(rollingParamsHeader()))

	var writeMu sync.Mutex
	writeStats := func(row []string) {
		writeMu.Lock()
		statsW.Write(row)
		writeMu.Unlock()
	}
	writeParams := func(row []string) {
		writeMu.Lock()
		paramsW.Write(row)
		writeMu.Unlock()
	}

	client, err := cerberus.NewClient(&cerberus.Config{
		Host:    cerberusHost,
		Timeout: cerberusTimeout,
		Retry:   3,
	})
	require.NoError(t, err)

	// Production mapping fetcher (same one production wires up). The
	// per-asset Fetch call below uses this.
	fetcher := newMappingFetcher(t)

	// --- SPY pre-fetch for beta(r*, S&P 500) ---
	// SPY UUID hardcoded: S&P 500 (SPY) from Cerberus, verified working.
	// Do not take from mapping — broad_uuid may change (e.g., JPM S&P 500 SPXT).
	spyUUID := "b1591cc0-f9ff-4255-99b8-d34cd4678391"
	t.Logf("SPY UUID: %s", spyUUID)
	spyCtx, spyCancel := context.WithTimeout(context.Background(), 60*time.Second)
	spyFull, spyErr := client.FetchSpotTimeseries(
		spyCtx, marketdata.Index, spyUUID,
		time.Date(1978, 1, 1, 0, 0, 0, 0, time.UTC), rollEnd,
	)
	spyCancel()
	require.NoError(t, spyErr, "failed to fetch SPY")
	t.Logf("SPY: %d entries, %s to %s",
		spyFull.NumEntries(), spyFull.At(0).Date, spyFull.Last().Date)

	var (
		completed    int64
		failedFetch  int64
		pipelineErrs int64
	)

	type assetJob struct {
		mapping mappingRow
	}

	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			done := atomic.LoadInt64(&completed)
			if done >= int64(totalRuns) {
				return
			}
			pct := float64(done) / float64(totalRuns) * 100
			t.Logf("Progress: %d/%d (%.1f%%) failedFetch=%d pipelineErr=%d",
				done, totalRuns, pct,
				atomic.LoadInt64(&failedFetch),
				atomic.LoadInt64(&pipelineErrs))
		}
	}()

	start := time.Now()

	jobs := make(chan assetJob, len(allMappings))
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			for job := range jobs {
				// Resolve mapping via production fetcher (sanity check that
				// this asset id can be resolved by the production code path).
				mapping, mapErr := fetcher.Fetch(job.mapping.navUUID)
				if mapErr != nil {
					atomic.AddInt64(&failedFetch, 1)
					atomic.AddInt64(&completed, int64(len(asOfDates)))
					continue
				}

				// Pre-fetch full history once for this asset. Production fetch
				// types: PrivateAsset / Fund / Index (same as
				// fetchSpotTimeseriesWithSSMPipeline). Window is from 1978-01-01
				// (effectively "all available") through rollEnd. Per-as_of we
				// slice in-memory to [asOf - calibrationWeeks*7, asOf].
				ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
				fetchFrom := time.Date(1978, 1, 1, 0, 0, 0, 0, time.UTC)
				nav, err1 := client.FetchSpotTimeseries(ctx, marketdata.PrivateAsset, job.mapping.navUUID, fetchFrom, rollEnd)
				idio, err2 := client.FetchSpotTimeseries(ctx, marketdata.Fund, mapping.IdiosyncraticProxyID, fetchFrom, rollEnd)
				mkt, err3 := client.FetchSpotTimeseries(ctx, marketdata.Index, mapping.MarketProxyID, fetchFrom, rollEnd)
				cancel()
				if err1 != nil || err2 != nil || err3 != nil {
					atomic.AddInt64(&failedFetch, 1)
					atomic.AddInt64(&completed, int64(len(asOfDates)))
					continue
				}
				if idio == nil || idio.IsEmpty() || mkt == nil || mkt.IsEmpty() {
					atomic.AddInt64(&completed, int64(len(asOfDates)))
					continue
				}
				config := SSMConfigForFundType(mapping.FundType)
				pre := &preAsset{nav: nav, idio: idio, mkt: mkt, spy: spyFull}

				for _, asOf := range asOfDates {
					statsRow, paramsRow, status := runRollingFast(job.mapping, asOf, pre, config)
					atomic.AddInt64(&completed, 1)
					if status == rollingStatusPipelineError {
						atomic.AddInt64(&pipelineErrs, 1)
					}
					writeStats(statsRow)
					writeParams(paramsRow)
				}
			}
		}(w)
	}

	for _, m := range allMappings {
		jobs <- assetJob{mapping: m}
	}
	close(jobs)
	wg.Wait()

	elapsed := time.Since(start)
	t.Logf("")
	t.Logf("============================================================")
	t.Logf("DONE — %d/%d runs completed", atomic.LoadInt64(&completed), totalRuns)
	t.Logf("  pipeline errors:    %d", atomic.LoadInt64(&pipelineErrs))
	t.Logf("  failed fetches:     %d", atomic.LoadInt64(&failedFetch))
	t.Logf("  total elapsed:      %s", elapsed)
	if totalRuns > 0 {
		t.Logf("  avg per run:        %.2f ms", float64(elapsed.Milliseconds())/float64(totalRuns))
	}
	t.Logf("============================================================")
	t.Logf("Wrote %s", filepath.Join(statsDir, "rolling_stats_by_asset.csv"))
	t.Logf("Wrote %s", filepath.Join(paramsDir, "rolling_params_by_asset.csv"))
}

// preAsset holds the fully-fetched input series for one asset, before
// per-as_of slicing.
type preAsset struct {
	nav  *marketdata.Timeseries
	idio *marketdata.Timeseries
	mkt  *marketdata.Timeseries
	spy  *marketdata.Timeseries // S&P 500 (SPY) for cross-benchmark beta
}

// truncateTimeseries returns the slice of `ts` that production
// fetchSpotTimeseriesWithSSMPipeline would see at the given as-of date:
//
//	calibFrom := asOf - calibrationWeeks*7 days
//	provider.FetchSpotTimeseries(..., calibFrom, asOf)
func truncateTimeseries(ts *marketdata.Timeseries, asOf time.Time) *marketdata.Timeseries {
	if ts == nil {
		return nil
	}
	asOfStr := asOf.Format("2006-01-02")
	calibFromStr := asOf.AddDate(0, 0, -calibrationWeeks*7).Format("2006-01-02")
	out := &marketdata.Timeseries{ID: ts.ID, Type: ts.Type}
	for _, e := range ts.Entries {
		ds := e.Date.String()
		if ds >= calibFromStr && ds <= asOfStr {
			out.Entries = append(out.Entries, e)
		}
	}
	return out
}

type rollingStatus int

const (
	rollingStatusOK rollingStatus = iota
	rollingStatusPipelineError
)

// runRollingFast executes one (asset, as_of) iteration. Same code path as
// production: truncate to calibration window, then nowcasting.RunPipeline.
// If pipeline returns an error, the error is recorded in the stats CSV's
// `error` column and an empty params row is emitted.
func runRollingFast(m mappingRow, asOf time.Time, pre *preAsset, config gapfilling.SSMConfig) ([]string, []string, rollingStatus) {
	asOfStr := asOf.Format("2006-01-02")

	// Initialise derived metrics with NaN so that when the pipeline errors
	// (3 525 rows in the 20-year backtest are expected to fail with
	// "need 156 weeks") the downstream aggregator can drop them. If we left
	// them at the Go zero value (0.0) they would be counted as legitimate
	// observations and pull medians towards zero, producing the flat-at-zero
	// artefact in 2007-2010 in the previous chart pass.
	nan := math.NaN()
	sr := rollingStatsRow{
		ticker: m.label, fundCat: m.fundType, asOf: asOfStr,
		wkAnnVol: nan, dyAnnVol: nan,
		wkMktAnnVol: nan, dyMktAnnVol: nan,
		wkPrxAnnVol: nan, dyPrxAnnVol: nan,
		wkCorrRstarMkt: nan, dyCorrRstarMkt: nan,
		wkCorrRstarPrx: nan, dyCorrRstarPrx: nan,
		wkCorrPrxMkt: nan, dyCorrPrxMkt: nan,
		wkCorrRstarSPY: nan, wkSPYAnnVol: nan, betaRstarSPY: nan,
	}
	pr := rollingParamsRow{
		ticker: m.label, fundCat: m.fundType, asOf: asOfStr,
		alphaOLS: nan, betaOLS: nan,
		alphaOLSRaw: nan, betaOLSRaw: nan,
		alpha: nan, beta: nan, lambda: nan, psi: nan,
		f: nan, sigmaNAV: nan, fc: nan, betaC: nan,
		chowlinMktCoeff: nan, chowlinPrxCoeff: nan, chowlinIntercept: nan,
		negLogLik: nan, navFrac: nan,
	}

	navTrunc := truncateTimeseries(pre.nav, asOf)
	idioTrunc := truncateTimeseries(pre.idio, asOf)
	mktTrunc := truncateTimeseries(pre.mkt, asOf)

	if idioTrunc.IsEmpty() || mktTrunc.IsEmpty() {
		sr.errorMsg = "empty input series"
		return sr.toCSV(), pr.toCSV(), rollingStatusPipelineError
	}

	// Production pipeline call.
	var (
		prices *marketdata.Timeseries
		out    gapfilling.SSMOutput
		runErr error
	)
	func() {
		defer func() {
			if r := recover(); r != nil {
				runErr = fmt.Errorf("panic: %v", r)
			}
		}()
		prices, out, runErr = RunPipeline(navTrunc, idioTrunc, mktTrunc, config)
	}()
	if runErr != nil {
		pipelineErrOnce.Do(func() {
			fmt.Printf("[PIPELINE ERROR] asset=%s as_of=%s err=%v\n", m.label, asOfStr, runErr)
		})
		sr.errorMsg = runErr.Error()
		return sr.toCSV(), pr.toCSV(), rollingStatusPipelineError
	}

	// Diagnostics from production output.
	sr.calibNavCnt = out.Diagnostics.NAVObservationCount
	sr.nWeeks = out.Diagnostics.CalibrationWeeks
	sr.nNavObs = out.Diagnostics.NAVObservationCount

	pr.calibNavCnt = out.Diagnostics.NAVObservationCount
	pr.calibDays = out.Diagnostics.CalibrationWeeks * 7
	pr.navFrac = out.Diagnostics.NAVObservationFraction

	// Output series properties from production prices.
	if prices != nil && prices.NumEntries() > 0 {
		sr.numPrices = prices.NumEntries()
		sr.firstPriceDate = prices.At(0).Date.String()
		sr.lastPriceDate = prices.Last().Date.String()
		sr.firstPrice = prices.At(0).Value
		sr.lastPrice = prices.Last().Value
		sr.maxDailyMovePct = maxDailyMovePct(prices)
	}

	// SSM parameters from production output.
	pr.alphaOLS = out.AlphaOLS
	pr.betaOLS = out.BetaOLS
	pr.alphaOLSRaw = out.Diagnostics.AlphaOLSRaw
	pr.betaOLSRaw = out.Diagnostics.BetaOLSRaw
	pr.alphaOLSClamped = out.Diagnostics.AlphaOLSClamped
	pr.betaOLSClamped = out.Diagnostics.BetaOLSClamped
	pr.alpha = out.Params.Alpha
	pr.beta = out.Params.Beta
	pr.lambda = out.Params.Lambda
	pr.psi = out.Params.Psi
	pr.f = out.Params.F
	pr.sigmaNAV = out.Params.SigmaNAV
	pr.fc = out.Params.Fc
	pr.betaC = out.Params.BetaC
	pr.chowlinMktCoeff = out.ChowLinMarketCoeff
	pr.chowlinPrxCoeff = out.ChowLinProxyCoeff
	pr.chowlinIntercept = out.ChowLinIntercept
	pr.negLogLik = out.NegLogLik

	// Derived weekly + daily aggregations on production-output arrays.
	// Replicate alignment locally (same exported function the pipeline uses
	// internally; deterministic given identical inputs).
	idioFrom := idioTrunc.At(0).Date
	idioTo := idioTrunc.Last().Date
	weekly, alignErr := AlignWeekly(idioTrunc, mktTrunc, navTrunc, idioFrom, idioTo)
	if alignErr == nil && len(out.WeeklyRStar) >= 2 {
		rStar := out.WeeklyRStar
		nWk := len(rStar)
		wkProxyOut := tail(weekly.ProxyReturns, nWk)
		wkMarketOut := tail(weekly.MarketReturns, nWk)

		sr.wkAnnVol = annualWeekly(rStar)
		sr.wkMktAnnVol = annualWeekly(wkMarketOut)
		sr.wkPrxAnnVol = annualWeekly(wkProxyOut)
		sr.wkCorrRstarMkt = pearson(rStar, wkMarketOut)
		sr.wkCorrRstarPrx = pearson(rStar, wkProxyOut)
		sr.wkCorrPrxMkt = pearson(wkProxyOut, wkMarketOut)

		// --- beta(r*, S&P 500) ---
		if pre.spy != nil && !pre.spy.IsEmpty() {
			spyTrunc := truncateTimeseries(pre.spy, asOf)
			if spyTrunc != nil && !spyTrunc.IsEmpty() {
				spyFrom := spyTrunc.At(0).Date
				spyTo := spyTrunc.Last().Date
				spyAligned, spyAlignErr := AlignWeekly(spyTrunc, spyTrunc, navTrunc, spyFrom, spyTo)
				if spyAlignErr == nil {
					wkSPY := tail(spyAligned.ProxyReturns, nWk)
					if len(wkSPY) == nWk {
						sr.wkCorrRstarSPY = pearson(rStar, wkSPY)
						sr.wkSPYAnnVol = annualWeekly(wkSPY)
						if sr.wkSPYAnnVol > 0 {
							sr.betaRstarSPY = sr.wkCorrRstarSPY * sr.wkAnnVol / sr.wkSPYAnnVol
						}
					}
				}
			}
		}

		// Daily alignment by date — see local_pipeline_test.go for rationale.
		if prices != nil && prices.NumEntries() >= 2 {
			priceDates := make([]date.Date, prices.NumEntries())
			pricesVals := make([]float64, prices.NumEntries())
			for i := 0; i < prices.NumEntries(); i++ {
				e := prices.At(i)
				priceDates[i] = e.Date
				pricesVals[i] = e.Value
			}
			idioOnGrid := valuesOnGrid(idioTrunc, priceDates)
			mktOnGrid := valuesOnGrid(mktTrunc, priceDates)
			dyRStar := logDiff(pricesVals)
			dyPrx := logDiffSafe(idioOnGrid)
			dyMkt := logDiffSafe(mktOnGrid)

			sr.dyAnnVol = annualDaily(dyRStar)
			sr.dyMktAnnVol = annualDaily(dyMkt)
			sr.dyPrxAnnVol = annualDaily(dyPrx)
			sr.dyCorrRstarMkt = pearson(dyRStar, dyMkt)
			sr.dyCorrRstarPrx = pearson(dyRStar, dyPrx)
			sr.dyCorrPrxMkt = pearson(dyPrx, dyMkt)
		}
	}

	return sr.toCSV(), pr.toCSV(), rollingStatusOK
}

// ---- CSV row types: production output + derived aggregations ----

type rollingStatsRow struct {
	ticker      string
	fundCat     string
	asOf        string
	calibNavCnt int
	nWeeks      int
	nNavObs     int

	// Output series properties.
	numPrices       int
	firstPriceDate  string
	lastPriceDate   string
	firstPrice      float64
	lastPrice       float64
	maxDailyMovePct float64

	// Derived weekly + daily aggregations (computed from production
	// AlignWeekly / AlignDaily / SSMOutput.WeeklyRStar).
	wkAnnVol, dyAnnVol         float64
	wkMktAnnVol, dyMktAnnVol   float64
	wkPrxAnnVol, dyPrxAnnVol   float64
	wkCorrRstarMkt, dyCorrRstarMkt float64
	wkCorrRstarPrx, dyCorrRstarPrx float64
	wkCorrPrxMkt, dyCorrPrxMkt     float64

	// S&P 500 cross-benchmark beta.
	wkCorrRstarSPY float64
	wkSPYAnnVol    float64
	betaRstarSPY   float64

	// Populated only when the production pipeline returned an error for this
	// (asset, as_of); blank otherwise.
	errorMsg string
}

func rollingStatsHeader() []string {
	return []string{
		// identity + diagnostics
		"asset_id", "ticker", "fund_cat", "fund_type", "as_of_date", "as_of",
		"flag_warmup_period",
		"calib_nav_cnt", "calib_nav_count", "n_weeks", "n_nav_obs",
		// output series properties
		"num_prices", "first_price_date", "last_price_date",
		"first_price", "last_price", "max_daily_move_pct",
		// derived weekly + daily aggregations (audit-script column names)
		"wk_ann_vol", "dy_ann_vol",
		"wk_mkt_ann_vol", "dy_mkt_ann_vol",
		"wk_prx_ann_vol", "dy_prx_ann_vol",
		"wk_corr_rstar_mkt", "dy_corr_rstar_mkt",
		"wk_corr_rstar_prx", "dy_corr_rstar_prx",
		"wk_corr_prx_mkt", "dy_corr_prx_mkt",
		// S&P 500 cross-benchmark beta
		"wk_corr_rstar_spy", "wk_spy_ann_vol", "beta_rstar_spy",
		// error
		"error",
	}
}

func (r rollingStatsRow) toCSV() []string {
	f := func(x float64) string { return strconv.FormatFloat(x, 'g', -1, 64) }
	// flag_warmup_period kept as a column for audit-script compatibility; it
	// is always 0 (the test does not classify, RunPipeline errors go to
	// `error`). asset_id / ticker, fund_cat / fund_type, as_of_date / as_of
	// are dual-named for the same reason.
	return []string{
		r.ticker, r.ticker, r.fundCat, r.fundCat, r.asOf, r.asOf,
		"0",
		strconv.Itoa(r.calibNavCnt), strconv.Itoa(r.calibNavCnt), strconv.Itoa(r.nWeeks), strconv.Itoa(r.nNavObs),
		strconv.Itoa(r.numPrices), r.firstPriceDate, r.lastPriceDate,
		f(r.firstPrice), f(r.lastPrice), f(r.maxDailyMovePct),
		f(r.wkAnnVol), f(r.dyAnnVol),
		f(r.wkMktAnnVol), f(r.dyMktAnnVol),
		f(r.wkPrxAnnVol), f(r.dyPrxAnnVol),
		f(r.wkCorrRstarMkt), f(r.dyCorrRstarMkt),
		f(r.wkCorrRstarPrx), f(r.dyCorrRstarPrx),
		f(r.wkCorrPrxMkt), f(r.dyCorrPrxMkt),
		f(r.wkCorrRstarSPY), f(r.wkSPYAnnVol), f(r.betaRstarSPY),
		r.errorMsg,
	}
}

type rollingParamsRow struct {
	ticker      string
	fundCat     string
	asOf        string
	calibNavCnt int
	calibDays   int

	alphaOLS, betaOLS               float64
	alphaOLSRaw, betaOLSRaw         float64
	alphaOLSClamped, betaOLSClamped bool
	alpha, beta, lambda, psi        float64
	f, sigmaNAV, fc, betaC          float64
	chowlinMktCoeff, chowlinPrxCoeff, chowlinIntercept float64
	negLogLik, navFrac              float64
}

func rollingParamsHeader() []string {
	return []string{
		"ticker", "fund_cat", "as_of",
		"calib_nav_cnt", "calib_days",
		"alpha_ols", "beta_ols",
		"alpha_ols_raw", "beta_ols_raw", "alpha_ols_clamped", "beta_ols_clamped",
		"alpha", "beta", "lambda", "psi",
		"f", "sigma_nav", "fc", "beta_c",
		"neg_log_lik", "nav_frac",
		"chowlin_mkt_coeff", "chowlin_prx_coeff", "chowlin_intercept",
	}
}

func (r rollingParamsRow) toCSV() []string {
	f := func(x float64) string { return strconv.FormatFloat(x, 'g', -1, 64) }
	return []string{
		r.ticker, r.fundCat, r.asOf,
		strconv.Itoa(r.calibNavCnt), strconv.Itoa(r.calibDays),
		f(r.alphaOLS), f(r.betaOLS),
		f(r.alphaOLSRaw), f(r.betaOLSRaw),
		strconv.FormatBool(r.alphaOLSClamped), strconv.FormatBool(r.betaOLSClamped),
		f(r.alpha), f(r.beta), f(r.lambda), f(r.psi),
		f(r.f), f(r.sigmaNAV), f(r.fc), f(r.betaC),
		f(r.negLogLik), f(r.navFrac),
		f(r.chowlinMktCoeff), f(r.chowlinPrxCoeff), f(r.chowlinIntercept),
	}
}

// ---- date helper ----

// monthlyAsOfDates emits the last calendar day of every month in
// [start, end] (clipped at end).
func monthlyAsOfDates(start, end time.Time) []time.Time {
	out := []time.Time{}
	cur := time.Date(start.Year(), start.Month(), 1, 0, 0, 0, 0, time.UTC)
	for !cur.After(end) {
		next := cur.AddDate(0, 1, 0)
		lastDay := next.AddDate(0, 0, -1)
		if lastDay.After(end) {
			lastDay = end
		}
		if !lastDay.Before(start) {
			out = append(out, lastDay)
		}
		cur = next
	}
	return out
}

// biweeklyAsOfDates emits every other Friday in [start, end].
func biweeklyAsOfDates(start, end time.Time) []time.Time {
	out := []time.Time{}
	// Find first Friday on or after start
	cur := start
	for cur.Weekday() != time.Friday {
		cur = cur.AddDate(0, 0, 1)
	}
	for !cur.After(end) {
		if !cur.Before(start) {
			out = append(out, cur)
		}
		cur = cur.AddDate(0, 0, 14) // every 2 weeks
	}
	return out
}
