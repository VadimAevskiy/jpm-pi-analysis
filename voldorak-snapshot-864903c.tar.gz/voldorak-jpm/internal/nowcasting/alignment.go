package nowcasting

import (
	"math"
	"sort"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

const (
	// weeklyPriceLookbackDays is the calendar-day window allowed when looking up a
	// proxy or market price at a weekly grid point, to tolerate short market closures.
	weeklyPriceLookbackDays = 5

	// dailyPriceLookbackDays is the calendar-day window allowed when looking up a
	// price for a daily return.
	dailyPriceLookbackDays = 5
)

// AlignedData holds proxy, market, and (optionally) NAV-derived series
// sharing a common date grid.
type AlignedData struct {
	// Dates is the ordered date grid that all other slices index into.
	Dates []date.Date

	// ProxyReturns are log-returns of the idiosyncratic proxy across consecutive grid points.
	ProxyReturns []float64

	// MarketReturns are log-returns of the broad market index across consecutive grid points.
	MarketReturns []float64

	// LogNAV is log(NAV_t / NAV_ref) at each grid point, NaN where no NAV observation lands. Populated by AlignWeekly only.
	LogNAV []float64

	// SegmentLengths is the number of business days in each weekly segment, used by Chow-Lin. Populated by AlignDaily only.
	SegmentLengths []int
}

// priceAt returns the latest non-NaN, positive price on or before d
// within maxLookback calendar days.
//
// The NaN and non-positive checks are defensive: the marketdata API
// does not enforce non-NaN values, and downstream log-return math
// would propagate NaN if such an entry slipped through.
func priceAt(ts *marketdata.Timeseries, d date.Date, maxLookback int) (float64, bool) {
	if ts.IsEmpty() {
		return 0, false
	}

	idx := sort.Search(ts.NumEntries(), func(i int) bool {
		return ts.At(i).Date.After(d)
	})

	for i := idx - 1; i >= 0; i-- {
		entry := ts.At(i)

		gap := d.Sub(entry.Date)
		if gap > maxLookback {
			return 0, false
		}

		if !math.IsNaN(entry.Value) && entry.Value > 0 {
			return entry.Value, true
		}
	}

	return 0, false
}
