//go:build local

package nowcasting

import (
	"context"
	"encoding/csv"
	"fmt"
	"os"
	"testing"
	"time"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
)

func TestDumpProxyNames(t *testing.T) {
	client, err := cerberus.NewClient(&cerberus.Config{
		Host:    cerberusHost,
		Timeout: cerberusTimeout,
		Retry:   3,
	})
	if err != nil {
		t.Fatal(err)
	}

	mappings := loadMappingRows(t)
	seen := make(map[string]bool)
	w := csv.NewWriter(os.Stdout)
	w.Write([]string{"uuid", "type", "used_by_example", "first_date", "last_date", "n_points"})

	for _, m := range mappings {
		for _, pair := range []struct{ uuid, role string }{
			{m.proxyUUID, "proxy"},
			{m.broadUUID, "broad"},
		} {
			if seen[pair.uuid] {
				continue
			}
			seen[pair.uuid] = true
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			ts, err := client.FetchSpotTimeseries(ctx, marketdata.Fund, pair.uuid,
				time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC),
				time.Date(2020, 1, 31, 0, 0, 0, 0, time.UTC))
			if err != nil {
				ts, err = client.FetchSpotTimeseries(ctx, marketdata.Index, pair.uuid,
					time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC),
					time.Date(2020, 1, 31, 0, 0, 0, 0, time.UTC))
			}
			cancel()
			name := pair.uuid
			fd, ld, np := "", "", "0"
			if err == nil && ts != nil && !ts.IsEmpty() {
				name = ts.ID
				fd = ts.At(0).Date.String()
				ld = ts.Last().Date.String()
				np = fmt.Sprintf("%d", ts.NumEntries())
			}
			w.Write([]string{name, pair.role, m.label, fd, ld, np})
		}
	}
	w.Flush()
}
