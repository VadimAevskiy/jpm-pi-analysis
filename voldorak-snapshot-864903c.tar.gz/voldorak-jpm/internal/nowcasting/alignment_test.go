package nowcasting

import (
	"math"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// buildTS constructs a *marketdata.Timeseries from parallel date/value slices.
func buildTS(dates []date.Date, values []float64) *marketdata.Timeseries {
	entries := make(marketdata.Entries, len(dates))

	for i := range dates {
		entries[i] = &marketdata.Entry{
			Date:  dates[i],
			Value: values[i],
		}
	}

	return &marketdata.Timeseries{Entries: entries}
}

func Test_priceAt(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		ts := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 3), date.New(2024, 1, 5)},
			[]float64{100.0, 101.0, 102.0},
		)

		for name, tc := range map[string]struct {
			d         date.Date
			lookback  int
			wantVal   float64
			wantFound bool
		}{
			"exact match":            {d: date.New(2024, 1, 3), lookback: 5, wantVal: 101.0, wantFound: true},
			"within lookback":        {d: date.New(2024, 1, 4), lookback: 5, wantVal: 101.0, wantFound: true},
			"past last date":         {d: date.New(2024, 1, 6), lookback: 5, wantVal: 102.0, wantFound: true},
			"before first date":      {d: date.New(2023, 12, 31), lookback: 5, wantVal: 0, wantFound: false},
			"beyond lookback":        {d: date.New(2024, 1, 15), lookback: 5, wantVal: 0, wantFound: false},
			"zero lookback exact":    {d: date.New(2024, 1, 3), lookback: 0, wantVal: 101.0, wantFound: true},
			"zero lookback no match": {d: date.New(2024, 1, 4), lookback: 0, wantVal: 0, wantFound: false},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, ok := priceAt(ts, tc.d, tc.lookback)

				assert.Equal(t, tc.wantFound, ok)

				if tc.wantFound {
					assert.InDelta(t, tc.wantVal, got, 1e-15)
				}
			})
		}
	})

	t.Run("skips invalid values", func(t *testing.T) {
		t.Parallel()

		ts := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)},
			[]float64{100.0, math.NaN(), -1.0},
		)

		got, ok := priceAt(ts, date.New(2024, 1, 3), 5)

		require.True(t, ok)
		assert.InDelta(t, 100.0, got, 1e-15)
	})
}

// businessDays is a test helper that returns weekdays in [from, to] inclusive.
func businessDays(from, to date.Date) []date.Date {
	var days []date.Date

	for d := from; !d.After(to); d = d.Add(1) {
		if d.Weekday() == time.Saturday || d.Weekday() == time.Sunday {
			continue
		}

		days = append(days, d)
	}

	return days
}

func Test_businessDays(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		from    date.Date
		to      date.Date
		wantLen int
	}{
		"full week":    {from: date.New(2024, 1, 1), to: date.New(2024, 1, 7), wantLen: 5},
		"single day":   {from: date.New(2024, 1, 3), to: date.New(2024, 1, 3), wantLen: 1},
		"weekend only": {from: date.New(2024, 1, 6), to: date.New(2024, 1, 7), wantLen: 0},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := businessDays(tc.from, tc.to)

			assert.Len(t, got, tc.wantLen)

			for _, d := range got {
				assert.NotEqual(t, time.Saturday, d.Weekday())
				assert.NotEqual(t, time.Sunday, d.Weekday())
			}
		})
	}
}
