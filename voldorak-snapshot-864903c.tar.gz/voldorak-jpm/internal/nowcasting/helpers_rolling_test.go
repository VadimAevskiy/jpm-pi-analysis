//go:build local

package nowcasting

import (
	"math"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// valuesOnGrid maps a Timeseries onto the given date grid.
// Returns NaN for dates not present in ts.
func valuesOnGrid(ts *marketdata.Timeseries, dates []date.Date) []float64 {
	idx := make(map[date.Date]float64, ts.NumEntries())
	for i := 0; i < ts.NumEntries(); i++ {
		e := ts.At(i)
		idx[e.Date] = e.Value
	}
	out := make([]float64, len(dates))
	for i, d := range dates {
		if v, ok := idx[d]; ok {
			out[i] = v
		} else {
			out[i] = math.NaN()
		}
	}
	return out
}

// logDiffSafe computes log-differences, producing NaN where inputs
// are NaN, zero, or negative.
func logDiffSafe(xs []float64) []float64 {
	if len(xs) < 2 {
		return nil
	}
	out := make([]float64, len(xs)-1)
	for i := 1; i < len(xs); i++ {
		if math.IsNaN(xs[i]) || math.IsNaN(xs[i-1]) || xs[i] <= 0 || xs[i-1] <= 0 {
			out[i-1] = math.NaN()
		} else {
			out[i-1] = math.Log(xs[i]) - math.Log(xs[i-1])
		}
	}
	return out
}
