package nowcasting

import (
	"iter"
	"math"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/biz"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	log "github.com/sirupsen/logrus"
)

// AlignWeekly converts daily proxy and market prices plus NAV
// observations into weekly-frequency aligned data on the ordered
// union of Mondays in [from, to] and NAV observation dates.
// Returns are log-returns across consecutive grid points with a
// 5-day lookback; grid points without valid prices are skipped.
// LogNAV is log(NAV_t / NAV_ref) where NAV_ref is the first NAV
// that lands on the grid at or after the first valid grid point.
func AlignWeekly(proxy, market, nav *marketdata.Timeseries, from, to date.Date) (AlignedData, error) {
	grid := buildMondayNAVGrid(from, to, nav)
	if len(grid) < 2 {
		return AlignedData{}, errors.Bug("need at least 2 grid points: [%s, %s]",
			from.Format("2006-01-02"), to.Format("2006-01-02"))
	}

	navValues := buildNAVLookup(nav)

	firstValid, ok := findFirstValidGridPoint(grid, proxy, market)
	if !ok {
		return AlignedData{}, errors.Bug("no grid point has both proxy and market prices within lookback")
	}

	navRef, ok := findNAVReference(grid, firstValid, navValues)
	if !ok {
		return AlignedData{}, errors.Bug("no NAV observation lands on the grid")
	}

	maxLen := len(grid) - firstValid - 1
	dates := make([]date.Date, 0, maxLen)
	proxyRet := make([]float64, 0, maxLen)
	marketRet := make([]float64, 0, maxLen)
	logNAV := make([]float64, 0, maxLen)

	// findFirstValidGridPoint already verified that grid[firstValid] resolves;
	// the explicit check guards against a regression in that contract.
	prev, ok := priceAtBothSync(proxy, market, grid[firstValid].Date(), weeklyPriceLookbackDays)
	if !ok {
		return AlignedData{}, errors.Bug("firstValid grid point does not resolve")
	}

	var pending pendingNAV

	droppedWeeks := 0

	for i := firstValid + 1; i < len(grid); i++ {
		// If a NAV observation lands on this grid point, capture it as pending.
		// It will be applied at the next grid point where proxy and market resolve.
		if v, ok := navValues[grid[i]]; ok {
			pending.set(v)
		}

		curr, ok := priceAtBothSync(proxy, market, grid[i].Date(), weeklyPriceLookbackDays)
		if !ok {
			droppedWeeks++

			continue
		}

		logNAVValue := math.NaN()
		if v, ok := pending.take(); ok {
			logNAVValue = math.Log(v / navRef)
		}

		proxyReturn, marketReturn := computeWeeklyReturn(prev, curr)

		dates = append(dates, grid[i].Date())
		proxyRet = append(proxyRet, proxyReturn)
		marketRet = append(marketRet, marketReturn)
		logNAV = append(logNAV, logNAVValue)

		prev = curr
	}

	if droppedWeeks > 0 {
		log.Warnf("AlignWeekly: dropped %d grid points where proxy or market price was missing within lookback", droppedWeeks)
	}

	return AlignedData{
		Dates:         dates,
		ProxyReturns:  proxyRet,
		MarketReturns: marketRet,
		LogNAV:        logNAV,
	}, nil
}

// buildMondayNAVGrid returns the ordered union of Mondays in [from, to]
// and NAV observation dates as a slice of biz.Date.
//
// All NAV observations are intentionally included regardless of whether
// their dates fall within [from, to]: NAVs are scarce and valuable for
// the model. NAVs that fall on a weekend (e.g. quarter-ends 30 Sep that
// happen to be Saturday) are shifted forward to the next business day
// via biz.AtOrAfter, preserving them in the grid without loss.
//
// The two input streams (Mondays and shifted NAV dates) are each already
// sorted, so the union is built by an iter.Pull-based merge in O(n+m).
// Duplicates are folded at the equality step.
func buildMondayNAVGrid(from, to date.Date, nav *marketdata.Timeseries) []biz.Date {
	mondays, stopM := iter.Pull(mondaysSeq(from, to))
	defer stopM()

	navs, stopN := iter.Pull(navDatesSeq(nav))
	defer stopN()

	navCount := 0
	if nav != nil {
		navCount = nav.NumEntries()
	}

	capacity := mondaysUpperBound(from, to) + navCount
	grid := make([]biz.Date, 0, capacity)

	m, mOk := mondays()
	n, nOk := navs()

	for mOk && nOk {
		switch {
		case m.Equal(n):
			grid = append(grid, m)
			m, mOk = mondays()
			n, nOk = navs()
		case m.Before(n):
			grid = append(grid, m)
			m, mOk = mondays()
		default:
			grid = append(grid, n)
			n, nOk = navs()
		}
	}

	for ; mOk; m, mOk = mondays() {
		grid = append(grid, m)
	}

	for ; nOk; n, nOk = navs() {
		grid = append(grid, n)
	}

	return grid
}

// mondaysSeq yields Mondays in [from, to] as biz.Date in ascending order.
func mondaysSeq(from, to date.Date) iter.Seq[biz.Date] {
	return func(yield func(biz.Date) bool) {
		anchor := biz.AtOrAfter(from)
		for anchor.Weekday() != time.Monday {
			anchor = anchor.Next()
		}

		toBiz := biz.AtOrBefore(to)
		for d := anchor; !d.After(toBiz); d = d.Add(5) {
			if !yield(d) {
				return
			}
		}
	}
}

// navDatesSeq yields NAV observation dates as biz.Date, shifted forward
// to the next business day via biz.AtOrAfter, in ascending order with
// consecutive duplicates collapsed.
//
// Duplicates can arise when adjacent NAV dates (for example Saturday
// and Sunday of the same weekend) both shift to the same Monday.
// Collapsing them here keeps the iter.Pull merge in buildMondayNAVGrid
// from emitting a duplicate grid point.
func navDatesSeq(nav *marketdata.Timeseries) iter.Seq[biz.Date] {
	return func(yield func(biz.Date) bool) {
		if nav == nil || nav.IsEmpty() {
			return
		}

		var prev *biz.Date

		for i := range nav.NumEntries() {
			shifted := biz.AtOrAfter(nav.At(i).Date)
			if prev != nil && shifted.Equal(*prev) {
				continue
			}

			if !yield(shifted) {
				return
			}

			prev = &shifted
		}
	}
}

// mondaysUpperBound returns an upper bound on the number of Mondays in
// [from, to], used to pre-size the grid slice.
func mondaysUpperBound(from, to date.Date) int {
	if !from.Before(to) {
		return 1
	}

	return to.Sub(from)/7 + 2
}

// buildNAVLookup builds a biz.Date-keyed map of valid NAV observations.
// Weekend NAV dates are shifted forward to the next business day via
// biz.AtOrAfter so they align with the grid produced by buildMondayNAVGrid.
//
// When several NAV dates collapse onto the same business day after the
// shift (for example NAVs on Saturday and Sunday of the same week both
// shifting to Monday), entries already on a business day take priority
// over shifted weekend entries, and earlier entries take priority over
// later ones. This preserves the most accurate observation for each
// grid point and keeps the 'never lose a NAV' guarantee at the slot
// level: every collision is resolved deterministically rather than by
// last-write-wins.
func buildNAVLookup(nav *marketdata.Timeseries) map[biz.Date]float64 {
	if nav == nil || nav.IsEmpty() {
		return map[biz.Date]float64{}
	}

	navValues := make(map[biz.Date]float64, nav.NumEntries())

	// Pass 1: NAVs already on a business day take priority.
	for i := range nav.NumEntries() {
		entry := nav.At(i)
		if !isValidNAV(entry.Value) {
			continue
		}

		if d, ok := biz.AtOk(entry.Date); ok {
			writeIfAbsent(navValues, d, entry.Value)
		}
	}

	// Pass 2: weekend NAVs fill any remaining slots without overwriting.
	for i := range nav.NumEntries() {
		entry := nav.At(i)
		if !isValidNAV(entry.Value) {
			continue
		}

		if _, isBiz := biz.AtOk(entry.Date); isBiz {
			continue
		}

		writeIfAbsent(navValues, biz.AtOrAfter(entry.Date), entry.Value)
	}

	return navValues
}

// isValidNAV reports whether a NAV value is finite and strictly positive.
func isValidNAV(v float64) bool {
	return !math.IsNaN(v) && v > 0
}

// writeIfAbsent stores value under key only if the slot is empty.
func writeIfAbsent(m map[biz.Date]float64, key biz.Date, value float64) {
	if _, exists := m[key]; !exists {
		m[key] = value
	}
}

func findFirstValidGridPoint(grid []biz.Date, proxy, market *marketdata.Timeseries) (int, bool) {
	for i, d := range grid {
		if _, ok := priceAtBothSync(proxy, market, d.Date(), weeklyPriceLookbackDays); ok {
			return i, true
		}
	}

	return 0, false
}

// findNAVReference returns the first NAV observation that lands on the grid
// at or after the firstValid index. The bool reports whether such an
// observation exists.
func findNAVReference(grid []biz.Date, firstValid int, navValues map[biz.Date]float64) (float64, bool) {
	for i := firstValid; i < len(grid); i++ {
		if v, ok := navValues[grid[i]]; ok {
			return v, true
		}
	}

	return 0, false
}

// pendingNAV holds a NAV observation captured at a grid point that
// could not yet be assigned because proxy or market prices were not
// available there. It is consumed at the next valid grid point.
type pendingNAV struct {
	value   float64
	present bool
}

func (p *pendingNAV) set(v float64) {
	p.value = v
	p.present = true
}

// take returns the pending NAV value and whether one was set.
// On a successful take, the pending state is cleared.
func (p *pendingNAV) take() (float64, bool) {
	if !p.present {
		return 0, false
	}

	p.present = false

	return p.value, true
}

// computeWeeklyReturn returns log-returns of proxy and market prices
// from one grid point to the next.
func computeWeeklyReturn(prev, curr syncedPrices) (float64, float64) {
	return math.Log(curr.ProxyPrice / prev.ProxyPrice), math.Log(curr.MarketPrice / prev.MarketPrice)
}

// syncedPrices holds proxy and market prices resolved at the same date.
type syncedPrices struct {
	ProxyPrice  float64
	MarketPrice float64
}

// priceAtBothSync returns the proxy and market prices at the most recent
// date in [d-maxLookback, d] where both are available. The bool reports
// whether such a date exists. Resolving both prices to the same date keeps
// the proxy and market returns derived from them describing the same period.
func priceAtBothSync(proxy, market *marketdata.Timeseries, d date.Date, maxLookback int) (syncedPrices, bool) {
	for back := range maxLookback + 1 {
		candidate := d.Add(-back)

		proxyPrice, proxyOK := priceAt(proxy, candidate, 0)

		marketPrice, marketOK := priceAt(market, candidate, 0)
		if proxyOK && marketOK {
			return syncedPrices{ProxyPrice: proxyPrice, MarketPrice: marketPrice}, true
		}
	}

	return syncedPrices{}, false
}
