// Package nowcasting implements the BGG state-space model pipeline for
// Burgiss private asset nowcasting. This file wires the per-asset
// orchestration: alignment -> SSM -> Chow-Lin -> cumulation.
package nowcasting

import (
	"fmt"
	"math"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/gapfilling"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// SSMConfigForFundType returns the gapfilling.SSMConfig with fund-type-
// specific MLE starting values and bounds taken from the BGG prototype.
func SSMConfigForFundType(ft FundType) gapfilling.SSMConfig {
	c := gapfilling.DefaultSSMConfig()
	c.OLSWindowWeeks = 260 // 5-year rolling OLS for responsive beta dynamics

	// Lock alpha and beta to their OLS values during MLE. This matches the
	// prototype's --fix-alpha --fix-beta flags and prevents MLE from drifting
	// to extreme values (e.g. lambda=0.999 blow-up) when the proxy/market
	// pair has limited NAV-grid information to identify a free 8-parameter MLE.
	c.FixAlphaOLS = true
	c.FixBetaOLS = true

	switch ft {
	case FundTypePrivateEquity:
		c.LambdaInitial = 0.70
		c.PsiInitial = 0
		c.BetaBounds = gapfilling.Bounds{Low: 0.001, High: 5.0}
	case FundTypePrivateCredit:
		c.LambdaInitial = 0.85
		c.PsiInitial = 0
		c.BetaBounds = gapfilling.Bounds{Low: 0.001, High: 5.0}
	case FundTypePrivateRealEstate:
		c.LambdaInitial = 0.80
		c.PsiInitial = 0
		c.BetaBounds = gapfilling.Bounds{Low: 0.001, High: 5.0}
	case FundTypePrivateRealAssets:
		c.LambdaInitial = 0.75
		c.PsiInitial = 0
		c.BetaBounds = gapfilling.Bounds{Low: 0.001, High: 5.0}
	}

	return c
}

// RunPipeline executes the SSM + Chow-Lin pipeline for one private asset.
//
// The caller (service layer) fetches the three series from Cerberus and
// builds the SSMConfig from the asset's fund type. RunPipeline is a pure
// computation: data in, prices + diagnostics out.
//
// Steps:
//  1. Align the three series to a weekly Friday grid.
//  2. Run gapfilling.RunSSM for weekly de-smoothed returns (r*).
//  3. Disaggregate weekly r* to daily via gapfilling.ChowLinDisaggregate.
//  4. Cumulate daily log-returns to a price path (base = 100).
//
// The returned *marketdata.Timeseries is windowed by the caller's existing
// .From().To() logic — no trimming is needed here.
func RunPipeline(
	nav, idiosyncraticProxy, marketProxy *marketdata.Timeseries,
	config gapfilling.SSMConfig,
) (*marketdata.Timeseries, gapfilling.SSMOutput, error) {
	if err := validateRunPipelineInputs(nav, idiosyncraticProxy, marketProxy); err != nil {
		return nil, gapfilling.SSMOutput{}, fmt.Errorf("could not validate pipeline inputs: %w", err)
	}

	from := idiosyncraticProxy.At(0).Date
	to := idiosyncraticProxy.Last().Date

	weekly, err := AlignWeekly(idiosyncraticProxy, marketProxy, nav, from, to)
	if err != nil {
		return nil, gapfilling.SSMOutput{}, fmt.Errorf("could not apply weekly alignment: %w", err)
	}

	ssmOutput, err := runSSM(weekly, config)
	if err != nil {
		return nil, gapfilling.SSMOutput{}, fmt.Errorf("could not run SSM: %w", err)
	}

	dailyReturns, dailyDates, chowlinResult, err := disaggregateToDaily(weekly, idiosyncraticProxy, marketProxy, ssmOutput.WeeklyRStar)
	if err != nil {
		return nil, ssmOutput, fmt.Errorf("could not disaggregate daily: %w", err)
	}

	if len(chowlinResult.Coefficients) >= 2 {
		ssmOutput.ChowLinMarketCoeff = chowlinResult.Coefficients[0]
		ssmOutput.ChowLinProxyCoeff = chowlinResult.Coefficients[1]
	}
	ssmOutput.ChowLinIntercept = chowlinResult.Intercept

	// Anchor the cumulated daily series at the last observed NAV. The SSM
	// price on the date of the last NAV equals that NAV exactly; earlier
	// dates are back-solved through cumulative SSM returns; later dates are
	// forward-propagated through the same returns. Shape (returns, vol,
	// scenarios) is unchanged; only the level is rescaled so absolute
	// pricing metrics (NPV, exposure) become meaningful.
	basePrice, err := anchorToLastNAV(nav, dailyReturns, dailyDates)
	if err != nil {
		return nil, ssmOutput, fmt.Errorf("could not anchor to last NAV: %w", err)
	}

	return CumulateToPrice(dailyReturns, dailyDates, basePrice), ssmOutput, nil
}

// validateRunPipelineInputs checks that the three required time series
// are present and non-empty. Extracted from RunPipeline to keep that
// function's cyclomatic complexity within the linter limit.
func validateRunPipelineInputs(nav, idiosyncraticProxy, marketProxy *marketdata.Timeseries) error {
	if idiosyncraticProxy == nil || idiosyncraticProxy.IsEmpty() {
		return errors.Bug("idiosyncratic proxy series is empty")
	}

	if marketProxy == nil || marketProxy.IsEmpty() {
		return errors.Bug("market proxy series is empty")
	}

	if nav == nil || nav.IsEmpty() {
		return errors.Bug("nav series is empty")
	}

	return nil
}

// anchorToLastNAV returns the basePrice such that the cumulated daily
// series passes through the last NAV value on its date. CumulateToPrice
// gives price[i] = basePrice * exp(sum_{j<=i} r_j), so picking the largest
// k with dailyDates[k] <= lastNAVDate and setting basePrice = lastNAV /
// exp(cumsum_to_k) yields price[k] = lastNAV exactly.
func anchorToLastNAV(
	nav *marketdata.Timeseries,
	dailyReturns []float64,
	dailyDates []date.Date,
) (float64, error) {
	if len(dailyReturns) != len(dailyDates) || len(dailyReturns) == 0 {
		return 0, errors.Bug(
			"daily returns / dates length mismatch or empty: %d returns, %d dates",
			len(dailyReturns), len(dailyDates),
		)
	}

	last := nav.Last()
	if last.Value <= 0 {
		return 0, errors.Bug("last NAV must be strictly positive, got %f", last.Value)
	}

	k := -1

	for i, d := range dailyDates {
		if d.After(last.Date) {
			break
		}

		k = i
	}

	if k < 0 {
		return 0, errors.Bug(
			"no daily date on or before lastNAVDate=%s (first daily=%s)",
			last.Date, dailyDates[0],
		)
	}

	cumsum := 0.0
	for j := 0; j <= k; j++ {
		cumsum += dailyReturns[j]
	}

	return last.Value / math.Exp(cumsum), nil
}

// runSSM calls gapfilling.RunSSM with the aligned weekly data.
func runSSM(weekly AlignedData, config gapfilling.SSMConfig) (gapfilling.SSMOutput, error) {
	input := gapfilling.SSMInput{
		ProxyReturns:  weekly.ProxyReturns,
		MarketReturns: weekly.MarketReturns,
		LogNAV:        weekly.LogNAV,
	}

	return gapfilling.RunSSM(input, config)
}

// disaggregateToDaily converts weekly r* into daily r* using Chow-Lin
// with daily proxy and market returns as indicators.
func disaggregateToDaily(
	weekly AlignedData,
	idiosyncraticProxy, marketProxy *marketdata.Timeseries,
	weeklyRStar []float64,
) ([]float64, []date.Date, gapfilling.ChowLinResult, error) {
	outWeeks := len(weeklyRStar)
	if outWeeks < 2 {
		return nil, nil, gapfilling.ChowLinResult{}, errors.Bug("need at least 2 weeks of r*, got %d", outWeeks)
	}

	if outWeeks+1 > len(weekly.Dates) {
		return nil, nil, gapfilling.ChowLinResult{}, errors.Bug(
			"weekly r* longer than aligned grid: %d r* points but only %d grid dates",
			outWeeks, len(weekly.Dates),
		)
	}

	outFridays := weekly.Dates[len(weekly.Dates)-(outWeeks+1):]
	daily := AlignDaily(idiosyncraticProxy, marketProxy, outFridays)

	if len(daily.SegmentLengths) != outWeeks {
		return nil, nil, gapfilling.ChowLinResult{}, errors.Bug(
			"segment count mismatch: %d segments vs %d weekly r*",
			len(daily.SegmentLengths), outWeeks,
		)
	}

	// Indicator order matters: the broad market index goes first as the
	// systemic driver, the idiosyncratic proxy second as the residual
	// asset-specific loading. This matches the SSM input convention.
	result, err := gapfilling.ChowLinDisaggregate(
		weeklyRStar,
		[][]float64{daily.MarketReturns, daily.ProxyReturns},
		daily.SegmentLengths,
	)
	if err != nil {
		return nil, nil, gapfilling.ChowLinResult{}, fmt.Errorf("could not disaggregate using Chow-Lin's methodology: %w", err)
	}

	return result.Values, daily.Dates, result, nil
}
