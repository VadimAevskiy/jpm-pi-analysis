package nowcasting

import (
	"math"

	"github.com/edgelaboratories/go-libraries/biz"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	log "github.com/sirupsen/logrus"
)

// AlignDaily builds the daily-frequency alignment needed for Chow-Lin
// disaggregation: business days and their count per weekly segment.
func AlignDaily(proxy, market *marketdata.Timeseries, fridays []date.Date) AlignedData {
	if len(fridays) < 2 {
		return AlignedData{}
	}

	span := biz.InclusiveSpan(biz.AtOrAfter(fridays[0]), biz.AtOrBefore(fridays[len(fridays)-1]))
	businessDays := make([]date.Date, 0, span.Size())

	for d := range span.Seq() {
		businessDays = append(businessDays, d.Date())
	}

	validDates, validProxy, validMarket, droppedDays := collectValidDailyData(proxy, market, businessDays)

	segLengths := countDaysPerSegment(validDates, fridays)

	if droppedDays > 0 {
		log.Warnf("AlignDaily: dropped %d business days where proxy or market price was missing within lookback", droppedDays)
	}

	return AlignedData{
		Dates:          validDates,
		MarketReturns:  validMarket,
		ProxyReturns:   validProxy,
		SegmentLengths: segLengths,
	}
}

// collectValidDailyData walks businessDays in pairs and keeps only days
// where both proxy and market returns are computable. Returns one entry
// per valid (prev, curr) pair, dated at curr; businessDays[0] is the
// reference for the first return and does not appear in the output.
func collectValidDailyData(proxy, market *marketdata.Timeseries, businessDays []date.Date) ([]date.Date, []float64, []float64, int) {
	capacity := 0
	if len(businessDays) > 1 {
		capacity = len(businessDays) - 1
	}

	validDates := make([]date.Date, 0, capacity)
	validProxy := make([]float64, 0, capacity)
	validMarket := make([]float64, 0, capacity)

	droppedDays := 0

	for i := 1; i < len(businessDays); i++ {
		proxyReturn, okProxy := dailyLogReturn(proxy, businessDays[i-1], businessDays[i])

		marketReturn, okMarket := dailyLogReturn(market, businessDays[i-1], businessDays[i])
		if !okProxy || !okMarket {
			droppedDays++

			continue
		}

		validDates = append(validDates, businessDays[i])
		validProxy = append(validProxy, proxyReturn)
		validMarket = append(validMarket, marketReturn)
	}

	return validDates, validProxy, validMarket, droppedDays
}

// countDaysPerSegment counts how many dailyDates fall in each weekly
// segment (fridays[w], fridays[w+1]]. dailyDates and fridays must each
// be sorted in ascending order, and every dailyDate must lie within
// (fridays[0], fridays[len(fridays)-1]] so the inner loop stays in range.
func countDaysPerSegment(dailyDates, fridays []date.Date) []int {
	nWeeks := len(fridays) - 1
	segLengths := make([]int, nWeeks)

	weekIndex := 0
	for _, d := range dailyDates {
		for d.After(fridays[weekIndex+1]) {
			weekIndex++
		}

		segLengths[weekIndex]++
	}

	return segLengths
}

func dailyLogReturn(ts *marketdata.Timeseries, prev, curr date.Date) (float64, bool) {
	pCurr, okC := priceAt(ts, curr, dailyPriceLookbackDays)
	pPrev, okP := priceAt(ts, prev, dailyPriceLookbackDays)

	if !okC || !okP || pPrev <= 0 {
		return 0, false
	}

	return math.Log(pCurr / pPrev), true
}
