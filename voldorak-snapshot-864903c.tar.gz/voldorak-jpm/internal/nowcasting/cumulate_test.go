package nowcasting

import (
	"math"
	"testing"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_CumulateToPrice(t *testing.T) {
	t.Parallel()

	t.Run("zero returns preserve base price", func(t *testing.T) {
		t.Parallel()

		returns := []float64{0, 0, 0}
		dates := []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)}

		got := CumulateToPrice(returns, dates, 100.0)

		require.Equal(t, 3, got.NumEntries())

		for i := range got.NumEntries() {
			assert.InDelta(t, 100.0, got.At(i).Value, 1e-10)
		}
	})

	t.Run("compounds cumulatively", func(t *testing.T) {
		t.Parallel()

		returns := []float64{math.Log(1.10), math.Log(1.05)}
		dates := []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2)}

		got := CumulateToPrice(returns, dates, 100.0)

		require.Equal(t, 2, got.NumEntries())
		assert.InDelta(t, 110.0, got.At(0).Value, 1e-10)
		assert.InDelta(t, 115.5, got.At(1).Value, 1e-10)
	})

	t.Run("sets PrivateAsset type", func(t *testing.T) {
		t.Parallel()

		got := CumulateToPrice([]float64{0}, []date.Date{date.New(2024, 1, 1)}, 100.0)
		assert.Equal(t, marketdata.PrivateAsset, got.Type)
	})
}

func Test_anchorToLastNAV(t *testing.T) {
	t.Parallel()

	t.Run("scaled series passes through last NAV on its date", func(t *testing.T) {
		t.Parallel()

		dates := []date.Date{
			date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3),
			date.New(2024, 1, 4), date.New(2024, 1, 5),
		}
		returns := []float64{0.01, -0.005, 0.003, 0.002, -0.001}
		nav := &marketdata.Timeseries{Type: marketdata.PrivateAsset, Entries: marketdata.Entries{
			&marketdata.Entry{Date: date.New(2024, 1, 1), Value: 100.0},
			&marketdata.Entry{Date: date.New(2024, 1, 3), Value: 110.0},
		}}

		basePrice, err := anchorToLastNAV(nav, returns, dates)
		require.NoError(t, err)

		series := CumulateToPrice(returns, dates, basePrice)
		assert.InDelta(t, 110.0, series.At(2).Value, 1e-10)
	})

	t.Run("log-returns are preserved by rescaling", func(t *testing.T) {
		t.Parallel()

		dates := []date.Date{
			date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3),
		}
		returns := []float64{0.012, -0.008, 0.005}
		nav := &marketdata.Timeseries{Type: marketdata.PrivateAsset, Entries: marketdata.Entries{
			&marketdata.Entry{Date: date.New(2024, 1, 3), Value: 250.0},
		}}

		basePrice, err := anchorToLastNAV(nav, returns, dates)
		require.NoError(t, err)

		series := CumulateToPrice(returns, dates, basePrice)
		for i := 1; i < series.NumEntries(); i++ {
			gotR := math.Log(series.At(i).Value / series.At(i-1).Value)
			assert.InDelta(t, returns[i], gotR, 1e-12)
		}
	})

	t.Run("uses largest daily date on or before lastNAVDate", func(t *testing.T) {
		t.Parallel()

		dates := []date.Date{
			date.New(2024, 1, 1), date.New(2024, 1, 2),
			date.New(2024, 1, 5), date.New(2024, 1, 8),
		}
		returns := []float64{0.0, 0.01, 0.0, 0.0}
		nav := &marketdata.Timeseries{Type: marketdata.PrivateAsset, Entries: marketdata.Entries{
			&marketdata.Entry{Date: date.New(2024, 1, 3), Value: 200.0},
		}}

		basePrice, err := anchorToLastNAV(nav, returns, dates)
		require.NoError(t, err)

		series := CumulateToPrice(returns, dates, basePrice)
		assert.InDelta(t, 200.0, series.At(1).Value, 1e-10)
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			returns []float64
			dates   []date.Date
			nav     marketdata.Entries
		}{
			"empty returns": {
				returns: nil,
				dates:   nil,
				nav:     marketdata.Entries{{Date: date.New(2024, 1, 1), Value: 100.0}},
			},
			"length mismatch": {
				returns: []float64{0.01},
				dates:   []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2)},
				nav:     marketdata.Entries{{Date: date.New(2024, 1, 1), Value: 100.0}},
			},
			"non-positive NAV": {
				returns: []float64{0.01},
				dates:   []date.Date{date.New(2024, 1, 1)},
				nav:     marketdata.Entries{{Date: date.New(2024, 1, 1), Value: 0.0}},
			},
			"NAV before all daily dates": {
				returns: []float64{0.01},
				dates:   []date.Date{date.New(2024, 6, 1)},
				nav:     marketdata.Entries{{Date: date.New(2024, 1, 1), Value: 100.0}},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				nav := &marketdata.Timeseries{Type: marketdata.PrivateAsset, Entries: tc.nav}
				_, err := anchorToLastNAV(nav, tc.returns, tc.dates)
				assert.Error(t, err)
			})
		}
	})
}
