package nowcasting

// FundType categorises the private asset class.
type FundType string

const (
	FundTypePrivateEquity     FundType = "Private Equity"
	FundTypePrivateCredit     FundType = "Private Credit"
	FundTypePrivateRealEstate FundType = "Private Real Estate"
	FundTypePrivateRealAssets FundType = "Private Real Assets"
)
