package nowcasting

import (
	"math"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/gapfilling"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_SSMConfigForFundType(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	t.Run("unknown fund type returns default config with FixOLS overrides", func(t *testing.T) {
		t.Parallel()

		got := SSMConfigForFundType(FundType("nonexistent"))
		want := gapfilling.DefaultSSMConfig()
		want.FixAlphaOLS = true
		want.FixBetaOLS = true

		assert.Equal(t, want, got)
	})

	for name, tc := range map[string]struct {
		fundType       FundType
		wantBetaLo     float64
		wantBetaHi     float64
		wantLambdaInit float64
		wantPsiInit    float64
	}{
		"private equity": {
			fundType:       FundTypePrivateEquity,
			wantBetaLo:     0.001,
			wantBetaHi:     5.0,
			wantLambdaInit: 0.70,
			wantPsiInit:    0.0,
		},
		"private credit": {
			fundType:       FundTypePrivateCredit,
			wantBetaLo:     0.001,
			wantBetaHi:     5.0,
			wantLambdaInit: 0.85,
			wantPsiInit:    0.0,
		},
		"private real estate": {
			fundType:       FundTypePrivateRealEstate,
			wantBetaLo:     0.001,
			wantBetaHi:     5.0,
			wantLambdaInit: 0.80,
			wantPsiInit:    0.0,
		},
		"private real assets": {
			fundType:       FundTypePrivateRealAssets,
			wantBetaLo:     0.001,
			wantBetaHi:     5.0,
			wantLambdaInit: 0.75,
			wantPsiInit:    0.0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := SSMConfigForFundType(tc.fundType)

			assert.InDelta(t, tc.wantBetaLo, got.BetaBounds.Low, tol)
			assert.InDelta(t, tc.wantBetaHi, got.BetaBounds.High, tol)
			assert.InDelta(t, tc.wantLambdaInit, got.LambdaInitial, tol)
			assert.InDelta(t, tc.wantPsiInit, got.PsiInitial, tol)
		})
	}
}

func Test_RunPipeline(t *testing.T) {
	t.Parallel()

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			nav                *marketdata.Timeseries
			idiosyncraticProxy *marketdata.Timeseries
			marketProxy        *marketdata.Timeseries
		}{
			"nil idiosyncratic proxy": {
				nav:                &marketdata.Timeseries{},
				idiosyncraticProxy: nil,
				marketProxy:        buildTS([]date.Date{date.New(2024, 1, 5)}, []float64{100}),
			},
			"empty idiosyncratic proxy": {
				nav:                &marketdata.Timeseries{},
				idiosyncraticProxy: &marketdata.Timeseries{},
				marketProxy:        buildTS([]date.Date{date.New(2024, 1, 5)}, []float64{100}),
			},
			"nil market proxy": {
				nav:                &marketdata.Timeseries{},
				idiosyncraticProxy: buildTS([]date.Date{date.New(2024, 1, 5)}, []float64{100}),
				marketProxy:        nil,
			},
			"empty market proxy": {
				nav:                &marketdata.Timeseries{},
				idiosyncraticProxy: buildTS([]date.Date{date.New(2024, 1, 5)}, []float64{100}),
				marketProxy:        &marketdata.Timeseries{},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				config := gapfilling.DefaultSSMConfig()
				_, _, err := RunPipeline(tc.nav, tc.idiosyncraticProxy, tc.marketProxy, config)

				require.Error(t, err)
			})
		}
	})

	t.Run("happy path", func(t *testing.T) {
		t.Parallel()

		from := date.New(2020, time.January, 1)
		to := date.New(2024, time.January, 1)

		days := businessDays(from, to)

		proxyValues := make([]float64, len(days))
		marketValues := make([]float64, len(days))

		for i := range days {
			x := float64(i)
			proxyValues[i] = 100.0 * math.Exp(0.0002*x+0.01*math.Sin(2*math.Pi*x/250))
			marketValues[i] = 100.0 * math.Exp(0.00015*x+0.008*math.Cos(2*math.Pi*x/250))
		}

		idiosyncraticProxy := buildTS(days, proxyValues)
		marketProxy := buildTS(days, marketValues)

		navDates := make([]date.Date, 0, 48)
		navValues := make([]float64, 0, 48)

		for year := 2020; year < 2024; year++ {
			for month := time.January; month <= time.December; month++ {
				d := date.New(year, month, 1)
				for d.Weekday() == time.Saturday || d.Weekday() == time.Sunday {
					d = d.Add(1)
				}

				navDates = append(navDates, d)
				navValues = append(navValues, 100.0*math.Exp(0.008*float64(len(navDates)-1)))
			}
		}

		nav := buildTS(navDates, navValues)

		config := gapfilling.DefaultSSMConfig()

		prices, output, err := RunPipeline(nav, idiosyncraticProxy, marketProxy, config)

		require.NoError(t, err)
		require.NotNil(t, prices)
		assert.False(t, prices.IsEmpty())
		assert.GreaterOrEqual(t, output.Diagnostics.NAVObservationCount, config.MinimumNAVObservations)
		assert.False(t, math.IsNaN(output.AlphaOLS) || math.IsInf(output.AlphaOLS, 0))
		assert.False(t, math.IsNaN(output.BetaOLS) || math.IsInf(output.BetaOLS, 0))
		assert.False(t, math.IsNaN(output.NegLogLik) || math.IsInf(output.NegLogLik, 0))
		assert.Greater(t, prices.NumEntries(), 100)
	})
}

func Test_disaggregateToDaily(t *testing.T) {
	t.Parallel()

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			weekly      AlignedData
			weeklyRStar []float64
		}{
			"weekly r star too short": {
				weekly:      AlignedData{Dates: []date.Date{date.New(2024, 1, 5)}},
				weeklyRStar: []float64{0.01},
			},
			"weekly r star longer than grid": {
				weekly: AlignedData{Dates: []date.Date{
					date.New(2024, 1, 5),
					date.New(2024, 1, 12),
					date.New(2024, 1, 19),
				}},
				weeklyRStar: []float64{0.01, 0.02, 0.03, 0.04, 0.05},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, _, err := disaggregateToDaily(
					tc.weekly,
					&marketdata.Timeseries{},
					&marketdata.Timeseries{},
					tc.weeklyRStar,
				)

				require.Error(t, err)
			})
		}
	})
}
