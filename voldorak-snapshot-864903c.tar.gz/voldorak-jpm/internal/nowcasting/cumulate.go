package nowcasting

import (
	"math"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// CumulateToPrice turns a sequence of daily log-returns into a price
// series anchored at basePrice on the first date. dailyReturns and dates
// must be of equal length; the loop is bounded by dailyReturns.
func CumulateToPrice(dailyReturns []float64, dates []date.Date, basePrice float64) *marketdata.Timeseries {
	entries := make(marketdata.Entries, len(dailyReturns))
	price := basePrice

	for i, r := range dailyReturns {
		price *= math.Exp(r)
		entries[i] = &marketdata.Entry{
			Date:  dates[i],
			Value: price,
		}
	}

	return &marketdata.Timeseries{
		Entries: entries,
		Type:    marketdata.PrivateAsset,
	}
}
