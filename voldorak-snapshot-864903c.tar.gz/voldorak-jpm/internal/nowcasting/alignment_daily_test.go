package nowcasting

import (
	"math"
	"testing"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_dailyLogReturn(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		ts := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)},
			[]float64{100.0, 101.0, 102.0},
		)

		for name, tc := range map[string]struct {
			prev    date.Date
			curr    date.Date
			wantVal float64
		}{
			"adjacent days": {
				prev:    date.New(2024, 1, 2),
				curr:    date.New(2024, 1, 3),
				wantVal: math.Log(102.0 / 101.0),
			},
			"resolves via 1-day lookback": {
				prev:    date.New(2024, 1, 1),
				curr:    date.New(2024, 1, 4),
				wantVal: math.Log(102.0 / 100.0),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, ok := dailyLogReturn(ts, tc.prev, tc.curr)

				require.True(t, ok)
				assert.InDelta(t, tc.wantVal, got, 1e-15)
			})
		}
	})

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			ts   *marketdata.Timeseries
			prev date.Date
			curr date.Date
		}{
			"missing curr beyond lookback": {
				ts: buildTS(
					[]date.Date{date.New(2024, 1, 1)},
					[]float64{100.0},
				),
				prev: date.New(2024, 1, 1),
				curr: date.New(2024, 1, 10),
			},
			"missing prev": {
				ts: buildTS(
					[]date.Date{date.New(2024, 1, 5)},
					[]float64{100.0},
				),
				prev: date.New(2024, 1, 1),
				curr: date.New(2024, 1, 5),
			},
			"empty timeseries": {
				ts:   &marketdata.Timeseries{},
				prev: date.New(2024, 1, 1),
				curr: date.New(2024, 1, 2),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, ok := dailyLogReturn(tc.ts, tc.prev, tc.curr)

				assert.False(t, ok)
			})
		}
	})
}

func Test_collectValidDailyData(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)},
			[]float64{100.0, 101.0, 102.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)},
			[]float64{200.0, 201.0, 202.0},
		)
		businessDays := []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3)}

		dates, proxyR, marketR, dropped := collectValidDailyData(proxy, market, businessDays)

		assert.Equal(t, 0, dropped)
		assert.Equal(t, businessDays[1:], dates)
		assert.InDelta(t, math.Log(101.0/100.0), proxyR[0], 1e-15)
		assert.InDelta(t, math.Log(102.0/101.0), proxyR[1], 1e-15)
		assert.InDelta(t, math.Log(201.0/200.0), marketR[0], 1e-15)
		assert.InDelta(t, math.Log(202.0/201.0), marketR[1], 1e-15)
	})

	t.Run("drops days where proxy is missing beyond lookback", func(t *testing.T) {
		t.Parallel()

		// Proxy has a 2-day gap (no entry on Jan 3 and Jan 4).
		// At least one of these days is dropped because dailyLogReturn
		// requires both prev and curr within the 1-day lookback, which
		// cannot bridge a 2-day gap.
		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 9)},
			[]float64{100.0, 101.0, 108.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3), date.New(2024, 1, 4), date.New(2024, 1, 5), date.New(2024, 1, 6), date.New(2024, 1, 7), date.New(2024, 1, 8), date.New(2024, 1, 9)},
			[]float64{200.0, 201.0, 202.0, 203.0, 204.0, 205.0, 206.0, 207.0, 208.0},
		)
		businessDays := []date.Date{date.New(2024, 1, 1), date.New(2024, 1, 2), date.New(2024, 1, 3), date.New(2024, 1, 4), date.New(2024, 1, 5), date.New(2024, 1, 6), date.New(2024, 1, 7), date.New(2024, 1, 8), date.New(2024, 1, 9)}

		dates, _, _, dropped := collectValidDailyData(proxy, market, businessDays)

		assert.Positive(t, dropped)
		assert.Less(t, len(dates), len(businessDays))
	})

	t.Run("empty businessDays returns empty result", func(t *testing.T) {
		t.Parallel()

		dates, proxyR, marketR, dropped := collectValidDailyData(
			&marketdata.Timeseries{},
			&marketdata.Timeseries{},
			[]date.Date{},
		)

		assert.Equal(t, 0, dropped)
		assert.Empty(t, dates)
		assert.Empty(t, proxyR)
		assert.Empty(t, marketR)
	})
}

func Test_AlignDaily(t *testing.T) {
	t.Parallel()

	t.Run("segment lengths sum to total days", func(t *testing.T) {
		t.Parallel()

		start := date.New(2024, 1, 5)
		dates := businessDays(start, date.New(2024, 1, 26))

		values := make([]float64, len(dates))
		for i := range values {
			values[i] = 100.0 + float64(i)
		}

		proxy := buildTS(dates, values)
		market := buildTS(dates, values)
		fridays := []date.Date{
			date.New(2024, 1, 5), date.New(2024, 1, 12),
			date.New(2024, 1, 19), date.New(2024, 1, 26),
		}

		got := AlignDaily(proxy, market, fridays)

		var sum int
		for _, s := range got.SegmentLengths {
			sum += s
		}

		assert.Equal(t, len(got.Dates), sum)
		assert.Len(t, got.SegmentLengths, len(fridays)-1)
	})

	t.Run("empty when fewer than 2 fridays", func(t *testing.T) {
		t.Parallel()

		got := AlignDaily(&marketdata.Timeseries{}, &marketdata.Timeseries{}, []date.Date{date.New(2024, 1, 5)})
		assert.Empty(t, got.Dates)
	})

	t.Run("drops days where proxy or market is missing", func(t *testing.T) {
		t.Parallel()

		// Friday 2024-01-05 to Friday 2024-01-12. Proxy has a wide gap
		// (no entries Jan 9, 10) so the 1-day lookback cannot bridge it.
		// Behavioral contract: at least one day is dropped, so the
		// output is shorter than the full business-day range.
		proxy := buildTS(
			[]date.Date{date.New(2024, 1, 5), date.New(2024, 1, 8), date.New(2024, 1, 11), date.New(2024, 1, 12)},
			[]float64{100.0, 101.0, 104.0, 105.0},
		)
		market := buildTS(
			[]date.Date{date.New(2024, 1, 5), date.New(2024, 1, 8), date.New(2024, 1, 9), date.New(2024, 1, 10), date.New(2024, 1, 11), date.New(2024, 1, 12)},
			[]float64{200.0, 201.0, 202.0, 203.0, 204.0, 205.0},
		)
		fridays := []date.Date{date.New(2024, 1, 5), date.New(2024, 1, 12)}

		got := AlignDaily(proxy, market, fridays)

		// 6 business days in [Jan 5, Jan 12]: 5, 8, 9, 10, 11, 12.
		// At least one is dropped due to the proxy gap.
		assert.Less(t, len(got.Dates), 6)
	})

	t.Run("last day is preserved", func(t *testing.T) {
		t.Parallel()

		start := date.New(2024, 1, 5)
		end := date.New(2024, 1, 26)
		dates := businessDays(start, end)

		values := make([]float64, len(dates))
		for i := range values {
			values[i] = 100.0 + float64(i)
		}

		proxy := buildTS(dates, values)
		market := buildTS(dates, values)
		fridays := []date.Date{
			date.New(2024, 1, 5), date.New(2024, 1, 12),
			date.New(2024, 1, 19), date.New(2024, 1, 26),
		}

		got := AlignDaily(proxy, market, fridays)

		require.NotEmpty(t, got.Dates)
		assert.Equal(t, end, got.Dates[len(got.Dates)-1])
	})
}

func Test_countDaysPerSegment(t *testing.T) {
	t.Parallel()

	t.Run("days distributed across segments", func(t *testing.T) {
		t.Parallel()

		// Two segments: (Fri Jan 5, Fri Jan 12] and (Fri Jan 12, Fri Jan 19].
		fridays := []date.Date{date.New(2024, 1, 5), date.New(2024, 1, 12), date.New(2024, 1, 19)}
		dailyDates := []date.Date{
			date.New(2024, 1, 8),  // segment 0
			date.New(2024, 1, 9),  // segment 0
			date.New(2024, 1, 15), // segment 1
			date.New(2024, 1, 16), // segment 1
			date.New(2024, 1, 17), // segment 1
		}

		got := countDaysPerSegment(dailyDates, fridays)

		assert.Equal(t, []int{2, 3}, got)
	})

	t.Run("week end is inclusive", func(t *testing.T) {
		t.Parallel()

		fridays := []date.Date{date.New(2024, 1, 5), date.New(2024, 1, 12)}
		dailyDates := []date.Date{
			date.New(2024, 1, 12), // weekEnd of segment 0, must count
		}

		got := countDaysPerSegment(dailyDates, fridays)

		assert.Equal(t, []int{1}, got)
	})

	t.Run("empty segment counted as zero", func(t *testing.T) {
		t.Parallel()

		fridays := []date.Date{date.New(2024, 1, 5), date.New(2024, 1, 12), date.New(2024, 1, 19)}
		dailyDates := []date.Date{
			date.New(2024, 1, 16),
		}

		got := countDaysPerSegment(dailyDates, fridays)

		assert.Equal(t, []int{0, 1}, got)
	})
}
