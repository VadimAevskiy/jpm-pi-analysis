//go:build local

// Cerberus data-quality scan. Fetches every unique proxy and market UUID from
// private_asset_mapping.csv, computes daily log-returns over the full history,
// and writes a CSV with max-move diagnostics. Used to detect bad cerberus data
// (e.g. the IUKP.L / IASP.L 100x scale jump on 2023-11-22 that broke RE Europe
// calibrations).
//
// Uses the production mapping fetcher (nowcasting.MakeMappingFetcher) and the
// production data types (marketdata.Fund for idiosyncratic proxies,
// marketdata.Index for market proxies) so the same identifiers that production
// SSM calls would resolve are what we check here.

package nowcasting

import (
	"context"
	"encoding/csv"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"testing"
	"time"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/cerberus"
)

func TestCerberusDataQuality(t *testing.T) {
	outDir := resolveOutputDir(t)
	outPath := filepath.Join(outDir, "cerberus_data_quality.csv")

	// Walk every mapping and collect unique UUIDs with their role
	// (idiosyncratic proxy => marketdata.Fund, market proxy => marketdata.Index).
	// Mapping is enumerated by reading the CSV (production Fetcher exposes
	// only Fetch(id), not enumeration); the same CSV that production uses.
	rows := loadMappingRows(t)
	type ref struct {
		role  string // "proxy" or "market"
		label string
	}
	uuidRefs := make(map[string][]ref)
	uuidType := make(map[string]marketdata.Type)
	for _, m := range rows {
		if m.proxyUUID != "" {
			uuidRefs[m.proxyUUID] = append(uuidRefs[m.proxyUUID], ref{"proxy", m.label})
			uuidType[m.proxyUUID] = marketdata.Fund
		}
		if m.broadUUID != "" {
			uuidRefs[m.broadUUID] = append(uuidRefs[m.broadUUID], ref{"market", m.label})
			// If the same UUID happens to be referenced as both Fund and Index
			// across different mappings (shouldn't happen in production but
			// guard anyway), prefer the Index type since that's what production
			// SSM uses for the market proxy in fetchSpotTimeseriesWithSSMPipeline.
			uuidType[m.broadUUID] = marketdata.Index
		}
	}
	t.Logf("unique UUIDs to check: %d", len(uuidRefs))

	client, err := cerberus.NewClient(&cerberus.Config{
		Host:    cerberusHost,
		Timeout: "60s",
		Retry:   3,
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	from := time.Date(2000, 1, 1, 0, 0, 0, 0, time.UTC)
	to := time.Now().UTC()

	type result struct {
		uuid           string
		fetchType      string
		usedAsProxyBy  []string
		usedAsMarketBy []string
		first          string
		last           string
		count          int
		maxAbsMove     float64
		maxMoveDate    string
		maxMoveFrom    string
		maxMoveTo      string
		maxMovePrev    float64
		maxMoveNext    float64
		hugeJumps      int // count of |log_return| > 2 (i.e. > 7x)
		hugeJumpDates  []string
	}
	results := make([]result, 0, len(uuidRefs))

	for uuid, refs := range uuidRefs {
		fetchType := uuidType[uuid]
		ts, err := client.FetchSpotTimeseries(ctx, fetchType, uuid, from, to)
		if err != nil {
			t.Logf("FETCH FAIL %s (%s): %v", uuid, fetchType, err)
			continue
		}
		if ts == nil || len(ts.Entries) < 2 {
			continue
		}
		res := result{
			uuid:      uuid,
			fetchType: string(fetchType),
		}
		for _, r := range refs {
			if r.role == "proxy" {
				res.usedAsProxyBy = append(res.usedAsProxyBy, r.label)
			} else {
				res.usedAsMarketBy = append(res.usedAsMarketBy, r.label)
			}
		}
		res.first = ts.At(0).Date.String()
		res.last = ts.Last().Date.String()
		res.count = len(ts.Entries)

		for i := 1; i < len(ts.Entries); i++ {
			p0 := ts.At(i - 1).Value
			p1 := ts.At(i).Value
			if p0 <= 0 || p1 <= 0 {
				continue
			}
			r := math.Log(p1 / p0)
			a := math.Abs(r)
			if a > res.maxAbsMove {
				res.maxAbsMove = a
				res.maxMoveDate = ts.At(i).Date.String()
				res.maxMoveFrom = ts.At(i - 1).Date.String()
				res.maxMoveTo = ts.At(i).Date.String()
				res.maxMovePrev = p0
				res.maxMoveNext = p1
			}
			if a > 2.0 {
				res.hugeJumps++
				res.hugeJumpDates = append(res.hugeJumpDates,
					fmt.Sprintf("%s:%.4g→%.4g(r=%.2f)", ts.At(i).Date.String(), p0, p1, r))
			}
		}
		results = append(results, res)
	}

	sort.Slice(results, func(i, j int) bool {
		if results[i].hugeJumps != results[j].hugeJumps {
			return results[i].hugeJumps > results[j].hugeJumps
		}
		return results[i].maxAbsMove > results[j].maxAbsMove
	})

	out, err := os.Create(outPath)
	if err != nil {
		t.Fatalf("create out: %v", err)
	}
	defer out.Close()
	w := csv.NewWriter(out)
	defer w.Flush()
	_ = w.Write([]string{
		"uuid", "fetch_type", "n_proxy_users", "n_market_users",
		"first_date", "last_date", "obs_count",
		"max_abs_log_move", "max_move_date", "max_move_prev_price", "max_move_next_price",
		"huge_jump_count", "huge_jump_dates",
		"proxy_users", "market_users",
	})
	for _, r := range results {
		jumpDates := ""
		if len(r.hugeJumpDates) > 0 {
			jumpDates = r.hugeJumpDates[0]
			for k := 1; k < len(r.hugeJumpDates) && k < 5; k++ {
				jumpDates += " | " + r.hugeJumpDates[k]
			}
		}
		_ = w.Write([]string{
			r.uuid,
			r.fetchType,
			fmt.Sprintf("%d", len(r.usedAsProxyBy)),
			fmt.Sprintf("%d", len(r.usedAsMarketBy)),
			r.first, r.last, fmt.Sprintf("%d", r.count),
			fmt.Sprintf("%.4f", r.maxAbsMove),
			r.maxMoveDate,
			fmt.Sprintf("%.4f", r.maxMovePrev),
			fmt.Sprintf("%.4f", r.maxMoveNext),
			fmt.Sprintf("%d", r.hugeJumps),
			jumpDates,
			joinShort(r.usedAsProxyBy),
			joinShort(r.usedAsMarketBy),
		})
	}
	t.Logf("wrote %s with %d rows", outPath, len(results))
}

func joinShort(xs []string) string {
	if len(xs) == 0 {
		return ""
	}
	if len(xs) == 1 {
		return xs[0]
	}
	if len(xs) <= 3 {
		out := xs[0]
		for _, x := range xs[1:] {
			out += "; " + x
		}
		return out
	}
	return fmt.Sprintf("%s; %s; ... (%d more)", xs[0], xs[1], len(xs)-2)
}
