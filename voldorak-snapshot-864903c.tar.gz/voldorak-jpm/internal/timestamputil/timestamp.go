package timestamputil

import (
	"fmt"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// TimeToString converts a time into an RFC3339-formatted string.
func TimeToString(t time.Time) string {
	return t.Format(time.RFC3339)
}

// TimestampToString converts a Google-protobuf timestamp into an RFC3339-formatted string.
func TimestampToString(t *timestamppb.Timestamp) string {
	return TimeToString(t.AsTime())
}

// TimeFromString converts an ISO8601 string into a time.
func TimeFromString(str string) (time.Time, error) {
	t, err := time.Parse(date.ISO8601, str)
	if err != nil {
		return time.Time{}, fmt.Errorf("could not parse date as time: %w", err)
	}

	return t, nil
}

// TimestampFromString converts an ISO8601 date into a Google-protobud timestamp.
func TimestampFromString(str string) (*timestamppb.Timestamp, error) {
	t, err := TimeFromString(str)
	if err != nil {
		return nil, err
	}

	return timestamppb.New(t), nil
}

// TimestampToDate converts an input timestamp into an ISO8601 date.
// The infra-day component of the timestamp is neglected and treated
// as the previous midnight. The output date refers to the UTC timezone.
func TimestampToDate(tp *timestamppb.Timestamp) date.Date {
	return date.NewAt(tp.AsTime())
}

// DateToTimestamp converts an input date into a timestamp.
func DateToTimestamp(year int, month time.Month, day int) *timestamppb.Timestamp {
	return timestamppb.New(time.Date(year, month, day, 0, 0, 0, 0, time.UTC))
}
