package timestamputil

import (
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func Test_TimestampToString(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    *timestamppb.Timestamp
		expected string
	}{
		"2019-05-22": {
			input:    timestamppb.New(time.Date(2019, time.May, 22, 7, 44, 30, 666, time.UTC)),
			expected: "2019-05-22T07:44:30Z",
		},
		"2020-02-18": {
			input:    timestamppb.New(time.Date(2020, time.February, 18, 2, 38, 41, 2, time.UTC)),
			expected: "2020-02-18T02:38:41Z",
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := TimestampToString(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_TimestampFromString(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input    string
			expected *timestamppb.Timestamp
		}{
			"2021-07-06": {
				input:    "2021-07-06",
				expected: timestamppb.New(time.Date(2021, time.July, 6, 0, 0, 0, 0, time.UTC)),
			},
			"2020-02-18": {
				input:    "2020-02-18",
				expected: timestamppb.New(time.Date(2020, time.February, 18, 0, 0, 0, 0, time.UTC)),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := TimestampFromString(tc.input)
				require.NoError(t, err)
				assert.Equal(t, tc.expected, got)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := TimestampFromString("not a timestamp")
		require.Error(t, err)
	})
}

func Test_TimestampToDate(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    *timestamppb.Timestamp
		expected date.Date
	}{
		"start of year": {
			input:    timestamppb.New(time.Date(2020, time.January, 1, 12, 34, 56, 123456789, time.UTC)),
			expected: date.New(2020, time.January, 1),
		},
		"end of year": {
			input:    timestamppb.New(time.Date(2020, time.December, 31, 23, 59, 59, 999999999, time.UTC)),
			expected: date.New(2020, time.December, 31),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := TimestampToDate(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}

func Test_DateToTimestamp(t *testing.T) {
	t.Parallel()

	expected := timestamppb.New(time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC))
	got := DateToTimestamp(2020, time.January, 1)
	assert.Equal(t, expected, got)
}
