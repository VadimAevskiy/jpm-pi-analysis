package tarantino

// Config describes the Tarantino configuration structure.
type Config struct {
	Host    string `yaml:"host"`
	Timeout string `yaml:"timeout"`
	Retry   uint32 `yaml:"retry"`
}

// DefaultConfig creates a default config.
func DefaultConfig() *Config {
	const defaultRetry = 3

	return &Config{
		Host:    "tarantino.service.consul:80",
		Timeout: "6s",
		Retry:   defaultRetry,
	}
}
