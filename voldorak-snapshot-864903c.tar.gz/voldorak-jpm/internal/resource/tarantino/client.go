package tarantino

import (
	"context"
	"fmt"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	pb "github.com/edgelaboratories/tarantino/apis/v2/v2"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/grpcclient"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	"google.golang.org/grpc"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// internalClient is the implementation satisfying
// the API required by the Tarantino resource.
// It is a subset of pb.TarantinoServiceClient.
type internalClient interface {
	SpotScenarios(ctx context.Context, in *pb.SpotScenariosRequest, opts ...grpc.CallOption) (*pb.ScenariosResponse, error)
	VolatilityScenarios(ctx context.Context, in *pb.VolatilityScenariosRequest, opts ...grpc.CallOption) (*pb.ScenariosResponse, error)
}

// Client wraps a Tarantino client and its connection.
type Client struct {
	internalClient

	conn *grpc.ClientConn
}

// NewClient creates a new client from the input config.
func NewClient(cfg *Config) (*Client, error) {
	if cfg == nil {
		return nil, errors.Bug("the configuration is missing")
	}

	if cfg.Host == "" {
		return nil, errors.Bug("couldn't provide the host from config")
	}

	timeout, err := time.ParseDuration(cfg.Timeout)
	if err != nil {
		return nil, fmt.Errorf("could not parse timeout duration: %w", err)
	}

	conn, err := grpcclient.NewConnection(cfg.Host, timeout, cfg.Retry)
	if err != nil {
		return nil, fmt.Errorf("could not connect client: %w", err)
	}

	return &Client{
		pb.NewTarantinoServiceClient(conn),
		conn,
	}, nil
}

// Close closes the client connection.
func (c *Client) Close() error {
	if c.conn == nil {
		return nil
	}

	return c.conn.Close()
}

// FetchSpotScenarios fetches the spot scenario values.
func (c Client) FetchSpotScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*scenario.Proxies, error) {
	if len(scenarios) == 0 {
		return make(map[uint32]float64), make(map[uint32]*scenario.Proxies), nil
	}

	riskFactorType, err := marketdataTypeToRiskFactorType(t)
	if err != nil {
		return nil, nil, fmt.Errorf("could not infer the risk factor type: %w", err)
	}

	res, err := c.SpotScenarios(ctx, &pb.SpotScenariosRequest{
		Snapshot: &pb.Snapshot{
			Timestamp: timestamppb.New(snapshot),
		},
		RiskFactor: &pb.SpotRiskFactor{
			MarketDataId: id,
			Type:         riskFactorType,
		},
		Scenarios: scenarios,
	})
	if err = extractErrorFromGRPCError(err); err != nil {
		return nil, nil, fmt.Errorf("could not fetch the spot scenarios: %w", err)
	}

	return res.GetRealizations(), pbProxiesToScenarioProxies(res.GetProxies()), nil
}

// FetchVolatilityScenarios fetches the volatility scenario values.
func (c Client) FetchVolatilityScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*scenario.Proxies, error) {
	if len(scenarios) == 0 {
		return make(map[uint32]float64), make(map[uint32]*scenario.Proxies), nil
	}

	riskFactorType, err := marketdataTypeToRiskFactorType(t)
	if err != nil {
		return nil, nil, fmt.Errorf("could not infer the risk factor type: %w", err)
	}

	res, err := c.VolatilityScenarios(ctx, &pb.VolatilityScenariosRequest{
		Snapshot: &pb.Snapshot{
			Timestamp: timestamppb.New(snapshot),
		},
		RiskFactor: &pb.VolatilityRiskFactor{
			MarketDataId: id,
			Type:         riskFactorType,
		},
		Scenarios: scenarios,
	})
	if err := extractErrorFromGRPCError(err); err != nil {
		return nil, nil, fmt.Errorf("could not fetch the volatility scenarios: %w", err)
	}

	return res.GetRealizations(), pbProxiesToScenarioProxies(res.GetProxies()), nil
}

func marketdataTypeToRiskFactorType(t marketdata.Type) (pb.RiskFactorType, error) { //nolint:cyclop
	switch t {
	case marketdata.Fund:
		return pb.RiskFactorType_FUND, nil
	case marketdata.FX:
		return pb.RiskFactorType_FX, nil
	case marketdata.Index:
		return pb.RiskFactorType_INDEX, nil
	case marketdata.Stock:
		return pb.RiskFactorType_EQUITY, nil
	case marketdata.PrivateAsset:
		return pb.RiskFactorType_PRIVATE_INVESTMENT, nil
	case marketdata.SwapRate:
		return pb.RiskFactorType_SWAP_RATE, nil
	case marketdata.OISRate:
		return pb.RiskFactorType_OIS_RATE, nil
	case marketdata.FXForwardRate:
		return pb.RiskFactorType_FX_FORWARD_RATE, nil
	case marketdata.InterestRate:
		return pb.RiskFactorType_INTEREST_RATE, nil
	default:
		return pb.RiskFactorType_RISK_FACTOR_TYPE_UNSPECIFIED, errors.Bug(
			"market data type %s cannot be mapped to risk factor type", t,
		)
	}
}

func pbProxiesToScenarioProxies(pbProxies map[uint32]*pb.ProxyOutput) map[uint32]*scenario.Proxies {
	if pbProxies == nil {
		return nil
	}

	result := make(map[uint32]*scenario.Proxies, len(pbProxies))
	for scenarioID, proxyOutput := range pbProxies {
		result[scenarioID] = &scenario.Proxies{
			Intercept: proxyOutput.GetIntercept(),
			Betas:     proxyOutput.GetBetas(),
		}
	}

	return result
}
