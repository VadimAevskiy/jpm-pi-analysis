package tarantino

import (
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

// extractErrorFromGRPCError extracts the error from a GRPC error.
// If the error is not found, it adds the appropriate status and tag.
// Any other error is matched to a bug.
func extractErrorFromGRPCError(err error) error {
	err, statusCode, _ := errors.FromGRPC(err)
	if err == nil {
		return nil
	}

	if statusCode == errors.StatusCodeNotFound {
		return errors.SetTag(errors.NotFound("scenario data not found: %w", err), tag.ScenarioDataNotFound)
	}

	return errors.Bug("%w", err)
}
