package tarantino

import (
	"context"

	pb "github.com/edgelaboratories/tarantino/apis/v2/v2"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type mockTarantinoServiceClient struct{}

var _ internalClient = mockTarantinoServiceClient{}

func (m mockTarantinoServiceClient) SpotScenarios(_ context.Context, in *pb.SpotScenariosRequest, _ ...grpc.CallOption) (*pb.ScenariosResponse, error) {
	switch in.GetRiskFactor().GetMarketDataId() {
	case "575d7fc2-e930-4e14-b64e-540597696d5d":
		return &pb.ScenariosResponse{
			Realizations: map[uint32]float64{
				1: 1.0,
				2: 0.5,
				3: 0.25,
			},
			Proxies: map[uint32]*pb.ProxyOutput{
				2: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy": 10.0,
					},
				},
			},
		}, nil
	case "30bdc9ee-c278-48d0-aa87-54da09372e39":
		return nil, status.Error(codes.NotFound, "risk factor not found")
	default:
		return nil, status.Error(codes.Internal, "some error occurred")
	}
}

func (m mockTarantinoServiceClient) VolatilityScenarios(_ context.Context, in *pb.VolatilityScenariosRequest, _ ...grpc.CallOption) (*pb.ScenariosResponse, error) {
	switch in.GetRiskFactor().GetMarketDataId() {
	case "575d7fc2-e930-4e14-b64e-540597696d5d":
		return &pb.ScenariosResponse{
			Realizations: map[uint32]float64{
				1: 1.0,
				2: 0.5,
				3: 0.25,
			},
			Proxies: map[uint32]*pb.ProxyOutput{
				2: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy": 10.0,
					},
				},
			},
		}, nil
	case "30bdc9ee-c278-48d0-aa87-54da09372e39":
		return nil, status.Error(codes.NotFound, "risk factor not found")
	default:
		return nil, status.Error(codes.Internal, "some error occurred")
	}
}
