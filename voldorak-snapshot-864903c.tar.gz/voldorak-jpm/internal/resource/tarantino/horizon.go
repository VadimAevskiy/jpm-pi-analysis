package tarantino

// VolatilityHorizon defines the volatility scenario horizon in business days.
type VolatilityHorizon struct {
	Days uint32
}
