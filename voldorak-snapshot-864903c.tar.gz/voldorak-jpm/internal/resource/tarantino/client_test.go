package tarantino

import (
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	pb "github.com/edgelaboratories/tarantino/apis/v2/v2"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func Test_Configure(t *testing.T) {
	t.Parallel()

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			cfg *Config
		}{
			"invalid host": {
				cfg: &Config{
					Host:    "",
					Timeout: "6s",
				},
			},
			"invalid timeout": {
				cfg: &Config{
					Host:    "localhost:6379",
					Timeout: "",
				},
			},
			"missing config": {
				cfg: nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := NewClient(tc.cfg)
				require.Error(t, err)
			})
		}
	})
}

func buildTestClient() (*Client, time.Time) {
	snapshot := time.Date(2019, time.September, 9, 12, 36, 51, 0, time.UTC)
	client := &Client{mockTarantinoServiceClient{}, nil}

	return client, snapshot
}

func Test_Client_FetchSpotScenarios(t *testing.T) {
	t.Parallel()

	client, snapshot := buildTestClient()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id                   string
			scenarios            []uint32
			expectedRealizations map[uint32]float64
			expectedProxies      map[uint32]*scenario.Proxies
		}{
			"scenario list": {
				id:                   "575d7fc2-e930-4e14-b64e-540597696d5d",
				scenarios:            []uint32{1, 2, 3},
				expectedRealizations: map[uint32]float64{1: 1.0, 2: 0.5, 3: 0.25},
				expectedProxies: map[uint32]*scenario.Proxies{
					2: {
						Intercept: 2.0,
						Betas: map[string]float64{
							"proxy": 10.0,
						},
					},
				},
			},
			"empty scenario list": {
				id:                   "575d7fc2-e930-4e14-b64e-540597696d5d",
				scenarios:            make([]uint32, 0),
				expectedRealizations: make(map[uint32]float64),
				expectedProxies:      make(map[uint32]*scenario.Proxies),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, proxies, err := client.FetchSpotScenarios(t.Context(), marketdata.Fund, tc.id, tc.scenarios, snapshot)
				require.NoError(t, err)
				assert.Equal(t, codes.OK, status.Convert(err).Code())
				assert.Equal(t, tc.expectedRealizations, got)
				assert.Equal(t, tc.expectedProxies, proxies)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id             string
			scenarios      []uint32
			expectNotFound bool
		}{
			"risk factor not found": {
				id:             "30bdc9ee-c278-48d0-aa87-54da09372e39",
				scenarios:      []uint32{1, 2, 3},
				expectNotFound: true,
			},
			"internal error": {
				id:             "d93f5780-0e24-4e68-b734-4f4422e0fc3d",
				scenarios:      []uint32{1, 2, 3},
				expectNotFound: false,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := client.FetchSpotScenarios(t.Context(), marketdata.Fund, tc.id, tc.scenarios, snapshot)
				require.Error(t, err)
				assert.Equal(t, tc.expectNotFound, errors.StatusFrom(err).Code == errors.StatusCodeNotFound)
			})
		}
	})
}

func Test_Client_FetchVolatilityScenarios(t *testing.T) {
	t.Parallel()

	client, snapshot := buildTestClient()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id                   string
			scenarios            []uint32
			expectedRealizations map[uint32]float64
			expectedProxies      map[uint32]*scenario.Proxies
		}{
			"with scenarios": {
				id:                   "575d7fc2-e930-4e14-b64e-540597696d5d",
				scenarios:            []uint32{1, 2, 3},
				expectedRealizations: map[uint32]float64{1: 1.0, 2: 0.5, 3: 0.25},
				expectedProxies: map[uint32]*scenario.Proxies{
					2: {
						Intercept: 2.0,
						Betas: map[string]float64{
							"proxy": 10.0,
						},
					},
				},
			},
			"empty scenario list": {
				id:                   "575d7fc2-e930-4e14-b64e-540597696d5d",
				scenarios:            make([]uint32, 0),
				expectedRealizations: make(map[uint32]float64),
				expectedProxies:      make(map[uint32]*scenario.Proxies),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, proxies, err := client.FetchVolatilityScenarios(t.Context(), marketdata.Fund, tc.id, tc.scenarios, snapshot)
				require.NoError(t, err)
				assert.Equal(t, codes.OK, status.Convert(err).Code())
				assert.Equal(t, tc.expectedRealizations, got)
				assert.Equal(t, tc.expectedProxies, proxies)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id             string
			scenarios      []uint32
			expectNotFound bool
		}{
			"risk factor not found": {
				id:             "30bdc9ee-c278-48d0-aa87-54da09372e39",
				scenarios:      []uint32{1, 2, 3},
				expectNotFound: true,
			},
			"internal error": {
				id:             "d93f5780-0e24-4e68-b734-4f4422e0fc3d",
				scenarios:      []uint32{1, 2, 3},
				expectNotFound: false,
			},
			"invalid horizon": {
				id:             "d93f5780-0e24-4e68-b734-4f4422e0fc3d",
				scenarios:      []uint32{1, 2, 3},
				expectNotFound: false,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := client.FetchVolatilityScenarios(t.Context(), marketdata.Fund, tc.id, tc.scenarios, snapshot)
				require.Error(t, err)
				assert.Equal(t, tc.expectNotFound, errors.StatusFrom(err).Code == errors.StatusCodeNotFound)
			})
		}
	})
}

func Test_marketdataTypeToRiskFactorType(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			t        marketdata.Type
			expected pb.RiskFactorType
		}{
			"fund": {
				t:        marketdata.Fund,
				expected: pb.RiskFactorType_FUND,
			},
			"fx": {
				t:        marketdata.FX,
				expected: pb.RiskFactorType_FX,
			},
			"index": {
				t:        marketdata.Index,
				expected: pb.RiskFactorType_INDEX,
			},
			"stock": {
				t:        marketdata.Stock,
				expected: pb.RiskFactorType_EQUITY,
			},
			"private asset": {
				t:        marketdata.PrivateAsset,
				expected: pb.RiskFactorType_PRIVATE_INVESTMENT,
			},
			"swap rate": {
				t:        marketdata.SwapRate,
				expected: pb.RiskFactorType_SWAP_RATE,
			},
			"ois rate": {
				t:        marketdata.OISRate,
				expected: pb.RiskFactorType_OIS_RATE,
			},
			"fx forward rate": {
				t:        marketdata.FXForwardRate,
				expected: pb.RiskFactorType_FX_FORWARD_RATE,
			},
			"interest rate": {
				t:        marketdata.InterestRate,
				expected: pb.RiskFactorType_INTEREST_RATE,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := marketdataTypeToRiskFactorType(tc.t)
				require.NoError(t, err)
				assert.Equal(t, tc.expected, got)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		got, err := marketdataTypeToRiskFactorType(marketdata.Type("Unspecified"))
		require.Error(t, err)
		assert.Equal(t, pb.RiskFactorType_RISK_FACTOR_TYPE_UNSPECIFIED, got)
	})
}

func Test_pbProxiesToScenarioProxies(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    map[uint32]*pb.ProxyOutput
		expected map[uint32]*scenario.Proxies
	}{
		"nil input": {
			input:    nil,
			expected: nil,
		},
		"empty input": {
			input:    make(map[uint32]*pb.ProxyOutput),
			expected: make(map[uint32]*scenario.Proxies),
		},
		"valid input": {
			input: map[uint32]*pb.ProxyOutput{
				1: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy1": 10.0,
						"proxy2": 20.0,
					},
				},
			},
			expected: map[uint32]*scenario.Proxies{
				1: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy1": 10.0,
						"proxy2": 20.0,
					},
				},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := pbProxiesToScenarioProxies(tc.input)
			assert.Equal(t, tc.expected, got)
		})
	}
}
