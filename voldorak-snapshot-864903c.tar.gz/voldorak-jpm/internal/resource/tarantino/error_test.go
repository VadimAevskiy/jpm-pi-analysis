package tarantino

import (
	"testing"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func Test_extractErrorFromGRPCError(t *testing.T) {
	t.Parallel()

	const msg = "wrapping message: some error"

	t.Run("nil", func(t *testing.T) {
		t.Parallel()

		require.NoError(t, extractErrorFromGRPCError(nil))
	})

	t.Run("not found", func(t *testing.T) {
		t.Parallel()

		err := extractErrorFromGRPCError(status.Error(codes.NotFound, msg))
		errors.AssertStatus(t, errors.StatusCodeNotFound, err)
		errors.AssertTag(t, tag.ScenarioDataNotFound, err)
	})

	t.Run("generic", func(t *testing.T) {
		t.Parallel()

		for _, tc := range []struct {
			name  string
			input error
		}{
			{
				"internal",
				errors.Bug(msg),
			},
			{
				"plain",
				errors.New(msg),
			},
		} {
			t.Run(tc.name, func(t *testing.T) {
				t.Parallel()

				err := extractErrorFromGRPCError(tc.input)
				errors.AssertStatus(t, errors.StatusCodeBug, err)
			})
		}
	})
}
