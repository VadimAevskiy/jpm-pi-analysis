package cerberus

import (
	"testing"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const spot = 123.45

func genericDividendYieldCurve() marketdata.DividendYieldCurve {
	return marketdata.DividendYieldCurve{Dividends: []marketdata.DividendPoint{
		{
			Dividend:       0.0125,
			CashDividend:   1.25,
			ExDividendDate: exDividendDateTestHelper(1),
			YearFraction:   yearFractionTestHelper(1),
		},
		{
			Dividend:       0.0225,
			CashDividend:   2.25,
			ExDividendDate: exDividendDateTestHelper(2),
			YearFraction:   yearFractionTestHelper(2),
		},
		{
			Dividend:       0.0325,
			CashDividend:   3.25,
			ExDividendDate: exDividendDateTestHelper(3),
			YearFraction:   yearFractionTestHelper(3),
		},
		{
			Dividend:       0.0425,
			CashDividend:   4.25,
			ExDividendDate: exDividendDateTestHelper(4),
			YearFraction:   yearFractionTestHelper(4),
		},
	}}
}

func genericDividendYieldCurveEntry() []dividendYieldCurveEntry {
	return []dividendYieldCurveEntry{
		{
			0.0125,
			1.25,
			exDividendDateTestHelper(1),
			0.0,
		},
		{
			0.0225,
			2.25,
			exDividendDateTestHelper(2),
			yearFractionTestHelper(2),
		},
		{
			0.0325,
			3.25,
			exDividendDateTestHelper(3),
			yearFractionTestHelper(3),
		},
		{
			0.0425,
			4.25,
			exDividendDateTestHelper(4),
			yearFractionTestHelper(4),
		},
	}
}

func Test_Client_FetchDividendYieldCurve(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		const id = "2f7da240-1415-463b-907d-1f5c00bc70eb"

		dividendYieldCurve, err := client.FetchDividendYieldCurve(t.Context(), id)
		require.NoError(t, err)

		expectedDividend := marketdata.DividendYieldCurve{Dividends: []marketdata.DividendPoint{
			{
				Dividend:       0.01,
				CashDividend:   1.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(1),
				YearFraction:   yearFractionTestHelper(1),
			},
			{
				Dividend:       0.03,
				CashDividend:   3.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(3),
				YearFraction:   yearFractionTestHelper(3),
			},
			{
				Dividend:       0.05,
				CashDividend:   5.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(5),
				YearFraction:   yearFractionTestHelper(5),
			},
		}}

		assert.Equal(t, expectedDividend, *dividendYieldCurve)
	})

	t.Run("invalid id", func(t *testing.T) {
		t.Parallel()

		const invalidID = "invalid"

		_, err := client.FetchDividendYieldCurve(t.Context(), invalidID)
		require.Error(t, err)
	})
}

func Test_mapToDividendYieldCurve(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		entries                    []dividendYieldCurveEntry
		expectedDividendYieldCurve marketdata.DividendYieldCurve
	}{
		"empty dividend yield curve": {
			entries:                    nil,
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"dividend yield curve entry without ex-dividend date": {
			entries:                    []dividendYieldCurveEntry{{ExDividendDate: date.Date{}}},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"single punctual dividend": {
			entries: []dividendYieldCurveEntry{
				{0.0125, 1.25, exDividendDateTestHelper(1), 0.0},
			},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{Dividends: []marketdata.DividendPoint{
				{
					Dividend:       0.0125,
					CashDividend:   1.25,
					ExDividendDate: exDividendDateTestHelper(1),
					YearFraction:   yearFractionTestHelper(1),
				},
			}},
		},
		"generic sorted dividend yield curve": {
			entries: []dividendYieldCurveEntry{
				{0.0125, 1.25, exDividendDateTestHelper(1), 0.0},
				{0.0225, 2.25, exDividendDateTestHelper(2), 0.0},
				{0.0325, 3.25, exDividendDateTestHelper(3), 0.0},
				{0.0425, 4.25, exDividendDateTestHelper(4), 0.0},
			},
			expectedDividendYieldCurve: genericDividendYieldCurve(),
		},
		"generic unsorted dividend yield curve": {
			entries: []dividendYieldCurveEntry{
				{0.0425, 4.25, exDividendDateTestHelper(4), 0.0},
				{0.0125, 1.25, exDividendDateTestHelper(1), 0.0},
				{0.0325, 3.25, exDividendDateTestHelper(3), 0.0},
				{0.0225, 2.25, exDividendDateTestHelper(2), 0.0},
			},
			expectedDividendYieldCurve: genericDividendYieldCurve(),
		},
		"ex dividend date in the future": {
			entries: []dividendYieldCurveEntry{
				{0.101, 10.1, exDividendDateTestHelper(3), yearFractionTestHelper(3)},
			},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{Dividends: []marketdata.DividendPoint{
				{
					Dividend:       0.101,
					CashDividend:   10.1,
					ExDividendDate: exDividendDateTestHelper(3),
					YearFraction:   yearFractionTestHelper(3),
				},
			}},
		},
		"ex dividend date one business day in the past": {
			entries: []dividendYieldCurveEntry{
				{
					0.101,
					10.1,
					businessCal().Add(date.Today(), -1),
					float64(businessCal().Add(date.Today(), -1).Sub(date.Today()) / daysPerYear),
				},
			},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"ex dividend date well in the past": {
			entries: []dividendYieldCurveEntry{
				{0.101, 10.1, exDividendDateTestHelper(-3), yearFractionTestHelper(-3)},
			},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"generic unsorted dividend yield curve with past entry": {
			entries: []dividendYieldCurveEntry{
				{0.0425, 4.25, exDividendDateTestHelper(4), 0.0},
				{0.0125, 1.25, exDividendDateTestHelper(1), 0.0},
				{0.025, 2.5, exDividendDateTestHelper(-1), 0.0},
				{0.0325, 3.25, exDividendDateTestHelper(3), 0.0},
				{0.0225, 2.25, exDividendDateTestHelper(2), 0.0},
			},
			expectedDividendYieldCurve: genericDividendYieldCurve(),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			dividend := mapToDividendYieldCurve(t.Context(), dividendYieldCurveEntries{exDividendDateTestHelper(-1), ForecastTable, tc.entries})
			assert.Equal(t, tc.expectedDividendYieldCurve, dividend)
		})
	}
}

func Test_mapToDividendYieldCurve_CurveDefinition(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		entries                    dividendYieldCurveEntries
		expectedDividendYieldCurve marketdata.DividendYieldCurve
	}{
		"dividend yield curve without calculation date": {
			entries:                    dividendYieldCurveEntries{date.Date{}, ForecastTable, []dividendYieldCurveEntry{}},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"dividend yield curve without valid curve definition type": {
			entries:                    dividendYieldCurveEntries{exDividendDateTestHelper(-1), "", []dividendYieldCurveEntry{}},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"dividend yield curve with unsupported curve definition type": {
			entries:                    dividendYieldCurveEntries{exDividendDateTestHelper(-1), ForecastYield, []dividendYieldCurveEntry{}},
			expectedDividendYieldCurve: marketdata.DividendYieldCurve{},
		},
		"dividend yield curve with supported curve definition type": {
			entries:                    dividendYieldCurveEntries{exDividendDateTestHelper(-1), HistoricalYield, genericDividendYieldCurveEntry()},
			expectedDividendYieldCurve: genericDividendYieldCurve(),
		},
		"dividend yield curve with supported curve definition type and calculation date in the future": {
			entries:                    dividendYieldCurveEntries{exDividendDateTestHelper(1), HistoricalYield, genericDividendYieldCurveEntry()},
			expectedDividendYieldCurve: genericDividendYieldCurve(),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			dividend := mapToDividendYieldCurve(t.Context(), dividendYieldCurveEntries{tc.entries.CalculationDate, tc.entries.CurveDefinitionType, tc.entries.Entries})
			assert.Equal(t, tc.expectedDividendYieldCurve, dividend)
		})
	}
}
