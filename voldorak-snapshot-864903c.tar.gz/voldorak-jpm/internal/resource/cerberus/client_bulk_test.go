package cerberus

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/jarcoal/httpmock"
	"github.com/stretchr/testify/require"
)

const (
	validAsset     = "73e54147-f8db-4204-8b24-8f6b7be90942"
	erroneousAsset = "01234567-89ab-cdef-0123-456789abcdef"
	invalidAsset   = "00000000-0000-0000-0000-000000000000"
	unstableHost   = "some.unstable.host:80"
)

type assetMinimalDescription struct {
	ID       string   `json:"id"`
	Currency currency `json:"currency"`
	Type     string   `json:"type"`
	SubType  string   `json:"subType"`
}

type currency struct {
	Name string `json:"name"`
	ID   string `json:"id"`
}

func newTestClient(t *testing.T) (*Client, *httpmock.MockTransport) {
	t.Helper()

	transport := httpmock.NewMockTransport()
	httpClient := &http.Client{
		Transport: transport,
	}

	client := &Client{
		client: httpClient,
		host:   "cerberus.addr",
	}

	mockDate := date.New(2024, time.January, 1)
	mockDateOneYearAgo := date.New(2023, time.January, 1)

	makeDescResponse(t, transport, client.host, validAsset, http.StatusOK, &assetMinimalDescription{
		ID: validAsset,
		Currency: currency{
			Name: "CHF",
			ID:   "CHF",
		},
		Type:    "StructuredAsset",
		SubType: "BarrierReverseConvertible",
	})
	makeDescResponseAsOf(t, transport, client.host, validAsset, mockDate, http.StatusOK, &assetMinimalDescription{
		ID: validAsset,
		Currency: currency{
			Name: "CHF",
			ID:   "CHF",
		},
		Type:    "StructuredAsset",
		SubType: "BarrierReverseConvertible",
	})
	makeDescResponseAsOf(t, transport, client.host, validAsset, mockDateOneYearAgo, http.StatusOK, &assetMinimalDescription{
		ID: validAsset,
		Currency: currency{
			Name: "USD",
			ID:   "USD",
		},
		Type:    "StructuredAsset",
		SubType: "BarrierReverseConvertible",
	})

	makeDescResponse(t, transport, client.host, invalidAsset, http.StatusNotFound, nil)
	makeDescResponse(t, transport, client.host, erroneousAsset, http.StatusInternalServerError, nil)
	makeDescResponseAsOf(t, transport, client.host, invalidAsset, mockDate, http.StatusNotFound, nil)
	makeDescResponseAsOf(t, transport, client.host, erroneousAsset, mockDate, http.StatusInternalServerError, nil)

	generateBulkResponse(t, transport, client.host, http.StatusOK, nil)
	generateBulkResponse(t, transport, client.host, http.StatusOK, &mockDate)
	generateBulkResponse(t, transport, client.host, http.StatusOK, &mockDateOneYearAgo)
	generateBulkResponse(t, transport, unstableHost, http.StatusInternalServerError, nil)

	t.Cleanup(func() {
		transport.Reset()
		require.NoError(t, client.Close())
	})

	return client, transport
}

func makeDescResponseAsOf(
	t *testing.T,
	transport *httpmock.MockTransport,
	host string,
	assetID string,
	at date.Date,
	status int,
	description *assetMinimalDescription,
) {
	t.Helper()

	respBytes, err := json.Marshal(description)
	require.NoError(t, err)

	transport.RegisterResponder(
		http.MethodGet,
		fmt.Sprintf("%s/assets/id/%s?at=%s&view=full", host, assetID, at),
		httpmock.NewBytesResponder(status, respBytes),
	)
}

func makeDescResponse(
	t *testing.T,
	transport *httpmock.MockTransport,
	host string,
	assetID string,
	status int,
	description *assetMinimalDescription,
) {
	t.Helper()

	respBytes, err := json.Marshal(description)
	require.NoError(t, err)

	transport.RegisterResponder(
		http.MethodGet,
		fmt.Sprintf("%s/assets/id/%s?view=full", host, assetID),
		httpmock.NewBytesResponder(status, respBytes),
	)
}

func generateBulkResponse(
	t *testing.T,
	transport *httpmock.MockTransport,
	host string,
	status int,
	at *date.Date,
) {
	t.Helper()

	mockDateOneYearAgo := date.New(2023, time.January, 1)

	var (
		ccy         = "CHF"
		atExtension = ""
	)

	if at != nil {
		if at.Equal(mockDateOneYearAgo) {
			ccy = "USD"
		}

		atExtension = fmt.Sprintf("&at=%s", at)
	}

	validRes, err := json.Marshal(&assetMinimalDescription{
		ID: validAsset,
		Currency: currency{
			Name: ccy,
			ID:   ccy,
		},
		Type:    "StructuredAsset",
		SubType: "BarrierReverseConvertible",
	})
	require.NoError(t, err)

	responses := bulkResponse{
		keyFromID(validAsset): {
			Status: http.StatusOK,
			Data:   validRes,
		},
		keyFromID(invalidAsset): {
			Status: http.StatusNotFound,
		},
		keyFromID(erroneousAsset): {
			Status: http.StatusInternalServerError,
		},
	}

	transport.RegisterResponder(
		http.MethodPost,
		host+"/assets/bulk?view=full"+atExtension,
		func(r *http.Request) (*http.Response, error) {
			if status != http.StatusOK {
				return &http.Response{
					StatusCode: status,
					Body:       httpmock.NewRespBodyFromString(""),
				}, nil
			}

			defer func() { _ = r.Body.Close() }()

			var assetFullIDs []string
			if err := json.NewDecoder(r.Body).Decode(&assetFullIDs); err != nil {
				return nil, fmt.Errorf("could not decode request body: %w", err)
			}

			response := make(bulkResponse, len(assetFullIDs))
			for _, key := range assetFullIDs {
				response[key] = responses[key]
			}

			res, err := json.Marshal(response)
			if err != nil {
				return nil, fmt.Errorf("could not encode response body: %w", err)
			}

			return &http.Response{
				StatusCode: http.StatusOK,
				Body:       httpmock.NewRespBodyFromBytes(res),
			}, nil
		},
	)
}
