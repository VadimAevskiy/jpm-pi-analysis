package cerberus

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/go-client/httpreq"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
)

func makeBulkDescriptionURL(host string, at *date.Date) string {
	url := host + "/assets/bulk?view=full"
	if at != nil {
		url += fmt.Sprintf("&at=%s", at)
	}

	return url
}

const idKey = "id"

func keyFromID(id string) string {
	return fmt.Sprintf("%s/%s", idKey, id)
}

var (
	keyPrefix = idKey + "/"
	keyExp    = regexp.MustCompile("^" + keyPrefix)
)

func idFromKey(key string) (string, error) {
	if ok := keyExp.MatchString(key); !ok {
		return "", errors.Bug("key %s does not respect id/<key> format", key)
	}

	return strings.TrimPrefix(key, keyPrefix), nil
}

func makeBulkBody(assetIDs []string) (json.RawMessage, error) {
	body := make([]string, len(assetIDs))
	for k, id := range assetIDs {
		body[k] = keyFromID(id)
	}

	return json.Marshal(body)
}

// bulk performs a request of all the input assets at once, for the given url.
func (c Client) bulk(ctx context.Context, assetIDs []string, url string) (map[string]json.RawMessage, error) {
	ctx, span := trace.StartSpan(ctx, "bulk")
	defer span.End()

	logger := logger.FromContext(ctx)

	logger.Infof("fetching description in bulk of %d assets", len(assetIDs))

	body, err := makeBulkBody(assetIDs)
	if err != nil {
		trace.SetSpanError(span, err)
		return nil, fmt.Errorf("could not create request body: %w", err)
	}

	req, err := http.NewRequestWithContext(
		ctx,
		http.MethodPost,
		url,
		bytes.NewReader(body),
	)
	if err != nil {
		trace.SetSpanError(span, err)
		return nil, fmt.Errorf("could not build request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")

	bulkRes, status, tag, err := httpreq.Request[bulkResponse](
		ctx,
		c.client,
		req,
		httpreq.WithXInternalService("etymologist"),
	)
	if status != errors.StatusCodeOK {
		err = c.handleBulkError(status, tag, err)
		trace.SetSpanError(span, err)

		return nil, err
	}

	data, err := extractDataFromBulkResponse(bulkRes)
	if err != nil {
		trace.SetSpanError(span, err)

		return nil, err
	}

	return data, nil
}

func (c Client) handleBulkError(status errors.StatusCode, tag errors.Tag, err error) error {
	if status == errors.StatusCodeNotFound {
		return errors.NotFound("could not find requested assets: %s", err)
	}

	if status == errors.StatusCodePreconditionFailed {
		return errors.PreconditionFailed("bulk asset request failed precondition: %s (tag=%s)", err, tag)
	}

	return errors.Bug("received status %d from provider: %s", status, err)
}

func (c Client) fetchDescriptions(ctx context.Context, assetIDs []string, at *date.Date) (map[string]marketdata.VanillaOptionDescription, error) {
	return fetchBulkTyped[marketdata.VanillaOptionDescription](
		ctx,
		c,
		assetIDs,
		c.buildOptionDescriptionsURL(at),
	)
}

func (c Client) fetchQuotes(ctx context.Context, assetIDs []string, at *date.Date) (map[string]marketdata.VanillaOptionQuotes, error) {
	return fetchBulkTyped[marketdata.VanillaOptionQuotes](
		ctx,
		c,
		assetIDs,
		c.buildOptionQuotesURL(at),
	)
}

func fetchBulkTyped[T any](ctx context.Context, c Client, assetIDs []string, url string) (map[string]T, error) {
	result := make(map[string]T, len(assetIDs))

	bulkRes, err := c.bulk(ctx, assetIDs, url)
	if err != nil {
		return nil, errors.Bug("could not fetch bulk data: %w", err)
	}

	for _, id := range assetIDs {
		data, ok := bulkRes[id]
		if !ok {
			return nil, errors.Bug("missing data for id %s", id)
		}

		var v T
		if err := json.Unmarshal(data, &v); err != nil {
			return nil, errors.Bug("could not unmarshal input for id %s: %w", id, err)
		}

		result[id] = v
	}

	return result, nil
}

// bulkResponse is the response produced by a bulk call.
// It consists of key-value pairs where the key is the asset
// ID and the value is a status-data unnamed structure.
type bulkResponse map[string]struct {
	Status int
	Data   json.RawMessage
}

// extractDataFromBulkResponse returns a map of string to JSON messages
// representing the asset descriptions per key.
//
// This function returns the first error encountered, if any.
func extractDataFromBulkResponse(bulkRes bulkResponse) (map[string]json.RawMessage, error) {
	out := make(map[string]json.RawMessage, len(bulkRes))
	for key, v := range bulkRes {
		id, err := idFromKey(key)
		if err != nil {
			return nil, fmt.Errorf("could not extract asset ID from key: %w", err)
		}

		if v.Status != http.StatusOK {
			return nil, httpStatusToError(v.Status, "received status %d for asset %s in bulk call", v.Status, id)
		}

		out[id] = v.Data
	}

	return out, nil
}
