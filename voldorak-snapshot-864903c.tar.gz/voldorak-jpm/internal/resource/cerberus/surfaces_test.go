package cerberus

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_FetchVolatilitySurface(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		const id = "83807b58-6c35-4663-bb5c-a699f1cd148f"

		surface, err := client.FetchVolatilitySurface(t.Context(), id)
		require.NoError(t, err)

		expectedSurface := marketdata.VolatilitySurface{
			Data: [][]float64{
				{0.1, 0.2},
				{0.4, 0.5},
				{0.8, 0.9},
			},
			TenorYearFractions: []float64{7.0 / 365.0, 2.0 / 12.0, 5.0},
			Strikes:            []float64{100.0, 150.0},
		}
		assert.Equal(t, expectedSurface, *surface)
	})

	t.Run("invalid id", func(t *testing.T) {
		t.Parallel()

		const invalidID = "invalid"

		_, err := client.FetchVolatilitySurface(t.Context(), invalidID)
		require.Error(t, err)
	})
}

func Test_mapToVolatilitySurface(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			entries         []volatilitySurfaceEntry
			expectedSurface marketdata.VolatilitySurface
		}{
			"scalar surface": {
				entries: []volatilitySurfaceEntry{
					{"1M", 100.0, 20.0},
				},
				expectedSurface: marketdata.VolatilitySurface{
					Data:               [][]float64{{0.2}},
					TenorYearFractions: []float64{1.0 / 12.0},
					Strikes:            []float64{100.0},
				},
			},
			"generic surface": {
				entries: []volatilitySurfaceEntry{
					{"1W", 100.0, 10.0},
					{"1W", 150.0, 20.0},
					{"2M", 100.0, 40.0},
					{"2M", 150.0, 50.0},
					{"5Y", 100.0, 80.0},
					{"5Y", 150.0, 90.0},
				},
				expectedSurface: marketdata.VolatilitySurface{
					Data: [][]float64{
						{0.1, 0.2},
						{0.4, 0.5},
						{0.8, 0.9},
					},
					TenorYearFractions: []float64{7.0 / 365.0, 2.0 / 12.0, 5.0},
					Strikes:            []float64{100.0, 150.0},
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				surface, err := mapToVolatilitySurface(volatilitySurfaceEntries{tc.entries})
				require.NoError(t, err)
				assert.Equal(t, tc.expectedSurface, surface)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			entries []volatilitySurfaceEntry
		}{
			"empty surface": {
				entries: []volatilitySurfaceEntry{},
			},
			"invalid tenor": {
				entries: []volatilitySurfaceEntry{
					{"M1", 100.0, 20.0},
				},
			},
			"mismatch in strike lists by tenor": {
				entries: []volatilitySurfaceEntry{
					{"1M", 100.0, 20.0},
					{"2M", 120.0, 20.0},
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := mapToVolatilitySurface(volatilitySurfaceEntries{tc.entries})
				require.Error(t, err)
			})
		}
	})
}
