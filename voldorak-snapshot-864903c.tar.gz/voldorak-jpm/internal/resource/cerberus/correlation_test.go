package cerberus

import (
	"testing"
	"time"

	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_FetchFXCorrelation(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	const tol = 1e-15

	for name, tc := range map[string]struct {
		domAgainstRef *fx.Pair
		forAgainstRef *fx.Pair
		snapshot      time.Time
		expected      float64
	}{
		"EUR-JPY": {
			domAgainstRef: &fx.Pair{Foreign: "USD", Domestic: "JPY"},
			forAgainstRef: &fx.Pair{Foreign: "USD", Domestic: "EUR"},
			snapshot:      time.Date(2018, time.July, 2, 0, 0, 0, 0, time.UTC),
			expected:      0.7,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			corr, err := client.FetchFXCorrelation(t.Context(), tc.domAgainstRef, tc.forAgainstRef, tc.snapshot)
			require.NoError(t, err)
			assert.InDelta(t, tc.expected, corr, tol)
		})
	}
}

func Test_currencyPairToIdentifier(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		currencyPair *fx.Pair
		expected     string
	}{
		"USD-JPY": {
			currencyPair: &fx.Pair{Foreign: "USD", Domestic: "JPY"},
			expected:     "fx/USDJPY",
		},
		"EUR-ZAR": {
			currencyPair: &fx.Pair{Foreign: "EUR", Domestic: "ZAR"},
			expected:     "fx/EURZAR",
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, currencyPairToIdentifier(tc.currencyPair))
		})
	}
}
