package cerberus

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_FetchFXPerspective(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			pair                *fx.Pair
			expectedPerspective *fx.Pair
		}{
			"EUR-USD": {
				pair:                &fx.Pair{Foreign: "EUR", Domestic: "USD"},
				expectedPerspective: &fx.Pair{Foreign: "USD", Domestic: "EUR"},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				perspective, err := client.FetchFXPerspective(t.Context(), tc.pair)
				require.NoError(t, err)
				assert.Equal(t, tc.expectedPerspective, perspective)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			pair *fx.Pair
		}{
			"invalid currency pair": {
				pair: &fx.Pair{Foreign: "AAA", Domestic: "BBB"},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := client.FetchFXPerspective(t.Context(), tc.pair)
				assert.Error(t, err)
			})
		}
	})
}

func Test_Client_extractPerspective(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	for name, tc := range map[string]struct {
		pair         *fx.Pair
		perspectives []perspectiveInfo
		expected     *fx.Pair
	}{
		"direct match": {
			pair:         &fx.Pair{Foreign: "USD", Domestic: "EUR"},
			perspectives: []perspectiveInfo{{Name: "USD-EUR"}},
			expected:     &fx.Pair{Foreign: "USD", Domestic: "EUR"},
		},
		"reversed match": {
			pair:         &fx.Pair{Foreign: "EUR", Domestic: "USD"},
			perspectives: []perspectiveInfo{{Name: "USD-EUR"}},
			expected:     &fx.Pair{Foreign: "USD", Domestic: "EUR"},
		},
		"no match with nil perspectives": {
			pair:         &fx.Pair{Foreign: "EUR", Domestic: "USD"},
			perspectives: nil,
			expected:     &fx.Pair{Foreign: "USD", Domestic: "EUR"},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, client.extractPerspective(tc.pair, tc.perspectives))
		})
	}
}
