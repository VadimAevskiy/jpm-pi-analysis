package cerberus

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_NewClient(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		c, err := NewClient(DefaultConfig())
		require.NoError(t, err)

		assert.NotNil(t, c)
		require.NoError(t, c.Close())
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			cfg *Config
		}{
			"invalid host": {
				cfg: &Config{
					Host:    "",
					Timeout: "6s",
				},
			},
			"invalid timeout": {
				cfg: &Config{
					Host:    "localhost",
					Timeout: "",
				},
			},
			"missing config": {
				cfg: nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				c, err := NewClient(tc.cfg)
				require.Error(t, err)

				require.NoError(t, c.Close())
			})
		}
	})
}
