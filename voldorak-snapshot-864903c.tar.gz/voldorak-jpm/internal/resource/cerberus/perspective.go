package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/fx"
)

type perspectiveInfo struct {
	Name string `json:"name"`
}

func (c Client) perspectiveURL() string {
	return c.host + "/exchange-rates/currency-pairs"
}

// FetchFXPerspective fetches the market perspective for a given currency pair "XXX-USD" or "USD-XXX".
func (c Client) FetchFXPerspective(ctx context.Context, p *fx.Pair) (*fx.Pair, error) {
	if p.Domestic != fx.ReferenceCurrency && p.Foreign != fx.ReferenceCurrency {
		return nil, errors.Bug("the input currency pair must contain %s", fx.ReferenceCurrency)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.perspectiveURL(), nil)
	if err != nil {
		return nil, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("could not execute the request: %w", err)
	}
	defer res.Body.Close()

	if err := errorFromHTTP(res); err != nil {
		return nil, err
	}

	var perspectives []perspectiveInfo
	if err := json.NewDecoder(res.Body).Decode(&perspectives); err != nil {
		return nil, fmt.Errorf("could not decode the perspectives: %w", err)
	}

	return c.extractPerspective(p, perspectives), nil
}

func (c Client) extractPerspective(pair *fx.Pair, perspectives []perspectiveInfo) *fx.Pair {
	for _, perspective := range perspectives {
		if perspective.Name == pair.String() {
			return pair
		}
	}

	return pair.Inverse()
}
