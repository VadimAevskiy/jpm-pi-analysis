package cerberus

import (
	"context"
	"fmt"
	"net/http"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/go-client/httpreq"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/surfacecalibration"
)

// surfaceIDs defines the response format the client uses for the
// volatility surface options of the input underlying.
type surfaceIDs struct {
	Entries []string `json:"surfaceIDs"`
}

// FetchOptions fetches the options' features and quotes of a given underlying at a given date.
func (c Client) FetchOptions(ctx context.Context, id string, at *date.Date) (surfacecalibration.OptionChainDescription, error) {
	surfaceIDs, err := c.fetchSurfaceIDs(ctx, c.buildSurfaceIDsURL(id, at))
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, errors.Bug("could not fetch volatility surface IDs %s: %w", id, err)
	}

	descriptions, err := c.fetchDescriptions(ctx, surfaceIDs, at)
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, errors.Bug("could not fetch option descriptions for underlying %s: %w", id, err)
	}

	currency, daycountConvention, exerciseType, err := validateDescriptionsConsistency(descriptions)
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, errors.Bug("option descriptions for underlying %s are inconsistent: %v", id, err)
	}

	quotes, err := c.fetchQuotes(ctx, surfaceIDs, at)
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, errors.Bug("could not fetch option quotes for underlying %s: %w", id, err)
	}

	optionChain, err := mapToSurfaceOptions(ctx, descriptions, quotes, at)
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, errors.Bug("could not map descriptions and quotes to surface options for underlying %s: %w", id, err)
	}

	return surfacecalibration.OptionChainDescription{
		Currency:           currency,
		DaycountConvention: daycountConvention,
		ExerciseType:       exerciseType,
		OptionChain:        optionChain,
	}, nil
}

func (c Client) buildSurfaceIDsURL(id string, at *date.Date) string {
	return fmt.Sprintf("%s/assets/volatility-surface-options/%s&at=%s", c.host, id, at)
}

func (c Client) buildOptionQuotesURL(at *date.Date) string {
	return fmt.Sprintf("%s/timeseries/assets?at=%s", c.host, at)
}

func (c Client) buildOptionDescriptionsURL(at *date.Date) string {
	return fmt.Sprintf("%s/assets/bulk?view=full&at=%s", c.host, at)
}

func (c Client) fetchSurfaceIDs(ctx context.Context, url string) ([]string, error) {
	ctx, span := trace.StartSpan(ctx, "fetchSurfaceIDs")
	defer span.End()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return []string{}, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")

	ids, status, tag, err := httpreq.Request[surfaceIDs](ctx, c.client, req)
	if status != errors.StatusCodeOK {
		err = c.handleFetchSurfaceIDsError(status, tag, err)
		trace.SetSpanError(span, err)

		return nil, err
	}

	return ids.Entries, nil
}

func (c Client) handleFetchSurfaceIDsError(status errors.StatusCode, tag errors.Tag, err error) error {
	if status == errors.StatusCodeNotFound {
		return errors.NotFound("surface IDs not found: %v", err)
	}

	if status == errors.StatusCodePreconditionFailed {
		return errors.PreconditionFailed("failed to fetch surface IDs due to precondition (tag=%s): %v", tag, err)
	}

	return errors.Bug("unexpected status %d while fetching surface IDs: %v", status, err)
}

func mapToSurfaceOptions(
	ctx context.Context,
	descriptions marketdata.VanillaOptionDescriptions,
	quotes marketdata.VanillaQuotes,
	at *date.Date,
) (surfacecalibration.OptionChain, error) {
	optionChain := surfacecalibration.OptionChain{}

	surfaceLogger := logger.FromContext(ctx).WithField("component", "mapToSurfaceOptions")

	for id, desc := range descriptions {
		quotes, ok := quotes[id]
		if !ok {
			return surfacecalibration.OptionChain{}, errors.Bug("missing quotes for option id %s", id)
		}

		k, err := extractSingleStrike(desc)
		if err != nil {
			return surfacecalibration.OptionChain{}, errors.Bug("could not extract single strike: %w", err)
		}

		price, ok := quotes.Quotes[*at]
		if !ok {
			surfaceLogger.Warningf("missing quote for option id %s at date %v", id, at)

			continue
		}

		t, err := computeYearFraction(*at, desc.FinalFixing, desc.DaycountConvention)
		if err != nil {
			return surfacecalibration.OptionChain{}, errors.Bug("could not compute year fraction for quote date %v: %w", at, err)
		}

		if !validQuote(price, k, t) {
			surfaceLogger.Warningf("invalid price or strike or tenor for option id %s at date %v will not be inserted: price=%f, strike=%f, tenor=%f", id, at, price, k, t)

			continue
		}

		if err := insertSurfaceOption(ctx, optionChain, *at, t, k, price, desc); err != nil {
			return surfacecalibration.OptionChain{}, errors.Bug("could not insert surface option for quote date %v, tenor %f, strike %f: %w", at, t, k, err)
		}
	}

	return optionChain, nil
}

func validQuote(price, strike, tenor float64) bool {
	return price > 0.0 && strike > 0.0 && tenor > 0.0
}

func validateDescriptionsConsistency(optionDescriptions marketdata.VanillaOptionDescriptions) (*marketdata.Currency, marketdata.DaycountConvention, marketdata.ExerciseType, error) {
	if len(optionDescriptions) == 0 {
		return &marketdata.Currency{}, "", "", errors.Bug("option descriptions are empty")
	}

	desc, err := firstOptionDescription(optionDescriptions)
	if err != nil {
		return &marketdata.Currency{}, "", "", errors.Bug("could not get first option description: %w", err)
	}

	var (
		commonCurrency           = desc.Currency
		commonDaycountConvention = desc.DaycountConvention
		commonExerciseType       = desc.ExerciseType
	)

	for id, desc := range optionDescriptions {
		if commonCurrency != desc.Currency {
			return &marketdata.Currency{}, "", "", errors.Bug("option id %s: currency mismatch: got %v, expected %v", id, desc.Currency, commonCurrency)
		}

		if commonDaycountConvention != desc.DaycountConvention {
			return &marketdata.Currency{}, "", "", errors.Bug("option id %s: daycount convention mismatch: got %v, expected %v", id, desc.DaycountConvention, commonDaycountConvention)
		}

		if commonExerciseType != desc.ExerciseType {
			return &marketdata.Currency{}, "", "", errors.Bug("option id %s: exercise type mismatch: got %v, expected %v", id, desc.ExerciseType, commonExerciseType)
		}
	}

	return commonCurrency, commonDaycountConvention, commonExerciseType, nil
}

func firstOptionDescription(
	optionDescriptions map[string]marketdata.VanillaOptionDescription,
) (marketdata.VanillaOptionDescription, error) {
	for _, desc := range optionDescriptions {
		return desc, nil
	}

	return marketdata.VanillaOptionDescription{}, errors.NotFound("option descriptions are empty")
}

func insertSurfaceOption(
	ctx context.Context,
	optionChain surfacecalibration.OptionChain,
	quoteDate date.Date,
	t float64,
	k float64,
	price float64,
	desc marketdata.VanillaOptionDescription,
) error {
	var (
		tenor         = surfacecalibration.Tenor(t)
		strike        = surfacecalibration.Strike(k)
		surfaceLogger = logger.FromContext(ctx).WithField("component", "insertSurfaceOption")
	)

	surfaceSlice, ok := optionChain[tenor]
	if !ok {
		surfaceSlice = make(surfacecalibration.SurfaceSlice)
		optionChain[tenor] = surfaceSlice
	}

	pair := surfaceSlice[strike]

	switch desc.OptionType {
	case vanillaoptionpricer.Call:
		if pair.Call != nil {
			surfaceLogger.Warningf("duplicate call for quote date %v tenor %f strike %f", quoteDate, t, k)

			return nil
		}

		pair.Call = &price

	case vanillaoptionpricer.Put:
		if pair.Put != nil {
			surfaceLogger.Warningf("duplicate put for quote date %v tenor %f strike %f", quoteDate, t, k)

			return nil
		}

		pair.Put = &price

	default:
		return errors.Bug("unsupported option type %v", desc.OptionType)
	}

	surfaceSlice[strike] = pair

	return nil
}

func extractSingleStrike(desc marketdata.VanillaOptionDescription) (float64, error) {
	if len(desc.Strikes) != 1 {
		return 0.0, errors.Bug("expected exactly 1 strike, got %d", len(desc.Strikes))
	}

	var s float64
	for _, strike := range desc.Strikes {
		s = strike.Level
	}

	if s == 0.0 {
		return 0.0, errors.Bug("zero strike for option id %s", desc.ID)
	}

	return s, nil
}

// computeYearFraction is a placeholder and should be replaced by the proper
// year fraction logic for the selected daycount convention.
//
//nolint:unparam
func computeYearFraction(quoteDate date.Date, finalFixing date.Date, _ marketdata.DaycountConvention) (float64, error) {
	days := finalFixing.Sub(quoteDate)

	return float64(days) / 365.0, nil
}
