package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
)

const daysPerYear = 365.0

type CurveDefinitionType string

const (
	// ImpliedYield is implied from the price of options, and presented as a yield.
	ImpliedYield CurveDefinitionType = "ImpliedYield"
	// ImpliedTable is implied from the price of options, and presented as a cash amount.
	ImpliedTable CurveDefinitionType = "ImpliedTable"
	// ForecastYield is derived from dividend projections, and presented as a yield.
	ForecastYield CurveDefinitionType = "ForecastYield"
	// ForecastTable is derived from dividend projections, and presented as a cash amount.
	ForecastTable CurveDefinitionType = "ForecastTable"
	// HistoricalYield is inferred from the past dividends.
	HistoricalYield CurveDefinitionType = "HistoricalYield"
)

func businessCal() *calendar.Calendar {
	return calendar.New(calendar.BusinessDays)
}

// dividendYieldCurveEntries defines the response format the client uses for dividend yield curves.
type dividendYieldCurveEntries struct {
	CalculationDate     date.Date                 `json:"calculationDate"`
	CurveDefinitionType CurveDefinitionType       `json:"curveDefinitionType"`
	Entries             []dividendYieldCurveEntry `json:"dividends"`
}

type dividendYieldCurveEntry struct {
	Dividend       float64   `json:"dividendYieldPercent"`
	CashDividend   float64   `json:"dividendCashAmount"`
	ExDividendDate date.Date `json:"exDate"`
	YearFraction   float64   `json:"yearFraction"`
}

// FetchDividendYieldCurve fetches the dividend yield curve for a given id.
func (c Client) FetchDividendYieldCurve(ctx context.Context, id string) (*marketdata.DividendYieldCurve, error) {
	url := c.buildDividendYieldCurveURL(id)

	dividendYieldCurveEntries, err := c.fetchDividendYieldCurve(ctx, url)
	if err != nil {
		return nil, fmt.Errorf("could not fetch dividend yield curve entries for %s: %w", id, err)
	}

	dividendYieldCurve := mapToDividendYieldCurve(ctx, dividendYieldCurveEntries)

	return &dividendYieldCurve, nil
}

func (c Client) buildDividendYieldCurveURL(id string) string {
	return fmt.Sprintf("%s/assets/implied-dividends/%s", c.host, id)
}

func (c Client) fetchDividendYieldCurve(ctx context.Context, url string) (dividendYieldCurveEntries, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return dividendYieldCurveEntries{}, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return dividendYieldCurveEntries{}, fmt.Errorf("could not execute the request: %w", err)
	}
	defer res.Body.Close()

	if err = errorFromHTTP(res); err != nil {
		return dividendYieldCurveEntries{}, err
	}

	var dividendEntries dividendYieldCurveEntries

	if err := json.NewDecoder(res.Body).Decode(&dividendEntries); err != nil {
		return dividendYieldCurveEntries{}, fmt.Errorf("could not decode the timeseries: %w", err)
	}

	return dividendEntries, nil
}

func validateCurveDefinitionType(curveDefinitionType CurveDefinitionType) error {
	if curveDefinitionType == "" {
		return errors.Bug("dividend yield curve without curve definition type")
	}

	if curveDefinitionType != ImpliedYield && curveDefinitionType != ForecastTable && curveDefinitionType != HistoricalYield {
		return errors.Unimplemented("dividend yield curve with unsupported curve definition type %s", curveDefinitionType)
	}

	return nil
}

func validateCalculationDate(calculationDate date.Date) error {
	if calculationDate.IsZero() {
		return errors.Bug("dividend yield curve without calculation date")
	}

	return nil
}

func warnAboutLaggedCalculationDate(ctx context.Context, calculationDate date.Date) {
	logger := logger.FromContext(ctx)

	if calculationDate.After(date.Today()) {
		logger.Warn("dividend yield curve with date in the future")
	}

	if calculationDate.Before(businessCal().Add(date.Today(), -1)) {
		logger.Warn("stale dividend yield curve")
	}
}

func mapToDividendYieldCurve(ctx context.Context, entries dividendYieldCurveEntries) marketdata.DividendYieldCurve {
	logger := logger.FromContext(ctx)

	if err := validateCalculationDate(entries.CalculationDate); err != nil {
		return marketdata.DividendYieldCurve{}
	}

	warnAboutLaggedCalculationDate(ctx, entries.CalculationDate)

	if err := validateCurveDefinitionType(entries.CurveDefinitionType); err != nil {
		return marketdata.DividendYieldCurve{}
	}

	if len(entries.Entries) == 0 {
		// The absence of dividend yield curve entries characterizes an empty dividend yield curve.
		// E.g. for a non-dividend paying stock.
		return marketdata.DividendYieldCurve{}
	}

	dividends := []marketdata.DividendPoint{}

	for _, entry := range entries.Entries {
		if entry.ExDividendDate.IsZero() {
			logger.Warn("dividend yield curve entry without ex dividend date")
			continue
		}

		if entry.ExDividendDate.Before(date.Today()) {
			// an ex dividend date prior to the current spot date
			// is simply ignored, since without effect on the calculations
			if entry.ExDividendDate.Before(businessCal().Add(date.Today(), -1)) {
				// Dividends older than one business day should not be present in the API
				// (Dividends one business day old are expected to be present in the API.)
				logger.Warn("ex dividend date prior to the current spot date")
			}

			continue
		}

		dividends = append(dividends, marketdata.DividendPoint{
			Dividend:       entry.Dividend,
			CashDividend:   entry.CashDividend,
			ExDividendDate: entry.ExDividendDate,
			YearFraction:   float64(entry.ExDividendDate.Sub(date.Today())) / daysPerYear,
		})
	}

	if len(dividends) == 0 {
		return marketdata.DividendYieldCurve{}
	}

	sort.Slice(dividends, func(i, j int) bool {
		return dividends[i].ExDividendDate.Before(dividends[j].ExDividendDate)
	})

	return marketdata.DividendYieldCurve{Dividends: dividends}
}
