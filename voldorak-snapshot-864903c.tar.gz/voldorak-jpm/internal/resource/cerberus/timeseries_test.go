package cerberus

import (
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_FetchTimeseries(t *testing.T) {
	t.Parallel()

	client := buildTestClient(t)

	var (
		from = time.Date(2018, time.November, 1, 0, 0, 0, 0, time.UTC)
		to   = time.Date(2018, time.November, 10, 0, 0, 0, 0, time.UTC)
	)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			t  marketdata.Type
			id string
		}{
			"fund": {
				t:  marketdata.Fund,
				id: "83807b58-6c35-4663-bb5c-a699f1cd148f",
			},
			"index": {
				t:  marketdata.Index,
				id: "83807b58-6c35-4663-bb5c-a699f1cd148f",
			},
			"stock": {
				t:  marketdata.Stock,
				id: "83807b58-6c35-4663-bb5c-a699f1cd148f",
			},
			"fx EUR-CHF": {
				t:  marketdata.FX,
				id: fx.Pair{Foreign: "EUR", Domestic: "CHF"}.String(),
			},
			"fx CHF-EUR": {
				t:  marketdata.FX,
				id: fx.Pair{Foreign: "CHF", Domestic: "EUR"}.String(),
			},
			"fx EUR-USD": {
				t:  marketdata.FX,
				id: fx.Pair{Foreign: "EUR", Domestic: "USD"}.String(),
			},
			"fx USD-EUR": {
				t:  marketdata.FX,
				id: fx.Pair{Foreign: "USD", Domestic: "EUR"}.String(),
			},
			"interest rate": {
				t:  marketdata.InterestRate,
				id: "EUR_LIBOR_3M",
			},
			"swap rate": {
				t:  marketdata.SwapRate,
				id: "USD_SWAP_5Y",
			},
			"OIS rate": {
				t:  marketdata.OISRate,
				id: "GBP_SONIA_OIS_2Y",
			},
			"FX forward rate": {
				t:  marketdata.FXForwardRate,
				id: "JPY_USD_FXFORWARD_1M",
			},
		} {
			t.Run("spot/"+name, func(t *testing.T) {
				t.Parallel()

				res, err := client.FetchSpotTimeseries(t.Context(), tc.t, tc.id, from, to)
				require.NoError(t, err)
				assert.Len(t, res.Entries, 3)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		id := "some-id"

		for name, tc := range map[string]struct {
			t marketdata.Type
		}{
			"invalid market data type": {
				t: marketdata.Type("Unsupported"),
			},
			"invalid fx id": {
				t: marketdata.FX,
			},
		} {
			t.Run("spot/"+name, func(t *testing.T) {
				t.Parallel()

				_, err := client.FetchSpotTimeseries(t.Context(), tc.t, id, from, to)
				require.Error(t, err)
			})
		}
	})
}

func Test_rawValuesToTimeseriesEntries(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	var (
		input = map[string]float64{
			"2006-01-02": 1.2,
			"2006-01-03": 1.3,
			"2006-01-04": 1.4,
			"2006-01-05": 1.5,
		}
		expected = &marketdata.Timeseries{
			Entries: []*marketdata.Entry{
				{
					Date:  date.New(2006, time.January, 2),
					Value: 1.2,
				},
				{
					Date:  date.New(2006, time.January, 3),
					Value: 1.3,
				},
				{
					Date:  date.New(2006, time.January, 4),
					Value: 1.4,
				},
				{
					Date:  date.New(2006, time.January, 5),
					Value: 1.5,
				},
			},
		}
	)

	entries, err := rawValuesToTimeseriesEntries(input)
	require.NoError(t, err)

	assert.Len(t, entries, len(expected.Entries))

	for k, v := range expected.Entries {
		assert.True(t, v.Date.Equal(entries[k].Date))
		assert.InDelta(t, v.Value, entries[k].Value, tol)
	}
}

func Test_isRateType(t *testing.T) {
	t.Parallel()

	for underlyingType, expected := range map[marketdata.Type]bool{
		marketdata.InterestRate:  true,
		marketdata.SwapRate:      true,
		marketdata.OISRate:       true,
		marketdata.FXForwardRate: true,
		marketdata.FX:            false,
		marketdata.Stock:         false,
		marketdata.Fund:          false,
		marketdata.Index:         false,
	} {
		t.Run(string(underlyingType), func(t *testing.T) {
			t.Parallel()

			actual := isRateType(underlyingType)
			assert.Equal(t, expected, actual)
		})
	}
}
