package cerberus

import (
	"fmt"
	"net/http"
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_fetchSpotRateTimeseries(t *testing.T) {
	t.Parallel()

	c := buildTestClient(t)

	var (
		from = date.New(2023, time.January, 1).UTC()
		to   = date.New(2023, time.January, 5).UTC()
	)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, rateType := range map[string]marketdata.Type{
			"interest rate":   marketdata.InterestRate,
			"swap rate":       marketdata.SwapRate,
			"ois rate":        marketdata.OISRate,
			"fx forward rate": marketdata.FXForwardRate,
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				ts, err := c.fetchSpotRateTimeseries(t.Context(), rateType, "valid-id", from, to)
				require.NoError(t, err)

				assert.Equal(t, "valid-id", ts.ID)
				assert.Equal(t, rateType, ts.Type)
				assert.NotEmpty(t, ts.Entries)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id       string
			rateType marketdata.Type
			errCode  int
		}{
			"not found": {
				id:       "not-found",
				rateType: marketdata.InterestRate,
				errCode:  http.StatusNotFound,
			},
			"server error": {
				id:       "server-error",
				rateType: marketdata.InterestRate,
				errCode:  http.StatusInternalServerError,
			},
			"bad response": {
				id:       "bad-json",
				rateType: marketdata.InterestRate,
				errCode:  0,
			},
			"unsupported type": {
				id:       "valid-id",
				rateType: "unsupported",
				errCode:  0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := c.fetchSpotRateTimeseries(t.Context(), tc.rateType, tc.id, from, to)
				require.Error(t, err)

				if tc.errCode != 0 {
					assert.Equal(t, tc.errCode, errors.StatusFrom(err).HTTPCode)
				}
			})
		}
	})
}

func Test_buildSpotRateTimeseriesURL(t *testing.T) {
	t.Parallel()

	const (
		host = "my.test.host:8080"
	)

	var (
		from     = date.New(2023, time.January, 1).UTC()
		to       = date.New(2023, time.January, 5).UTC()
		fromStr  = timestamputil.TimeToString(from)
		toStr    = timestamputil.TimeToString(to)
		basePath = host + "/%s/my-rate/time-series?from=" + fromStr + "&to=" + toStr
	)

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			rateType marketdata.Type
			expected string
		}{
			"interest": {
				rateType: marketdata.InterestRate,
				expected: fmt.Sprintf(basePath, "interest-rates"),
			},
			"swap": {
				rateType: marketdata.SwapRate,
				expected: fmt.Sprintf(basePath, "swap-rates"),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				url, err := buildSpotRateTimeseriesURL(host, "my-rate", tc.rateType, from, to)
				require.NoError(t, err)
				assert.Equal(t, tc.expected, url)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := buildSpotRateTimeseriesURL(host, "my-rate", "unknown", from, to)
		require.Error(t, err)
	})
}

func Test_endpointFromMarketdataRateType(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for rateType, expected := range map[marketdata.Type]string{
			marketdata.SwapRate:      "swap-rates",
			marketdata.OISRate:       "ois-rates",
			marketdata.FXForwardRate: "fx-forward-rates",
			marketdata.InterestRate:  "interest-rates",
		} {
			t.Run(string(rateType), func(t *testing.T) {
				t.Parallel()

				endpoint, err := endpointFromMarketdataRateType(rateType)
				require.NoError(t, err)
				assert.Equal(t, expected, endpoint)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		_, err := endpointFromMarketdataRateType("unknown")
		require.Error(t, err)
	})
}

func Test_rawValuesToTimeseriesEntriesRates(t *testing.T) {
	t.Parallel()

	const tol = 1e-15

	var (
		input = map[string]float64{
			"2006-01-02": 1.2,
			"2006-01-03": 1.3,
			"2006-01-04": 1.4,
			"2006-01-05": 1.5,
			"2006-01-06": -1.0,
		}
		expected = &marketdata.Timeseries{
			Entries: []*marketdata.Entry{
				{
					Date:  date.New(2006, time.January, 2),
					Value: 1.2,
				},
				{
					Date:  date.New(2006, time.January, 3),
					Value: 1.3,
				},
				{
					Date:  date.New(2006, time.January, 4),
					Value: 1.4,
				},
				{
					Date:  date.New(2006, time.January, 5),
					Value: 1.5,
				},
				{
					Date:  date.New(2006, time.January, 6),
					Value: minRateValue,
				},
			},
		}
	)

	entries, err := rawValuesToTimeseriesEntriesRates(input)
	require.NoError(t, err)

	assert.Len(t, entries, len(expected.Entries))

	for k, v := range expected.Entries {
		assert.True(t, v.Date.Equal(entries[k].Date))
		assert.InDelta(t, v.Value, entries[k].Value, tol)
	}
}
