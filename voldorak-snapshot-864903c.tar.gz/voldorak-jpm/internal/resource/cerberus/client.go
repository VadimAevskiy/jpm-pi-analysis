package cerberus

import (
	"fmt"
	"net/http"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/go-client/httpclient"
)

// Client wraps an HTTP client and the host address.
type Client struct {
	host   string
	client *http.Client
}

// NewClient creates a new client from the input config.
func NewClient(cfg *Config) (*Client, error) {
	if cfg == nil {
		return nil, errors.Bug("the configuration is missing")
	}

	if cfg.Host == "" {
		return nil, errors.Bug("couldn't provide the host from config")
	}

	timeout, err := time.ParseDuration(cfg.Timeout)
	if err != nil {
		return nil, fmt.Errorf("could not parse timeout duration: %w", err)
	}

	return &Client{
		host:   cfg.Host,
		client: httpclient.NewClient(timeout, int(cfg.Retry)),
	}, nil
}

// Close closes the client connection.
func (c *Client) Close() error {
	return nil
}
