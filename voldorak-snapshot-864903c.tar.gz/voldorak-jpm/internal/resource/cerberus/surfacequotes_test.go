package cerberus

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"
	"time"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	surfcalib "github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_fetchSurfaceIDs(t *testing.T) {
	t.Parallel()

	t.Run("success", func(t *testing.T) {
		t.Parallel()

		client := newTestHTTPClient(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			assert.Equal(t, "/surfaces", r.URL.Path)

			respBytes, err := json.Marshal(surfaceIDs{
				Entries: []string{"surface-1", "surface-2", "surface-3"},
			})
			assert.NoError(t, err)

			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write(respBytes)
		}))

		url := client.host + "/surfaces"

		got, err := client.fetchSurfaceIDs(t.Context(), url)
		require.NoError(t, err)
		assert.Equal(t, []string{"surface-1", "surface-2", "surface-3"}, got)
	})

	t.Run("invalid url", func(t *testing.T) {
		t.Parallel()

		client := newTestHTTPClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`[]`))
		}))

		got, err := client.fetchSurfaceIDs(t.Context(), "://bad-url")
		assert.Empty(t, got)
		require.Error(t, err)
		assert.ErrorContains(t, err, "could not create the request")
	})

	t.Run("not found", func(t *testing.T) {
		t.Parallel()

		client := newTestHTTPClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusNotFound)
		}))

		url := client.host + "/surfaces"

		got, err := client.fetchSurfaceIDs(t.Context(), url)
		assert.Nil(t, got)
		require.Error(t, err)
		assert.ErrorContains(t, err, "surface IDs not found")
	})

	t.Run("precondition failed", func(t *testing.T) {
		t.Parallel()

		client := newTestHTTPClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusPreconditionFailed)
		}))

		url := client.host + "/surfaces"

		got, err := client.fetchSurfaceIDs(t.Context(), url)
		assert.Nil(t, got)
		require.Error(t, err)
		assert.ErrorContains(t, err, "failed to fetch surface IDs due to precondition")
	})

	t.Run("unexpected provider status", func(t *testing.T) {
		t.Parallel()

		client := newTestHTTPClient(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusInternalServerError)
		}))

		url := client.host + "/surfaces"

		got, err := client.fetchSurfaceIDs(t.Context(), url)
		assert.Nil(t, got)
		require.Error(t, err)
		require.ErrorContains(t, err, "unexpected status")
		assert.ErrorContains(t, err, "while fetching surface IDs")
	})
}

func newTestHTTPClient(t *testing.T, h http.Handler) Client {
	t.Helper()

	server := httptest.NewServer(h)
	t.Cleanup(server.Close)

	client, err := NewClient(&Config{
		Host:    server.URL,
		Timeout: "1s",
	})
	require.NoError(t, err)

	return *client
}

func sameURL(r *http.Request, raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}

	return r.URL.Path == u.Path && r.URL.RawQuery == u.RawQuery
}

func writeJSON(t *testing.T, w http.ResponseWriter, body any) {
	t.Helper()

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	require.NoError(t, json.NewEncoder(w).Encode(body))
}

func bulkOK(t *testing.T, id string, payload any) map[string]any {
	t.Helper()

	b, err := json.Marshal(payload)
	require.NoError(t, err)

	return map[string]any{
		keyFromID(id): map[string]any{
			"Status": http.StatusOK,
			"Data":   json.RawMessage(b),
		},
	}
}

func descBody(id string) map[string]any {
	return map[string]any{
		"id":                 id,
		"currency":           map[string]any{},
		"issuer":             map[string]any{},
		"callPut":            "Call",
		"finalFixing":        "2026-12-31",
		"underlyings":        map[string]any{"u1": map[string]any{"id": "underlying-1"}},
		"strikes":            map[string]any{"s1": map[string]any{"strike": 55.0}},
		"daycountConvention": "ActAct",
		"exerciseType":       "European",
	}
}

func quoteBody() map[string]any {
	return map[string]any{
		"unit": map[string]any{
			"id":   "Nominal",
			"name": "Nominal",
		},
		"values": map[string]any{
			"2020-02-03": 10664.95,
		},
	}
}

func makeFetchOptionsClient(
	t *testing.T,
	at *date.Date,
	underlyingID string,
	surfaceID string,
	withSurfaceIDs bool,
	withDescriptions bool,
	withQuotes bool,
	descriptionsBody any,
) Client {
	t.Helper()

	var client Client

	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case sameURL(r, client.buildSurfaceIDsURL(underlyingID, at)):
			if !withSurfaceIDs {
				w.WriteHeader(http.StatusNotFound)
				return
			}

			writeJSON(t, w, surfaceIDs{
				Entries: []string{surfaceID},
			})

		case sameURL(r, client.buildOptionDescriptionsURL(at)):
			if withDescriptions {
				writeJSON(t, w, bulkOK(t, surfaceID, descriptionsBody))
				return
			}

			http.NotFound(w, r)

		case sameURL(r, client.buildOptionQuotesURL(at)):
			if withQuotes {
				writeJSON(t, w, bulkOK(t, surfaceID, quoteBody()))
				return
			}

			http.NotFound(w, r)

		default:
			http.NotFound(w, r)
		}
	})

	client = newTestHTTPClient(t, handler)

	return client
}

func Test_Client_FetchOptions(t *testing.T) {
	t.Parallel()

	at := date.New(2020, time.February, 3)
	underlyingID := "underlying-1"
	surfaceID := validAsset

	t.Run("success", func(t *testing.T) {
		t.Parallel()

		client := makeFetchOptionsClient(
			t,
			&at,
			underlyingID,
			surfaceID,
			true,
			true,
			true,
			descBody(surfaceID),
		)

		got, err := client.FetchOptions(t.Context(), underlyingID, &at)
		require.NoError(t, err)
		assert.NotEqual(t, surfcalib.OptionChainDescription{}, got)
		assert.NotEmpty(t, got.OptionChain)
		assert.NotNil(t, got.Currency)
		assert.NotEmpty(t, got.DaycountConvention)
		assert.NotEmpty(t, got.ExerciseType)
	})

	t.Run("surface ids error", func(t *testing.T) {
		t.Parallel()

		client := makeFetchOptionsClient(
			t,
			&at,
			underlyingID,
			surfaceID,
			false,
			false,
			false,
			nil,
		)

		got, err := client.FetchOptions(t.Context(), underlyingID, &at)
		requireEmptyOptionsError(t, got, err, "could not fetch volatility surface IDs "+underlyingID)
	})

	t.Run("descriptions error", func(t *testing.T) {
		t.Parallel()

		client := makeFetchOptionsClient(
			t,
			&at,
			underlyingID,
			surfaceID,
			true,
			true,
			true,
			"not a vanilla option description object",
		)

		got, err := client.FetchOptions(t.Context(), underlyingID, &at)
		requireEmptyOptionsError(t, got, err, "could not fetch option descriptions for underlying "+underlyingID)
	})

	t.Run("quotes error", func(t *testing.T) {
		t.Parallel()

		client := makeFetchOptionsClient(
			t,
			&at,
			underlyingID,
			surfaceID,
			true,
			true,
			false,
			descBody(surfaceID),
		)

		got, err := client.FetchOptions(t.Context(), underlyingID, &at)
		requireEmptyOptionsError(t, got, err, "could not fetch option quotes for underlying "+underlyingID)
	})
}

func requireEmptyOptionsError(
	t *testing.T,
	got surfcalib.OptionChainDescription,
	err error,
	expectedErr string,
) {
	t.Helper()

	require.Error(t, err)
	assert.Equal(t, surfcalib.OptionChainDescription{}, got)
	assert.ErrorContains(t, err, expectedErr)
}

func Test_validateDescriptionsConsistency(t *testing.T) {
	t.Parallel()

	usd := &marketdata.Currency{ID: "USD"}
	eur := &marketdata.Currency{ID: "EUR"}
	chf := &marketdata.Currency{ID: "CHF"}

	t.Run("valid descriptions", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input                marketdata.VanillaOptionDescriptions
			expectedCurrency     *marketdata.Currency
			expectedDaycount     marketdata.DaycountConvention
			expectedExerciseType marketdata.ExerciseType
		}{
			"single description": {
				input: marketdata.VanillaOptionDescriptions{
					"option-1": {
						Currency:           usd,
						DaycountConvention: "ACT/365",
						ExerciseType:       "European",
					},
				},
				expectedCurrency:     usd,
				expectedDaycount:     "ACT/365",
				expectedExerciseType: "European",
			},
			"multiple consistent descriptions": {
				input: marketdata.VanillaOptionDescriptions{
					"option-1": {
						Currency:           chf,
						DaycountConvention: "30/360",
						ExerciseType:       "American",
					},
					"option-2": {
						Currency:           chf,
						DaycountConvention: "30/360",
						ExerciseType:       "American",
					},
				},
				expectedCurrency:     chf,
				expectedDaycount:     "30/360",
				expectedExerciseType: "American",
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				currency, daycountConvention, exerciseType, err := validateDescriptionsConsistency(tc.input)
				require.NoError(t, err)
				assert.Equal(t, tc.expectedCurrency, currency)
				assert.Equal(t, tc.expectedDaycount, daycountConvention)
				assert.Equal(t, tc.expectedExerciseType, exerciseType)
			})
		}
	})

	t.Run("invalid descriptions", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input    marketdata.VanillaOptionDescriptions
			expected errors.StatusCode
		}{
			"empty descriptions": {
				input:    marketdata.VanillaOptionDescriptions{},
				expected: errors.StatusCodeBug,
			},
			"currency mismatch": {
				input: marketdata.VanillaOptionDescriptions{
					"option-1": {
						Currency:           usd,
						DaycountConvention: "ACT/365",
						ExerciseType:       "European",
					},
					"option-2": {
						Currency:           eur,
						DaycountConvention: "ACT/365",
						ExerciseType:       "European",
					},
				},
				expected: errors.StatusCodeBug,
			},
			"daycount mismatch": {
				input: marketdata.VanillaOptionDescriptions{
					"option-1": {
						Currency:           usd,
						DaycountConvention: "ACT/365",
						ExerciseType:       "European",
					},
					"option-2": {
						Currency:           usd,
						DaycountConvention: "30/360",
						ExerciseType:       "European",
					},
				},
				expected: errors.StatusCodeBug,
			},
			"exercise type mismatch": {
				input: marketdata.VanillaOptionDescriptions{
					"option-1": {
						Currency:           usd,
						DaycountConvention: "ACT/365",
						ExerciseType:       "European",
					},
					"option-2": {
						Currency:           usd,
						DaycountConvention: "ACT/365",
						ExerciseType:       "American",
					},
				},
				expected: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, _, err := validateDescriptionsConsistency(tc.input)
				require.Error(t, err)
				errors.AssertStatus(t, tc.expected, err)
			})
		}
	})
}

func Test_extractSingleStrike(t *testing.T) {
	t.Parallel()

	t.Run("valid strike extraction", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input    marketdata.VanillaOptionDescription
			expected float64
		}{
			"single non-zero strike": {
				input: marketdata.VanillaOptionDescription{
					ID: "option-1",
					Strikes: map[string]*marketdata.Strike{
						"strike-1": {
							Level: 123.45,
						},
					},
				},
				expected: 123.45,
			},
			"single integer strike": {
				input: marketdata.VanillaOptionDescription{
					ID: "option-2",
					Strikes: map[string]*marketdata.Strike{
						"strike-1": {
							Level: 100.0,
						},
					},
				},
				expected: 100.0,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := extractSingleStrike(tc.input)
				require.NoError(t, err)
				assert.InDelta(t, tc.expected, got, 1e-9)
			})
		}
	})

	t.Run("invalid strike extraction", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input    marketdata.VanillaOptionDescription
			expected errors.StatusCode
		}{
			"no strikes": {
				input: marketdata.VanillaOptionDescription{
					ID:      "option-1",
					Strikes: map[string]*marketdata.Strike{},
				},
				expected: errors.StatusCodeBug,
			},
			"multiple strikes": {
				input: marketdata.VanillaOptionDescription{
					ID: "option-2",
					Strikes: map[string]*marketdata.Strike{
						"strike-1": {Level: 100.0},
						"strike-2": {Level: 110.0},
					},
				},
				expected: errors.StatusCodeBug,
			},
			"multiple identical strikes": {
				input: marketdata.VanillaOptionDescription{
					ID: "option-2",
					Strikes: map[string]*marketdata.Strike{
						"strike-1": {Level: 100.0},
						"strike-2": {Level: 100.0},
					},
				},
				expected: errors.StatusCodeBug,
			},
			"single zero strike": {
				input: marketdata.VanillaOptionDescription{
					ID: "option-3",
					Strikes: map[string]*marketdata.Strike{
						"strike-1": {Level: 0.0},
					},
				},
				expected: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := extractSingleStrike(tc.input)
				require.Error(t, err)
				errors.AssertStatus(t, tc.expected, err)
			})
		}
	})
}

func pairTestHelper(t *testing.T, pair surfcalib.OptionPair, expectedCall, expectedPut *float64) {
	t.Helper()

	const tol = 1e-9

	gotCall, err := pair.Price(vanillaoptionpricer.Call)

	switch expectedCall == nil {
	case true:
		require.Error(t, err)
	case false:
		require.NoError(t, err)
		assert.InDelta(t, *expectedCall, gotCall, tol)
	}

	gotPut, err := pair.Price(vanillaoptionpricer.Put)

	switch expectedPut == nil {
	case true:
		require.Error(t, err)
	case false:
		require.NoError(t, err)
		assert.InDelta(t, *expectedPut, gotPut, tol)
	}
}

func Test_insertSurfaceOption(t *testing.T) {
	t.Parallel()

	var (
		quoteDate = date.New(2024, time.January, 1)
		tau       = 1.0
		strike    = 100.0
		price     = 12.5
	)

	t.Run("valid insertions", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			initial      surfcalib.OptionChain
			price        float64
			desc         marketdata.VanillaOptionDescription
			expectedCall *float64
			expectedPut  *float64
		}{
			"insert call into empty chain": {
				initial: make(surfcalib.OptionChain),
				price:   price,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Call,
				},
				expectedCall: &price,
				expectedPut:  nil,
			},
			"insert put into empty chain": {
				initial: make(surfcalib.OptionChain),
				price:   price,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Put,
				},

				expectedCall: nil,
				expectedPut:  &price,
			},
			"insert call when put already exists": {
				initial: surfcalib.OptionChain{
					surfcalib.Tenor(tau): surfcalib.SurfaceSlice{
						surfcalib.Strike(strike): surfcalib.OptionPair{
							Put: new(7.0),
						},
					},
				},
				price: price,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Call,
				},
				expectedCall: &price,
				expectedPut:  new(7.0),
			},
			"insert put when call already exists": {
				initial: surfcalib.OptionChain{
					surfcalib.Tenor(tau): surfcalib.SurfaceSlice{
						surfcalib.Strike(strike): surfcalib.OptionPair{
							Call: new(9.0),
						},
					},
				},
				price: price,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Put,
				},
				expectedCall: new(9.0),
				expectedPut:  &price,
			},
			"duplicate call is ignored": {
				initial: surfcalib.OptionChain{
					surfcalib.Tenor(tau): surfcalib.SurfaceSlice{
						surfcalib.Strike(strike): surfcalib.OptionPair{
							Call: new(8.0),
						},
					},
				},
				price: 99.0,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Call,
				},
				expectedCall: new(8.0),
				expectedPut:  nil,
			},
			"duplicate put is ignored": {
				initial: surfcalib.OptionChain{
					surfcalib.Tenor(tau): surfcalib.SurfaceSlice{
						surfcalib.Strike(strike): surfcalib.OptionPair{
							Put: new(6.0),
						},
					},
				},
				price: 99.0,
				desc: marketdata.VanillaOptionDescription{
					OptionType: vanillaoptionpricer.Put,
				},
				expectedPut:  new(6.0),
				expectedCall: nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				err := insertSurfaceOption(t.Context(), tc.initial, quoteDate, tau, strike, tc.price, tc.desc)
				require.NoError(t, err)

				pair := tc.initial[surfcalib.Tenor(tau)][surfcalib.Strike(strike)]

				pairTestHelper(t, pair, tc.expectedCall, tc.expectedPut)
			})
		}
	})

	t.Run("invalid insertions", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			desc     marketdata.VanillaOptionDescription
			expected errors.StatusCode
		}{
			"unsupported option type": {
				desc: marketdata.VanillaOptionDescription{
					OptionType: "",
				},
				expected: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				OptionChain := make(surfcalib.OptionChain)

				err := insertSurfaceOption(t.Context(), OptionChain, quoteDate, tau, strike, price, tc.desc)
				require.Error(t, err)
				errors.AssertStatus(t, tc.expected, err)
			})
		}
	})
}

func Test_mapToSurfaceOptions(t *testing.T) {
	t.Parallel()

	var (
		quoteDate1   = date.New(2024, time.January, 1)
		quoteDate2   = date.New(2024, time.January, 2)
		finalFixing1 = date.New(2025, time.January, 1)
		finalFixing2 = date.New(2025, time.July, 1)
	)

	t.Run("valid mappings", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			descriptions marketdata.VanillaOptionDescriptions
			quotes       marketdata.VanillaQuotes
			at           date.Date

			expectedQuoteDate1 *date.Date
			expectedTenor1     float64
			expectedStrike1    float64
			expectedCall1      *float64
			expectedPut1       *float64

			expectedQuoteDate2 *date.Date
			expectedTenor2     float64
			expectedStrike2    float64
			expectedCall2      *float64
			expectedPut2       *float64
		}{
			"single call option single quote date": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"option-1": {
						ID:                 "option-1",
						OptionType:         vanillaoptionpricer.Call,
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
						},
					},
				},
				quotes: marketdata.VanillaQuotes{
					"option-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 12.5,
						},
					},
				},
				at:                 quoteDate1,
				expectedQuoteDate1: &quoteDate1,
				expectedTenor1:     float64(finalFixing1.Sub(quoteDate1)) / 365.0,
				expectedStrike1:    100.0,
				expectedCall1:      new(12.5),
				expectedPut1:       nil,
			},
			"call and put same quote date and strike": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"call-1": {
						ID:                 "call-1",
						OptionType:         vanillaoptionpricer.Call,
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
						},
					},
					"put-1": {
						ID:                 "put-1",
						OptionType:         vanillaoptionpricer.Put,
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
						},
					},
				},
				quotes: marketdata.VanillaQuotes{
					"call-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 10.0,
						},
					},
					"put-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 8.0,
						},
					},
				},
				at:                 quoteDate1,
				expectedQuoteDate1: &quoteDate1,
				expectedTenor1:     float64(finalFixing1.Sub(quoteDate1)) / 365.0,
				expectedStrike1:    100.0,
				expectedCall1:      new(10.0),
				expectedPut1:       new(8.0),
			},
			"single option multiple quote dates": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"option-1": {
						ID:                 "option-1",
						OptionType:         vanillaoptionpricer.Call,
						FinalFixing:        finalFixing2,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 95.0},
						},
					},
				},
				quotes: marketdata.VanillaQuotes{
					"option-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 14.0,
							quoteDate2: 13.5,
						},
					},
				},
				at: quoteDate2,

				expectedQuoteDate2: &quoteDate2,
				expectedTenor2:     float64(finalFixing2.Sub(quoteDate2)) / 365.0,
				expectedStrike2:    95.0,
				expectedCall2:      new(13.5),
				expectedPut2:       nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got, err := mapToSurfaceOptions(t.Context(), tc.descriptions, tc.quotes, &tc.at)
				require.NoError(t, err)

				if tc.expectedQuoteDate1 != nil {
					pair1 := got[surfcalib.Tenor(tc.expectedTenor1)][surfcalib.Strike(tc.expectedStrike1)]
					pairTestHelper(t, pair1, tc.expectedCall1, tc.expectedPut1)
				}

				if tc.expectedQuoteDate2 != nil {
					pair2 := got[surfcalib.Tenor(tc.expectedTenor2)][surfcalib.Strike(tc.expectedStrike2)]
					pairTestHelper(t, pair2, tc.expectedCall2, tc.expectedPut2)
				}
			})
		}
	})

	t.Run("invalid mappings", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			descriptions marketdata.VanillaOptionDescriptions
			quotes       marketdata.VanillaQuotes
			expected     errors.StatusCode
			at           date.Date
		}{
			"missing quotes for option": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"option-1": {
						ID:                 "option-1",
						OptionType:         vanillaoptionpricer.Call,
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
						},
					},
				},
				quotes:   marketdata.VanillaQuotes{},
				at:       quoteDate1,
				expected: errors.StatusCodeBug,
			},
			"invalid strike extraction": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"option-1": {
						ID:                 "option-1",
						OptionType:         vanillaoptionpricer.Call,
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
							"strike-2": {Level: 110.0},
						},
					},
				},
				quotes: marketdata.VanillaQuotes{
					"option-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 12.5,
						},
					},
				},
				expected: errors.StatusCodeBug,
			},
			"unsupported option type": {
				descriptions: marketdata.VanillaOptionDescriptions{
					"option-1": {
						ID:                 "option-1",
						FinalFixing:        finalFixing1,
						DaycountConvention: marketdata.DaycountConvention("ActAct"),
						Strikes: map[string]*marketdata.Strike{
							"strike-1": {Level: 100.0},
						},
					},
				},
				quotes: marketdata.VanillaQuotes{
					"option-1": {
						Quotes: map[date.Date]float64{
							quoteDate1: 12.5,
						},
					},
				},
				at:       quoteDate1,
				expected: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := mapToSurfaceOptions(t.Context(), tc.descriptions, tc.quotes, &tc.at)
				require.Error(t, err)
				errors.AssertStatus(t, tc.expected, err)
			})
		}
	})
}
