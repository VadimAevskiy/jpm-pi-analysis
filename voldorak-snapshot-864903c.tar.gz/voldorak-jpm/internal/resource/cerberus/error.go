package cerberus

import (
	"fmt"
	"net/http"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

// errorFromHTTP extracts the error from an HTTP error.
// If the error is not found, it adds the appropriate status and tag.
// Any other error is matched to a bug.
func errorFromHTTP(resp *http.Response) error {
	err, statusCode, _ := errors.FromHTTP(resp)
	if err == nil {
		return nil
	}

	err = fmt.Errorf("error from downstream service: %w", err)

	if statusCode == errors.StatusCodeNotFound {
		return errors.SetTag(errors.NotFound("timeseries data not found: %w", err), tag.TimeSeriesDataNotFound)
	}

	return errors.Bug("%w", err)
}

// httpStatusToError maps an input status code into an error with
// formatting directives. The output error is always non-nil.
func httpStatusToError(statusCode int, format string, args ...any) error {
	switch statusCode {
	case http.StatusNotFound:
		return errors.NotFound(format, args...)

	default:
		return errors.Bug(format, args...)
	}
}
