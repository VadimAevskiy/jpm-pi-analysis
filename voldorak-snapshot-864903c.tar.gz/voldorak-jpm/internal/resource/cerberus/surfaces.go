package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// FetchVolatilitySurface fetches the volatility surface for a given id.
func (c Client) FetchVolatilitySurface(ctx context.Context, id string) (*marketdata.VolatilitySurface, error) {
	url := c.buildVolatilitySurfaceURL(id)

	surfaceEntries, err := c.fetchVolatilitySurface(ctx, url)
	if err != nil {
		return nil, fmt.Errorf("could not fetch volatility surface entries for %s: %w", id, err)
	}

	volatilitySurface, err := mapToVolatilitySurface(surfaceEntries)
	if err != nil {
		return nil, fmt.Errorf("could not map volatility surface entries into pricing data: %w", err)
	}

	return &volatilitySurface, nil
}

func (c Client) buildVolatilitySurfaceURL(id string) string {
	return fmt.Sprintf("%s/assets/volatility-surfaces/%s", c.host, id)
}

func (c Client) fetchVolatilitySurface(ctx context.Context, url string) (volatilitySurfaceEntries, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return volatilitySurfaceEntries{}, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return volatilitySurfaceEntries{}, fmt.Errorf("could not execute the request: %w", err)
	}
	defer res.Body.Close()

	if err := errorFromHTTP(res); err != nil {
		return volatilitySurfaceEntries{}, err
	}

	var surfaceEntries volatilitySurfaceEntries
	if err := json.NewDecoder(res.Body).Decode(&surfaceEntries); err != nil {
		return volatilitySurfaceEntries{}, fmt.Errorf("could not decode the timeseries: %w", err)
	}

	return surfaceEntries, nil
}

// volatilitySurface defines the response format the client uses for volatility surfaces.
type volatilitySurfaceEntries struct {
	Entries []volatilitySurfaceEntry `json:"surfaces"`
}

type volatilitySurfaceEntry struct {
	Tenor      string  `json:"tenor"`
	Strike     float64 `json:"strike"`
	Volatility float64 `json:"volatility"`
}

func mapToVolatilitySurface(entries volatilitySurfaceEntries) (marketdata.VolatilitySurface, error) {
	if len(entries.Entries) == 0 {
		return marketdata.VolatilitySurface{}, errors.NotFound("volatility surface entries are empty")
	}

	const scalingFactor = 100.0

	// Get tenor and strike lists.
	tenorsMap := make(map[marketdata.Tenor]struct{})
	strikesMap := make(map[float64]struct{})
	surfaceMap := make(map[marketdata.Tenor]map[float64]float64)

	for _, entry := range entries.Entries {
		tenor := marketdata.Tenor(entry.Tenor)
		tenorsMap[tenor] = struct{}{}
		strikesMap[entry.Strike] = struct{}{}

		if _, ok := surfaceMap[tenor]; !ok {
			surfaceMap[tenor] = make(map[float64]float64)
		}

		surfaceMap[tenor][entry.Strike] = entry.Volatility / scalingFactor
	}

	// Sort slices of tenors and strikes.
	type tenorPair struct {
		tenor        marketdata.Tenor
		yearFraction float64
	}

	tenorPairsSlice := make([]tenorPair, 0, len(tenorsMap))
	for tenor := range tenorsMap {
		tenorYearFraction, err := tenor.ToYearFraction()
		if err != nil {
			return marketdata.VolatilitySurface{}, fmt.Errorf("could not convert tenor %s to year fraction: %w", tenor, err)
		}

		tenorPairsSlice = append(tenorPairsSlice, tenorPair{
			tenor:        tenor,
			yearFraction: tenorYearFraction,
		})
	}

	sort.Slice(tenorPairsSlice, func(i, j int) bool {
		return tenorPairsSlice[i].yearFraction < tenorPairsSlice[j].yearFraction
	})

	strikesSlice := make([]float64, 0, len(strikesMap))
	for strike := range strikesMap {
		strikesSlice = append(strikesSlice, strike)
	}

	sort.Float64s(strikesSlice)

	// Store the volatility surface data in a two-dimensional slice.
	surfaceData := make([][]float64, 0, len(tenorPairsSlice))

	tenorYearFractions := make([]float64, 0, len(tenorPairsSlice))
	for _, tenorPair := range tenorPairsSlice {
		surfaceSlice := make([]float64, 0, len(strikesSlice))

		for _, strike := range strikesSlice {
			volValue, ok := surfaceMap[tenorPair.tenor][strike]
			if !ok {
				return marketdata.VolatilitySurface{}, errors.Bug("could not find volatility value for tenor %s and strike %f in volatility surface", tenorPair.tenor, strike)
			}

			surfaceSlice = append(surfaceSlice, volValue)
		}

		surfaceData = append(surfaceData, surfaceSlice)
		tenorYearFractions = append(tenorYearFractions, tenorPair.yearFraction)
	}

	return marketdata.VolatilitySurface{
		Data:               surfaceData,
		TenorYearFractions: tenorYearFractions,
		Strikes:            strikesSlice,
	}, nil
}
