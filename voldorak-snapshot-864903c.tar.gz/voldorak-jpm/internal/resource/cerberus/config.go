package cerberus

// Config describes the Cerberus configuration structure.
type Config struct {
	Host                       string `yaml:"host"`
	Timeout                    string `yaml:"timeout"`
	Retry                      uint32 `yaml:"retry"`
	SSVICalibrationActivated   bool   `yaml:"ssvi_calibration_activated"`
	HestonCalibrationActivated bool   `yaml:"heston_calibration_activated"`
}

// DefaultConfig creates a default config.
func DefaultConfig() *Config {
	const defaultRetry = 3

	return &Config{
		Host:                       "localhost:8888",
		Timeout:                    "6s",
		Retry:                      defaultRetry,
		SSVICalibrationActivated:   false,
		HestonCalibrationActivated: false,
	}
}
