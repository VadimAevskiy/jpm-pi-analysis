package cerberus

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/fx"
)

const horizon = 90

// FetchFXCorrelation fetches the correlation between two currency pairs sharing a pivot currency.
func (c Client) FetchFXCorrelation(ctx context.Context, domAgainstRef, forAgainstRef *fx.Pair, snapshot time.Time) (float64, error) {
	rawBody, err := json.Marshal(struct {
		ToDate  string   `json:"toDate"`
		Horizon int      `json:"horizon"`
		IDs     []string `json:"ids"`
	}{
		ToDate:  snapshot.Format(time.RFC3339Nano),
		Horizon: horizon,
		IDs: []string{
			currencyPairToIdentifier(domAgainstRef),
			currencyPairToIdentifier(forAgainstRef),
		},
	})
	if err != nil {
		return 0.0, fmt.Errorf("failed to marshal request to JSON: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.host+"/timeseries/correlation", bytes.NewReader(rawBody))
	if err != nil {
		return 0.0, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return 0.0, fmt.Errorf("could not execute the request: %w", err)
	}
	defer res.Body.Close()

	if err := errorFromHTTP(res); err != nil {
		return 0.0, err
	}

	var response []struct {
		Correlation float64 `json:"correlation"`
	}

	if err := json.NewDecoder(res.Body).Decode(&response); err != nil {
		return 0.0, fmt.Errorf("could not decode the response: %w", err)
	}

	if len(response) != 1 {
		return 0.0, fmt.Errorf("received more than one correlation: %w", err)
	}

	return response[0].Correlation, nil
}

func currencyPairToIdentifier(p *fx.Pair) string {
	return fmt.Sprintf("fx/%s%s", p.Foreign, p.Domestic)
}
