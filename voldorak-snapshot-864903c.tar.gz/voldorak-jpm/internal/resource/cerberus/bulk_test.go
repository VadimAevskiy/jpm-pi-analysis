package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"testing"
	"time"

	"github.com/edgelaboratories/eve/pkg/pricing/vanillaoptionpricer"
	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_bulkDescription(t *testing.T) {
	t.Parallel()

	var (
		mockDate           = date.New(2024, time.January, 1)
		mockDateOneYearAgo = date.New(2023, time.January, 1)
	)

	t.Run("valid responses", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			at       *date.Date
			assetIDs []string
			expected assetMinimalDescription
		}{
			"without asOf date": {
				at:       nil,
				assetIDs: []string{validAsset},
				expected: assetMinimalDescription{
					ID: validAsset,
					Currency: currency{
						Name: "CHF",
						ID:   "CHF",
					},
					Type:    "StructuredAsset",
					SubType: "BarrierReverseConvertible",
				},
			},
			"with mock date": {
				at:       &mockDate,
				assetIDs: []string{validAsset},
				expected: assetMinimalDescription{
					ID: validAsset,
					Currency: currency{
						Name: "CHF",
						ID:   "CHF",
					},
					Type:    "StructuredAsset",
					SubType: "BarrierReverseConvertible",
				},
			},
			"with one year earlier mock date": {
				at:       &mockDateOneYearAgo,
				assetIDs: []string{validAsset},
				expected: assetMinimalDescription{
					ID: validAsset,
					Currency: currency{
						Name: "USD",
						ID:   "USD",
					},
					Type:    "StructuredAsset",
					SubType: "BarrierReverseConvertible",
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				client, _ := newTestClient(t)

				data, err := client.bulk(t.Context(), tc.assetIDs, makeBulkDescriptionURL(client.host, tc.at))
				require.NoError(t, err)

				require.Len(t, data, 1)

				v, ok := data[validAsset]
				require.True(t, ok)

				var asset assetMinimalDescription
				require.NoError(t, json.Unmarshal(v, &asset))
				assert.Equal(t, tc.expected, asset)
			})
		}
	})

	t.Run("invalid asset responses", func(t *testing.T) {
		t.Parallel()

		// Since the first error encountered is randomly returned
		// depending on the order the responses are iterated over
		// in the response, we only check cases where the returned
		// status is unambiguous.
		for name, tc := range map[string]struct {
			input    []string
			expected errors.StatusCode
		}{
			"invalid asset": {
				input:    []string{invalidAsset},
				expected: errors.StatusCodeNotFound,
			},
			"valid and invalid assets": {
				input:    []string{invalidAsset, validAsset},
				expected: errors.StatusCodeNotFound,
			},
			"erroneous asset": {
				input:    []string{erroneousAsset},
				expected: errors.StatusCodeBug,
			},
			"valid and erroneous assets": {
				input:    []string{erroneousAsset, validAsset},
				expected: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				client, _ := newTestClient(t)

				_, err := client.bulk(t.Context(), tc.input, makeBulkDescriptionURL(client.host, nil))
				require.Error(t, err)
				errors.AssertStatus(t, tc.expected, err)
			})
		}
	})

	t.Run("invalid bulk endpoint response", func(t *testing.T) {
		t.Parallel()

		_, transport := newTestClient(t)

		client := Client{
			host: unstableHost,
			client: &http.Client{
				Transport: transport,
			},
		}

		_, err := client.bulk(t.Context(), []string{validAsset}, makeBulkDescriptionURL(client.host, nil))
		require.Error(t, err)
	})

	t.Run("no bulk endpoint response", func(t *testing.T) {
		t.Parallel()

		_, transport := newTestClient(t)

		client := Client{
			host: "some.unknown.host",
			client: &http.Client{
				Transport: transport,
			},
		}

		_, err := client.bulk(t.Context(), []string{validAsset}, makeBulkDescriptionURL(client.host, nil))
		require.Error(t, err)
	})
}

func Test_extractDataFromBulkResponse(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		res, err := extractDataFromBulkResponse(bulkResponse{
			keyFromID(validAsset): {
				Status: http.StatusOK,
			},
		})
		require.NoError(t, err)
		assert.Len(t, res, 1)
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, input := range map[string]bulkResponse{
			"invalid key": {
				"not a valid key": {
					Status: http.StatusOK,
				},
			},
			"invalid asset": {
				keyFromID(invalidAsset): {
					Status: http.StatusExpectationFailed,
				},
			},
			"valid and invalid asset": {
				keyFromID(validAsset): {
					Status: http.StatusOK,
				},
				keyFromID(invalidAsset): {
					Status: http.StatusExpectationFailed,
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := extractDataFromBulkResponse(input)
				require.Error(t, err)
			})
		}
	})
}

func Test_makeBulkDescriptionURL(t *testing.T) {
	t.Parallel()

	const host = "some.host"

	mockDate := date.New(2021, time.July, 9)

	for name, tc := range map[string]struct {
		at          *date.Date
		expectedURL string
	}{
		"no date": {
			at:          nil,
			expectedURL: host + "/assets/bulk?view=full",
		},
		"with date": {
			at:          &mockDate,
			expectedURL: host + "/assets/bulk?view=full&at=2021-07-09",
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expectedURL, makeBulkDescriptionURL(host, tc.at))
		})
	}
}

func Test_makeBulkBody(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		assetIDs []string
		expected string
	}{
		"nil": {
			assetIDs: nil,
			expected: `[]`,
		},
		"empty": {
			assetIDs: []string{},
			expected: `[]`,
		},
		"one entry": {
			assetIDs: []string{"7c352de7-af45-404c-9023-5f96ca49bef8"},
			expected: `["id/7c352de7-af45-404c-9023-5f96ca49bef8"]`,
		},
		"multiple entries": {
			assetIDs: []string{
				"7c352de7-af45-404c-9023-5f96ca49bef8",
				"8ba21bdb-8516-45ad-83df-3b0a5192329f",
				"9fa1eb2b-60fa-4acc-a9a6-a6bdabd4f911",
			},
			expected: `[
				"id/7c352de7-af45-404c-9023-5f96ca49bef8",
				"id/8ba21bdb-8516-45ad-83df-3b0a5192329f",
				"id/9fa1eb2b-60fa-4acc-a9a6-a6bdabd4f911"
			]`,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			res, err := makeBulkBody(tc.assetIDs)
			require.NoError(t, err)
			assert.JSONEq(t, tc.expected, string(res))
		})
	}
}

func Test_keyFromID(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		id       string
		expected string
	}{
		"plain text": {
			id:       "toto",
			expected: "id/toto",
		},
		"special characters": {
			id:       "235$23#",
			expected: "id/235$23#",
		},
		"uuid": {
			id:       validAsset,
			expected: fmt.Sprintf("%s/%s", idKey, validAsset),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, keyFromID(tc.id))
		})
	}
}

func Test_idFromKey(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		key      string
		expected string
	}{
		"plain text": {
			key:      "id/toto",
			expected: "toto",
		},
		"special characters": {
			key:      "id/235$23#",
			expected: "235$23#",
		},
		"uuid": {
			key:      fmt.Sprintf("%s/%s", idKey, validAsset),
			expected: validAsset,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			id, err := idFromKey(tc.key)
			require.NoError(t, err)
			assert.Equal(t, tc.expected, id)
		})
	}
}

func Test_idFromKey_Invalid(t *testing.T) {
	t.Parallel()

	for name, key := range map[string]string{
		"not an ID":          "not an ID",
		"unsupported prefix": "isin/unsupported",
		"wrong separator":    "something-id/else",
		"leading space":      " id/else",
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			_, err := idFromKey(key)
			require.Error(t, err)
		})
	}
}

func Test_Client_fetchDescriptions(t *testing.T) {
	t.Parallel()

	at := date.New(2024, time.January, 1)
	assetIDs := []string{validAsset}

	client := newDescriptionsTestClient(
		t,
		&at,
		map[string]json.RawMessage{
			keyFromID(validAsset): json.RawMessage(`{
				"id": "` + validAsset + `",
				"currency": {},
				"issuer": {},
				"callPut": "Call",
				"finalFixing": "2026-12-31",
				"underlyings": {
					"u1": {}
				},
				"strikes": {
					"s1": {}
				},
				"exerciseType": "European"
			}`),
		},
	)

	got, err := client.fetchDescriptions(context.Background(), assetIDs, &at)
	require.NoError(t, err)
	require.Len(t, got, 1)

	opt, ok := got[validAsset]
	require.True(t, ok)
	assert.Equal(t, validAsset, opt.ID)
	assert.Equal(t, vanillaoptionpricer.Call, opt.OptionType)
	assert.Equal(t, marketdata.European, opt.ExerciseType)
	assert.True(t, opt.FinalFixing.Equal(date.New(2026, time.December, 31)))
}

func newDescriptionsTestClient(
	t *testing.T,
	at *date.Date,
	dataByAssetID map[string]json.RawMessage,
) Client {
	t.Helper()

	var client Client

	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case sameURL(r, client.buildOptionDescriptionsURL(at)):
			writeBulkResponse(t, w, r, dataByAssetID)
		default:
			http.NotFound(w, r)
		}
	})

	client = newTestHTTPClient(t, handler)

	return client
}

func writeBulkResponse(
	t *testing.T,
	w http.ResponseWriter,
	r *http.Request,
	dataByAssetID map[string]json.RawMessage,
) {
	t.Helper()

	defer func() { _ = r.Body.Close() }()

	var reqIDs []string
	require.NoError(t, json.NewDecoder(r.Body).Decode(&reqIDs))

	resp := make(bulkResponse, len(reqIDs))
	for _, reqID := range reqIDs {
		raw, ok := dataByAssetID[reqID]
		if !ok {
			resp[reqID] = struct {
				Status int
				Data   json.RawMessage
			}{
				Status: http.StatusNotFound,
			}

			continue
		}

		resp[reqID] = struct {
			Status int
			Data   json.RawMessage
		}{
			Status: http.StatusOK,
			Data:   raw,
		}
	}

	writeJSON(t, w, resp)
}

func Test_Client_fetchQuotes(t *testing.T) {
	t.Parallel()

	at := date.New(2024, time.January, 1)
	assetIDs := []string{validAsset}

	client := newBulkTypedTestClient(
		t,
		&at,
		map[string]json.RawMessage{
			keyFromID(validAsset): json.RawMessage(`{
				"unit": {
					"id": "Nominal",
					"name": "Nominal"
				},
				"values": {
					"2020-02-03": 10664.95
				}
			}`),
		},
	)

	got, err := client.fetchQuotes(context.Background(), assetIDs, &at)
	require.NoError(t, err)

	quotes, ok := got[validAsset]
	require.True(t, ok)
	assert.InDelta(t, 10664.95, quotes.Quotes[date.New(2020, time.February, 3)], 1e-6)
}

func Test_fetchBulkTyped(t *testing.T) {
	t.Parallel()

	const tol = 1e-6

	at := date.New(2024, time.January, 1)

	t.Run("success", func(t *testing.T) {
		t.Parallel()

		assetIDs := []string{validAsset}

		client := newBulkTypedTestClient(
			t,
			&at,
			map[string]json.RawMessage{
				keyFromID(validAsset): json.RawMessage(`{
					"unit": {
						"id": "Nominal",
						"name": "Nominal"
					},
					"values": {
						"2020-02-03": 10664.95,
						"2020-02-04": 10800.64,
						"2020-02-05": 10994.15
					}
				}`),
			},
		)

		url := client.buildOptionQuotesURL(&at)

		got, err := fetchBulkTyped[marketdata.VanillaOptionQuotes](
			context.Background(),
			client,
			assetIDs,
			url,
		)
		require.NoError(t, err)
		require.Len(t, got, 1)

		quotes, ok := got[validAsset]
		require.True(t, ok)

		require.Len(t, quotes.Quotes, 3)
		assert.InDelta(t, 10664.95, quotes.Quotes[date.New(2020, time.February, 3)], tol)
	})

	t.Run("unmarshal error", func(t *testing.T) {
		t.Parallel()

		assetIDs := []string{validAsset}

		client := newBulkTypedTestClient(
			t,
			&at,
			map[string]json.RawMessage{
				keyFromID(validAsset): json.RawMessage(`"invalid"`),
			},
		)

		url := client.buildOptionQuotesURL(&at)

		got, err := fetchBulkTyped[marketdata.VanillaOptionQuotes](
			context.Background(),
			client,
			assetIDs,
			url,
		)
		assert.Nil(t, got)

		require.Error(t, err)
		require.ErrorContains(t, err, "could not unmarshal input for id")
		require.ErrorContains(t, err, validAsset)
	})

	t.Run("bulk error", func(t *testing.T) {
		t.Parallel()

		client, err := NewClient(&Config{
			Host:    unstableHost,
			Timeout: "1s",
		})
		require.NoError(t, err)

		url := client.buildOptionQuotesURL(&at)

		got, err := fetchBulkTyped[marketdata.VanillaOptionQuotes](
			context.Background(),
			*client,
			[]string{validAsset},
			url,
		)
		assert.Nil(t, got)
		require.Error(t, err)
		assert.ErrorContains(t, err, "could not fetch bulk data")
	})
}

func newBulkTypedTestClient(
	t *testing.T,
	at *date.Date,
	dataByAssetID map[string]json.RawMessage,
) Client {
	t.Helper()

	var client Client

	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case sameURL(r, client.buildOptionQuotesURL(at)):
			writeBulkTypedResponse(t, w, r, dataByAssetID)
		default:
			http.NotFound(w, r)
		}
	})

	client = newTestHTTPClient(t, handler)

	return client
}

func writeBulkTypedResponse(
	t *testing.T,
	w http.ResponseWriter,
	r *http.Request,
	dataByAssetID map[string]json.RawMessage,
) {
	t.Helper()

	defer func() { _ = r.Body.Close() }()

	var reqIDs []string
	require.NoError(t, json.NewDecoder(r.Body).Decode(&reqIDs))

	resp := make(bulkResponse, len(reqIDs))
	for _, reqID := range reqIDs {
		raw, ok := dataByAssetID[reqID]
		if !ok {
			resp[reqID] = struct {
				Status int
				Data   json.RawMessage
			}{
				Status: http.StatusNotFound,
			}

			continue
		}

		resp[reqID] = struct {
			Status int
			Data   json.RawMessage
		}{
			Status: http.StatusOK,
			Data:   raw,
		}
	}

	writeJSON(t, w, resp)
}
