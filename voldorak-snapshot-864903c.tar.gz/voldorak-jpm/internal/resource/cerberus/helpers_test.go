package cerberus

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/edgelaboratories/go-libraries/date"
)

var testServer *httptest.Server

func TestMain(m *testing.M) {
	testServer = httptest.NewServer(newMockCerberusServer())

	exitCode := m.Run()

	testServer.Close()

	os.Exit(exitCode)
}

func buildTestClient(t *testing.T) *Client {
	t.Helper()

	return &Client{
		host:   testServer.URL,
		client: &http.Client{},
	}
}

func newMockCerberusServer() http.Handler {
	mux := http.NewServeMux()

	// Perspectives
	mux.HandleFunc("GET /exchange-rates/currency-pairs", handlePerspective)

	// Correlation
	mux.HandleFunc("POST /timeseries/correlation", handleCorrelation)

	// Timeseries (assets)
	mux.HandleFunc("GET /timeseries/assets/{id}", handleTimeseries)

	// Rate timeseries
	mux.HandleFunc("GET /interest-rates/{id}/time-series", handleRateTimeseries)
	mux.HandleFunc("GET /swap-rates/{id}/time-series", handleRateTimeseries)
	mux.HandleFunc("GET /fx-forward-rates/{id}/time-series", handleRateTimeseries)
	mux.HandleFunc("GET /ois-rates/{id}/time-series", handleRateTimeseries)

	// FX exchange rates
	mux.HandleFunc("GET /exchange-rates/{foreign}/{domestic}/{from}/{to}", handleExchangeRates)

	// Volatility surfaces
	mux.HandleFunc("GET /assets/volatility-surfaces/{id}", handleVolatilitySurface)

	// Dividend yield curves
	mux.HandleFunc("GET /assets/implied-dividends/{id}", handleDividendYieldCurve)

	return mux
}

func handlePerspective(w http.ResponseWriter, _ *http.Request) {
	resp := []struct {
		Name string `json:"name"`
	}{
		{Name: "USD-EUR"},
		{Name: "USD-JPY"},
		{Name: "USD-CHF"},
	}
	respond200(w, resp)
}

func handleCorrelation(w http.ResponseWriter, _ *http.Request) {
	resp := []struct {
		Correlation float64 `json:"correlation"`
	}{
		{Correlation: 0.7},
	}
	respond200(w, resp)
}

func handleTimeseries(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if !isValidUUID(id) {
		http.Error(w, "invalid id", http.StatusBadRequest)
		return
	}

	resp := struct {
		Values map[string]float64 `json:"values"`
	}{
		Values: map[string]float64{
			"2018-01-01": 1.1,
			"2018-01-02": 1.2,
			"2018-01-03": 1.3,
		},
	}
	respond200(w, resp)
}

func handleRateTimeseries(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	switch id {
	case "not-found":
		http.Error(w, "not found", http.StatusNotFound)
		return
	case "server-error":
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	case "bad-json":
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"values": "bad"}`))

		return
	}

	resp := map[string]float64{
		"2018-01-01": 1.1,
		"2018-01-02": 1.2,
		"2018-01-03": 1.3,
	}
	respond200(w, resp)
}

func handleExchangeRates(w http.ResponseWriter, _ *http.Request) {
	resp := map[string]float64{
		"2018-01-01": 1.1,
		"2018-01-02": 1.2,
		"2018-01-03": 1.3,
	}
	respond200(w, resp)
}

func handleVolatilitySurface(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if !isValidUUID(id) {
		http.Error(w, "invalid id", http.StatusBadRequest)
		return
	}

	resp := volatilitySurfaceEntries{
		Entries: []volatilitySurfaceEntry{
			{"1W", 100.0, 10.0},
			{"1W", 150.0, 20.0},
			{"2M", 100.0, 40.0},
			{"2M", 150.0, 50.0},
			{"5Y", 100.0, 80.0},
			{"5Y", 150.0, 90.0},
		},
	}
	respond200(w, resp)
}

func handleDividendYieldCurve(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if !isValidUUID(id) {
		http.Error(w, "invalid id", http.StatusBadRequest)
		return
	}

	resp := dividendYieldCurveEntries{
		CalculationDate:     exDividendDateTestHelper(1),
		CurveDefinitionType: ForecastTable,
		Entries: []dividendYieldCurveEntry{
			{
				Dividend:       0.01,
				CashDividend:   1.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(1),
				YearFraction:   yearFractionTestHelper(1),
			},
			{
				Dividend:       0.03,
				CashDividend:   3.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(3),
				YearFraction:   yearFractionTestHelper(3),
			},
			{
				Dividend:       0.05,
				CashDividend:   5.0 * spot / 100.0,
				ExDividendDate: exDividendDateTestHelper(5),
				YearFraction:   yearFractionTestHelper(5),
			},
		},
	}
	respond200(w, resp)
}

func respond200(w http.ResponseWriter, data any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	//nolint:errchkjson
	_ = json.NewEncoder(w).Encode(data)
}

func isValidUUID(s string) bool {
	if len(s) != 36 {
		return false
	}

	for i, c := range s {
		if i == 8 || i == 13 || i == 18 || i == 23 {
			if c != '-' {
				return false
			}
		} else {
			if !strings.ContainsRune("0123456789abcdef", c) {
				return false
			}
		}
	}

	return true
}

func exDividendDateTestHelper(n int) date.Date {
	return date.Today().AddDate(n, n, n)
}

func yearFractionTestHelper(n int) float64 {
	return float64(exDividendDateTestHelper(n).Sub(date.Today())) / daysPerYear
}
