package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
)

const minRateValue = 1e-6

// FetchSpotTimeseries fetches the spot timeseries for a given id and a given window.
func (c Client) FetchSpotTimeseries(ctx context.Context, t marketdata.Type, id string, from, to time.Time) (*marketdata.Timeseries, error) {
	if isRateType(t) {
		return c.fetchSpotRateTimeseries(ctx, t, id, from, to)
	}

	url, responder, err := c.buildSpotURLAndResponder(t, id, from, to)
	if err != nil {
		return nil, fmt.Errorf("could not build spot URL: %w", err)
	}

	entries, err := c.fetchTimeseriesEntries(ctx, url, responder)
	if err != nil {
		return nil, fmt.Errorf("could not fetch spot entries for %s %s: %w", t, id, err)
	}

	return &marketdata.Timeseries{
		ID:      id,
		Type:    t,
		Entries: entries,
	}, nil
}

func isRateType(t marketdata.Type) bool {
	switch t {
	case marketdata.SwapRate, marketdata.OISRate, marketdata.FXForwardRate, marketdata.InterestRate:
		return true
	case marketdata.Index, marketdata.Fund, marketdata.Stock, marketdata.PrivateAsset, marketdata.FX:
		fallthrough
	default:
		return false
	}
}

func (c Client) buildSpotURLAndResponder(t marketdata.Type, id string, from, to time.Time) (string, responder, error) {
	switch t {
	case marketdata.FX:
		pair, err := fx.NewPair(id)
		if err != nil {
			return "", nil, fmt.Errorf("could not parse FX pair: %w", err)
		}

		return fmt.Sprintf(
			"%s/exchange-rates/%s/%s/%s/%s",
			c.host,
			pair.Foreign,
			pair.Domestic,
			timestamputil.TimeToString(from),
			timestamputil.TimeToString(to),
		), newRawValues(), nil

	case marketdata.Fund,
		marketdata.Index,
		marketdata.Stock,
		marketdata.PrivateAsset:
		return fmt.Sprintf(
			"%s/timeseries/assets/%s?field=Price&from=%s&to=%s",
			c.host,
			id,
			timestamputil.TimeToString(from),
			timestamputil.TimeToString(to),
		), newValueResponder(), nil

	case marketdata.SwapRate,
		marketdata.OISRate,
		marketdata.FXForwardRate,
		marketdata.InterestRate:
		// Rates are handled elsewhere.
		fallthrough

	default:
		return "", nil, errors.Bug("market data type %s not supported", t)
	}
}

type responder interface {
	values() map[string]float64
}

// rawValues defines the response format the client uses for FX.
type rawValues map[string]float64

func newRawValues() *rawValues {
	vs := make(rawValues)
	return &vs
}

func (vs rawValues) values() map[string]float64 {
	return vs
}

// valueResponder defines the response format the client uses for assets.
type valueResponder struct {
	Values map[string]float64 `json:"values"`
}

func (vs valueResponder) values() map[string]float64 {
	return vs.Values
}

func newValueResponder() *valueResponder {
	return &valueResponder{}
}

func (c Client) fetchTimeseriesEntries(ctx context.Context, url string, responder responder) (marketdata.Entries, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, fmt.Errorf("could not create the request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("could not execute the request: %w", err)
	}
	defer res.Body.Close()

	if err := errorFromHTTP(res); err != nil {
		return nil, err
	}

	if err := json.NewDecoder(res.Body).Decode(responder); err != nil {
		return nil, fmt.Errorf("could not decode the timeseries: %w", err)
	}

	return rawValuesToTimeseriesEntries(responder.values())
}

func rawValuesToTimeseriesEntries(values rawValues) (marketdata.Entries, error) {
	entries := make(marketdata.Entries, 0, len(values))
	for k, v := range values {
		d, err := date.ParseISO(k)
		if err != nil {
			return nil, fmt.Errorf("could not convert %s into a timestamp: %w", k, err)
		}

		entries = append(entries, &marketdata.Entry{
			Date:  d,
			Value: v,
		})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Date.Before(entries[j].Date)
	})

	return entries, nil
}
