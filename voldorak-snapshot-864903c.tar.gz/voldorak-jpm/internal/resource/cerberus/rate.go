package cerberus

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
)

func (c Client) fetchSpotRateTimeseries(ctx context.Context, t marketdata.Type, id string, from, to time.Time) (*marketdata.Timeseries, error) {
	ctx, span := trace.StartSpan(ctx, "SpotRateTimeSeries")
	defer span.End()

	logger.FromContext(ctx).Infof("fetching rate %s timeseries of type %s for [%s,%s]", id, t, from, to)

	entries, err := c.fetchSpotRateSingleEndpoint(ctx, id, t, from, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch rate spot timeseries for %s: %w", id, err)
	}

	return &marketdata.Timeseries{
		ID:      id,
		Type:    t,
		Entries: entries,
	}, nil
}

func (c Client) fetchSpotRateSingleEndpoint(ctx context.Context, id string, t marketdata.Type, from, to time.Time) (marketdata.Entries, error) {
	url, err := buildSpotRateTimeseriesURL(c.host, id, t, from, to)
	if err != nil {
		return marketdata.Entries{}, fmt.Errorf("could not build spot rate timeseries url: %w", err)
	}

	req, err := http.NewRequestWithContext(
		ctx,
		http.MethodGet,
		url,
		nil,
	)
	if err != nil {
		return marketdata.Entries{}, fmt.Errorf("could not build request: %w", err)
	}

	req.Header.Set("X-Internal-Service", "voldorak")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	trace.InjectSpanInHTTPRequest(ctx, req)

	res, err := c.client.Do(req)
	if err != nil {
		return marketdata.Entries{}, fmt.Errorf("could not execute request: %w", err)
	}

	if res.Body != nil {
		defer func() {
			if err := res.Body.Close(); err != nil {
				logger.FromContext(ctx).Errorf("error closing response body: %v", err)
			}
		}()
	}

	if res.StatusCode == http.StatusNotFound {
		return marketdata.Entries{}, errors.NotFound("rate %s not found for type %s", id, t)
	}

	if res.StatusCode != http.StatusOK {
		return marketdata.Entries{}, errors.Bug("received status %d from rate provider", res.StatusCode)
	}

	var rawValues rawValues
	if err := json.NewDecoder(res.Body).Decode(&rawValues); err != nil {
		return marketdata.Entries{}, fmt.Errorf("could not decode response body: %w", err)
	}

	entries, err := rawValuesToTimeseriesEntriesRates(rawValues)
	if err != nil {
		return marketdata.Entries{}, fmt.Errorf("could not convert map to ts entries: %w", err)
	}

	return entries, nil
}

func buildSpotRateTimeseriesURL(host, rateID string, t marketdata.Type, from, to time.Time) (string, error) {
	endpoint, err := endpointFromMarketdataRateType(t)
	if err != nil {
		return "", fmt.Errorf("could not determine endpoint from marketdata rate type: %w", err)
	}

	return fmt.Sprintf(
		"%s/%s/%s/time-series?from=%s&to=%s",
		host,
		endpoint,
		rateID,
		timestamputil.TimeToString(from),
		timestamputil.TimeToString(to),
	), nil
}

func endpointFromMarketdataRateType(t marketdata.Type) (string, error) {
	switch t {
	case marketdata.InterestRate:
		return "interest-rates", nil
	case marketdata.FXForwardRate:
		return "fx-forward-rates", nil
	case marketdata.OISRate:
		return "ois-rates", nil
	case marketdata.SwapRate:
		return "swap-rates", nil
	case marketdata.Index, marketdata.Fund, marketdata.Stock, marketdata.PrivateAsset, marketdata.FX:
		fallthrough
	default:
		return "", errors.Bug("unsupported marketdata rate type: %v", t)
	}
}

func rawValuesToTimeseriesEntriesRates(values rawValues) (marketdata.Entries, error) {
	entries := make(marketdata.Entries, 0, len(values))
	for k, v := range values {
		d, err := date.ParseISO(k)
		if err != nil {
			return nil, fmt.Errorf("could not convert %s into a timestamp: %w", k, err)
		}

		entries = append(entries, &marketdata.Entry{
			Date:  d,
			Value: max(v, minRateValue),
		})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Date.Before(entries[j].Date)
	})

	return entries, nil
}
