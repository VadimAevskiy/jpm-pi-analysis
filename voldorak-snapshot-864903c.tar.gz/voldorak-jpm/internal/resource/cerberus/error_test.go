package cerberus

import (
	"io"
	"net/http"
	"strings"
	"testing"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

type readCloser struct {
	io.Reader
}

func (r *readCloser) Close() error {
	return nil
}

var _ io.ReadCloser = &readCloser{}

func newReadCloser(msg string) io.ReadCloser {
	return &readCloser{strings.NewReader(msg)}
}

func responseHTTP(st int) *http.Response {
	return &http.Response{
		StatusCode: st,
		Body:       newReadCloser("my error message"),
	}
}

func Test_errorFromHTTP(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		want       errors.StatusCode
		httpStatus int
	}{
		"bad request": {
			want:       errors.StatusCodeBug,
			httpStatus: http.StatusBadRequest,
		},
		"not found": {
			want:       errors.StatusCodeNotFound,
			httpStatus: http.StatusNotFound,
		},
		"bug": {
			want:       errors.StatusCodeBug,
			httpStatus: http.StatusInternalServerError,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			res := responseHTTP(tc.httpStatus)
			defer res.Body.Close()

			err := errorFromHTTP(res)
			errors.AssertStatus(t, tc.want, err)

			if tc.want == errors.StatusCodeNotFound {
				errors.AssertTag(t, tag.TimeSeriesDataNotFound, err)
			}
		})
	}
}

func Test_httpStatusToError(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		statusCode int
		expected   errors.StatusCode
	}{
		"NotFound": {
			http.StatusNotFound,
			errors.StatusCodeNotFound,
		},
		"InternalServerError": {
			http.StatusInternalServerError,
			errors.StatusCodeBug,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			err := httpStatusToError(tc.statusCode, "some error: %s", "some message")
			errors.AssertStatus(t, tc.expected, err)
		})
	}
}
