package logger

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Configure(t *testing.T) { //nolint:paralleltest
	t.Run("valid", func(t *testing.T) { //nolint:paralleltest
		for name, tc := range map[string]struct {
			cfg *Config
		}{
			"default": {
				cfg: DefaultConfig(),
			},
			"json": {
				cfg: &Config{
					Format: "json",
					Level:  "debug",
				},
			},
			"non json": {
				cfg: &Config{
					Format: "something else than json",
					Level:  "debug",
				},
			},
		} {
			t.Run(name, func(t *testing.T) { //nolint:paralleltest
				require.NoError(t, Configure(tc.cfg))
			})
		}
	})

	t.Run("invalid", func(t *testing.T) { //nolint:paralleltest
		for name, tc := range map[string]struct {
			cfg *Config
		}{
			"empty": {
				cfg: nil,
			},
			"invalid level": {
				cfg: &Config{
					Format: "json",
					Level:  "some-crappy-level",
				},
			},
		} {
			t.Run(name, func(t *testing.T) { //nolint:paralleltest
				require.Error(t, Configure(tc.cfg))
			})
		}
	})
}

func Test_FromContext(t *testing.T) { //nolint:paralleltest
	t.Run("no trace", func(t *testing.T) { //nolint:paralleltest
		logger := FromContext(t.Context())

		assert.NotContains(t, logger.Data, "traceID")
		assert.NotContains(t, logger.Data, "spanID")
	})

	t.Run("with tracer", func(t *testing.T) { //nolint:paralleltest
		require.NoError(t, Configure(DefaultConfig(),
			WithTracer(TracerFunc(func(_ context.Context) map[string]any {
				return map[string]any{
					"traceID": "trace-id",
					"spanID":  "span-id",
				}
			})),
		))

		logger := FromContext(t.Context())

		assert.Contains(t, logger.Data, "traceID")
		assert.Contains(t, logger.Data, "spanID")
	})
}
