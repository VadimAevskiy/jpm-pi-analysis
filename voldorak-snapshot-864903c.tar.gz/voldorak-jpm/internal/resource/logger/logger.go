package logger

import (
	"context"
	"fmt"
	"os"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	log "github.com/sirupsen/logrus"
)

// Tracer returns tracing information for logging purposes.
type Tracer interface {
	// FieldsFromContext returns the tracing information as key-value pairs.
	FieldsFromContext(ctx context.Context) map[string]any
}

// TracerFunc is a tracer functional.
type TracerFunc func(ctx context.Context) map[string]any

var _ Tracer = TracerFunc(nil)

// FieldsFromContext returns the tracing information as key-value pairs.
func (f TracerFunc) FieldsFromContext(ctx context.Context) map[string]any {
	return f(ctx)
}

// NoopTracer returns no tracing information.
func NoopTracer() TracerFunc {
	return func(_ context.Context) map[string]any {
		return nil
	}
}

var globalTracer Tracer = NoopTracer()

// Option configures the logger's internal setup.
type Option func()

// WithTracer sets the tracer.
func WithTracer(tracer Tracer) Option {
	return func() {
		globalTracer = tracer
	}
}

// Configure initializes the logger from the config.
func Configure(cfg *Config, opts ...Option) error {
	if cfg == nil {
		return errors.Bug("the configuration is missing")
	}

	level, err := log.ParseLevel(cfg.Level)
	if err != nil {
		return fmt.Errorf("couldn't parse the log level: %w", err)
	}

	log.SetLevel(level)
	log.SetFormatter(buildFormatter(cfg.Format))
	log.SetOutput(os.Stdout)

	for _, opt := range opts {
		opt()
	}

	return nil
}

func buildFormatter(format string) log.Formatter {
	switch format {
	case "json":
		return &log.JSONFormatter{
			TimestampFormat: time.RFC3339Nano,
			FieldMap: log.FieldMap{
				log.FieldKeyTime: "timestamp",
				log.FieldKeyMsg:  "message",
			},
		}

	default:
		return &log.TextFormatter{
			TimestampFormat: time.RFC3339Nano,
			FullTimestamp:   true,
		}
	}
}

// FromContext returns a logger that contains trace information.
func FromContext(ctx context.Context) *log.Entry {
	return log.WithFields(globalTracer.FieldsFromContext(ctx))
}
