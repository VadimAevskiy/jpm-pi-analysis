package logger

// Config describes the logger configuration structure.
type Config struct {
	Level  string `yaml:"level"`
	Format string `yaml:"format"`
}

// DefaultConfig creates a default config.
func DefaultConfig() *Config {
	return &Config{
		Level:  "info",
		Format: "json",
	}
}
