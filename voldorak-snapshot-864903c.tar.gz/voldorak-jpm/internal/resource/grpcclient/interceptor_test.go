package grpcclient

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/metadata"
)

func Test_UnaryXInternalServiceInterceptor(t *testing.T) {
	t.Parallel()

	//nolint:containedctx
	for name, tc := range map[string]struct {
		ctx context.Context
	}{
		"empty context": {
			ctx: t.Context(),
		},
		"context with existing metadata": {
			ctx: metadata.NewOutgoingContext(t.Context(), metadata.Pairs("other-key", "other-value")),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			var got metadata.MD

			invoker := func(ctx context.Context, _ string, _, _ any, _ *grpc.ClientConn, _ ...grpc.CallOption) error {
				got, _ = metadata.FromOutgoingContext(ctx)

				return nil
			}

			err := UnaryXInternalServiceInterceptor()(tc.ctx, "/test.Service/Method", nil, nil, nil, invoker)
			require.NoError(t, err)

			assert.Equal(t, []string{serviceName}, got.Get(xInternalServiceKey))

			originalFields, _ := metadata.FromOutgoingContext(tc.ctx)

			for k, want := range originalFields {
				assert.Equal(t, want, got.Get(k), "pre-existing metadata key %q should be preserved", k)
			}
		})
	}
}

func Test_StreamXInternalServiceInterceptor(t *testing.T) {
	t.Parallel()

	//nolint:containedctx
	for name, tc := range map[string]struct {
		ctx context.Context
	}{
		"empty context": {
			ctx: t.Context(),
		},
		"context with existing metadata": {
			ctx: metadata.NewOutgoingContext(t.Context(), metadata.Pairs("other-key", "other-value")),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			var got metadata.MD

			streamer := func(ctx context.Context, _ *grpc.StreamDesc, _ *grpc.ClientConn, _ string, _ ...grpc.CallOption) (grpc.ClientStream, error) {
				got, _ = metadata.FromOutgoingContext(ctx)

				//nolint:nilnil
				return nil, nil
			}

			_, err := StreamXInternalServiceInterceptor()(tc.ctx, nil, nil, "/test.Service/Stream", streamer)
			require.NoError(t, err)

			assert.Equal(t, []string{serviceName}, got.Get(xInternalServiceKey))

			originalFields, _ := metadata.FromOutgoingContext(tc.ctx)

			for k, want := range originalFields {
				assert.Equal(t, want, got.Get(k), "pre-existing metadata key %q should be preserved", k)
			}
		})
	}
}
