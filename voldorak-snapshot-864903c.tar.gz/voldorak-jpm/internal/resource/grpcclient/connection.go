package grpcclient

import (
	"time"

	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	grpclogging "github.com/grpc-ecosystem/go-grpc-middleware/v2/interceptors/logging"
	grpcretry "github.com/grpc-ecosystem/go-grpc-middleware/v2/interceptors/retry"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func NewConnection(host string, timeout time.Duration, retry uint32) (*grpc.ClientConn, error) {
	// Configure logging.
	logEntry := log.WithFields(nil)

	// Configure retry.
	const (
		minWait        = time.Second
		jitterFraction = 0.2
	)

	retryOpts := []grpcretry.CallOption{
		grpcretry.WithPerRetryTimeout(timeout),
		grpcretry.WithMax(uint(retry)),
		grpcretry.WithBackoff(grpcretry.BackoffExponentialWithJitter(minWait, jitterFraction)),
	}

	return grpc.NewClient(host,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		trace.WithGRPCClientStatsHandler(),
		grpc.WithChainStreamInterceptor(
			StreamXInternalServiceInterceptor(),
			grpcretry.StreamClientInterceptor(retryOpts...),
			grpclogging.StreamClientInterceptor(InterceptorLogger(logEntry)),
		),
		grpc.WithChainUnaryInterceptor(
			UnaryXInternalServiceInterceptor(),
			grpcretry.UnaryClientInterceptor(retryOpts...),
			grpclogging.UnaryClientInterceptor(InterceptorLogger(logEntry)),
		),
	)
}
