package grpcclient

import (
	"context"
	"fmt"

	grpclogging "github.com/grpc-ecosystem/go-grpc-middleware/v2/interceptors/logging"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/metadata"
)

const (
	xInternalServiceKey = "X-Internal-Service"
	serviceName         = "voldorak"
)

// UnaryXInternalServiceInterceptor injects the X-Internal-Service metadata key into all outgoing unary gRPC calls.
func UnaryXInternalServiceInterceptor() grpc.UnaryClientInterceptor {
	return func(ctx context.Context, method string, req, reply any, cc *grpc.ClientConn, invoker grpc.UnaryInvoker, opts ...grpc.CallOption) error {
		ctx = metadata.AppendToOutgoingContext(ctx, xInternalServiceKey, serviceName)

		return invoker(ctx, method, req, reply, cc, opts...)
	}
}

// StreamXInternalServiceInterceptor injects the X-Internal-Service metadata key into all outgoing streaming gRPC calls.
func StreamXInternalServiceInterceptor() grpc.StreamClientInterceptor {
	return func(ctx context.Context, desc *grpc.StreamDesc, cc *grpc.ClientConn, method string, streamer grpc.Streamer, opts ...grpc.CallOption) (grpc.ClientStream, error) {
		ctx = metadata.AppendToOutgoingContext(ctx, xInternalServiceKey, serviceName)

		return streamer(ctx, desc, cc, method, opts...)
	}
}

// InterceptorLogger adapts logrus logger to interceptor logger.
func InterceptorLogger(l log.FieldLogger) grpclogging.Logger {
	return grpclogging.LoggerFunc(func(_ context.Context, lvl grpclogging.Level, msg string, fields ...any) {
		const fieldsPerEntry = 2

		f := make(map[string]any, len(fields)/fieldsPerEntry)

		i := grpclogging.Fields(fields).Iterator()
		if i.Next() {
			k, v := i.At()
			f[k] = v
		}

		l := l.WithFields(f)

		switch lvl {
		case grpclogging.LevelDebug:
			l.Debug(msg)
		case grpclogging.LevelInfo:
			l.Info(msg)
		case grpclogging.LevelWarn:
			l.Warn(msg)
		case grpclogging.LevelError:
			l.Error(msg)
		default:
			panic(fmt.Sprintf("unknown level %v", lvl))
		}
	})
}
