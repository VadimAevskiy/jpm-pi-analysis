package picsou

// Config describes the Picsou configuration structure.
type Config struct {
	Host    string `yaml:"host"`
	Timeout string `yaml:"timeout"`
	Retry   uint32 `yaml:"retry"`
}

// DefaultConfig creates a default config.
func DefaultConfig() *Config {
	const defaultRetry = 3

	return &Config{
		Host:    "localhost:8888",
		Timeout: "6s",
		Retry:   defaultRetry,
	}
}
