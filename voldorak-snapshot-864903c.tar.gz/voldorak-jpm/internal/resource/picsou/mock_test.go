package picsou

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"

	"github.com/gorilla/mux"
	"github.com/stretchr/testify/require"
)

func mockPicsou(t *testing.T) *mocker {
	t.Helper()

	return newMocker(
		t,
		func(w http.ResponseWriter, _ *http.Request) {
			msg := []byte(`{"M1": 0.01,"M3": 0.02,"M6": 0.03}`)
			_, _ = w.Write(msg)
		},
	)
}

func mockPicsouIncorrectJSON(t *testing.T) *mocker {
	t.Helper()

	return newMocker(
		t,
		func(w http.ResponseWriter, _ *http.Request) {
			_, _ = w.Write([]byte(`{"USD": [{"date": "2021-01-01", "rate": 0.01}]}`))
		},
	)
}

func mockPicsouError(t *testing.T) *mocker {
	t.Helper()

	return newMocker(
		t,
		func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusNotFound)
		},
	)
}

type mocker struct {
	server *httptest.Server
	client Client
}

func (m *mocker) close() {
	m.server.Close()
}

func newMocker(t *testing.T, f http.HandlerFunc) *mocker {
	t.Helper()

	server := httptest.NewServer(mockHandler(f))

	serverURL, err := url.Parse(server.URL)
	require.NoError(t, err)

	return &mocker{
		server: server,
		client: Client{
			host:   serverURL.String(),
			client: server.Client(),
		},
	}
}

func mockHandler(f http.HandlerFunc) http.Handler {
	router := mux.NewRouter()
	router.HandleFunc("/interest-rate-curves/{currency}/term-structure", f)

	return router
}
