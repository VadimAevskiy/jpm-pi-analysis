package picsou

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-libraries/go-client/httpreq"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
)

// Yield returns the yield term structure for the given currency.
func (c *Client) Yield(ctx context.Context, snapshot time.Time, currency marketdata.Currency, to date.Date) (termstructure.TermStructure, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.url(snapshot, currency, to), nil)
	if err != nil {
		return termstructure.TermStructure{}, fmt.Errorf("could not create HTTP request: %w", err)
	}

	data, _, _, err := httpreq.Request[termstructure.TermStructure](ctx, c.client, req)
	if err != nil {
		return termstructure.TermStructure{}, fmt.Errorf("could not perform HTTP request: %w", err)
	}

	return data, nil
}

func (c *Client) url(snapshot time.Time, currency marketdata.Currency, to date.Date) string {
	return fmt.Sprintf("%s/interest-rate-curves/%s/term-structure?to=%s&valuationDate=%s",
		c.host,
		currency.ID,
		to.Format("2006-01-02"),
		snapshot.Format(time.RFC3339),
	)
}
