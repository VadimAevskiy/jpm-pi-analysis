package picsou

import (
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_Client_Yield(t *testing.T) {
	t.Parallel()

	var ccy marketdata.Currency

	t.Run("valid response", func(t *testing.T) {
		t.Parallel()

		const tol = 1e-15

		mock := mockPicsou(t)
		t.Cleanup(mock.close)

		var (
			snapshot = time.Date(2025, time.January, 3, 12, 0, 0, 0, time.UTC)
			to       = date.New(2025, time.January, 3)
			ccy      = marketdata.Currency{ID: "USD"}
		)

		got, err := mock.client.Yield(t.Context(), snapshot, ccy, to)
		require.NoError(t, err)

		require.Equal(t, map[termstructure.Tenor]float64{
			termstructure.M1: 0.01,
			termstructure.M3: 0.02,
			termstructure.M6: 0.03,
		}, got.Data)

		yf, err := termstructure.M3.ToYearFraction()
		require.NoError(t, err)

		assert.InDelta(t, 0.02, got.Value(yf), tol)
	})

	t.Run("invalid json response", func(t *testing.T) {
		t.Parallel()

		mock := mockPicsouIncorrectJSON(t)
		t.Cleanup(mock.close)

		snapshot := time.Date(2025, time.January, 3, 12, 0, 0, 0, time.UTC)
		to := date.New(2025, time.January, 3)

		_, err := mock.client.Yield(t.Context(), snapshot, ccy, to)
		require.Error(t, err)
	})

	t.Run("http error response", func(t *testing.T) {
		t.Parallel()

		mock := mockPicsouError(t)
		t.Cleanup(mock.close)

		snapshot := time.Date(2025, time.January, 3, 12, 0, 0, 0, time.UTC)
		to := date.New(2025, time.January, 3)

		_, err := mock.client.Yield(t.Context(), snapshot, ccy, to)
		require.Error(t, err)
	})
}

func Test_Fetcher_url(t *testing.T) {
	t.Parallel()

	var (
		snapshot = date.New(2026, 4, 15).UTC()
		to       = date.New(2026, 4, 16)
		usd      = marketdata.Currency{ID: "USD"}

		client = Client{
			host: "http://picsou.test",
		}
		want = "http://picsou.test/interest-rate-curves/USD/term-structure?to=2026-04-16&valuationDate=2026-04-15T00:00:00Z"
	)

	assert.Equal(t, want, client.url(snapshot, usd, to))
}
