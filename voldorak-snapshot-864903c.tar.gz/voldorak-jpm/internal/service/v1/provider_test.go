package service

import (
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_service_fetchSpotTimeseries(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		res, err := service.fetchSpotTimeseries(t.Context(),
			marketdata.Index,
			"1b940b30-751f-4d55-b8af-b027ee5aed7a",
			time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC),
			time.Date(2020, time.January, 5, 0, 0, 0, 0, time.UTC),
		)
		require.NoError(t, err)
		assert.False(t, res.IsEmpty())
	})

	t.Run("not found", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			t    marketdata.Type
			id   string
			from time.Time
			to   time.Time
		}{
			"not found by provider": {
				t:    marketdata.Index,
				id:   "37acde74-ee79-4bbd-bb99-9e9c25ee2f19",
				from: time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC),
				to:   time.Date(2020, time.January, 5, 0, 0, 0, 0, time.UTC),
			},
			"provider timeseries is empty": {
				t:    marketdata.FX,
				id:   "CHF-AUD",
				from: time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC),
				to:   time.Date(2020, time.January, 5, 0, 0, 0, 0, time.UTC),
			},
			"provider timeseries is too old for window": {
				t:    marketdata.Index,
				id:   "1b940b30-751f-4d55-b8af-b027ee5aed7a",
				from: time.Date(2021, time.January, 1, 0, 0, 0, 0, time.UTC),
				to:   time.Date(2021, time.January, 5, 0, 0, 0, 0, time.UTC),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.fetchSpotTimeseries(t.Context(), tc.t, tc.id, tc.from, tc.to)
				errors.AssertStatus(t, errors.StatusCodeNotFound, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		const assetType = marketdata.Index

		var (
			from = time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC)
			to   = time.Date(2020, time.January, 5, 0, 0, 0, 0, time.UTC)
		)

		for name, tc := range map[string]struct {
			id string
		}{
			"spot value is zero": {
				id: "f47ac10b-58cc-4372-a567-0e02b2c3d479",
			},
			"spot value is negative": {
				id: "a8304c02-394e-4e24-8b5d-dc1ab6e55a9f",
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.fetchSpotTimeseries(t.Context(), assetType, tc.id, from, to)
				errors.AssertStatus(t, errors.StatusCodePreconditionFailed, err)
			})
		}
	})
}

func Test_service_fetchSpotTimeseriesWithSSMPipeline(t *testing.T) {
	t.Parallel()

	service := newService()

	var (
		from = time.Date(2020, time.January, 1, 0, 0, 0, 0, time.UTC)
		to   = time.Date(2020, time.January, 5, 0, 0, 0, 0, time.UTC)
	)

	t.Run("error", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id                 string
			expectedStatusCode errors.StatusCode
		}{
			"calibration window too short": {
				id:                 "1b940b30-751f-4d55-b8af-b027ee5aed7a",
				expectedStatusCode: errors.StatusCodeBug,
			},
			"asset not found": {
				id:                 "37acde74-ee79-4bbd-bb99-9e9c25ee2f19",
				expectedStatusCode: errors.StatusCodeNotFound,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.fetchSpotTimeseriesWithSSMPipeline(t.Context(),
					tc.id,
					from,
					to,
				)

				require.Error(t, err)
				errors.AssertStatus(t, tc.expectedStatusCode, err)
			})
		}
	})
}

func Test_newSpotConfig(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		opts           []spotOption
		expectedUseSSM bool
	}{
		"default configuration": {
			opts:           nil,
			expectedUseSSM: false,
		},
		"with SSM pipeline enabled": {
			opts:           []spotOption{withSSMPipeline(true)},
			expectedUseSSM: true,
		},
		"with SSM pipeline disabled": {
			opts:           []spotOption{withSSMPipeline(false)},
			expectedUseSSM: false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			cfg := newSpotConfig(tc.opts...)

			require.NotNil(t, cfg)
			assert.Equal(t, tc.expectedUseSSM, cfg.useSSMPipeline)
		})
	}
}

func Test_withSSMPipeline(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		initialValue  bool
		setValue      bool
		expectedValue bool
	}{
		"enable SSM pipeline": {
			initialValue:  false,
			setValue:      true,
			expectedValue: true,
		},
		"disable SSM pipeline": {
			initialValue:  true,
			setValue:      false,
			expectedValue: false,
		},
		"enable when already enabled": {
			initialValue:  true,
			setValue:      true,
			expectedValue: true,
		},
		"disable when already disabled": {
			initialValue:  false,
			setValue:      false,
			expectedValue: false,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			cfg := &spotConfig{useSSMPipeline: tc.initialValue}
			opt := withSSMPipeline(tc.setValue)

			opt(cfg)

			assert.Equal(t, tc.expectedValue, cfg.useSSMPipeline)
		})
	}
}

func Test_NewPrivateAssetConfig(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		activateSSMPipeline bool
		calibrationWeeks    int
	}{
		"SSM pipeline enabled, production calibration": {
			activateSSMPipeline: true,
			calibrationWeeks:    1428,
		},
		"SSM pipeline disabled, production calibration": {
			activateSSMPipeline: false,
			calibrationWeeks:    1428,
		},
		"SSM pipeline enabled, minimum calibration": {
			activateSSMPipeline: true,
			calibrationWeeks:    156,
		},
		"SSM pipeline disabled, zero calibration": {
			activateSSMPipeline: false,
			calibrationWeeks:    0,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			cfg := NewPrivateAssetConfig(tc.activateSSMPipeline, tc.calibrationWeeks)

			require.NotNil(t, cfg)
			assert.Equal(t, tc.activateSSMPipeline, cfg.ActivateSSMPipeline)
			assert.Equal(t, tc.calibrationWeeks, cfg.CalibrationWeeks)
		})
	}
}
