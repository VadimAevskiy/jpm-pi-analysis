package service

import (
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/service/testdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func newService(opts ...Option) *service {
	s := newDefaultService(&testdata.Provider{}, testdata.NewScenarioProvider(), testdata.MockYieldProvider{}, testdata.MockPrivateAssetFetcher{}, NewPrivateAssetConfig(false, 1428), false, false)
	for _, opt := range opts {
		opt(s)
	}

	return s
}

func newVolatilityRequest() *pb.VolatilityRequest {
	return &pb.VolatilityRequest{
		VolatilityType: pb.VolatilityType_VOLATILITY_TYPE_90_DAYS,
		From:           timestamputil.DateToTimestamp(2020, time.January, 1),
		To:             timestamputil.DateToTimestamp(2020, time.January, 5),
		Underlying: &pb.Underlying{
			Id:   "1b940b30-751f-4d55-b8af-b027ee5aed7a",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		},
		Horizon: &pb.Horizon{
			Days: 2,
		},
	}
}

func Test_service_validateVolatilityRequest(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request func() *pb.VolatilityRequest
		}{
			"default request": {
				request: newVolatilityRequest,
			},
			"volatility type unspecified": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED

					return req
				},
			},
			"90-days volatility": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_90_DAYS
					req.Horizon = nil

					return req
				},
			},
			"LM-ARCH volatility": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.NoError(t, service.validateVolatilityRequest(tc.request()))
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request func() *pb.VolatilityRequest
		}{
			"empty request": {
				request: func() *pb.VolatilityRequest {
					return nil
				},
			},
			"missing to": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.To = nil

					return req
				},
			},
			"from later than to": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.From = timestamppb.New(req.GetTo().AsTime().Add(12 * time.Hour))

					return req
				},
			},
			"from equals to": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.From = req.GetTo()

					return req
				},
			},
			"missing underlying": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying = nil

					return req
				},
			},
			"missing underlying type": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED

					return req
				},
			},
			"ill-formed underlying id/asset": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Id = "aabbccddee"

					return req
				},
			},
			"ill-formed underlying id/fx": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "abd-usd"

					return req
				},
			},
			"missing time horizon": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Horizon = nil

					return req
				},
			},
			"zero time horizon": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Horizon.Days = 0

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateVolatilityRequest(tc.request()))
			})
		}
	})
}

func Test_service_Volatility(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request func() *pb.VolatilityRequest
		}{
			"90-days volatility": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Id = "b0799580-2c2e-4384-92ce-31fd8a80e5fd"

					return req
				},
			},
			"90-days volatility/fx": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Id = "EUR-CHF"
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX

					return req
				},
			},
			"lm-arch volatility": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Id = "b0799580-2c2e-4384-92ce-31fd8a80e5fd"

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.Volatility(t.Context(), tc.request())
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request      func() *pb.VolatilityRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				request: func() *pb.VolatilityRequest {
					return nil
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"missing data/asset": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED
					req.Underlying.Id = "0214e629-e012-4130-9e7d-9bdcb5038369"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"missing data/fx": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "CHF-AUD"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"spot not found by provider/asset spot": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Id = "0214e629-e012-4130-9e7d-9bdcb5038369"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"spot not found by provider/fx spot": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "CHF-AUD"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"unknown underlying type": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Type = pb.UnderlyingType(666)
					req.Underlying.Id = "2ff645bf-50fe-492c-8f2e-04639a884560"

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"underlying data not found/asset": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Id = "a924d2ac-c55d-4959-a693-18bb27ad6a24"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"underlying data not found/fx": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "EUR-USD"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"invalid fx identifier/90-days vol from provider": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "EUR-xxx"

					return req
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"invalid fx identifier/lm arch vol": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "EUR-xxx"

					return req
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"not enough data to compute returns": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Id = "37b3193a-9706-46c6-8293-d4c152523e49"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
			"spot data too old": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2021, time.January, 4)
					req.To = timestamputil.DateToTimestamp(2021, time.January, 5)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"only one return in window": {
				request: func() *pb.VolatilityRequest {
					req := newVolatilityRequest()
					req.VolatilityType = pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2020, time.January, 3)
					req.To = timestamputil.DateToTimestamp(2020, time.January, 4)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.Volatility(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					_, _, tag := errors.FromGRPC(err)
					assert.Equal(t, *tc.tag, tag)
				}
			})
		}
	})
}

func Test_service_computeVolatility_UnimplementedVolatilityType(t *testing.T) {
	t.Parallel()

	// This test ensures the internal consistency of volatility computations
	// It should not be triggered by an external call to the server

	_, err := newService().computeVolatility(
		t.Context(),
		model.VolatilityBackboneModel("Unsupported"),
		newVolatilityRequest(),
	)
	require.Error(t, err)
	assert.Equal(t, codes.Unimplemented, status.Convert(err).Code())
}

func Test_service_validateUnderlyingID(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, underlying := range map[string]*pb.Underlying{
			"fx": {
				Id:   "EUR-USD",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_FX,
			},
			"fund": {
				Id:   "1b940b30-751f-4d55-b8af-b027ee5aed7a",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
			},
			"index": {
				Id:   "e4808f35-2a90-4a60-bebe-263c938ac20b",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
			},
			"stock": {
				Id:   "b0799580-2c2e-4384-92ce-31fd8a80e5fd",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
			},
			"private investment": {
				Id:   "2ff645bf-50fe-492c-8f2e-04639a884560",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT,
			},
			"swap rate": {
				Id:   "USD_Swap_5Y",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE,
			},
			"ois rate": {
				Id:   "JPY_TONAR_OIS_1Y",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE,
			},
			"fx forward rate": {
				Id:   "JPY_TONAR_OIS_1Y",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE,
			},
			"interest rate": {
				Id:   "USD_LIBOR_3M",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.NoError(t, service.validateUnderlying(underlying))
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, underlying := range map[string]*pb.Underlying{
			"fx": {
				Id:   "EURUSD",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_FX,
			},
			"fund": {
				Id:   "invalid-uuid",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
			},
			"index": {
				Id:   "12345",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
			},
			"stock": {
				Id:   "not-a-uuid",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
			},
			"private investment": {
				Id:   "also-not-uuid",
				Type: pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateUnderlying(underlying))
			})
		}
	})
}

func Test_service_buildForecastInput_Unsupported(t *testing.T) {
	t.Parallel()

	backboneModel := model.VolatilityBackboneModel("Unsupported")
	service := newService()

	_, err := service.buildForecaster(backboneModel)
	require.Error(t, err)
	assert.Equal(t, codes.Unimplemented, status.Convert(err).Code())
}

func Test_service_buildForecastInput(t *testing.T) {
	t.Parallel()

	var (
		expectedWeights = []float64{
			0.056214117296532425,
			0.049170256962264965,
			0.043283401728013024,
			0.038339528255578105,
			0.034166789557917396,
			0.03062688469640477,
			0.027608237276960535,
			0.025020597554951795,
			0.022790765886220678,
			0.020859200199047658,
		}

		tol = 1e-10
	)

	backboneModel := model.LongMemoryARCHForecast
	service := newService()

	bbm, err := service.buildForecaster(backboneModel)
	require.NoError(t, err)

	w := bbm.ComputeWeights(10)

	assert.Len(t, w, 1500)
	assert.InDeltaSlice(t, expectedWeights, w[:10], tol)
}

func Benchmark_service_ComputeVolatility_LongMemoryARCH(b *testing.B) {
	ctx := b.Context()
	req := &pb.VolatilityRequest{
		VolatilityType: pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH,
		Underlying: &pb.Underlying{
			Id:   "e4808f35-2a90-4a60-bebe-263c938ac20b",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
		},
		From: timestamputil.DateToTimestamp(2019, time.January, 1),
		To:   timestamputil.DateToTimestamp(2020, time.July, 1),
		Horizon: &pb.Horizon{
			Days: 252.0,
		},
	}
	service := newService()

	b.ResetTimer()

	for b.Loop() {
		_, err := service.Volatility(ctx, req)
		require.NoError(b, err)
	}
}

func Test_mapPBToMarketdataType(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    pb.UnderlyingType
		expected marketdata.Type
	}{
		"fund": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_FUND,
			expected: marketdata.Fund,
		},
		"fx": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_FX,
			expected: marketdata.FX,
		},
		"index": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
			expected: marketdata.Index,
		},
		"stock": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
			expected: marketdata.Stock,
		},
		"private investment": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT,
			expected: marketdata.PrivateAsset,
		},
		"swap rate": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE,
			expected: marketdata.SwapRate,
		},
		"ois rate": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE,
			expected: marketdata.OISRate,
		},
		"fx forward rate": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE,
			expected: marketdata.FXForwardRate,
		},
		"interest rate": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE,
			expected: marketdata.InterestRate,
		},
		"unspecified": {
			input:    pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED,
			expected: marketdata.Type(""),
		},
		"unknown type": {
			input:    pb.UnderlyingType(666),
			expected: marketdata.Type(""),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, mapPBToMarketdataType(tc.input))
		})
	}
}

func Test_mapVolatilityModel(t *testing.T) {
	t.Parallel()

	s := newService()

	for name, tc := range map[string]struct {
		volatilityType pb.VolatilityType
		expected       model.VolatilityBackboneModel
	}{
		"90 days": {
			volatilityType: pb.VolatilityType_VOLATILITY_TYPE_90_DAYS,
			expected:       model.MovingAverage90Days,
		},
		"lm-arch": {
			volatilityType: pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH,
			expected:       model.LongMemoryARCHForecast,
		},
		"unspecified": {
			volatilityType: pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED,
			expected:       s.volatilityBackboneModel,
		},
		"unknown type": {
			volatilityType: pb.VolatilityType(666),
			expected:       s.volatilityBackboneModel,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, s.mapVolatilityModel(tc.volatilityType))
		})
	}
}
