package service

import (
	"testing"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/stretchr/testify/assert"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func Test_computeEffectiveFromTime(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		from     *timestamppb.Timestamp
		to       *timestamppb.Timestamp
		expected time.Time
	}{
		"provided": {
			from:     timestamppb.New(date.New(2021, time.September, 1).UTC()),
			to:       timestamppb.New(date.New(2022, time.September, 1).UTC()),
			expected: date.New(2021, time.September, 1).UTC(),
		},
		"with default lag": {
			from:     nil,
			to:       timestamppb.New(date.New(2022, time.September, 1).UTC()),
			expected: date.New(2019, time.October, 17).UTC(),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, computeEffectiveFromTime(tc.from, tc.to))
		})
	}
}

func Test_computeReturnsWarmUpDate(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		from     time.Time
		to       time.Time
		expected time.Time
	}{
		"from long before to": {
			from:     date.New(2011, time.January, 1).UTC(),
			to:       date.New(2022, time.January, 1).UTC(),
			expected: date.New(2011, time.January, 1).UTC(),
		},
		"from within lag of to": {
			from:     date.New(2021, time.January, 1).UTC(),
			to:       date.New(2022, time.January, 1).UTC(),
			expected: date.New(2022, time.January, 1).Add(-returnsDaysLag - returnsPreservationLag).UTC(),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, computeReturnsWarmUpDate(tc.from, tc.to))
		})
	}
}
