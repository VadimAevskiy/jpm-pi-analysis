package service

import (
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func Test_service_Spot(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid request", func(t *testing.T) {
		t.Parallel()

		service := newService()
		req := newSpotRequest()

		_, err := service.Spot(t.Context(), req)
		require.NoError(t, err)
	})

	t.Run("invalid request", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request      func() *pb.SpotRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				func() *pb.SpotRequest {
					return nil
				},
				codes.InvalidArgument,
				nil,
			},
			"missing data/asset": {
				func() *pb.SpotRequest {
					req := newSpotRequest()
					req.Underlying.Id = "0214e629-e012-4130-9e7d-9bdcb5038369"

					return req
				},
				codes.NotFound,
				&tag.TimeSeriesDataTooOld,
			},
			"missing data/fx": {
				func() *pb.SpotRequest {
					req := newSpotRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "CHF-AUD"

					return req
				},
				codes.NotFound,
				&tag.TimeSeriesDataTooOld,
			},
			"underlying data not found/asset": {
				func() *pb.SpotRequest {
					req := newSpotRequest()
					req.Underlying.Id = "a924d2ac-c55d-4959-a693-18bb27ad6a24"

					return req
				},
				codes.NotFound,
				nil,
			},
			"underlying data not found/fx": {
				func() *pb.SpotRequest {
					req := newSpotRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "EUR-USD"

					return req
				},
				codes.NotFound,
				nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.Spot(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					_, _, tag := errors.FromGRPC(err)
					assert.Equal(t, *tc.tag, tag)
				}
			})
		}
	})
}

func Test_service_validateSpotRequest(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		req := newSpotRequest()
		require.NoError(t, service.validateSpotRequest(req))
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, request := range map[string]func() *pb.SpotRequest{
			"empty request": func() *pb.SpotRequest {
				return nil
			},
			"missing to": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.To = nil

				return req
			},
			"from later than to": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.From = timestamppb.New(req.GetTo().AsTime().Add(12 * time.Hour))

				return req
			},
			"missing underlying": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.Underlying = nil

				return req
			},
			"missing underlying type": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED

				return req
			},
			"ill-formed underlying id/asset": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.Underlying.Id = "aabbccddee"

				return req
			},
			"ill-formed underlying id/fx": func() *pb.SpotRequest {
				req := newSpotRequest()
				req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
				req.Underlying.Id = "abd-usd"

				return req
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateSpotRequest(request()))
			})
		}
	})
}

func newSpotRequest() *pb.SpotRequest {
	return &pb.SpotRequest{
		From: timestamputil.DateToTimestamp(2020, time.January, 1),
		To:   timestamputil.DateToTimestamp(2020, time.January, 5),
		Underlying: &pb.Underlying{
			Id:   "1b940b30-751f-4d55-b8af-b027ee5aed7a",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		},
	}
}
