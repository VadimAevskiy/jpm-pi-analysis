package service

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/service/testdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_NewService(t *testing.T) {
	t.Parallel()

	s := NewService(&testdata.Provider{}, testdata.NewScenarioProvider(), testdata.MockYieldProvider{}, testdata.MockPrivateAssetFetcher{}, NewPrivateAssetConfig(false, 1428), false, false)
	require.NotNil(t, s)

	ss, ok := s.(*service)
	assert.True(t, ok)
	assert.Equal(t, model.DefaultVolatilityBackboneModel, ss.volatilityBackboneModel)
}

func Test_NewService_WithVolatilityModel(t *testing.T) {
	t.Parallel()

	s := NewService(&testdata.Provider{}, testdata.NewScenarioProvider(), testdata.MockYieldProvider{}, testdata.MockPrivateAssetFetcher{}, NewPrivateAssetConfig(false, 1428), false, false,
		WithVolatilityBackboneModel(model.LongMemoryARCHForecast),
	)
	require.NotNil(t, s)

	ss, ok := s.(*service)
	assert.True(t, ok)
	assert.Equal(t, model.LongMemoryARCHForecast, ss.volatilityBackboneModel)
}
