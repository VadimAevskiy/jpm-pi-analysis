package service

import (
	"testing"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/service/testdata"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

const (
	daysPerYear = 365.0
	spot        = 123.45
)

func newDividendYieldCurveRequest() *pb.DividendYieldCurveRequest {
	return &pb.DividendYieldCurveRequest{
		Underlying: &pb.Underlying{
			Id:   "2f7da240-1415-463b-907d-1f5c00bc70eb",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
		},
	}
}

func exDivDateTestHelper(n int) date.Date {
	return date.Today().AddDate(n, n, n)
}

func tenorTestHelper(n int) float64 {
	return float64(exDivDateTestHelper(n).Sub(date.Today())) / daysPerYear
}

func Test_service_validateDividendYieldCurveRequest(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		require.NoError(t, service.validateDividendYieldCurveRequest(newDividendYieldCurveRequest()))
	})

	t.Run("valid with snapshot and to when ssvi is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newDividendYieldCurveRequest()
		req.Snapshot = timestamppb.New(date.Today().UTC())
		req.To = timestamppb.New(date.Today().AddDate(0, 0, -3).UTC())

		require.NoError(t, ssviActivatedService.validateDividendYieldCurveRequest(req))
	})

	t.Run("invalid if missing snapshot when ssvi is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newDividendYieldCurveRequest()
		req.To = timestamppb.New(date.Today().AddDate(0, 0, -3).UTC())

		err := ssviActivatedService.validateDividendYieldCurveRequest(req)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "snapshot is not provided")
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request func() *pb.DividendYieldCurveRequest
		}{
			"empty request": {
				request: func() *pb.DividendYieldCurveRequest {
					return nil
				},
			},
			"missing underlying": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying = nil

					return req
				},
			},
			"missing underlying type": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED

					return req
				},
			},
			"fx underlying type": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX

					return req
				},
			},
			"ill-formed underlying id": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying.Id = "aabbccddee"

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateDividendYieldCurveRequest(tc.request()))
			})
		}
	})
}

func Test_mapPBDividends(t *testing.T) {
	t.Parallel()

	t.Run("valid dividends", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			input    *marketdata.DividendYieldCurve
			expected *pb.Dividends
		}{
			"dividend curve": {
				input: &marketdata.DividendYieldCurve{
					Dividends: []marketdata.DividendPoint{
						{DividendZeroRate: 0.01, YearFraction: 0.25},
						{DividendZeroRate: 0.02, YearFraction: 0.50},
					},
				},
				expected: &pb.Dividends{
					Data: []*pb.DividendPoint{
						{DividendZeroRate: 0.01, YearFraction: 0.25},
						{DividendZeroRate: 0.02, YearFraction: 0.50},
					},
				},
			},
			"dividend yield curve": {
				input: &marketdata.DividendYieldCurve{
					Dividends: []marketdata.DividendPoint{
						{
							Dividend:     0.015,
							CashDividend: 1.5 * spot / 100.0,
							YearFraction: tenorTestHelper(1),
						},
						{
							Dividend:     0.04,
							CashDividend: 4.0 * spot / 100.0,
							YearFraction: tenorTestHelper(4),
						},
						{
							Dividend:     0.03125,
							CashDividend: 3.125 * spot / 100.0,
							YearFraction: tenorTestHelper(5),
						},
					},
				},
				expected: &pb.Dividends{
					Data: []*pb.DividendPoint{
						{
							Dividend:     0.015,
							CashDividend: 1.5 * spot / 100.0,
							YearFraction: tenorTestHelper(1),
						},
						{
							Dividend:     0.04,
							CashDividend: 4.0 * spot / 100.0,
							YearFraction: tenorTestHelper(4),
						},
						{
							Dividend:     0.03125,
							CashDividend: 3.125 * spot / 100.0,
							YearFraction: tenorTestHelper(5),
						},
					},
				},
			},
			"mixed dividends": {
				input: &marketdata.DividendYieldCurve{
					Dividends: []marketdata.DividendPoint{
						{
							Dividend:         0.015,
							CashDividend:     1.5 * spot / 100.0,
							DividendZeroRate: 0.01,
							YearFraction:     0.25,
						},
					},
				},
				expected: &pb.Dividends{
					Data: []*pb.DividendPoint{
						{
							Dividend:         0.015,
							CashDividend:     1.5 * spot / 100.0,
							DividendZeroRate: 0.01,
							YearFraction:     0.25,
						},
					},
				},
			},
			"empty dividends": {
				input: &marketdata.DividendYieldCurve{
					Dividends: []marketdata.DividendPoint{},
				},
				expected: &pb.Dividends{
					Data: []*pb.DividendPoint{},
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				got := mapPBDividend(tc.input)

				require.NotNil(t, got)
				assert.Equal(t, tc.expected.GetData(), got.GetData())
			})
		}
	})
}

func Test_service_DividendYieldCurve(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		req := newDividendYieldCurveRequest()
		_, err := service.DividendYieldCurve(t.Context(), req)
		require.NoError(t, err)
	})

	t.Run("valid when SSVI calibration is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true
		ssviActivatedService.marketDataProvider = &testdata.Provider{}

		req := newDividendYieldCurveRequest()
		req.Snapshot = timestamppb.New(date.New(2026, 4, 21).UTC())
		req.To = timestamppb.New(date.New(2026, 4, 18).UTC())

		_, err := ssviActivatedService.DividendYieldCurve(t.Context(), req)
		require.NoError(t, err)
	})

	t.Run("invalid when SSVI calibration is activated and to date missing", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true
		ssviActivatedService.marketDataProvider = &testdata.Provider{}

		req := newDividendYieldCurveRequest()
		req.Snapshot = timestamppb.New(date.Today().UTC())

		_, err := ssviActivatedService.DividendYieldCurve(t.Context(), req)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "to timestamp is not provided")
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request      func() *pb.DividendYieldCurveRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				request: func() *pb.DividendYieldCurveRequest {
					return nil
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"underlying data not found": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying.Id = "0214e629-e012-4130-9e7d-9bdcb5038369"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"unknown underlying type": {
				request: func() *pb.DividendYieldCurveRequest {
					req := newDividendYieldCurveRequest()
					req.Underlying.Type = pb.UnderlyingType(666)

					return req
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.DividendYieldCurve(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					errors.AssertTag(t, *tc.tag, err)
				}
			})
		}
	})
}

func Test_averageDividend(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		dividends             *pb.Dividends
		expectedDividendYield float64
	}{
		"no dividend": {
			&pb.Dividends{
				Data: []*pb.DividendPoint{},
			},
			0.0,
		},
		"null dividend": {
			&pb.Dividends{
				Data: []*pb.DividendPoint{
					{
						Dividend:     0.0,
						CashDividend: 0.0,
						YearFraction: tenorTestHelper(1),
					},
				},
			},
			0.0,
		},
		"single dividend": {
			&pb.Dividends{
				Data: []*pb.DividendPoint{
					{
						Dividend:     0.025,
						CashDividend: 0.025 * spot * tenorTestHelper(2),
						YearFraction: tenorTestHelper(2),
					},
				},
			},
			0.025,
		},
		"single dividend with ex-dividend date at spot date": {
			&pb.Dividends{
				Data: []*pb.DividendPoint{
					{
						Dividend:     0.025,
						CashDividend: 0.025 * spot * tenorTestHelper(0),
						YearFraction: tenorTestHelper(0),
					},
				},
			},
			0.0,
		},
		"multiple dividends": {
			&pb.Dividends{
				Data: []*pb.DividendPoint{
					{
						Dividend:     0.015,
						CashDividend: 0.015 * spot * tenorTestHelper(1),
						YearFraction: tenorTestHelper(1),
					},
					{
						Dividend:     0.04,
						CashDividend: (0.04 * (tenorTestHelper(4) - tenorTestHelper(1))) * spot,
						YearFraction: tenorTestHelper(4),
					},
					{
						Dividend:     0.03125,
						CashDividend: (0.03125 * (tenorTestHelper(5) - tenorTestHelper(4))) * spot,
						YearFraction: tenorTestHelper(5),
					},
				},
			},
			(0.015*tenorTestHelper(1) + 0.04*(tenorTestHelper(4)-tenorTestHelper(1)) + 0.03125*(tenorTestHelper(5)-tenorTestHelper(4))) / tenorTestHelper(5),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.InDelta(t, tc.expectedDividendYield, averageDividendYield(tc.dividends), 1.0e-15)
			assert.InDelta(t, tc.expectedDividendYield, averageCashDividendYield(tc.dividends, spot), 1.0e-15)
		})
	}
}

func Test_averageDividendYield_flattenDividendYieldCurve(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		dividendYieldCurve *marketdata.DividendYieldCurve
		expected           float64
	}{
		"no dividend": {
			dividendYieldCurve: &marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{},
			},
			expected: 0.0,
		},
		"null dividend": {
			dividendYieldCurve: &marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{
						Dividend:       0.0,
						CashDividend:   0.0,
						ExDividendDate: exDivDateTestHelper(1),
						YearFraction:   tenorTestHelper(1),
					},
				},
			},
			expected: 0.0,
		},
		"single dividend": {
			dividendYieldCurve: &marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{
						Dividend:       0.025,
						CashDividend:   0.025 * spot * tenorTestHelper(2),
						ExDividendDate: exDivDateTestHelper(2),
						YearFraction:   tenorTestHelper(2),
					},
				},
			},
			expected: 0.025,
		},
		"single dividend with ex-dividend date at spot date": {
			dividendYieldCurve: &marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{
						Dividend:       0.015,
						CashDividend:   0.015 * spot * tenorTestHelper(0),
						ExDividendDate: exDivDateTestHelper(0),
						YearFraction:   tenorTestHelper(0),
					},
				},
			},
			expected: 0.0,
		},
		"multiple dividends": {
			dividendYieldCurve: &marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{
						Dividend:       0.015,
						CashDividend:   0.015 * tenorTestHelper(1) * spot,
						ExDividendDate: exDivDateTestHelper(1),
						YearFraction:   tenorTestHelper(1),
					},
					{
						Dividend:       0.04,
						CashDividend:   (0.04 * (tenorTestHelper(4) - tenorTestHelper(1))) * spot,
						ExDividendDate: exDivDateTestHelper(4),
						YearFraction:   tenorTestHelper(4),
					},
					{
						Dividend:       0.03125,
						CashDividend:   (0.03125 * (tenorTestHelper(5) - tenorTestHelper(4))) * spot,
						ExDividendDate: exDivDateTestHelper(5),
						YearFraction:   tenorTestHelper(5),
					},
				},
			},
			expected: (0.015*tenorTestHelper(1) + 0.04*(tenorTestHelper(4)-tenorTestHelper(1)) + 0.03125*(tenorTestHelper(5)-tenorTestHelper(4))) / tenorTestHelper(5),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.InDelta(t, tc.expected, averageDividendYield(mapPBDividend(tc.dividendYieldCurve)), 1.0e-15)
			assert.InDelta(t, tc.expected, averageCashDividendYield(mapPBDividend(tc.dividendYieldCurve), spot), 1.0e-15)
		})
	}
}
