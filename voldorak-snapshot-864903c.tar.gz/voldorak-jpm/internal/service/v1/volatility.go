package service

import (
	"context"
	"fmt"
	"regexp"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/forecast"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

var volatilityDuration = promauto.NewHistogramVec(prometheus.HistogramOpts{
	Name:    "voldorak_volatility_duration_seconds",
	Help:    "Time spent to compute a volatility time series",
	Buckets: []float64{0.001, 0.01, 0.1, 1, 10, 20, 30},
}, []string{"volatility_type"})

func (s *service) Volatility(ctx context.Context, req *pb.VolatilityRequest) (*pb.VolatilityResponse, error) {
	ctx, span := trace.StartSpan(ctx, "Volatility")
	defer span.End()

	logger := logger.FromContext(ctx)

	if err := s.validateVolatilityRequest(req); err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, status.Error(codes.InvalidArgument, err.Error())
	}

	model := s.mapVolatilityModel(req.GetVolatilityType())

	defer func(start time.Time) {
		volatilityDuration.WithLabelValues(string(model)).Observe(time.Since(start).Seconds())
	}(time.Now())

	ts, err := s.computeVolatility(ctx, model, req)
	if err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, errors.ToGRPC(fmt.Errorf("could not compute the volatility response: %w", err))
	}

	return &pb.VolatilityResponse{
		Timeseries: mapTimeseries(ts),
	}, nil
}

// mapVolatilityModel maps the gRPC volatility type into the service-level
// volatility model. If not or badly specified, it defaults to the universal model.
func (s *service) mapVolatilityModel(volatilityType pb.VolatilityType) model.VolatilityBackboneModel {
	switch volatilityType {
	case pb.VolatilityType_VOLATILITY_TYPE_90_DAYS:
		return model.MovingAverage90Days

	case pb.VolatilityType_VOLATILITY_TYPE_LM_ARCH:
		return model.LongMemoryARCHForecast

	case pb.VolatilityType_VOLATILITY_TYPE_UNSPECIFIED:
		fallthrough

	default:
		return s.volatilityBackboneModel
	}
}

func (s *service) validateVolatilityRequest(req *pb.VolatilityRequest) error {
	if req == nil {
		return errors.BadRequest("empty request")
	}

	if err := s.validateUnderlying(req.GetUnderlying()); err != nil {
		return fmt.Errorf("underlying is invalid: %w", err)
	}

	if req.GetTo() == nil {
		return errors.BadRequest("to timestamp is not provided")
	}

	if !req.GetFrom().AsTime().Before(req.GetTo().AsTime()) {
		return errors.BadRequest(
			"'from' time (%s) must be earlier than 'to' time (%s)",
			timestamputil.TimestampToString(req.GetFrom()),
			timestamputil.TimestampToString(req.GetTo()),
		)
	}

	switch s.mapVolatilityModel(req.GetVolatilityType()) {
	case model.MovingAverage90Days:
		// No further validation is required.

	case model.LongMemoryARCHForecast:
		if err := s.validateHorizon(req.GetHorizon()); err != nil {
			return fmt.Errorf("time horizon is not valid: %w", err)
		}
	}

	return nil
}

func (s *service) validateUnderlying(underlying *pb.Underlying) error {
	if underlying == nil {
		return errors.BadRequest("underlying is not provided")
	}

	if underlying.GetType() == pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED {
		return errors.BadRequest("underlying type is not specified")
	}

	if err := s.validateUnderlyingID(underlying); err != nil {
		return fmt.Errorf("underlying id is invalid: %w", err)
	}

	return nil
}

var (
	uuidFormat = regexp.MustCompile("^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$")
	fxFormat   = regexp.MustCompile("^[A-Z]{3}-[A-Z]{3}$")
)

func (s *service) validateUnderlyingID(underlying *pb.Underlying) error {
	switch underlying.GetType() {
	case pb.UnderlyingType_UNDERLYING_TYPE_FX:
		if !fxFormat.MatchString(underlying.GetId()) {
			return errors.BadRequest("underlying ID %s of type %s does not match %s format", underlying.GetId(), underlying.GetType().String(), fxFormat.String())
		}
	case pb.UnderlyingType_UNDERLYING_TYPE_FUND, pb.UnderlyingType_UNDERLYING_TYPE_INDEX, pb.UnderlyingType_UNDERLYING_TYPE_STOCK, pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT:
		if !uuidFormat.MatchString(underlying.GetId()) {
			return errors.BadRequest("underlying ID %s of type %s does not match %s format", underlying.GetId(), underlying.GetType().String(), uuidFormat.String())
		}
	case pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED:
	}

	return nil
}

func (s *service) validateHorizon(horizon *pb.Horizon) error {
	if horizon.GetDays() <= 0 {
		return errors.BadRequest("horizon must be strictly positive, but got %d days", horizon.GetDays())
	}

	return nil
}

func (s *service) computeVolatility(ctx context.Context, backboneModel model.VolatilityBackboneModel, req *pb.VolatilityRequest) (*marketdata.Timeseries, error) {
	logger := logger.FromContext(ctx)
	logger.WithFields(log.Fields{
		"volatility_type": backboneModel,
	}).Infof("computing volatility time series for underlying %s", req.GetUnderlying().GetId())

	var (
		from = computeEffectiveFromTime(req.GetFrom(), req.GetTo())
		to   = req.GetTo().AsTime()
		t    = mapPBToMarketdataType(req.GetUnderlying().GetType())
		id   = req.GetUnderlying().GetId()
	)

	ts, err := s.fetchSpotTimeseries(ctx, t, id, from, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch spot timeseries: %w", err)
	}

	forecaster, err := s.buildForecaster(backboneModel)
	if err != nil {
		return nil, fmt.Errorf("could not build the forecast parameters: %w", err)
	}

	returns, err := marketdata.NewReturnsTimeseries(ctx, ts)
	if err != nil {
		return nil, fmt.Errorf("could not compute the time series returns: %w", err)
	}

	const minimalReturns = 2

	// Notice that:
	// - the (from,to) time window ranges from the effective from date to the
	// last return date;
	// - the horizon calendar is the same as the returns one.
	vol, err := forecast.ComputeVolatility(returns,
		forecaster,
		forecast.NewRelativeHorizon(int(req.GetHorizon().GetDays())),
		forecast.WithFrom(date.NewAt(from)),
		forecast.WithTo(date.NewAt(to)),
		forecast.WithConditionsOnReturns(
			forecast.AtLeastNReturns(minimalReturns),
		),
	)
	if err != nil {
		return nil, fmt.Errorf("could not compute the volatility forecast: %w", err)
	}

	return vol, nil
}

func (s *service) buildForecaster(backboneModel model.VolatilityBackboneModel) (forecast.Forecaster, error) {
	const (
		defaultTimeWindow             = 90
		defaultLowerCutoff            = 4.0
		defaultUpperCutoff            = 2048.0
		defaultLogarithmicDecayFactor = 2048.0
	)

	switch backboneModel {
	case model.MovingAverage90Days:
		return forecast.NewMovingAverage(
			forecast.WithTimeWindow(defaultTimeWindow),
		), nil

	case model.LongMemoryARCHForecast:
		return forecast.NewLongMemoryARCH(
			forecast.WithLowerCutoff(defaultLowerCutoff),
			forecast.WithUpperCutoff(defaultUpperCutoff),
			forecast.WithLogarithmicDecayFactor(defaultLogarithmicDecayFactor),
			forecast.WithMaximumReturnLag(returnsBusinessDaysLag),
		), nil

	default:
		return nil, status.Errorf(codes.Unimplemented, "volatility model %s not supported for forecast", backboneModel)
	}
}

func mapTimeseries(input *marketdata.Timeseries) *pb.Timeseries {
	entries := make([]*pb.Entry, len(input.Entries))
	for k, v := range input.Entries {
		entries[k] = &pb.Entry{
			Timestamp: timestamppb.New(v.Date.UTC()),
			Value:     v.Value,
		}
	}

	return &pb.Timeseries{
		Entries: entries,
	}
}

func mapPBToMarketdataType(input pb.UnderlyingType) marketdata.Type { //nolint: cyclop
	switch input {
	case pb.UnderlyingType_UNDERLYING_TYPE_FUND:
		return marketdata.Fund

	case pb.UnderlyingType_UNDERLYING_TYPE_FX:
		return marketdata.FX

	case pb.UnderlyingType_UNDERLYING_TYPE_INDEX:
		return marketdata.Index

	case pb.UnderlyingType_UNDERLYING_TYPE_STOCK:
		return marketdata.Stock

	case pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT:
		return marketdata.PrivateAsset

	case pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE:
		return marketdata.SwapRate

	case pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE:
		return marketdata.OISRate

	case pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE:
		return marketdata.FXForwardRate

	case pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE:
		return marketdata.InterestRate

	case pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED:
		fallthrough

	default:
		return marketdata.Type("")
	}
}
