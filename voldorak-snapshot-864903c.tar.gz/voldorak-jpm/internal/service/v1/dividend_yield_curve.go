package service

import (
	"context"
	"fmt"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (s *service) DividendYieldCurve(ctx context.Context, req *pb.DividendYieldCurveRequest) (*pb.DividendYieldCurveResponse, error) {
	ctx, span := trace.StartSpan(ctx, "DividendYieldCurve")
	defer span.End()

	logger := logger.FromContext(ctx)

	if err := s.validateDividendYieldCurveRequest(req); err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, status.Error(codes.InvalidArgument, err.Error())
	}

	var (
		dividendYieldCurve *marketdata.DividendYieldCurve
		err                error
	)

	if s.SSVICalibrationActivated {
		// only today's spot is fetched from MD. If missing, we do not use an older spot for now.
		spotTimeseries, err := s.fetchSpotTimeseries(
			ctx,
			marketdata.Type(req.GetUnderlying().GetType().String()),
			req.GetUnderlying().GetId(),
			req.GetTo().AsTime(),
			req.GetTo().AsTime(),
		)
		if err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not fetch spot timeseries: %w", err))
		}

		dividendYieldCurve, err = s.computeDividendCurveFromOptions(
			ctx,
			req.GetUnderlying().GetId(),
			req.GetSnapshot().AsTime(),
			date.NewAt(req.GetTo().AsTime()),
			spotTimeseries,
		)

		return &pb.DividendYieldCurveResponse{
			Dividends: mapPBDividend(dividendYieldCurve),
		}, nil
	}

	dividendYieldCurve, err = s.marketDataProvider.FetchDividendYieldCurve(ctx, req.GetUnderlying().GetId())
	if err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, errors.ToGRPC(fmt.Errorf("could not compute the dividend yield curve response: %w", err))
	}

	return &pb.DividendYieldCurveResponse{
		Dividends: mapPBDividend(dividendYieldCurve),
	}, nil
}

func (s *service) validateDividendYieldCurveRequest(req *pb.DividendYieldCurveRequest) error {
	if req == nil {
		return errors.BadRequest("empty request")
	}

	if err := s.validateUnderlyingForDividend(req.GetUnderlying()); err != nil {
		return errors.BadRequest("underlying is invalid: %w", err)
	}

	if s.SSVICalibrationActivated && req.GetSnapshot() == nil {
		return errors.BadRequest("snapshot is not provided")
	}

	if s.SSVICalibrationActivated && req.GetTo() == nil {
		return errors.BadRequest("to timestamp is not provided")
	}

	return nil
}

func (s *service) validateUnderlyingForDividend(underlying *pb.Underlying) error {
	if underlying == nil {
		return errors.BadRequest("underlying is not provided")
	}

	switch underlying.GetType() {
	case pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED:
		return errors.BadRequest("underlying type is not specified")

	case pb.UnderlyingType_UNDERLYING_TYPE_FX:
		return errors.BadRequest("fx type does not provides dividend")

	case pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
		pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
		pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT,
		pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE:

	default:
		return errors.BadRequest("underlying type is unknown")
	}

	if err := s.validateUnderlyingID(underlying); err != nil {
		return fmt.Errorf("underlying id is invalid: %w", err)
	}

	return nil
}

func mapPBDividend(input *marketdata.DividendYieldCurve) *pb.Dividends {
	pbDividend := make([]*pb.DividendPoint, 0, len(input.Dividends))
	for _, dividendPoint := range input.Dividends {
		pbDividend = append(pbDividend, &pb.DividendPoint{
			DividendZeroRate: dividendPoint.DividendZeroRate,
			Dividend:         dividendPoint.Dividend,
			CashDividend:     dividendPoint.CashDividend,
			YearFraction:     dividendPoint.YearFraction,
		})
	}

	return &pb.Dividends{Data: pbDividend}
}

// The dividend yield is the sum of the forecasted dividend payments
// divided by the horizon of the forecast, relative to the price of the dividend-paying underlying.
// In this context, averageDividendYield provides a unique dividend yield value applicable to all maturity dates,
// and corresponding to the stepwise average of the dividend yield curve.
// This is equivalent to flattening the yield curve, while being agnostic to the maturity date of the option
// (and analytically assuming that the maturity dates of assets are uniformly distributed).
func averageDividendYield(input *pb.Dividends) float64 {
	data := input.GetData()

	nbDividendPoints := len(data)
	if nbDividendPoints == 0 {
		return 0.0
	}

	dividendStreamYearFraction := data[nbDividendPoints-1].GetYearFraction()
	if dividendStreamYearFraction == 0 {
		// By definition of the ex-dividend date, return zero
		// The ex-dividend date is the first date at which the stock is trading without ownership of the dividend.
		return 0.0
	}

	previousYearFraction := 0.0
	distributedDividends := 0.0

	for _, dividendPoint := range data {
		currentYearFraction := dividendPoint.GetYearFraction()
		distributedDividends += dividendPoint.GetDividend() * (currentYearFraction - previousYearFraction)
		previousYearFraction = currentYearFraction
	}

	return distributedDividends / dividendStreamYearFraction
}

// The averageCashDividendYield is the average, over the forecast horizon,
// of all forecasted cash dividend payments
// divided by spot price of the underlying.
func averageCashDividendYield(input *pb.Dividends, spotPrice float64) float64 {
	if spotPrice == 0 {
		// By convention, if the spot price is zero, the dividend yield can only be zero,
		// by reference to the Dividend Discount Model (whereby the stock price is the present value of the future dividends),
		// the stock being constrained to be non-negative, legally.
		return 0.0
	}

	data := input.GetData()

	nbDividendPoints := len(data)
	if nbDividendPoints == 0 {
		return 0.0
	}

	dividendStreamYearFraction := data[nbDividendPoints-1].GetYearFraction()
	if dividendStreamYearFraction == 0 {
		// By definition of the ex-dividend date, return zero
		// The ex-dividend date is the first date at which the stock is trading without ownership of the dividend.
		return 0.0
	}

	distributedCashDividends := 0.0
	for _, dividendPoint := range data {
		distributedCashDividends += dividendPoint.GetCashDividend()
	}

	return distributedCashDividends / spotPrice / dividendStreamYearFraction
}
