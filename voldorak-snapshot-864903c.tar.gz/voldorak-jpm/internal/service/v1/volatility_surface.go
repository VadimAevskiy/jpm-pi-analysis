package service

import (
	"context"
	"fmt"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (s *service) VolatilitySurface(ctx context.Context, req *pb.VolatilitySurfaceRequest) (*pb.VolatilitySurfaceResponse, error) {
	ctx, span := trace.StartSpan(ctx, "VolatilitySurface")
	defer span.End()

	logger := logger.FromContext(ctx)

	if err := s.validateVolatilitySurfaceRequest(req); err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, status.Error(codes.InvalidArgument, err.Error())
	}

	var (
		underlyingID = req.GetUnderlying().GetId()
		volSurface   *marketdata.VolatilitySurface
		err          error
	)

	//nolint: nestif
	if s.SSVICalibrationActivated {
		spotTimeSeries, err := s.marketDataProvider.FetchSpotTimeseries(ctx, mapPBToMarketdataType(req.GetUnderlying().GetType()), underlyingID, req.GetTo().AsTime(), req.GetTo().AsTime())
		if err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not fetch the spot timeseries: %w", err))
		}

		optionChainDesc, spot, yieldCurve, dividendCurve, err := s.computeVolatilitySurfaceInputs(
			ctx,
			underlyingID,
			req.GetSnapshot().AsTime(),
			date.NewAt(req.GetTo().AsTime()),
			spotTimeSeries,
		)
		if err != nil {
			return nil, errors.Bug("could not compute volatility surface inputs: %w", err)
		}

		volSurface, err = computeSurface(optionChainDesc, spot, yieldCurve, dividendCurve)
		if err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not compute the volatility surface response: %w", err))
		}
	} else {
		volSurface, err = s.marketDataProvider.FetchVolatilitySurface(ctx, underlyingID)
		if err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not fetch the volatility surface response: %w", err))
		}
	}

	return &pb.VolatilitySurfaceResponse{
		Surface: mapPBSurface(volSurface),
	}, nil
}

func (s *service) validateVolatilitySurfaceRequest(req *pb.VolatilitySurfaceRequest) error {
	if req == nil {
		return errors.BadRequest("empty request")
	}

	if err := s.validateUnderlyingForSurface(req.GetUnderlying()); err != nil {
		return fmt.Errorf("underlying is invalid: %w", err)
	}

	if s.SSVICalibrationActivated && req.GetSnapshot() == nil {
		return errors.BadRequest("snapshot is not provided")
	}

	if s.SSVICalibrationActivated && req.GetTo() == nil {
		return errors.BadRequest("to timestamp is not provided")
	}

	return nil
}

func (s *service) validateUnderlyingForSurface(underlying *pb.Underlying) error {
	if underlying == nil {
		return errors.BadRequest("underlying is not provided")
	}

	switch underlying.GetType() {
	case pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED:
		return errors.BadRequest("underlying type is not specified")

	case pb.UnderlyingType_UNDERLYING_TYPE_FX:
		return errors.BadRequest("fx type does not provides volatility surfaces")

	case pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		pb.UnderlyingType_UNDERLYING_TYPE_INDEX,
		pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
		pb.UnderlyingType_UNDERLYING_TYPE_PRIVATE_INVESTMENT,
		pb.UnderlyingType_UNDERLYING_TYPE_SWAP_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_OIS_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_FX_FORWARD_RATE,
		pb.UnderlyingType_UNDERLYING_TYPE_INTEREST_RATE:

	default:
		return errors.BadRequest("underlying type is unknown")
	}

	if err := s.validateUnderlyingID(underlying); err != nil {
		return fmt.Errorf("underlying id is invalid: %w", err)
	}

	return nil
}

func mapPBSurface(input *marketdata.VolatilitySurface) *pb.Surface {
	pbSurface := make([]*pb.TenorVolatilitySlice, 0, len(input.Data))
	for _, slice := range input.Data {
		pbSurface = append(pbSurface, &pb.TenorVolatilitySlice{
			VolatilitySlice: slice,
		})
	}

	return &pb.Surface{
		Data:    pbSurface,
		Tenors:  input.TenorYearFractions,
		Strikes: input.Strikes,
	}
}

func (s *service) computeVolatilitySurfaceInputs(ctx context.Context, underlyingID string, snapshot time.Time, to date.Date, spotTimeSeries *marketdata.Timeseries) (surfacecalibration.OptionChainDescription, float64, termstructure.TermStructure, marketdata.DividendYieldCurve, error) {
	optionChainDesc, err := s.marketDataProvider.FetchOptions(ctx, underlyingID, &to)
	if err != nil {
		return surfacecalibration.OptionChainDescription{}, 0.0, termstructure.TermStructure{}, marketdata.DividendYieldCurve{}, fmt.Errorf("could not fetch the historical option chain: %w", err)
	}

	yieldCurve, err := s.yieldProvider.Yield(ctx, snapshot, *optionChainDesc.Currency, to)
	if err != nil {
		return surfacecalibration.OptionChainDescription{},
			0.0,
			termstructure.TermStructure{},
			marketdata.DividendYieldCurve{},
			fmt.Errorf(
				"could not fetch the yield curve values for currency %s: %w",
				optionChainDesc.Currency.ID,
				err,
			)
	}

	spot := spotTimeSeries.Last()
	if spot.Date != to {
		log.Warnf("id %s has a spot price with date %s different from requested date %s", underlyingID, spot.Date, to)
	}

	dividendCurve, err := surfacecalibration.ComputeDividendCurveFromOptionChain(optionChainDesc, spot.Value, yieldCurve)
	if err != nil {
		return surfacecalibration.OptionChainDescription{},
			0.0,
			termstructure.TermStructure{},
			marketdata.DividendYieldCurve{},
			fmt.Errorf("could not compute dividend term structure: %w", err)
	}

	return optionChainDesc, spot.Value, yieldCurve, dividendCurve, nil
}
