package service

import (
	"context"
	"fmt"
	"math"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/forecast"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	"github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	surfcalib "github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	log "github.com/sirupsen/logrus"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

const epsilon = 1e-6

var (
	underlyingDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "voldorak_underlying_duration_seconds",
		Help:    "Time spent to compute an underlying response",
		Buckets: []float64{0.001, 0.01, 0.1, 1, 10, 60, 120, 300, 600},
	})
	gridTenors = []float64{
		1.0 / 12.0,
		1.0 / 6.0,
		1.0 / 4.0,
		1.0 / 3.0,
		5.0 / 12.0,
		1.0 / 2.0,
		7.0 / 12.0,
		2.0 / 3.0,
		3.0 / 4.0,
		5.0 / 6.0,
		11.0 / 12.0,
		1.0,
		13.0 / 12.0,
		7.0 / 6.0,
		5.0 / 4.0,
		4.0 / 3.0,
		17.0 / 12.0,
		3.0 / 2.0,
		19.0 / 12.0,
		5.0 / 3.0,
		7.0 / 4.0,
		11.0 / 6.0,
		23.0 / 12.0,
		2.0,
	}
)

// generateGridStrikes generates a grid of strikes for the volatility surface.
// The grid has a fixed length of 19, is centered at the spot price and extends from 50% to 150% of the spot.
func generateGridStrikes(spot float64) []float64 {
	ratios := []float64{
		0.50, 0.60, 0.70,
		0.75, 0.80, 0.85, 0.90, 0.95,
		0.975, 1.0, 1.025,
		1.05, 1.10, 1.15, 1.20, 1.25, 1.30,
		1.40, 1.50,
	}

	strikes := make([]float64, len(ratios))

	for i, ratio := range ratios {
		strikes[i] = spot * ratio
	}

	return strikes
}

//nolint:cyclop
func (s *service) Underlying(ctx context.Context, req *pb.UnderlyingRequest) (*pb.UnderlyingResponse, error) {
	ctx, span := trace.StartSpan(ctx, "Underlying")
	defer span.End()

	defer func(start time.Time) {
		underlyingDuration.Observe(time.Since(start).Seconds())
	}(time.Now())

	logger := logger.FromContext(ctx)
	logger.Info("call to `Underlying` rpc")

	var (
		effectiveFrom = computeEffectiveFromTime(req.GetFrom(), req.GetTo())
		t             = mapPBToMarketdataType(req.GetUnderlying().GetType())
		id            = req.GetUnderlying().GetId()
		to            = req.GetTo().AsTime()
	)

	logger.Info("validating request")

	if err := s.validateUnderlyingRequest(req); err != nil {
		trace.SetSpanError(span, err)
		logger.Warnf("request is invalid: %v", err)

		return nil, status.Error(codes.InvalidArgument, err.Error())
	}

	logger.Infof("elaborating underlying response for underlying %s of type %s", id, t)

	logger.Infof(
		"fetching spot timeseries from %s to %s",
		timestamputil.TimeToString(effectiveFrom),
		timestamputil.TimeToString(to),
	)

	ts, err := s.fetchSpotTimeseries(ctx, t, id, effectiveFrom, to)
	if err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, errors.ToGRPC(fmt.Errorf("could not fetch spot timeseries: %w", err))
	}

	// The spot time series contains additional entries that allowed
	// returns computations to "warm up". We filter these out to ensure
	// data are actually framed in the requested time window.
	// Make sure the final restriction is not empty. This can happen if
	// the data in the warm-up window are not included in the (from, to)
	// window (i.e. when they are very old).

	var (
		windowFrom = date.NewAt(effectiveFrom)
		windowTo   = date.NewAt(to)
	)

	// Notice that the Deprecated backbone model should imply an Unspecified convention.

	res := &pb.UnderlyingResponse{
		Spot: &pb.AttributeResponse{
			Timeseries: mapTimeseries(ts.
				From(windowFrom).
				To(windowTo),
			),
		},
		Convention: s.mapCalendarConvention(ts.CalendarConvention()),
	}

	scenariosIDs := s.getScenariosIDs(req.GetScenarios())
	if len(scenariosIDs) != 0 {
		logger.Infof("fetching %d spot scenarios", len(scenariosIDs))

		var proxiesMap map[string]map[uint32]*scenario.Proxies

		res.Spot.Scenarios, proxiesMap, err = s.fetchSpotScenarios(ctx, t, id, scenariosIDs, to)
		if err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not fetch spot scenarios: %w", err))
		}

		res.ProxiesList = proxiesMapToPBProxiesList(proxiesMap)
	}

	if !s.SSVICalibrationActivated {
		if err := s.computeUnderlyingDividend(ctx, req, res, ts); err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not compute underlying dividend: %w", err))
		}
	}

	// If volatility surface is not requested, we directly compute the dividend curve.
	if s.SSVICalibrationActivated && !req.GetVolatilitySurface() && req.GetDividendYieldCurve() {
		dividendCurve, err := s.computeDividendCurveFromOptions(
			ctx,
			req.GetUnderlying().GetId(),
			req.GetSnapshot().AsTime(),
			windowTo,
			ts,
		)
		if err != nil {
			return nil, fmt.Errorf("could not compute dividend curve: %w", err)
		}

		dividends := mapPBDividend(dividendCurve)

		res.DividendYieldCurve = &pb.DividendYieldCurve{
			Dividends: dividends,
		}

		if err := s.computeAverageDividend(*dividendCurve, res); err != nil {
			return nil, fmt.Errorf("could not compute dividend yield from options: %w", err)
		}
	}

	if req.GetVolatilityContext() == nil && !req.GetVolatilitySurface() {
		return res, nil
	}

	// Compute LM ARCH reference volatility for surface validation.
	returns, err := marketdata.NewReturnsTimeseries(ctx, ts)
	if err != nil {
		return nil, errors.ToGRPC(fmt.Errorf("could not compute the time series returns: %w", err))
	}

	if s.SSVICalibrationActivated {
		if err := s.computeVolatilityAndScenarios(ctx, req, res, ts, returns, windowFrom, windowTo); err != nil {
			trace.SetSpanError(span, err)
			logger.Warn(err.Error())

			return nil, errors.ToGRPC(fmt.Errorf("could not compute ssvi calibrated underlying volatility: %w", err))
		}

		return res, nil
	}

	if err := s.computeUnderlyingVolatility(ctx, req, res, returns, windowFrom, windowTo); err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, errors.ToGRPC(fmt.Errorf("could not compute underlying volatility: %w", err))
	}

	return res, nil
}

func proxiesMapToPBProxiesList(proxiesMap map[string]map[uint32]*scenario.Proxies) map[string]*pb.ProxyPerScenarioResponse {
	result := make(map[string]*pb.ProxyPerScenarioResponse, len(proxiesMap))
	for id, proxies := range proxiesMap {
		proxyMap := make(map[uint32]*pb.ProxyResponse, len(proxies))
		for scnID, proxy := range proxies {
			proxyMap[scnID] = &pb.ProxyResponse{
				Intercept: proxy.Intercept,
				Betas:     proxy.Betas,
			}
		}

		result[id] = &pb.ProxyPerScenarioResponse{
			Proxies: proxyMap,
		}
	}

	return result
}

//nolint:cyclop
func (s *service) validateUnderlyingRequest(req *pb.UnderlyingRequest) error {
	if req == nil {
		return errors.BadRequest("empty request")
	}

	if err := s.validateUnderlying(req.GetUnderlying()); err != nil {
		return fmt.Errorf("underlying is invalid: %w", err)
	}

	if req.GetTo() == nil {
		return errors.BadRequest("to timestamp is not provided")
	}

	if req.GetFrom() != nil && !req.GetFrom().AsTime().Before(req.GetTo().AsTime()) {
		return errors.BadRequest(
			"'from' time (%s) must be earlier than 'to' time (%s)",
			timestamputil.TimestampToString(req.GetFrom()),
			timestamputil.TimestampToString(req.GetTo()),
		)
	}

	if s.SSVICalibrationActivated && req.GetSnapshot() == nil {
		return errors.BadRequest("snapshot is not provided")
	}

	if s.HestonCalibrationActivated && req.GetVolatilitySurfaceModel() == 0 {
		return errors.BadRequest("volatility surface model is not provided")
	}

	if req.GetVolatilityContext() == nil {
		// No further validation is required.
		return nil
	}

	switch s.mapVolatilityBackboneModel(req.GetVolatilityContext().GetVolatilityBackboneModel()) {
	case model.MovingAverage90Days:
		// No further validation is required.

	case model.LongMemoryARCHForecast:
		if horizon, to := req.GetVolatilityContext().GetHorizon().AsTime(), req.GetTo().AsTime(); horizon.Before(to) {
			return errors.BadRequest("volatility horizon time (%s) must be later than 'to' time (%s)", horizon, to)
		}
	}

	return nil
}

func (s *service) fetchSpotScenarios(ctx context.Context, t marketdata.Type, id string, scenariosIDs []uint32, to time.Time) (map[uint32]float64, map[string]map[uint32]*scenario.Proxies, error) {
	ctx, span := trace.StartSpan(ctx, "FetchSpotScenarios")
	defer span.End()

	scenarios, proxiesMap, err := s.scenariosProvider.FetchSpotScenarios(ctx, t, id, scenariosIDs, to)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the spot scenarios from provider: %w", err)
	}

	return scenarios, proxiesMap, nil
}

// getScenariosFromIDs builds Scenarios from a list of IDs.
// The output scenarios can't provide any information on the horizon.
func (s *service) getScenariosIDs(scenarios map[uint32]*pb.Scenario) []uint32 {
	scenarioIDs := make([]uint32, 0, len(scenarios))
	for _, v := range scenarios {
		scenarioIDs = append(scenarioIDs, v.GetId())
	}

	return scenarioIDs
}

func (s *service) computeVolatilityAndScenarios(ctx context.Context, req *pb.UnderlyingRequest, res *pb.UnderlyingResponse, spotTimeSeries *marketdata.Timeseries, returns *marketdata.ReturnsTimeseries, windowFrom, windowTo date.Date) error {
	if !req.GetVolatilitySurface() {
		return s.computeBackboneVolAndScenarios(ctx, req, res, returns, windowFrom, windowTo)
	}

	return s.computeVolatilitySurfaceAndScenarios(ctx, req, res, spotTimeSeries, returns)
}

func (s *service) computeVolatilitySurfaceAndScenarios(ctx context.Context, req *pb.UnderlyingRequest, res *pb.UnderlyingResponse, spotTimeSeries *marketdata.Timeseries, returns *marketdata.ReturnsTimeseries) error {
	to := date.NewAt(req.GetTo().AsTime())

	optionChainDesc, spot, yieldCurve, dividendCurve, err := s.computeVolatilitySurfaceInputs(
		ctx,
		req.GetUnderlying().GetId(),
		req.GetSnapshot().AsTime(),
		to,
		spotTimeSeries,
	)
	if err != nil {
		return fmt.Errorf("could not compute volatility surface inputs: %w", err)
	}

	if req.GetDividendYieldCurve() {
		if err := s.populateDividendYieldCurve(dividendCurve, res); err != nil {
			return fmt.Errorf("could not populate dividend yield curve: %w", err)
		}
	}

	reqModel := s.requestedVolatilitySurfaceModel(req)

	switch reqModel {
	case pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI:
		return s.computeSSVIVolatilitySurfaceAndScenarios(ctx, req, res, optionChainDesc, spot, yieldCurve, dividendCurve, returns)

	case pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON:
		return s.computeHestonVolatilitySurfaceAndScenarios(ctx, req, res, optionChainDesc, spot, yieldCurve, dividendCurve, returns, to)

	case pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED:
		return errors.Bug("volatility surface model is not specified")
	}

	return errors.Bug("unsupported volatility surface model %s", reqModel.String())
}

func (s *service) requestedVolatilitySurfaceModel(req *pb.UnderlyingRequest) pb.VolatilitySurfaceModel {
	if !s.HestonCalibrationActivated {
		return pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI
	}

	return req.GetVolatilitySurfaceModel()
}

func (s *service) computeBackboneVolAndScenarios(ctx context.Context, req *pb.UnderlyingRequest, res *pb.UnderlyingResponse, returns *marketdata.ReturnsTimeseries, windowFrom, windowTo date.Date) error {
	volTS, volScenarios, err := s.computeBackboneScenarios(ctx, req, s.mapVolatilityBackboneModel(req.GetVolatilityContext().GetVolatilityBackboneModel()), returns)
	if err != nil {
		return fmt.Errorf("could not compute volatility timeseries: %w", err)
	}

	res.Volatility = &pb.AttributeResponse{
		Timeseries: mapTimeseries(volTS.
			From(windowFrom).
			To(windowTo),
		),
		Scenarios: volScenarios,
	}

	return nil
}

func (s *service) computeSSVIVolatilitySurfaceAndScenarios(
	ctx context.Context,
	req *pb.UnderlyingRequest,
	res *pb.UnderlyingResponse,
	optionChainDesc surfacecalibration.OptionChainDescription,
	spot float64,
	yieldCurve termstructure.TermStructure,
	dividendCurve marketdata.DividendYieldCurve,
	returns *marketdata.ReturnsTimeseries,
) error {
	volSurface, err := computeSurface(optionChainDesc, spot, yieldCurve, dividendCurve)
	if err != nil {
		return fmt.Errorf("could not compute volatility surface: %w", err)
	}

	referenceVol, err := s.computeReferenceVolatility(returns, model.LongMemoryARCHForecast, computeEffectiveFromTime(req.GetFrom(), req.GetTo()), req.GetTo().AsTime())
	if err != nil {
		return fmt.Errorf("could not compute reference volatility: %w", err)
	}

	if err := validateVolatilitySurface(volSurface, referenceVol); err != nil {
		return fmt.Errorf("implied volatility surface is invalid: %w", err)
	}

	res.VolatilitySurface = &pb.VolatilitySurface{
		Surface: mapPBSurface(volSurface),
	}

	// If no scenarios are asked, no need to compute the LM-ARCH volatility scenarios.
	if len(req.GetScenarios()) == 0 {
		return nil
	}

	volTS, volScenarios, err := s.computeBackboneScenarios(ctx, req, model.LongMemoryARCHForecast, returns)
	if err != nil {
		return fmt.Errorf("could not compute volatility timeseries: %w", err)
	}

	res.VolatilitySurface.ScenarioShifts = computeScenarioShifts(
		volTS.Last().Value,
		volScenarios,
	)

	return nil
}

func (s *service) computeHestonVolatilitySurfaceAndScenarios(
	ctx context.Context,
	req *pb.UnderlyingRequest,
	res *pb.UnderlyingResponse,
	optionChainDesc surfacecalibration.OptionChainDescription,
	spot float64,
	yieldCurve termstructure.TermStructure,
	dividendCurve marketdata.DividendYieldCurve,
	returns *marketdata.ReturnsTimeseries,
	to date.Date,
) error {
	hestonParams, v0Tenor, thetaTenor, err := computeHestonSurface(optionChainDesc, spot, yieldCurve, dividendCurve)
	if err != nil {
		return fmt.Errorf("could not compute Heston volatility surface: %w", err)
	}

	referenceVol, err := s.computeReferenceVolatility(returns, model.LongMemoryARCHForecast, computeEffectiveFromTime(req.GetFrom(), req.GetTo()), req.GetTo().AsTime())
	if err != nil {
		return fmt.Errorf("could not compute reference volatility: %w", err)
	}

	if err := validateHestonParameters(hestonParams.V0, hestonParams.Theta, referenceVol); err != nil {
		return fmt.Errorf("implied volatility surface is invalid: %w", err)
	}

	res.HestonSurface.HestonParameters = map[string]float64{
		"v0":    hestonParams.V0,
		"theta": hestonParams.Theta,
		"kappa": hestonParams.Kappa,
		"sigma": hestonParams.Sigma,
		"rho":   hestonParams.Rho,
	}

	if len(req.GetScenarios()) == 0 {
		return nil
	}

	v0Scenarios, err := s.computeHestonScenarios(
		ctx,
		to.UTC().AddDate(0, 0, int(math.Round(float64(v0Tenor)*365))), // to be updated once vol convention is set to business days
		req,
		model.LongMemoryARCHForecast,
		returns,
	)
	if err != nil {
		return fmt.Errorf("could not compute v0 scenarios: %w", err)
	}

	thetaScenarios, err := s.computeHestonScenarios(
		ctx,
		to.UTC().AddDate(0, 0, int(math.Round(float64(thetaTenor)*365))), // to be updated once vol convention is set to business days
		req,
		model.LongMemoryARCHForecast,
		returns,
	)
	if err != nil {
		return fmt.Errorf("could not compute theta scenarios: %w", err)
	}

	res.HestonSurface.V0ScenarioShifts = computeScenarioShifts(hestonParams.V0, v0Scenarios)
	res.HestonSurface.ThetaScenarioShifts = computeScenarioShifts(hestonParams.Theta, thetaScenarios)

	return nil
}

func (s *service) populateDividendYieldCurve(dividendCurve marketdata.DividendYieldCurve, res *pb.UnderlyingResponse) error {
	res.DividendYieldCurve = &pb.DividendYieldCurve{
		Dividends: mapPBDividend(&dividendCurve),
	}

	if err := s.computeAverageDividend(dividendCurve, res); err != nil {
		return fmt.Errorf("could not compute dividend yield from options: %w", err)
	}

	return nil
}

// computeUnderlyingVolatility fetches and compute the requested volatility.
// Either a volatility timeseries or a volatility surface depending on the
// boolean field VolatilitySurface in the request.
func (s *service) computeUnderlyingVolatility(ctx context.Context, req *pb.UnderlyingRequest, res *pb.UnderlyingResponse, returns *marketdata.ReturnsTimeseries, from, to date.Date) error {
	// If no surface is fetched, just get and return the volatility.
	if !req.GetVolatilitySurface() {
		volTS, volScenarios, err := s.computeBackboneScenarios(
			ctx,
			req,
			s.mapVolatilityBackboneModel(req.GetVolatilityContext().GetVolatilityBackboneModel()),
			returns,
		)
		if err != nil {
			return fmt.Errorf("could not compute volatility timeseries: %w", err)
		}

		// We make sure also the volatility time series is contained
		// in the requested time window by symmetry.
		// This statement should be ineffective.
		res.Volatility = &pb.AttributeResponse{
			Timeseries: mapTimeseries(volTS.
				From(from).
				To(to),
			),
			Scenarios: volScenarios,
		}

		return nil
	}

	var (
		underlyingID = req.GetUnderlying().GetId()
		volSurface   *marketdata.VolatilitySurface
		err          error
	)

	volSurface, err = s.marketDataProvider.FetchVolatilitySurface(ctx, underlyingID)
	if err != nil {
		return fmt.Errorf("could not fetch volatility surface: %w", err)
	}

	referenceVol, err := s.computeReferenceVolatility(returns, model.LongMemoryARCHForecast, computeEffectiveFromTime(req.GetFrom(), req.GetTo()), req.GetTo().AsTime())
	if err != nil {
		return fmt.Errorf("could not compute reference volatility: %w", err)
	}

	if err := validateVolatilitySurface(volSurface, referenceVol); err != nil {
		return fmt.Errorf("implied volatility surface is invalid: %w", err)
	}

	// If no scenarios are asked, no need to compute the LM-ARCH volatility scenarios.
	if len(req.GetScenarios()) == 0 {
		res.VolatilitySurface = &pb.VolatilitySurface{
			Surface: mapPBSurface(volSurface),
		}

		return nil
	}

	volTS, volScenarios, err := s.computeBackboneScenarios(ctx, req, model.LongMemoryARCHForecast, returns)
	if err != nil {
		return fmt.Errorf("could not compute volatility timeseries: %w", err)
	}

	res.VolatilitySurface = &pb.VolatilitySurface{
		Surface:        mapPBSurface(volSurface),
		ScenarioShifts: computeScenarioShifts(volTS.Last().Value, volScenarios),
	}

	return nil
}

func computeSurface(optionChainDesc surfcalib.OptionChainDescription, spot float64, yieldCurve termstructure.TermStructure, dividendCurve marketdata.DividendYieldCurve) (*marketdata.VolatilitySurface, error) {
	volSurface, err := surfacecalibration.ComputeRawVolatilitySurface(optionChainDesc, spot, yieldCurve, dividendCurve)
	if err != nil {
		return nil, fmt.Errorf("could not compute raw volatility surface: %w", err)
	}

	params, err := surfacecalibration.CalibrateSSVI(volSurface, surfacecalibration.DefaultInitialParams)
	if err != nil {
		return nil, fmt.Errorf("could not calibrate SSVI parameters: %w", err)
	}

	surfaceGrid, err := surfacecalibration.ComputeSSVIsurfaceOnGrid(params.Parameters, spot, gridTenors, generateGridStrikes(spot), yieldCurve, dividendCurve)
	if err != nil {
		return nil, fmt.Errorf("could not compute SSVI surface on grid: %w", err)
	}

	return &surfaceGrid, nil
}

func computeHestonSurface(optionChainDesc surfcalib.OptionChainDescription, spot float64, yieldCurve termstructure.TermStructure, dividendCurve marketdata.DividendYieldCurve) (*marketdata.HestonParameters, surfacecalibration.Tenor, surfacecalibration.Tenor, error) {
	volSurface, err := surfacecalibration.ComputeRawVolatilitySurface(optionChainDesc, spot, yieldCurve, dividendCurve)
	if err != nil {
		return nil, 0.0, 0.0, fmt.Errorf("could not compute raw volatility surface: %w", err)
	}

	hestonResults, err := surfacecalibration.CalibrateHeston(volSurface, surfacecalibration.DefaultHestonInitialParams)
	if err != nil {
		return nil, 0.0, 0.0, fmt.Errorf("could not calibrate Heston parameters: %w", err)
	}

	if len(volSurface.SortedTenors) < 2 {
		return nil, 0.0, 0.0, errors.Bug("not enough sorted tenors in the volatility surface")
	}

	return &hestonResults.Parameters, volSurface.SortedTenors[0], volSurface.SortedTenors[len(volSurface.SortedTenors)-1], nil
}

// computeBackboneScenarios computes the volatility timeseries
// based on the input backbone model.
func (s *service) computeBackboneScenarios(ctx context.Context, req *pb.UnderlyingRequest, backboneModel model.VolatilityBackboneModel, returns *marketdata.ReturnsTimeseries) (*marketdata.Timeseries, map[uint32]float64, error) {
	logger := logger.FromContext(ctx)
	logger.Info("computing volatility response")

	var (
		horizonDate = req.GetVolatilityContext().GetHorizon().AsTime()
		from        = computeEffectiveFromTime(req.GetFrom(), req.GetTo())
		to          = req.GetTo().AsTime()
		t           = mapPBToMarketdataType(req.GetUnderlying().GetType())
		id          = req.GetUnderlying().GetId()
		scenarios   = req.GetScenarios()
	)

	logger.Infof("computing volatility time series for backbone model %s", backboneModel)

	vol, err := s.computeVolatilityTimeseries(horizonDate, returns, backboneModel, from, to)
	if err != nil {
		return nil, nil, fmt.Errorf("could not compute the volatility timeseries: %w", err)
	}

	volScenarios, err := s.computeVolatilityResponse(ctx, backboneModel, returns, scenarios, horizonDate, from, to, t, id)
	if err != nil {
		return nil, nil, fmt.Errorf("could not compute the volatility response: %w", err)
	}

	return vol, volScenarios, nil
}

// computeHestonScenarios computes the volatility scenarios for the Heston model.
func (s *service) computeHestonScenarios(ctx context.Context, horizonDate time.Time, req *pb.UnderlyingRequest, backboneModel model.VolatilityBackboneModel, returns *marketdata.ReturnsTimeseries) (map[uint32]float64, error) {
	logger := logger.FromContext(ctx)
	logger.Info("computing volatility response")

	var (
		from      = computeEffectiveFromTime(req.GetFrom(), req.GetTo())
		to        = req.GetTo().AsTime()
		t         = mapPBToMarketdataType(req.GetUnderlying().GetType())
		id        = req.GetUnderlying().GetId()
		scenarios = req.GetScenarios()
	)

	volScenarios, err := s.computeVolatilityResponse(ctx, backboneModel, returns, scenarios, horizonDate, from, to, t, id)
	if err != nil {
		return nil, fmt.Errorf("could not compute the volatility response: %w", err)
	}

	return volScenarios, nil
}

// computeVolatilityResponse returns the scenario values
// the final scenario values are obtained by applying a scaling to translate a
// scenario volatility value for a reference universal horizon into a scenario volatility
// for the request horizon: i.e. scenario horizon.
func (s *service) computeVolatilityResponse(ctx context.Context, backboneModel model.VolatilityBackboneModel, returns *marketdata.ReturnsTimeseries, scenarios map[uint32]*pb.Scenario, horizonDate time.Time, from, to time.Time, t marketdata.Type, id string) (map[uint32]float64, error) {
	logger := logger.FromContext(ctx)

	logger.Info("computing volatility scenarios")

	referenceVol, err := s.computeReferenceVolatility(returns, backboneModel, from, to)
	if err != nil {
		return nil, fmt.Errorf("could not compute the reference volatility: %w", err)
	}

	scalingFactors, err := s.computeScenariosScalingFactors(ctx, returns, scenarios, backboneModel, referenceVol, horizonDate, to, t, id)
	if err != nil {
		return nil, fmt.Errorf("could not compute the scaling factors: %w", err)
	}

	return s.computeVolatilityScenarios(referenceVol, scalingFactors), nil
}

func (s *service) computeVolatilityScenarios(referenceVol float64, scalingFactors map[uint32]float64) map[uint32]float64 {
	volScenarios := make(map[uint32]float64, len(scalingFactors))

	for scnID, scaler := range scalingFactors {
		volScenarios[scnID] = referenceVol * scaler
	}

	return volScenarios
}

func (s *service) computeVolatilityTimeseries(horizonDate time.Time, returns *marketdata.ReturnsTimeseries, backboneModel model.VolatilityBackboneModel, from, to time.Time) (*marketdata.Timeseries, error) {
	forecaster, err := s.buildForecaster(backboneModel)
	if err != nil {
		return nil, fmt.Errorf("could not build the forecast parameters: %w", err)
	}

	const minimalReturns = 2

	volatilityTimeseries, err := forecast.ComputeVolatility(returns,
		forecaster,
		forecast.NewAbsoluteHorizon(
			date.NewAt(to),
			date.NewAt(horizonDate),
		),
		forecast.WithFrom(date.NewAt(from)),
		forecast.WithTo(date.NewAt(to)),
		forecast.WithConditionsOnReturns(
			forecast.AtLeastNReturns(minimalReturns),
		),
	)
	if err != nil {
		return nil, fmt.Errorf("could not compute the volatility timeseries: %w", err)
	}

	return volatilityTimeseries, nil
}

// mapVolatilityBackboneModel maps the gRPC volatility backbone model into the service-level
// volatility model. If not or badly specified, it defaults to the universal model.
func (s *service) mapVolatilityBackboneModel(volatilityBackboneModel pb.VolatilityBackboneModel) model.VolatilityBackboneModel {
	switch volatilityBackboneModel {
	case pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS:
		return model.MovingAverage90Days

	case pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH:
		return model.LongMemoryARCHForecast

	case pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED:
		fallthrough

	default:
		return s.volatilityBackboneModel
	}
}

func (s *service) fetchVolatilityScenarios(ctx context.Context, t marketdata.Type, id string, scenarios map[uint32]*pb.Scenario, to time.Time) (map[uint32]float64, map[string]map[uint32]*scenario.Proxies, error) {
	ctx, span := trace.StartSpan(ctx, "FetchVolatilityScenarios")
	defer span.End()

	// fetching volatility scenarios for the reference universalhorizon.
	volScenarios, proxiesMap, err := s.scenariosProvider.FetchVolatilityScenarios(ctx, t, id, s.getScenariosIDs(scenarios), to)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the volatility scenarios: %w", err)
	}

	return volScenarios, proxiesMap, nil
}

// computeReferenceVolatility computes the reference volatility for scenario
// normalization purposes. The input `vol` parameter representing the
// default volatility must not be empty, otherwise this method will panic.
func (s *service) computeReferenceVolatility(returns *marketdata.ReturnsTimeseries, backboneModel model.VolatilityBackboneModel, from, to time.Time) (float64, error) {
	forecaster, err := s.buildForecaster(backboneModel)
	if err != nil {
		return 0.0, fmt.Errorf("could not build the forecast parameters: %w", err)
	}

	const minimalReturns = 2

	referenceVolTS, err := forecast.ComputeVolatility(returns,
		forecaster,
		forecast.NewRelativeHorizon(model.ReferenceScenarioHorizon),
		forecast.WithFrom(date.NewAt(from)),
		forecast.WithTo(date.NewAt(to)),
		forecast.WithConditionsOnReturns(
			forecast.AtLeastNReturns(minimalReturns),
		),
	)
	if err != nil {
		return 0.0, fmt.Errorf("could not compute the volatility forecast for the universal horizon: %w", err)
	}

	return referenceVolTS.Last().Value, nil
}

func (s *service) computeScenariosScalingFactors(ctx context.Context, returns *marketdata.ReturnsTimeseries, scenarios map[uint32]*pb.Scenario, backboneModel model.VolatilityBackboneModel, referenceVol float64, horizonDate, to time.Time, t marketdata.Type, id string) (map[uint32]float64, error) {
	if len(scenarios) == 0 {
		// Return an empty but not nil map to prevent nilnil lint check.
		return make(map[uint32]float64), nil
	}

	// fetching volatility realizations for the reference universalhorizon.
	volRealizations, _, err := s.fetchVolatilityScenarios(ctx, t, id, scenarios, to)
	if err != nil {
		return nil, err
	}

	// Nowadays scaling applies only to LM-ARCH forecast.
	// This choice can be extended by means of a switch construct
	// with each model choosing its own scaler.

	if backboneModel != model.LongMemoryARCHForecast {
		return volRealizations, nil
	}

	return s.computeScalingFactors(
		scenarios,
		returns.Calendar,
		volRealizations,
		referenceVol,
		scenario.NewLongMemoryARCHScaler(),
		returns.Last().Date,
		date.NewAt(horizonDate),
	), nil
}

// computeScalingFactors computes the scaling factors for the scenario volatility from reference
// universal horizon to scenario horizon.
// The input calendar refers to the convention of time series returns.
func (s *service) computeScalingFactors(scenarios map[uint32]*pb.Scenario, cal *calendar.Calendar, scalingFactors map[uint32]float64, referenceVol float64, scaler scenario.Scaler, lastDate, horizonDate date.Date) map[uint32]float64 {
	// Scenario horizons are expressed in business days.
	businessCal := calendar.New(calendar.BusinessDays)

	for k, scn := range scenarios {
		scenarioHorizon := int(scn.GetHorizon())

		scenarioDate := businessCal.Add(lastDate, scenarioHorizon)

		volHorizon := max(cal.DaysBetween(scenarioDate, horizonDate), 1)

		scalingFactors[k] = scenario.ComputeScenarioScaler(scalingFactors[k], referenceVol, float64(volHorizon), float64(scenarioHorizon), scaler)
	}

	return scalingFactors
}

func (s *service) mapCalendarConvention(convention calendar.Convention) pb.CalendarConvention {
	switch convention {
	case calendar.CalendarDays:
		return pb.CalendarConvention_CALENDAR_CONVENTION_CALENDAR_DAYS

	case calendar.BusinessDays:
		return pb.CalendarConvention_CALENDAR_CONVENTION_BUSINESS_DAYS

	default:
		// Leave the convention unspecified. In this case we assume the client
		// will fall back on the most appropriate convention.
		return pb.CalendarConvention_CALENDAR_CONVENTION_UNSPECIFIED
	}
}

// computeScenarioShifts computes the differences between
// the volatility value and the scenario values.
// It assumes that the input timeseries is not empty.
func computeScenarioShifts(baselineVolatility float64, scenarios map[uint32]float64) map[uint32]float64 {
	scenarioShifts := make(map[uint32]float64, len(scenarios))
	for id, scenario := range scenarios {
		scenarioShifts[id] = scenario - baselineVolatility
	}

	return scenarioShifts
}

// computeUnderlyingDividend fetches and computes the requested dividend.
func (s *service) computeUnderlyingDividend(ctx context.Context, req *pb.UnderlyingRequest, res *pb.UnderlyingResponse, spotTimeseries *marketdata.Timeseries) error {
	// If no dividend yield curve is fetched, return zero.
	if !req.GetDividendYieldCurve() {
		return nil
	}

	// Fetch dividend yield curve from Cerberus.
	dividendYieldCurve, err := s.marketDataProvider.FetchDividendYieldCurve(ctx, req.GetUnderlying().GetId())
	if err != nil {
		return fmt.Errorf("could not fetch dividend yield curve: %w", err)
	}

	dividends := mapPBDividend(dividendYieldCurve)

	res.DividendYieldCurve = &pb.DividendYieldCurve{
		Dividends: dividends,
	}

	// give priority to dividend yield if available (to minimize friction due to potentially inconsistent spot prices),
	// otherwise infer dividend yield from the stream of cash dividends.
	if dividendYield := averageDividendYield(dividends); dividendYield > epsilon {
		res.FlatDividendYield = &pb.FlatDividendYield{Yield: dividendYield}

		return nil
	}

	if spotTimeseries != nil {
		// The dividend yield is measured relative to the most recent spot price available for the timeseries.
		// (Note that dividends are not retrieved historically.)
		res.FlatDividendYield = &pb.FlatDividendYield{Yield: averageCashDividendYield(dividends, spotTimeseries.Last().Value)}

		return nil
	}

	res.FlatDividendYield = &pb.FlatDividendYield{Yield: 0.0}

	return nil
}

func (s *service) computeAverageDividend(
	dividendCurve marketdata.DividendYieldCurve,
	res *pb.UnderlyingResponse,
) error {
	averageDividendYield, err := dividendCurve.AverageDividendYield()
	if err != nil {
		return fmt.Errorf("could not compute average dividend yield: %w", err)
	}

	res.FlatDividendYield = &pb.FlatDividendYield{Yield: averageDividendYield}

	return nil
}

func (s *service) computeDividendCurveFromOptions(
	ctx context.Context,
	underlyingID string,
	snapshot time.Time,
	to date.Date,
	spotTimeseries *marketdata.Timeseries,
) (*marketdata.DividendYieldCurve, error) {
	optionChainDesc, err := s.marketDataProvider.FetchOptions(ctx, underlyingID, &to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the historical option chain: %w", err)
	}

	yieldCurve, err := s.yieldProvider.Yield(ctx, snapshot, *optionChainDesc.Currency, to)
	if err != nil {
		return nil,
			fmt.Errorf("could not fetch the yield curve values for currency %s: %w", optionChainDesc.Currency.ID, err)
	}

	spot := spotTimeseries.Last()
	if spot.Date != to {
		log.Warnf("id %s has a spot price with date %s different from requested date %s", underlyingID, spot.Date, to)
	}

	dividendCurve, err := surfacecalibration.ComputeDividendCurveFromOptionChain(optionChainDesc, spot.Value, yieldCurve)
	if err != nil {
		return nil, fmt.Errorf("could not compute dividend term structure: %w", err)
	}

	return &dividendCurve, nil
}

// validateVolatilitySurface check that the volatility ratio (market IV / LM ARCH back-bone) is within a reasonable range.
func validateVolatilitySurface(surface *marketdata.VolatilitySurface, lmArchVol float64) error {
	const (
		lowerBound   = 0.0
		upperBound   = 20.0
		minLmArchVol = 0.05
	)

	lmArchVol = math.Max(lmArchVol, minLmArchVol)

	for i, slice := range surface.Data {
		for j, vol := range slice {
			volatilityRatio := vol / lmArchVol
			if volatilityRatio < lowerBound || volatilityRatio > upperBound {
				return errors.PreconditionFailed(
					"volatility ratio value %f (%f / %f) at tenor index %d, strike index %d is outside acceptable range [%f, %f]",
					volatilityRatio, vol, lmArchVol, i, j, lowerBound, upperBound,
				)
			}
		}
	}

	return nil
}

// validateHestonParameters checks that the volatility ratio (heston parameter / LM ARCH back-bone) is within a reasonable range.
func validateHestonParameters(v0, theta float64, lmArchVol float64) error {
	const (
		lowerBound   = 0.0
		upperBound   = 20.0
		minLmArchVol = 0.05
	)

	if v0 < 0.0 {
		return errors.Bug("invalid v0 %f: variance must be non-negative", v0)
	}

	if theta < 0.0 {
		return errors.Bug("invalid theta %f: variance must be non-negative", theta)
	}

	safeLmArchVol := math.Max(lmArchVol, minLmArchVol)

	if v0Ratio := math.Sqrt(v0) / safeLmArchVol; v0Ratio < lowerBound || v0Ratio > upperBound {
		return errors.PreconditionFailed(
			"volatility ratio value %f (%f / %f) is outside acceptable range [%f, %f]",
			v0Ratio, math.Sqrt(v0), safeLmArchVol, lowerBound, upperBound,
		)
	}

	if thetaRatio := math.Sqrt(theta) / safeLmArchVol; thetaRatio < lowerBound || thetaRatio > upperBound {
		return errors.PreconditionFailed(
			"volatility ratio value %f (%f / %f) is outside acceptable range [%f, %f]",
			thetaRatio, math.Sqrt(theta), safeLmArchVol, lowerBound, upperBound,
		)
	}

	return nil
}
