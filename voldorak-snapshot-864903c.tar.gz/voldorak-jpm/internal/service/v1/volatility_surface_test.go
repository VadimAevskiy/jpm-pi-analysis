package service

import (
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/service/testdata"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func newVolatilitySurfaceRequest() *pb.VolatilitySurfaceRequest {
	return &pb.VolatilitySurfaceRequest{
		Underlying: &pb.Underlying{
			Id:   "2f7da240-1415-463b-907d-1f5c00bc70eb",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
		},
	}
}

func newVolatilitySurfaceRequestWithSSVIActivated() *pb.VolatilitySurfaceRequest {
	return &pb.VolatilitySurfaceRequest{
		Underlying: &pb.Underlying{
			Id:   "2f7da240-1415-463b-907d-1f5c00bc70eb",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_STOCK,
		},
		Snapshot: timestamppb.New(date.Today().UTC()),
		To:       timestamppb.New(date.Today().AddDate(0, 0, -3).UTC()),
	}
}

func Test_service_validateVolatilitySurfaceRequest(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		require.NoError(t, service.validateVolatilitySurfaceRequest(newVolatilitySurfaceRequest()))
	})

	t.Run("valid with snapshot and to when ssvi is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newVolatilitySurfaceRequest()
		req.Snapshot = timestamppb.New(date.Today().UTC())
		req.To = timestamppb.New(date.Today().AddDate(0, 0, -3).UTC())

		require.NoError(t, ssviActivatedService.validateVolatilitySurfaceRequest(req))
	})

	t.Run("invalid if missing snapshot when ssvi is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newVolatilitySurfaceRequest()
		req.To = timestamppb.New(date.Today().AddDate(0, 0, -3).UTC())

		err := ssviActivatedService.validateVolatilitySurfaceRequest(req)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "snapshot is not provided")
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request func() *pb.VolatilitySurfaceRequest
		}{
			"empty request": {
				request: func() *pb.VolatilitySurfaceRequest {
					return nil
				},
			},
			"missing underlying": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying = nil

					return req
				},
			},
			"missing underlying type": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_UNSPECIFIED

					return req
				},
			},
			"fx underlying type": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX

					return req
				},
			},
			"ill-formed underlying id": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying.Id = "aabbccddee"

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateVolatilitySurfaceRequest(tc.request()))
			})
		}
	})
}

func Test_mapPBSurface(t *testing.T) {
	t.Parallel()

	surface := &marketdata.VolatilitySurface{
		Data: [][]float64{
			{0.1, 0.2},
			{0.4, 0.5},
			{0.8, 0.9},
		},
		TenorYearFractions: []float64{7.0 / 365.0, 2.0 / 12.0, 5.0},
		Strikes:            []float64{100.0, 150.0},
	}

	expectedPBSurface := pb.Surface{
		Data: []*pb.TenorVolatilitySlice{
			{
				VolatilitySlice: []float64{0.1, 0.2},
			},
			{
				VolatilitySlice: []float64{0.4, 0.5},
			},
			{
				VolatilitySlice: []float64{0.8, 0.9},
			},
		},
		Tenors:  []float64{7.0 / 365.0, 2.0 / 12.0, 5.0},
		Strikes: []float64{100.0, 150.0},
	}

	mappedSurface := mapPBSurface(surface)
	assert.Equal(t, expectedPBSurface.GetTenors(), mappedSurface.GetTenors())
	assert.Equal(t, expectedPBSurface.GetStrikes(), mappedSurface.GetStrikes())
	assert.Equal(t, expectedPBSurface.GetData(), mappedSurface.GetData())
}

func Test_service_VolatilitySurface(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		req := newVolatilitySurfaceRequest()
		_, err := service.VolatilitySurface(t.Context(), req)
		require.NoError(t, err)
	})

	t.Run("valid when ssvi is activated", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newVolatilitySurfaceRequestWithSSVIActivated()
		_, err := ssviActivatedService.VolatilitySurface(t.Context(), req)
		require.NoError(t, err)
	})

	t.Run("invalid when ssvi is activated and its missing snapshot", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		req := newVolatilitySurfaceRequest()
		_, err := ssviActivatedService.VolatilitySurface(t.Context(), req)
		require.Error(t, err)
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			request      func() *pb.VolatilitySurfaceRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				request: func() *pb.VolatilitySurfaceRequest {
					return nil
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"underlying data not found": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying.Id = "0214e629-e012-4130-9e7d-9bdcb5038369"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"unknown underlying type": {
				request: func() *pb.VolatilitySurfaceRequest {
					req := newVolatilitySurfaceRequest()
					req.Underlying.Type = pb.UnderlyingType(666)

					return req
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.VolatilitySurface(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					errors.AssertTag(t, *tc.tag, err)
				}
			})
		}
	})
}

func Test_service_computeVolatilitySurfaceInputs(t *testing.T) {
	t.Parallel()

	t.Run("valid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		spotTimeSeries := &marketdata.Timeseries{
			ID:   "73e54147-f8db-4204-8b24-8f6b7be90942",
			Type: marketdata.Type("spot"),
			Entries: marketdata.Entries{
				{Date: date.New(2020, time.January, 1), Value: 100.0},
				{Date: date.New(2020, time.January, 2), Value: 100.5},
				{Date: date.New(2020, time.January, 3), Value: 101.0},
				{Date: date.New(2020, time.January, 4), Value: 100.2},
				{Date: date.New(2020, time.January, 5), Value: 100.8},
			},
		}

		optionChainDesc, spot, yieldCurve, dividendCurve, err := svc.computeVolatilitySurfaceInputs(
			t.Context(),
			"73e54147-f8db-4204-8b24-8f6b7be90942",
			date.Today().UTC(),
			date.Today(),
			spotTimeSeries,
		)

		require.NoError(t, err)
		require.NotEmpty(t, optionChainDesc.OptionChain)
		require.NotNil(t, optionChainDesc.Currency)
		require.Positive(t, spot)
		require.NotEmpty(t, yieldCurve.Data)
		require.NotEmpty(t, dividendCurve.Dividends)
	})

	t.Run("invalid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		optionChainDesc, spot, yieldCurve, dividendCurve, err := svc.computeVolatilitySurfaceInputs(
			t.Context(),
			"unknown-id",
			date.Today().UTC(),
			date.Today(),
			nil,
		)

		require.Error(t, err)
		require.Empty(t, optionChainDesc)
		require.Zero(t, spot)
		require.Empty(t, yieldCurve)
		require.Empty(t, dividendCurve)
		require.ErrorContains(t, err, "could not fetch the historical option chain")
	})
}
