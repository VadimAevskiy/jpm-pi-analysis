package service

import (
	"time"

	"google.golang.org/protobuf/types/known/timestamppb"
)

const (
	// defaultTimeWindowLag is the default time window amplitude.
	// It corresponds to 750 business days.
	defaultTimeWindowDaysLag = 750 / 5 * 7

	// returnsBusinessDaysLag defines the default time window lag
	// to use when fetching spot time series data.
	//
	// Using a large lag is more costly, but allows volatility forecasts
	// to "warm up", i.e. not to suffer from instabilities due to
	// initial conditions.
	//
	// This constant should be used only in a business-days context.
	returnsBusinessDaysLag = 1500

	// returnsDaysLag is the calendar-days equivalent of returnsBusinessDaysLag.
	//
	// This constant should be used only in a calendar-days context
	// such as data fetching based on calendar dates.
	returnsDaysLag = returnsBusinessDaysLag / 5 * 7

	// returnsPreservationLag is an additional, safety time lag
	// used to fetch spot time series data. In order to prevent
	// the most recent forecast entries to depend too much on the
	// whole spot time series window, we can add a "preservation lag"
	// in such a way that there are more returns available than
	// forecast weights.
	//
	// We set this lag to one month. This means that, for the same
	// relative horizon, volatility forecast entries will be preserved
	// when the to date moves forward by at most one month. This gives
	// the forecast more stability across consecutive days.
	//
	// This constant should only be used in a calendar-days context.
	returnsPreservationLag = 30
)

// computeFromTime computes the effective left end of a time window
// ranging from `from` to `to` proto timestamps. It returns
//
// - the input `from` parameter, if provided;
//
// - the time obtained by shifting the `to` parameter backwards
// by the default time window days lag, otherwise.
func computeEffectiveFromTime(from, to *timestamppb.Timestamp) time.Time {
	if from != nil {
		return from.AsTime()
	}

	return to.AsTime().AddDate(0, 0, -defaultTimeWindowDaysLag)
}

// computeReturnsWarmUpDate computes the date to be used as `from`
// parameter for spot time series requests for computing returns.
// For this computation, calendar days are used.
//
// The purpose of applying a window lag is to ensure return-based
// estimates (e.g. volatility) do not suffer from the choice of
// initial conditions around the `to` date.
//
// This function returns:
//
// - the input `from` if earlier than the default time window lag
// applied to the `to` parameter;
//
// - the back-shifted `to` time by the default lag otherwise.
func computeReturnsWarmUpDate(from, to time.Time) time.Time {
	if lag := to.AddDate(0, 0, -returnsDaysLag-returnsPreservationLag); lag.Before(from) {
		return lag
	}

	return from
}
