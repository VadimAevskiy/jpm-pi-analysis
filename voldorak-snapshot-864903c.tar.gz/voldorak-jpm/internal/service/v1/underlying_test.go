package service

import (
	"math"
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/calendar"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	"github.com/edgelaboratories/voldorak/internal/service/testdata"
	"github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	surfcalib "github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func newUnderlyingRequest() *pb.UnderlyingRequest {
	return &pb.UnderlyingRequest{
		Underlying: &pb.Underlying{
			Id:   "b0799580-2c2e-4384-92ce-31fd8a80e5fd",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		},
		From: timestamputil.DateToTimestamp(2020, time.January, 1),
		To:   timestamputil.DateToTimestamp(2020, time.January, 5),
		VolatilityContext: &pb.VolatilityContext{
			Horizon:                 timestamputil.DateToTimestamp(2021, time.January, 5),
			VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS,
		},
		VolatilitySurface: false,
	}
}

func newUnderlyingRequestWithSSVIActivated() *pb.UnderlyingRequest {
	return &pb.UnderlyingRequest{
		Underlying: &pb.Underlying{
			Id:   "73e54147-f8db-4204-8b24-8f6b7be90942",
			Type: pb.UnderlyingType_UNDERLYING_TYPE_FUND,
		},
		From: timestamputil.DateToTimestamp(2020, time.January, 1),
		To:   timestamputil.DateToTimestamp(2020, time.January, 5),
		VolatilityContext: &pb.VolatilityContext{
			Horizon:                 timestamputil.DateToTimestamp(2021, time.January, 5),
			VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS,
		},
		VolatilitySurface: false,
		Snapshot:          timestamppb.New(date.Today().UTC()),
	}
}

func Test_service_validateUnderlyingRequest(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		service := newService()

		t.Run("default request", func(t *testing.T) {
			t.Parallel()

			require.NoError(t, service.validateUnderlyingRequest(newUnderlyingRequest()))
		})

		for name, tc := range map[string]struct {
			request func() *pb.UnderlyingRequest
		}{
			"volatility type unspecified": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
			"90-days volatility": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
			"LM-ARCH volatility": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.NoError(t, service.validateUnderlyingRequest(tc.request()))
			})
		}
	})

	t.Run("spot request", func(t *testing.T) {
		t.Parallel()

		// This test verifies that spot requests are always valid
		// regardless of the configured volatility model, when
		// the other request parameters are valid.

		for name, tc := range map[string]struct {
			model model.VolatilityBackboneModel
		}{
			"default": {
				model: model.DefaultVolatilityBackboneModel,
			},
			"90 days": {
				model: model.MovingAverage90Days,
			},
			"LM ARCH": {
				model: model.LongMemoryARCHForecast,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				req := newUnderlyingRequest()
				req.VolatilityContext = nil

				require.NoError(t, newService(
					WithVolatilityBackboneModel(tc.model),
				).validateUnderlyingRequest(req))
			})
		}
	})

	t.Run("invalid horizon with default volatility", func(t *testing.T) {
		t.Parallel()

		// The validity of this test depends on the default volatility model:
		// - models without time dependence neglect ill-formed horizons and
		// still accept invalid requests;
		// - models with time dependency on the contrary invalidate them.

		req := newUnderlyingRequest()

		// Set the horizon one month before the to date
		// to make it systematically invalid.

		req.VolatilityContext = &pb.VolatilityContext{
			Horizon: timestamppb.New(req.GetTo().AsTime().AddDate(0, -1, 0)),
		}

		t.Run("no backbone", func(t *testing.T) {
			t.Parallel()

			for name, tc := range map[string]struct {
				opts []Option
			}{
				"moving average": {
					opts: []Option{
						WithVolatilityBackboneModel(model.MovingAverage90Days),
					},
				},
			} {
				t.Run(name, func(t *testing.T) {
					t.Parallel()

					require.NoError(t, newService(tc.opts...).validateUnderlyingRequest(req))
				})
			}
		})

		t.Run("with backbone", func(t *testing.T) {
			t.Parallel()

			for name, tc := range map[string]struct {
				opts []Option
			}{
				"default": {
					opts: nil,
				},
				"LM ARCH": {
					opts: []Option{
						WithVolatilityBackboneModel(model.LongMemoryARCHForecast),
					},
				},
			} {
				t.Run(name, func(t *testing.T) {
					t.Parallel()

					require.Error(t, newService(tc.opts...).validateUnderlyingRequest(req))
				})
			}
		})
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		service := newService()

		for name, tc := range map[string]struct {
			request func() *pb.UnderlyingRequest
		}{
			"empty request": {
				request: func() *pb.UnderlyingRequest {
					return nil
				},
			},
			"missing to": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.To = nil

					return req
				},
			},
			"from later than to": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.From = timestamppb.New(req.GetTo().AsTime().Add(12 * time.Hour))

					return req
				},
			},
			"missing underlying": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Underlying = nil

					return req
				},
			},
			"ill-formed underlying id/asset": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Underlying.Id = "aabbccddee"

					return req
				},
			},
			"ill-formed underlying id/fx": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "abd-usd"

					return req
				},
			},
			"missing volatility context horizon": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 nil,
					}

					return req
				},
			},
			"volatility context horizon before to date": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 timestamppb.New(req.GetTo().AsTime().Add(-12 * time.Hour)),
					}

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateUnderlyingRequest(tc.request()))
			})
		}
	})
}

func Test_service_validateUnderlyingRequest_SSVI_Activated(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		ssviActivatedService := newService()
		ssviActivatedService.SSVICalibrationActivated = true

		t.Run("default request", func(t *testing.T) {
			t.Parallel()

			require.NoError(t, ssviActivatedService.validateUnderlyingRequest(newUnderlyingRequestWithSSVIActivated()))
		})

		for name, tc := range map[string]struct {
			request func() *pb.UnderlyingRequest
		}{
			"volatility type unspecified": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
			"90-days volatility": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
			"LM-ARCH volatility": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 timestamputil.DateToTimestamp(2021, time.March, 2),
					}

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.NoError(t, ssviActivatedService.validateUnderlyingRequest(tc.request()))
			})
		}
	})

	t.Run("spot request", func(t *testing.T) {
		t.Parallel()

		// This test verifies that spot requests are always valid
		// regardless of the configured volatility model, when
		// the other request parameters are valid.

		for name, tc := range map[string]struct {
			model model.VolatilityBackboneModel
		}{
			"default": {
				model: model.DefaultVolatilityBackboneModel,
			},
			"90 days": {
				model: model.MovingAverage90Days,
			},
			"LM ARCH": {
				model: model.LongMemoryARCHForecast,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				req := newUnderlyingRequestWithSSVIActivated()
				req.VolatilityContext = nil

				service := newService(WithVolatilityBackboneModel(tc.model))
				service.SSVICalibrationActivated = true

				require.NoError(t, service.validateUnderlyingRequest(req))
			})
		}
	})

	t.Run("invalid horizon with default volatility", func(t *testing.T) {
		t.Parallel()

		// The validity of this test depends on the default volatility model:
		// - models without time dependence neglect ill-formed horizons and
		// still accept invalid requests;
		// - models with time dependency on the contrary invalidate them.

		req := newUnderlyingRequestWithSSVIActivated()

		// Set the horizon one month before the to date
		// to make it systematically invalid.

		req.VolatilityContext = &pb.VolatilityContext{
			Horizon: timestamppb.New(req.GetTo().AsTime().AddDate(0, -1, 0)),
		}

		t.Run("no backbone", func(t *testing.T) {
			t.Parallel()

			for name, tc := range map[string]struct {
				opts []Option
			}{
				"moving average": {
					opts: []Option{
						WithVolatilityBackboneModel(model.MovingAverage90Days),
					},
				},
			} {
				t.Run(name, func(t *testing.T) {
					t.Parallel()

					service := newService(tc.opts...)
					service.SSVICalibrationActivated = true
					require.NoError(t, service.validateUnderlyingRequest(req))
				})
			}
		})

		t.Run("with backbone", func(t *testing.T) {
			t.Parallel()

			for name, tc := range map[string]struct {
				opts []Option
			}{
				"default": {
					opts: nil,
				},
				"LM ARCH": {
					opts: []Option{
						WithVolatilityBackboneModel(model.LongMemoryARCHForecast),
					},
				},
			} {
				t.Run(name, func(t *testing.T) {
					t.Parallel()

					ssviActivatedService := newService(tc.opts...)
					ssviActivatedService.SSVICalibrationActivated = true

					require.Error(t, ssviActivatedService.validateUnderlyingRequest(req))
				})
			}
		})
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		service := newService()
		service.SSVICalibrationActivated = true

		for name, tc := range map[string]struct {
			request func() *pb.UnderlyingRequest
		}{
			"empty request": {
				request: func() *pb.UnderlyingRequest {
					return nil
				},
			},
			"missing to": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.To = nil

					return req
				},
			},
			"missing snapshot": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Snapshot = nil

					return req
				},
			},
			"from later than to": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.From = timestamppb.New(req.GetTo().AsTime().Add(12 * time.Hour))

					return req
				},
			},
			"missing underlying": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Underlying = nil

					return req
				},
			},
			"ill-formed underlying id/asset": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Underlying.Id = "aabbccddee"

					return req
				},
			},
			"ill-formed underlying id/fx": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Underlying.Type = pb.UnderlyingType_UNDERLYING_TYPE_FX
					req.Underlying.Id = "abd-usd"

					return req
				},
			},
			"missing volatility context horizon": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 nil,
					}

					return req
				},
			},
			"volatility context horizon before to date": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = &pb.VolatilityContext{
						VolatilityBackboneModel: pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
						Horizon:                 timestamppb.New(req.GetTo().AsTime().Add(-12 * time.Hour)),
					}

					return req
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.Error(t, service.validateUnderlyingRequest(tc.request()))
			})
		}
	})
}

//nolint:maintidx // Test function with multiple subtests is expected to have high complexity.
func Test_service_Underlying(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		t.Run("default request", func(t *testing.T) {
			t.Parallel()

			service := newService()
			_, err := service.Underlying(t.Context(), newUnderlyingRequest())
			assert.NoError(t, err)
		})

		const expectedConvention = pb.CalendarConvention_CALENDAR_CONVENTION_BUSINESS_DAYS

		scenarios := map[uint32]*pb.Scenario{
			1: {
				Id:      1,
				Horizon: 10,
			},
			2: {
				Id:      2,
				Horizon: 30,
			},
		}

		// This test checks that:
		// - spot and volatility responses are not nil
		// - the expected calendar convention is returned.

		for name, tc := range map[string]struct {
			opts    []Option
			request *pb.UnderlyingRequest
		}{
			"spot/without scenarios/unspecified backbone model": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()

					return req
				}(),
			},
			"spot/without scenarios/with backbone model": {
				opts: []Option{
					WithVolatilityBackboneModel(model.MovingAverage90Days),
				},
				request: func() *pb.UnderlyingRequest {
					// Note that in this case the default backbone model requires a business
					// days convention, even when the volatility is not specified.
					req := newUnderlyingRequest()
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot and volatility/without scenarios": {
				opts:    nil,
				request: newUnderlyingRequest(),
			},
			"spot and volatility/without scenarios/with backbone model": {
				opts: []Option{
					WithVolatilityBackboneModel(model.MovingAverage90Days),
				},
				request: func() *pb.UnderlyingRequest {
					// In this case the backbone model is unspecified in the request,
					// so the service default one should be adopted with the
					// consequent calendar convention.
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED

					return req
				}(),
			},
			"spot/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility/with scenarios/90 days": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility/with scenarios/lm-arch": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility surface/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilitySurface = true
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot, volatility surface and dividend yield curve/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.DividendYieldCurve = true

					return req
				}(),
			},
			"spot and dividend yield curve/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.DividendYieldCurve = true
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot and volatility surface/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot, volatility surface and dividend yield curve/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.DividendYieldCurve = true
					req.Scenarios = scenarios

					return req
				}(),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				service := newService(tc.opts...)

				wantVolatility := tc.request.GetVolatilityContext() != nil
				wantVolatilitySurface := tc.request.GetVolatilitySurface()
				wantDividendYieldCurve := tc.request.GetDividendYieldCurve()
				wantScenarios := len(tc.request.GetScenarios()) > 0

				res, err := service.Underlying(t.Context(), tc.request)
				require.NoError(t, err)

				spot := res.GetSpot()
				require.NotNil(t, spot)
				assert.NotNil(t, spot.GetTimeseries())
				assert.Equal(t, wantScenarios, len(spot.GetScenarios()) > 0)

				volatility := res.GetVolatility()
				assert.Equal(t, wantVolatility, volatility != nil)

				if wantVolatility {
					assert.NotNil(t, volatility.GetTimeseries())
					assert.Equal(t, wantScenarios, len(volatility.GetScenarios()) > 0)
				}

				volatilitySurface := res.GetVolatilitySurface()
				assert.Equal(t, wantVolatilitySurface, volatilitySurface != nil)

				if wantVolatilitySurface {
					assert.NotNil(t, volatilitySurface.GetSurface())
					assert.Equal(t, wantScenarios, len(volatilitySurface.GetScenarioShifts()) > 0)
				}

				dividendYieldCurve := res.GetDividendYieldCurve()
				assert.Equal(t, wantDividendYieldCurve, dividendYieldCurve != nil)

				if wantDividendYieldCurve {
					assert.NotNil(t, dividendYieldCurve.GetDividends())
				}

				assert.Equal(t, expectedConvention, res.GetConvention())
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		service := newService()

		for name, tc := range map[string]struct {
			request      func() *pb.UnderlyingRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				request: func() *pb.UnderlyingRequest {
					return nil
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"underlying data not found/asset": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Underlying.Id = "a924d2ac-c55d-4959-a693-18bb27ad6a24"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"missing scenarios": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.Underlying.Id = "2ff645bf-50fe-492c-8f2e-04639a884560"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 10,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"no spot data": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED
					req.Underlying = &pb.Underlying{
						Id:   "CHF-AUD",
						Type: pb.UnderlyingType_UNDERLYING_TYPE_FX,
					}

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"not enough data to compute returns": {
				request: func() *pb.UnderlyingRequest {
					// In this case there are not enough valid spot data to
					// compute returns. This situation is for the moment handled
					// as a missing data instance via a NotFound status code.
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "37b3193a-9706-46c6-8293-d4c152523e49"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
			"not enough spot data in window": {
				request: func() *pb.UnderlyingRequest {
					// In this case the spot time series warms up before the from date,
					// so there are spot returns available.
					// However, the last return falls before the input time window, so
					// there are no spot data within the desired time frame.
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2021, time.January, 4)
					req.To = timestamputil.DateToTimestamp(2021, time.January, 5)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"only one return in window for volatility": {
				request: func() *pb.UnderlyingRequest {
					// In this case the spot time series "warms up" before the from date,
					// so there are spot returns available.
					// However, the last return falls on the first day of the time window,
					// so the volatility estimate will have only one return at disposal.
					// This case should produce a FailedPrecondition error code at some point.
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2020, time.January, 3)
					req.To = timestamputil.DateToTimestamp(2020, time.January, 4)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
			"volatility scenario provider/missing scenarios": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "1b940b30-751f-4d55-b8af-b027ee5aed7a"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 10,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"volatility scenario provider/unsupported scenario horizon": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "e4808f35-2a90-4a60-bebe-263c938ac20b"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 3000,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"volatility surface/too high volatility ratio exceeds upper bound": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequest()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.Underlying.Id = "11111111-1111-1111-1111-111111111111"
					req.From = timestamputil.DateToTimestamp(2024, time.December, 2)
					req.To = timestamputil.DateToTimestamp(2024, time.December, 31)

					return req
				},
				expectedCode: codes.FailedPrecondition,
				tag:          nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.Underlying(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					_, _, tag := errors.FromGRPC(err)
					assert.Equal(t, *tc.tag, tag)
				}
			})
		}
	})
}

//nolint:maintidx // Test function with multiple subtests is expected to have high complexity.
func Test_service_Underlying_SSVI_activated(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		t.Run("default request", func(t *testing.T) {
			t.Parallel()

			ssviActivatedService := newService()
			ssviActivatedService.SSVICalibrationActivated = true

			_, err := ssviActivatedService.Underlying(t.Context(), newUnderlyingRequestWithSSVIActivated())
			assert.NoError(t, err)
		})

		const expectedConvention = pb.CalendarConvention_CALENDAR_CONVENTION_BUSINESS_DAYS

		scenarios := map[uint32]*pb.Scenario{
			1: {
				Id:      1,
				Horizon: 10,
			},
			2: {
				Id:      2,
				Horizon: 30,
			},
		}

		// This test checks that:
		// - spot and volatility responses are not nil
		// - the expected calendar convention is returned.

		for name, tc := range map[string]struct {
			opts    []Option
			request *pb.UnderlyingRequest
		}{
			"spot/without scenarios/unspecified backbone model": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()

					return req
				}(),
			},
			"spot/without scenarios/with backbone model": {
				opts: []Option{
					WithVolatilityBackboneModel(model.MovingAverage90Days),
				},
				request: func() *pb.UnderlyingRequest {
					// Note that in this case the default backbone model requires a business
					// days convention, even when the volatility is not specified.
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot and volatility/without scenarios": {
				opts:    nil,
				request: newUnderlyingRequestWithSSVIActivated(),
			},
			"spot and volatility/without scenarios/with backbone model": {
				opts: []Option{
					WithVolatilityBackboneModel(model.MovingAverage90Days),
				},
				request: func() *pb.UnderlyingRequest {
					// In this case the backbone model is unspecified in the request,
					// so the service default one should be adopted with the
					// consequent calendar convention.
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED

					return req
				}(),
			},
			"spot/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility/with scenarios/90 days": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility/with scenarios/lm-arch": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot and volatility surface/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilitySurface = true
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot, volatility surface and dividend yield curve/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.DividendYieldCurve = true

					return req
				}(),
			},
			"spot and dividend yield curve/no scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.DividendYieldCurve = true
					req.VolatilityContext = nil

					return req
				}(),
			},
			"spot and volatility surface/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.Scenarios = scenarios

					return req
				}(),
			},
			"spot, volatility surface and dividend yield curve/with scenarios": {
				opts: nil,
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.DividendYieldCurve = true
					req.Scenarios = scenarios

					return req
				}(),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				service := newService(tc.opts...)
				service.SSVICalibrationActivated = true

				wantVolatility := tc.request.GetVolatilityContext() != nil
				wantVolatilitySurface := tc.request.GetVolatilitySurface()
				wantDividendYieldCurve := tc.request.GetDividendYieldCurve()
				wantScenarios := len(tc.request.GetScenarios()) > 0

				res, err := service.Underlying(t.Context(), tc.request)
				require.NoError(t, err)

				spot := res.GetSpot()
				require.NotNil(t, spot)
				assert.NotNil(t, spot.GetTimeseries())
				assert.Equal(t, wantScenarios, len(spot.GetScenarios()) > 0)

				volatility := res.GetVolatility()
				assert.Equal(t, wantVolatility, volatility != nil)

				if wantVolatility {
					assert.NotNil(t, volatility.GetTimeseries())
					assert.Equal(t, wantScenarios, len(volatility.GetScenarios()) > 0)
				}

				volatilitySurface := res.GetVolatilitySurface()
				assert.Equal(t, wantVolatilitySurface, volatilitySurface != nil)

				if wantVolatilitySurface {
					assert.NotNil(t, volatilitySurface.GetSurface())
					assert.Equal(t, wantScenarios, len(volatilitySurface.GetScenarioShifts()) > 0)
				}

				dividendYieldCurve := res.GetDividendYieldCurve()
				assert.Equal(t, wantDividendYieldCurve, dividendYieldCurve != nil)

				if wantDividendYieldCurve {
					assert.NotNil(t, dividendYieldCurve.GetDividends())
				}

				assert.Equal(t, expectedConvention, res.GetConvention())
			})
		}
	})

	t.Run("SSVI calibration activated and missing snapshot returns bad request", func(t *testing.T) {
		t.Parallel()

		svc := newService()
		svc.SSVICalibrationActivated = true

		req := newUnderlyingRequestWithSSVIActivated()
		req.Snapshot = nil

		err := svc.validateUnderlyingRequest(req)

		require.Error(t, err)
		assert.ErrorContains(t, err, "snapshot is not provided")
	})

	t.Run("valid Heston model returns calibration unimplemented error", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider:         &testdata.Provider{},
			yieldProvider:              testdata.MockYieldProvider{},
			HestonCalibrationActivated: true,
			SSVICalibrationActivated:   true,
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.VolatilitySurfaceModel = pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON
		req.Scenarios = nil

		res := &pb.UnderlyingResponse{}

		err := svc.computeVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			testSpotTimeseries(),
			testReturnsTimeseries(),
		)

		require.Error(t, err)
		require.Nil(t, res.GetVolatilitySurface())
		require.ErrorContains(t, err, "could not compute Heston volatility surface")
		assert.ErrorContains(t, err, "not implemented")
	})

	t.Run("Heston model requested but Heston calibration disabled uses SSVI", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider:         &testdata.Provider{},
			yieldProvider:              testdata.MockYieldProvider{},
			HestonCalibrationActivated: false,
			SSVICalibrationActivated:   true,
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.VolatilitySurfaceModel = pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON
		req.Scenarios = nil

		res := &pb.UnderlyingResponse{}

		err := svc.computeVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			testSpotTimeseries(),
			testReturnsTimeseries(),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatilitySurface())
		require.NotNil(t, res.GetVolatilitySurface().GetSurface())
		assert.Empty(t, res.GetVolatilitySurface().GetScenarioShifts())
	})

	t.Run("Heston calibration activated and missing volatility surface model returns bad request", func(t *testing.T) {
		t.Parallel()

		svc := newService()
		svc.HestonCalibrationActivated = true

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.VolatilitySurfaceModel = pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED

		err := svc.validateUnderlyingRequest(req)

		require.Error(t, err)
		assert.ErrorContains(t, err, "volatility surface model is not provided")
	})

	t.Run("Heston calibration disabled allows unspecified volatility surface model", func(t *testing.T) {
		t.Parallel()

		svc := newService()
		svc.HestonCalibrationActivated = false

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.VolatilitySurfaceModel = pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED

		err := svc.validateUnderlyingRequest(req)

		require.NoError(t, err)
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		service := newService()

		for name, tc := range map[string]struct {
			request      func() *pb.UnderlyingRequest
			expectedCode codes.Code
			tag          *errors.Tag
		}{
			"invalid request": {
				request: func() *pb.UnderlyingRequest {
					return nil
				},
				expectedCode: codes.InvalidArgument,
				tag:          nil,
			},
			"underlying data not found/asset": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Underlying.Id = "a924d2ac-c55d-4959-a693-18bb27ad6a24"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          nil,
			},
			"missing scenarios": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.Underlying.Id = "2ff645bf-50fe-492c-8f2e-04639a884560"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 10,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"no spot data": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED
					req.Underlying = &pb.Underlying{
						Id:   "CHF-AUD",
						Type: pb.UnderlyingType_UNDERLYING_TYPE_FX,
					}

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"not enough data to compute returns": {
				request: func() *pb.UnderlyingRequest {
					// In this case there are not enough valid spot data to
					// compute returns. This situation is for the moment handled
					// as a missing data instance via a NotFound status code.
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "37b3193a-9706-46c6-8293-d4c152523e49"

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
			"not enough spot data in window": {
				request: func() *pb.UnderlyingRequest {
					// In this case the spot time series warms up before the from date,
					// so there are spot returns available.
					// However, the last return falls before the input time window, so
					// there are no spot data within the desired time frame.
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2021, time.January, 4)
					req.To = timestamputil.DateToTimestamp(2021, time.January, 5)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.TimeSeriesDataTooOld,
			},
			"only one return in window for volatility": {
				request: func() *pb.UnderlyingRequest {
					// In this case the spot time series "warms up" before the from date,
					// so there are spot returns available.
					// However, the last return falls on the first day of the time window,
					// so the volatility estimate will have only one return at disposal.
					// This case should produce a FailedPrecondition error code at some point.
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "a27bc5a7-105c-415f-9272-5c9b27b48530"
					req.From = timestamputil.DateToTimestamp(2020, time.January, 3)
					req.To = timestamputil.DateToTimestamp(2020, time.January, 4)

					return req
				},
				expectedCode: codes.NotFound,
				tag:          &tag.NotEnoughData,
			},
			"volatility scenario provider/missing scenarios": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "1b940b30-751f-4d55-b8af-b027ee5aed7a"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 10,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"volatility scenario provider/unsupported scenario horizon": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilityContext.VolatilityBackboneModel = pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH
					req.Underlying.Id = "e4808f35-2a90-4a60-bebe-263c938ac20b"
					req.Scenarios = map[uint32]*pb.Scenario{
						1: {
							Id:      1,
							Horizon: 3000,
						},
					}

					return req
				},
				expectedCode: codes.Internal,
				tag:          nil,
			},
			"volatility surface/too high volatility ratio exceeds upper bound": {
				request: func() *pb.UnderlyingRequest {
					req := newUnderlyingRequestWithSSVIActivated()
					req.VolatilitySurface = true
					req.VolatilityContext = nil
					req.Underlying.Id = "11111111-1111-1111-1111-111111111111"
					req.From = timestamputil.DateToTimestamp(2024, time.December, 2)
					req.To = timestamputil.DateToTimestamp(2024, time.December, 31)

					return req
				},
				expectedCode: codes.FailedPrecondition,
				tag:          nil,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, err := service.Underlying(t.Context(), tc.request())
				require.Error(t, err)
				assert.Equal(t, tc.expectedCode, status.Convert(err).Code())

				if tc.tag != nil {
					_, _, tag := errors.FromGRPC(err)
					assert.Equal(t, *tc.tag, tag)
				}
			})
		}
	})
}

func Test_service_mapCalendarConvention(t *testing.T) {
	t.Parallel()

	service := newService()

	for name, tc := range map[string]struct {
		input    calendar.Convention
		expected pb.CalendarConvention
	}{
		"calendar days": {
			input:    calendar.CalendarDays,
			expected: pb.CalendarConvention_CALENDAR_CONVENTION_CALENDAR_DAYS,
		},
		"business days": {
			input:    calendar.BusinessDays,
			expected: pb.CalendarConvention_CALENDAR_CONVENTION_BUSINESS_DAYS,
		},
		"undefined": {
			input:    calendar.Convention("Undefined"),
			expected: pb.CalendarConvention_CALENDAR_CONVENTION_UNSPECIFIED,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, service.mapCalendarConvention(tc.input))
		})
	}
}

func Test_service_computeScenariosScalingFactors(t *testing.T) {
	t.Parallel()

	service := newService()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		const tol = 1e-15

		req := newUnderlyingRequest()
		req.Scenarios = map[uint32]*pb.Scenario{
			1: {
				Id:      1,
				Horizon: 10,
			},
		}
		returns := &marketdata.ReturnsTimeseries{
			Calendar:   calendar.New(calendar.BusinessDays),
			ReturnType: marketdata.RelativeReturn,
			Entries: marketdata.ReturnEntries{
				{
					Date:  date.New(2021, time.September, 23),
					Value: 0.02,
					Days:  1,
				},
			},
		}

		scenarioVol := 0.2
		referenceVol := 0.2
		scenarios, err := service.computeScenariosScalingFactors(
			t.Context(),
			returns,
			map[uint32]*pb.Scenario{
				1: {
					Id:      1,
					Horizon: 3,
				},
			},
			model.MovingAverage90Days,
			referenceVol,
			timestamputil.DateToTimestamp(2020, time.January, 5).AsTime(),
			timestamputil.DateToTimestamp(2021, time.January, 5).AsTime(),
			mapPBToMarketdataType(pb.UnderlyingType_UNDERLYING_TYPE_FUND),
			"b0799580-2c2e-4384-92ce-31fd8a80e5fd",
		)
		require.NoError(t, err)

		assert.Len(t, scenarios, 1)
		assert.InDelta(t, scenarios[1], scenarioVol, tol)
	})

	t.Run("missing scenarios", func(t *testing.T) {
		t.Parallel()

		volScenarios, err := service.computeScenariosScalingFactors(
			t.Context(),
			nil,
			map[uint32]*pb.Scenario{},
			model.MovingAverage90Days,
			0.0,
			timestamputil.DateToTimestamp(2020, time.January, 5).AsTime(),
			timestamputil.DateToTimestamp(2021, time.January, 5).AsTime(),
			mapPBToMarketdataType(pb.UnderlyingType_UNDERLYING_TYPE_FUND),
			"b0799580-2c2e-4384-92ce-31fd8a80e5fd",
		)
		assert.Equal(t, map[uint32]float64{}, volScenarios)
		require.NoError(t, err)
	})
}

func Test_service_scaleVolatilityScenarios(t *testing.T) {
	t.Parallel()

	const (
		scenarioID uint32  = 1
		tol        float64 = 1e-15
	)

	service := newService()

	scenarios := map[uint32]*pb.Scenario{
		scenarioID: {
			Id:      scenarioID,
			Horizon: 10,
		},
	}

	referenceVol, scenarioRealization := 0.5, 0.2
	lastDate := date.New(2021, time.January, 1)
	universalHorizon := float64(model.ReferenceScenarioHorizon)

	for name, tc := range map[string]struct {
		scaler      scenario.Scaler
		horizonDate date.Date
		expected    float64
	}{
		"long memory arch": {
			scaler:      scenario.NewLongMemoryARCHScaler(),
			horizonDate: date.New(2021, time.January, 31),
			expected: func() float64 {
				// There are 10 business days between scenario date (15th = 1st + 10 business
				// days) and the horizon date (31st, Sunday).
				horizon := 10.0
				scalingFactor := 1.0 - 0.5*math.Tanh(0.41*math.Log(horizon/universalHorizon))

				return math.Pow(scenarioRealization/referenceVol, scalingFactor)
			}(),
		},
		"long memory arch with negative horizon": {
			scaler:      scenario.NewLongMemoryARCHScaler(),
			horizonDate: lastDate.Add(5),
			expected: func() float64 {
				// scaling factor for a 10 days scenario horizon
				// the amplitude and slope paremeters are respectively 0.5 and 0.41.
				scalingFactor := 1.0 - 0.5*math.Tanh(0.41*math.Log(1.0/universalHorizon))
				return math.Pow(scenarioRealization/referenceVol, scalingFactor)
			}(),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			realizations := map[uint32]float64{
				scenarioID: scenarioRealization,
			}

			volScenarios := service.computeScalingFactors(scenarios, calendar.New(calendar.BusinessDays), realizations, referenceVol, tc.scaler, lastDate, tc.horizonDate)
			require.Len(t, scenarios, 1)
			require.Contains(t, volScenarios, scenarioID)
			assert.InDelta(t, tc.expected, volScenarios[scenarioID], tol)
		})
	}
}

func Test_mapVolatilityBackboneModel(t *testing.T) {
	t.Parallel()

	service := newService()

	for name, tc := range map[string]struct {
		pbModel  pb.VolatilityBackboneModel
		expected model.VolatilityBackboneModel
	}{
		"90 days": {
			pbModel:  pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_90_DAYS,
			expected: model.MovingAverage90Days,
		},
		"lm-arch": {
			pbModel:  pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_LM_ARCH,
			expected: model.LongMemoryARCHForecast,
		},
		"unspecified": {
			pbModel:  pb.VolatilityBackboneModel_VOLATILITY_BACKBONE_MODEL_TYPE_UNSPECIFIED,
			expected: model.DefaultVolatilityBackboneModel,
		},
		"unknown": {
			pbModel:  pb.VolatilityBackboneModel(666),
			expected: model.DefaultVolatilityBackboneModel,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tc.expected, service.mapVolatilityBackboneModel(tc.pbModel))
		})
	}
}

func Test_computeScenarioShifts(t *testing.T) {
	t.Parallel()

	const tol = 1e-13

	ts := &marketdata.Timeseries{
		Entries: marketdata.Entries{
			&marketdata.Entry{
				Date:  date.New(2022, time.July, 1),
				Value: 0.5,
			},
		},
	}

	for name, tc := range map[string]struct {
		scenarios      map[uint32]float64
		expectedShifts map[uint32]float64
	}{
		"no scenarios": {
			scenarios:      map[uint32]float64{},
			expectedShifts: map[uint32]float64{},
		},
		"valid case": {
			scenarios: map[uint32]float64{
				1001:  0.7,
				1502:  0.2,
				12345: 0.5,
			},
			expectedShifts: map[uint32]float64{
				1001:  0.2,
				1502:  -0.3,
				12345: 0.0,
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			shifts := computeScenarioShifts(ts.Last().Value, tc.scenarios)
			assert.Len(t, shifts, len(tc.expectedShifts))

			for id, shift := range shifts {
				require.Contains(t, tc.expectedShifts, id)
				assert.InDelta(t, tc.expectedShifts[id], shift, tol)
			}
		})
	}
}

func Test_proxiesMapToPBProxiesList(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		input    map[string]map[uint32]*scenario.Proxies
		expected map[string]*pb.ProxyPerScenarioResponse
	}{
		"empty map": {
			input:    make(map[string]map[uint32]*scenario.Proxies),
			expected: make(map[string]*pb.ProxyPerScenarioResponse, 0),
		},
		"valid case": {
			input: map[string]map[uint32]*scenario.Proxies{
				"fundA": {
					1: {
						Intercept: 0.5,
						Betas: map[string]float64{
							"proxy1": 1.0,
							"proxy2": 2.0,
						},
					},
					2: {
						Intercept: 1.5,
						Betas: map[string]float64{
							"proxy3": 3.0,
						},
					},
				},
				"fundB": {
					1: {
						Intercept: 2.5,
						Betas: map[string]float64{
							"proxy4": 4.0,
						},
					},
				},
			},
			expected: map[string]*pb.ProxyPerScenarioResponse{
				"fundA": {
					Proxies: map[uint32]*pb.ProxyResponse{
						1: {
							Intercept: 0.5,
							Betas: map[string]float64{
								"proxy1": 1.0,
								"proxy2": 2.0,
							},
						},
						2: {
							Intercept: 1.5,
							Betas: map[string]float64{
								"proxy3": 3.0,
							},
						},
					},
				},
				"fundB": {
					Proxies: map[uint32]*pb.ProxyResponse{
						1: {
							Intercept: 2.5,
							Betas: map[string]float64{
								"proxy4": 4.0,
							},
						},
					},
				},
			},
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			result := proxiesMapToPBProxiesList(tc.input)
			assert.Equal(t, tc.expected, result)
		})
	}
}

func Test_validateVolatilitySurface(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			surface   *marketdata.VolatilitySurface
			lmArchVol float64
		}{
			"ratio within bounds": {
				surface: &marketdata.VolatilitySurface{
					Data: [][]float64{
						{0.1, 0.2},
						{0.4, 0.5},
						{0.8, 0.9},
					},
					TenorYearFractions: []float64{7.0 / 365.0, 2.0 / 12.0, 5.0},
					Strikes:            []float64{100.0, 150.0},
				},
				lmArchVol: 0.2,
			},
			"ratio at upper bound": {
				surface: &marketdata.VolatilitySurface{
					Data: [][]float64{
						{1.4},
					},
					TenorYearFractions: []float64{1.0},
					Strikes:            []float64{100.0},
				},
				lmArchVol: 0.2,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				require.NoError(t, validateVolatilitySurface(tc.surface, tc.lmArchVol))
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			surface   *marketdata.VolatilitySurface
			lmArchVol float64
		}{
			"volatility ratio exceeds upper bound": {
				surface: &marketdata.VolatilitySurface{
					Data: [][]float64{
						{0.1, 0.2},
						{40.0, 1.5},
					},
					TenorYearFractions: []float64{1.0, 2.0},
					Strikes:            []float64{100.0, 150.0},
				},
				lmArchVol: 0.2,
			},
			"negative volatility": {
				surface: &marketdata.VolatilitySurface{
					Data: [][]float64{
						{0.1, -0.2},
					},
					TenorYearFractions: []float64{1.0},
					Strikes:            []float64{100.0, 150.0},
				},
				lmArchVol: 0.2,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				err := validateVolatilitySurface(tc.surface, tc.lmArchVol)
				assert.Equal(t, codes.FailedPrecondition, errors.StatusFrom(err).GRPCCode)
			})
		}
	})
}

func Test_validateHestonParameters(t *testing.T) {
	t.Parallel()

	t.Run("valid parameters", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			v0        float64
			theta     float64
			lmArchVol float64
		}{
			"ratios within bounds": {
				v0:        0.04,
				theta:     0.09,
				lmArchVol: 0.2,
			},
			"uses minimum lm arch volatility": {
				v0:        0.04,
				theta:     0.04,
				lmArchVol: 0.01,
			},
			"ratio exactly upper bound": {
				v0:        1.0,
				theta:     1.0,
				lmArchVol: 0.05,
			},
			"ratio exactly lower bound": {
				v0:        0.0,
				theta:     0.0,
				lmArchVol: 0.2,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				err := validateHestonParameters(tc.v0, tc.theta, tc.lmArchVol)
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid parameters", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			v0             float64
			theta          float64
			lmArchVol      float64
			expectedStatus errors.StatusCode
		}{
			"v0 ratio above upper bound": {
				v0:             1.01,
				theta:          0.04,
				lmArchVol:      0.05,
				expectedStatus: errors.StatusCodePreconditionFailed,
			},
			"theta ratio above upper bound": {
				v0:             0.04,
				theta:          1.01,
				lmArchVol:      0.05,
				expectedStatus: errors.StatusCodePreconditionFailed,
			},
			"v0 ratio above upper bound with minimum lm arch volatility": {
				v0:             1.01,
				theta:          0.04,
				lmArchVol:      0.01,
				expectedStatus: errors.StatusCodePreconditionFailed,
			},
			"negative v0 returns bug": {
				v0:             -0.01,
				theta:          0.04,
				lmArchVol:      0.2,
				expectedStatus: errors.StatusCodeBug,
			},
			"negative theta returns bug": {
				v0:             0.04,
				theta:          -0.01,
				lmArchVol:      0.2,
				expectedStatus: errors.StatusCodeBug,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				err := validateHestonParameters(tc.v0, tc.theta, tc.lmArchVol)

				require.Error(t, err)
				errors.AssertStatus(t, tc.expectedStatus, err)
			})
		}
	})
}

var irCurveSample = termstructure.TermStructure{
	Data: map[termstructure.Tenor]float64{
		"M1":  -5.403085386509094e-15,
		"M12": 0.00059419151966005,
		"M18": 0.0013354644743006647,
	},
}

var optionChainSample = surfcalib.OptionChain{
	0.4904109589: surfcalib.SurfaceSlice{
		14200.0: surfcalib.OptionPair{Call: new(769.75), Put: new(853.00)},
		14300.0: surfcalib.OptionPair{Call: new(714.25), Put: new(897.50)},
		14400.0: surfcalib.OptionPair{Call: new(661.25), Put: new(944.50)},
		14500.0: surfcalib.OptionPair{Call: new(610.50), Put: new(993.50)},
		14600.0: surfcalib.OptionPair{Call: new(562.00), Put: new(1045.00)},
		14700.0: surfcalib.OptionPair{Call: new(516.00), Put: new(1099.00)},
		14800.0: surfcalib.OptionPair{Call: new(472.25), Put: new(1155.50)},
	},
	0.7397260274: surfcalib.SurfaceSlice{
		14000.0: surfcalib.OptionPair{Call: new(1066.75), Put: new(951.75)},
		14100.0: surfcalib.OptionPair{Call: new(1009.25), Put: new(994.25)},
		14200.0: surfcalib.OptionPair{Call: new(953.50), Put: new(1038.50)},
		14300.0: surfcalib.OptionPair{Call: new(899.75), Put: new(1084.75)},
		14400.0: surfcalib.OptionPair{Call: new(848.00), Put: new(1132.75)},
		14500.0: surfcalib.OptionPair{Call: new(797.75), Put: new(1182.75)},
		14600.0: surfcalib.OptionPair{Call: new(749.50), Put: new(1234.50)},
		14700.0: surfcalib.OptionPair{Call: new(703.25), Put: new(1288.00)},
		14800.0: surfcalib.OptionPair{Call: new(658.50), Put: new(1343.25)},
	},
}

func Test_computeVolatilitySurface(t *testing.T) {
	t.Parallel()

	t.Run("valid american volatility surface computation", func(t *testing.T) {
		t.Parallel()

		yieldCurve := irCurveSample
		require.NoError(t, yieldCurve.BuildInterpolator())

		optionChainDesc := surfcalib.OptionChainDescription{
			OptionChain:        optionChainSample,
			ExerciseType:       marketdata.American,
			DaycountConvention: marketdata.DaycountConvention("ActAct"),
		}

		const spotPrice = 14137.23

		gridStrikes := generateGridStrikes(spotPrice)

		dividendCurve := marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{DividendZeroRate: 0.02, YearFraction: 0.5},
				{DividendZeroRate: 0.02, YearFraction: 1.0},
				{DividendZeroRate: 0.02, YearFraction: 2.0},
			},
		}

		got, err := computeSurface(optionChainDesc, spotPrice, yieldCurve, dividendCurve)
		require.NoError(t, err)
		require.NotNil(t, got)

		assert.Equal(t, gridTenors, got.TenorYearFractions)
		assert.Equal(t, gridStrikes, got.Strikes)

		require.Len(t, got.Data, len(got.TenorYearFractions))

		for i := range got.Data {
			require.Len(t, got.Data[i], len(got.Strikes))

			for j := range got.Data[i] {
				assert.Positive(t, got.Data[i][j])
			}
		}
	})

	t.Run("valid european volatility surface computation", func(t *testing.T) {
		t.Parallel()

		yieldCurve := irCurveSample
		require.NoError(t, yieldCurve.BuildInterpolator())

		const spotPrice = 14137.23

		var (
			optionChainDesc = surfcalib.OptionChainDescription{
				OptionChain:        optionChainSample,
				ExerciseType:       marketdata.European,
				DaycountConvention: marketdata.DaycountConvention("ActAct"),
			}
			gridStrikes = generateGridStrikes(spotPrice)

			dividendCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{DividendZeroRate: 0.02, YearFraction: 0.5},
					{DividendZeroRate: 0.02, YearFraction: 1.0},
					{DividendZeroRate: 0.02, YearFraction: 2.0},
				},
			}
		)

		got, err := computeSurface(optionChainDesc, spotPrice, yieldCurve, dividendCurve)
		require.NoError(t, err)
		require.NotNil(t, got)

		assert.Equal(t, gridTenors, got.TenorYearFractions)
		assert.Equal(t, gridStrikes, got.Strikes)

		require.Len(t, got.Data, len(got.TenorYearFractions))

		for i := range got.Data {
			require.Len(t, got.Data[i], len(got.Strikes))

			for j := range got.Data[i] {
				assert.Positive(t, got.Data[i][j])
			}
		}
	})

	t.Run("invalid option chain description", func(t *testing.T) {
		t.Parallel()

		yieldCurve := irCurveSample
		require.NoError(t, yieldCurve.BuildInterpolator())

		var (
			optionChainDesc = surfcalib.OptionChainDescription{
				OptionChain: surfcalib.OptionChain{
					0.4904109589: surfcalib.SurfaceSlice{
						10000.0: surfcalib.OptionPair{Call: new(4213.75), Put: new(97.75)},
					},
				},
				ExerciseType:       marketdata.American,
				DaycountConvention: marketdata.DaycountConvention("ActAct"),
			}

			dividendCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{DividendZeroRate: 0.02, YearFraction: 0.5},
					{DividendZeroRate: 0.02, YearFraction: 1.0},
					{DividendZeroRate: 0.02, YearFraction: 2.0},
				},
			}
		)

		const spotPrice = 14137.23

		got, err := computeSurface(optionChainDesc, spotPrice, yieldCurve, dividendCurve)
		require.Nil(t, got)
		require.Error(t, err)
	})
}

func Test_computeHestonSurface(t *testing.T) {
	t.Parallel()

	t.Run("valid raw surface but heston calibration unimplemented", func(t *testing.T) {
		t.Parallel()

		yieldCurve := irCurveSample
		require.NoError(t, yieldCurve.BuildInterpolator())

		optionChainDesc := surfcalib.OptionChainDescription{
			OptionChain:        optionChainSample,
			ExerciseType:       marketdata.American,
			DaycountConvention: marketdata.DaycountConvention("ActAct"),
		}

		const spotPrice = 14137.23

		dividendCurve := marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{DividendZeroRate: 0.02, YearFraction: 0.5},
				{DividendZeroRate: 0.02, YearFraction: 1.0},
				{DividendZeroRate: 0.02, YearFraction: 2.0},
			},
		}

		gotParams, gotV0Tenor, gotThetaTenor, err := computeHestonSurface(
			optionChainDesc,
			spotPrice,
			yieldCurve,
			dividendCurve,
		)

		require.Error(t, err)
		require.Nil(t, gotParams)
		assert.Zero(t, gotV0Tenor)
		assert.Zero(t, gotThetaTenor)
		assert.ErrorContains(t, err, "could not calibrate Heston parameters")
	})

	t.Run("invalid option chain description", func(t *testing.T) {
		t.Parallel()

		yieldCurve := irCurveSample
		require.NoError(t, yieldCurve.BuildInterpolator())

		optionChainDesc := surfcalib.OptionChainDescription{
			OptionChain: surfcalib.OptionChain{
				0.4904109589: surfcalib.SurfaceSlice{
					10000.0: surfcalib.OptionPair{Call: new(4213.75), Put: new(97.75)},
				},
			},
			ExerciseType:       marketdata.American,
			DaycountConvention: marketdata.DaycountConvention("ActAct"),
		}

		const spotPrice = 14137.23

		dividendCurve := marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{DividendZeroRate: 0.02, YearFraction: 0.5},
				{DividendZeroRate: 0.02, YearFraction: 1.0},
				{DividendZeroRate: 0.02, YearFraction: 2.0},
			},
		}

		gotParams, gotV0Tenor, gotThetaTenor, err := computeHestonSurface(
			optionChainDesc,
			spotPrice,
			yieldCurve,
			dividendCurve,
		)

		require.Error(t, err)
		require.Nil(t, gotParams)
		assert.Zero(t, gotV0Tenor)
		assert.Zero(t, gotThetaTenor)
		assert.ErrorContains(t, err, "could not compute raw volatility surface")
	})
}

func Test_service_computeDividendCurveFromOptions(t *testing.T) {
	t.Parallel()

	t.Run("valid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		spotTimeseries := &marketdata.Timeseries{
			Entries: marketdata.Entries{
				&marketdata.Entry{
					Date:  date.Today(),
					Value: 14137.23,
				},
			},
		}

		got, err := svc.computeDividendCurveFromOptions(
			t.Context(),
			"2f7da240-1415-463b-907d-1f5c00bc70eb",
			date.Today().UTC(),
			date.Today(),
			spotTimeseries,
		)
		require.NoError(t, err)
		require.NotNil(t, got)
		require.NotEmpty(t, got.Dividends)
	})

	t.Run("invalid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		spotTimeseries := &marketdata.Timeseries{
			Entries: marketdata.Entries{
				&marketdata.Entry{
					Date:  date.Today(),
					Value: 14137.23,
				},
			},
		}

		got, err := svc.computeDividendCurveFromOptions(
			t.Context(),
			"unknown-id",
			date.Today().UTC(),
			date.Today(),
			spotTimeseries,
		)
		require.Error(t, err)
		require.ErrorContains(t, err, "could not fetch the historical option chain")
		require.Nil(t, got)
	})
}

func Test_service_computeFlatUnderlyingDividendFromOptions(t *testing.T) {
	t.Parallel()

	t.Run("valid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		var (
			res = &pb.UnderlyingResponse{}

			dividendCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{
					{DividendZeroRate: 0.02, YearFraction: 0.5},
					{DividendZeroRate: 0.02, YearFraction: 1.0},
					{DividendZeroRate: 0.02, YearFraction: 2.0},
				},
			}
		)

		err := svc.computeAverageDividend(
			dividendCurve,
			res,
		)
		require.NoError(t, err)
		require.NotNil(t, res.GetFlatDividendYield())
		require.False(t, math.IsNaN(res.GetFlatDividendYield().GetYield()))
		require.False(t, math.IsInf(res.GetFlatDividendYield().GetYield(), 0))
	})

	t.Run("empty dividend curve", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		var (
			res = &pb.UnderlyingResponse{}

			dividendCurve = marketdata.DividendYieldCurve{
				Dividends: []marketdata.DividendPoint{},
			}
		)

		err := svc.computeAverageDividend(
			dividendCurve,
			res,
		)
		require.Error(t, err)
		require.ErrorContains(t, err, "dividend term structure is empty")
		require.Nil(t, res.GetFlatDividendYield())
	})
}

func testSpotTimeseries() *marketdata.Timeseries {
	return &marketdata.Timeseries{
		ID:   "73e54147-f8db-4204-8b24-8f6b7be90942",
		Type: marketdata.Type("spot"),
		Entries: marketdata.Entries{
			{Date: date.New(2020, time.January, 1), Value: 100.0},
			{Date: date.New(2020, time.January, 2), Value: 100.5},
			{Date: date.New(2020, time.January, 3), Value: 101.0},
			{Date: date.New(2020, time.January, 4), Value: 100.2},
			{Date: date.New(2020, time.January, 5), Value: 100.8},
		},
	}
}

func testReturnsTimeseries() *marketdata.ReturnsTimeseries {
	return &marketdata.ReturnsTimeseries{
		Calendar:   calendar.New(calendar.BusinessDays),
		ReturnType: marketdata.RelativeReturn,
		Entries: marketdata.ReturnEntries{
			{Date: date.New(2020, time.January, 2), Value: 0.01, Days: 1},
			{Date: date.New(2020, time.January, 3), Value: -0.02, Days: 1},
			{Date: date.New(2020, time.January, 4), Value: 0.015, Days: 1},
			{Date: date.New(2020, time.January, 5), Value: 0.005, Days: 1},
		},
	}
}

func testVolatilitySurfaceInputs(t *testing.T, svc *service, req *pb.UnderlyingRequest) (surfacecalibration.OptionChainDescription, float64, termstructure.TermStructure, marketdata.DividendYieldCurve) {
	t.Helper()

	optionChainDesc, spot, yieldCurve, dividendCurve, err := svc.computeVolatilitySurfaceInputs(
		t.Context(),
		req.GetUnderlying().GetId(),
		req.GetSnapshot().AsTime(),
		date.NewAt(req.GetTo().AsTime()),
		testSpotTimeseries(),
	)
	require.NoError(t, err)

	return optionChainDesc, spot, yieldCurve, dividendCurve
}

func Test_service_computeVolatilityAndScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid volatility only", func(t *testing.T) {
		t.Parallel()

		svc := newService()

		req := newUnderlyingRequest()
		res := &pb.UnderlyingResponse{}

		returns := testReturnsTimeseries()

		err := svc.computeVolatilityAndScenarios(
			t.Context(),
			req,
			res,
			nil,
			returns,
			date.New(2020, time.January, 1),
			date.New(2020, time.January, 5),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatility())
		require.NotNil(t, res.GetVolatility().GetTimeseries())
		require.Nil(t, res.GetVolatilitySurface())
	})

	t.Run("valid SSVI volatility surface", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.DividendYieldCurve = true

		res := &pb.UnderlyingResponse{}

		err := svc.computeVolatilityAndScenarios(
			t.Context(),
			req,
			res,
			testSpotTimeseries(),
			testReturnsTimeseries(),
			date.New(2020, time.January, 1),
			date.New(2020, time.January, 5),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatilitySurface())
		require.NotNil(t, res.GetVolatilitySurface().GetSurface())
		require.NotNil(t, res.GetDividendYieldCurve())
	})
}

func Test_service_computeVolatilitySurfaceAndScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid SSVI surface without scenarios", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.Scenarios = nil

		res := &pb.UnderlyingResponse{}

		err := svc.computeVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			testSpotTimeseries(),
			testReturnsTimeseries(),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatilitySurface())
		require.NotNil(t, res.GetVolatilitySurface().GetSurface())
		assert.Empty(t, res.GetVolatilitySurface().GetScenarioShifts())
	})

	t.Run("invalid underlying", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.Underlying.Id = "unknown-id"

		res := &pb.UnderlyingResponse{}

		err := svc.computeVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			nil,
			nil,
		)

		require.Error(t, err)
		require.Nil(t, res.GetVolatilitySurface())
		assert.ErrorContains(t, err, "could not compute volatility surface inputs")
	})
}

func Test_service_computeBackboneVolAndScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		svc := newService()

		req := newUnderlyingRequest()
		res := &pb.UnderlyingResponse{}

		err := svc.computeBackboneVolAndScenarios(
			t.Context(),
			req,
			res,
			testReturnsTimeseries(),
			date.New(2020, time.January, 1),
			date.New(2020, time.January, 5),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatility())
		require.NotNil(t, res.GetVolatility().GetTimeseries())
		assert.NotNil(t, res.GetVolatility().GetScenarios())
	})
}

func Test_service_computeSSVIVolatilitySurfaceAndScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid without scenarios", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.Scenarios = nil

		res := &pb.UnderlyingResponse{}

		optionChainDesc, spot, yieldCurve, dividendCurve := testVolatilitySurfaceInputs(
			t,
			svc,
			req,
		)

		err := svc.computeSSVIVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			optionChainDesc,
			spot,
			yieldCurve,
			dividendCurve,
			testReturnsTimeseries(),
		)

		require.NoError(t, err)
		require.NotNil(t, res.GetVolatilitySurface())
		require.NotNil(t, res.GetVolatilitySurface().GetSurface())
		assert.Empty(t, res.GetVolatilitySurface().GetScenarioShifts())
	})
}

func Test_service_computeHestonVolatilitySurfaceAndScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid raw surface but heston calibration unimplemented", func(t *testing.T) {
		t.Parallel()

		svc := &service{
			marketDataProvider: &testdata.Provider{},
			yieldProvider:      testdata.MockYieldProvider{},
		}

		req := newUnderlyingRequestWithSSVIActivated()
		req.VolatilitySurface = true
		req.Scenarios = nil

		res := &pb.UnderlyingResponse{}

		optionChainDesc, spot, yieldCurve, dividendCurve := testVolatilitySurfaceInputs(
			t,
			svc,
			req,
		)

		err := svc.computeHestonVolatilitySurfaceAndScenarios(
			t.Context(),
			req,
			res,
			optionChainDesc,
			spot,
			yieldCurve,
			dividendCurve,
			testReturnsTimeseries(),
			date.NewAt(req.GetTo().AsTime()),
		)

		require.Error(t, err)
		require.Nil(t, res.GetVolatilitySurface())
		assert.ErrorContains(t, err, "could not compute Heston volatility surface")
	})
}

func Test_service_populateDividendYieldCurve(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		svc := newService()
		res := &pb.UnderlyingResponse{}

		dividendCurve := marketdata.DividendYieldCurve{
			Dividends: []marketdata.DividendPoint{
				{DividendZeroRate: 0.02, YearFraction: 0.5},
				{DividendZeroRate: 0.025, YearFraction: 1.0},
				{DividendZeroRate: 0.03, YearFraction: 2.0},
			},
		}

		err := svc.populateDividendYieldCurve(dividendCurve, res)

		require.NoError(t, err)
		require.NotNil(t, res.GetDividendYieldCurve())
		require.NotNil(t, res.GetDividendYieldCurve().GetDividends())
		assert.Len(t, res.GetDividendYieldCurve().GetDividends().GetData(), len(dividendCurve.Dividends))
	})
}

func Test_service_computeVolatilityScenarios(t *testing.T) {
	t.Parallel()

	t.Run("valid scaling factors", func(t *testing.T) {
		t.Parallel()

		svc := newService()

		scalingFactors := map[uint32]float64{
			1: 0.8,
			2: 1.0,
			3: 1.2,
		}

		got := svc.computeVolatilityScenarios(0.25, scalingFactors)

		expected := map[uint32]float64{
			1: 0.20,
			2: 0.25,
			3: 0.30,
		}

		assert.Equal(t, expected, got)
	})
}

func Test_service_requestedVolatilitySurfaceModel(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		hestonCalibrationActivated bool
		requestedModel             pb.VolatilitySurfaceModel
		expectedModel              pb.VolatilitySurfaceModel
	}{
		"Heston calibration disabled defaults to SSVI": {
			hestonCalibrationActivated: false,
			requestedModel:             pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON,
			expectedModel:              pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI,
		},
		"Heston calibration disabled ignores unspecified": {
			hestonCalibrationActivated: false,
			requestedModel:             pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED,
			expectedModel:              pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI,
		},
		"Heston calibration enabled returns SSVI": {
			hestonCalibrationActivated: true,
			requestedModel:             pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI,
			expectedModel:              pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_SSVI,
		},
		"Heston calibration enabled returns Heston": {
			hestonCalibrationActivated: true,
			requestedModel:             pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON,
			expectedModel:              pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_HESTON,
		},
		"Heston calibration enabled returns unspecified": {
			hestonCalibrationActivated: true,
			requestedModel:             pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED,
			expectedModel:              pb.VolatilitySurfaceModel_VOLATILITY_SURFACE_MODEL_UNSPECIFIED,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			svc := &service{
				HestonCalibrationActivated: tc.hestonCalibrationActivated,
			}

			req := &pb.UnderlyingRequest{
				VolatilitySurfaceModel: tc.requestedModel,
			}
			got := svc.requestedVolatilitySurfaceModel(req)
			assert.Equal(t, tc.expectedModel, got)
		})
	}
}
