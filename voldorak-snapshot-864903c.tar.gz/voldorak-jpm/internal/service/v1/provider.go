package service

import (
	"context"
	"fmt"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/nowcasting"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/edgelaboratories/voldorak/internal/timestamputil"
)

// fetchSpotTimeseries fetches the spot time series by applying a warm-up lag.
// This prevents volatility forecasts to undergo
// instabilities due to the initial conditions.
//
// If the spot time series is empty, a NotFound-code error is returned.
func (s *service) fetchSpotTimeseries(ctx context.Context, t marketdata.Type, id string, from, to time.Time, opts ...spotOption) (*marketdata.Timeseries, error) {
	ctx, span := trace.StartSpan(ctx, "FetchSpotTimeseries")
	defer span.End()

	cfg := newSpotConfig(opts...)

	if t == marketdata.PrivateAsset && (cfg.useSSMPipeline || s.privateAssetConfig.ActivateSSMPipeline) {
		return s.fetchSpotTimeseriesWithSSMPipeline(ctx, id, from, to)
	}

	laggedFrom := computeReturnsWarmUpDate(from, to)

	ts, err := s.marketDataProvider.FetchSpotTimeseries(ctx, t, id, laggedFrom, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the spot from provider: %w", err)
	}

	if ts.IsEmpty() {
		return nil, errors.SetTag(errors.NotFound("time series restriction is empty: no spot time series from provider for %s %s in window [%s, %s]",
			t,
			id,
			timestamputil.TimeToString(laggedFrom),
			timestamputil.TimeToString(to),
		), tag.TimeSeriesDataTooOld)
	}

	// Spot data are requested in the input time window (from, to).
	// Filter out cases where data might be too old not to follow
	// within the input time window.

	if ts.From(date.NewAt(from)).IsEmpty() {
		return nil, errors.SetTag(errors.NotFound("time series data are too old for the input time window: spot data for %s %s were requested from %s, but last spot was on %s",
			t,
			id,
			timestamputil.TimeToString(from),
			ts.Last().Date,
		), tag.TimeSeriesDataTooOld)
	}

	// Spot data's last value should not be non-positive.
	if spot := ts.Last().Value; spot <= 0 {
		return nil, errors.SetTag(errors.PreconditionFailed("spot value is non-positive: last spot value for %s %s is non-positive: %f",
			t,
			id,
			spot,
		), tag.TimeSeriesValueNonPositive)
	}

	// Fill gaps monthly for spot time series.
	if t == marketdata.PrivateAsset {
		ts.ShiftToCalendarDay()
		ts.FillGapsMonthlyEndLinearly(date.NewAt(to))
	}

	return ts, nil
}

// PrivateAssetConfig holds the configuration for fetching the spot time series of private assets.
type PrivateAssetConfig struct {
	ActivateSSMPipeline bool
	CalibrationWeeks    int
}

// NewPrivateAssetConfig creates a new instance of PrivateAssetConfig with the given parameters.
func NewPrivateAssetConfig(activateSSMPipeline bool, calibrationWeeks int) *PrivateAssetConfig {
	return &PrivateAssetConfig{
		ActivateSSMPipeline: activateSSMPipeline,
		CalibrationWeeks:    calibrationWeeks,
	}
}

func (s *service) fetchSpotTimeseriesWithSSMPipeline(ctx context.Context, id string, from, to time.Time) (*marketdata.Timeseries, error) {
	ctx, span := trace.StartSpan(ctx, "FetchSpotTimeseriesWithSSMPipeline")
	defer span.End()

	mapping, err := s.privateAssetMappingFetcher.Fetch(id)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the private asset mapping: %w", err)
	}

	calibFrom := to.AddDate(0, 0, -s.privateAssetConfig.CalibrationWeeks*7)
	if calibFrom.After(from) {
		calibFrom = from
	}

	assetTS, err := s.marketDataProvider.FetchSpotTimeseries(ctx, marketdata.PrivateAsset, id, calibFrom, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the asset NAV timeseries from provider: %w", err)
	}

	// Convention: idiosyncratic proxies are Funds (ETFs are stored as Fund type),
	// market proxies are Indices.
	idiosyncraticProxyTS, err := s.marketDataProvider.FetchSpotTimeseries(ctx, marketdata.Fund, mapping.IdiosyncraticProxyID, calibFrom, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the idiosyncratic proxy timeseries from provider: %w", err)
	}

	marketProxyTS, err := s.marketDataProvider.FetchSpotTimeseries(ctx, marketdata.Index, mapping.MarketProxyID, calibFrom, to)
	if err != nil {
		return nil, fmt.Errorf("could not fetch the market proxy timeseries from provider: %w", err)
	}

	config := nowcasting.SSMConfigForFundType(mapping.FundType)

	prices, _, err := nowcasting.RunPipeline(assetTS, idiosyncraticProxyTS, marketProxyTS, config)
	if err != nil {
		return nil, fmt.Errorf("could not run the SSM pipeline: %w", err)
	}

	return prices, nil
}

// spotConfig holds the configuration for fetching the spot time series.
type spotConfig struct {
	// useSSMPipeline indicates whether the SSM pipeline should be used to fetch the spot time series.
	useSSMPipeline bool
}

func newSpotConfig(opts ...spotOption) *spotConfig {
	cfg := &spotConfig{
		useSSMPipeline: false,
	}

	for _, opt := range opts {
		opt(cfg)
	}

	return cfg
}

// spotOption defines the type for functional options to configure the spot time series fetching.
type spotOption func(*spotConfig)

// withSSMPipeline configures the service to use the SSM pipeline to fetch the spot time series.
func withSSMPipeline(useSSM bool) spotOption {
	return func(c *spotConfig) {
		c.useSSMPipeline = useSSM
	}
}
