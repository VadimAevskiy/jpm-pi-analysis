package service

import (
	"context"
	"fmt"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/go-opentelemetry/v2/trace"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/resource/logger"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (s *service) Spot(ctx context.Context, req *pb.SpotRequest) (*pb.SpotResponse, error) {
	ctx, span := trace.StartSpan(ctx, "Spot")
	defer span.End()

	logger := logger.FromContext(ctx)

	if err := s.validateSpotRequest(req); err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, status.Error(codes.InvalidArgument, err.Error())
	}

	var (
		effectiveFrom = computeEffectiveFromTime(req.GetFrom(), req.GetTo())
		id            = req.GetUnderlying().GetId()
		t             = mapPBToMarketdataType(req.GetUnderlying().GetType())
		to            = req.GetTo().AsTime()

		opts = make([]spotOption, 0, 1)
	)

	if t == marketdata.PrivateAsset {
		opts = append(opts, withSSMPipeline(req.GetUseSsmPipeline()))
	}

	ts, err := s.fetchSpotTimeseries(ctx, t, id, effectiveFrom, to, opts...)
	if err != nil {
		trace.SetSpanError(span, err)
		logger.Warn(err.Error())

		return nil, errors.ToGRPC(fmt.Errorf("could not fetch spot timeseries: %w", err))
	}

	var (
		windowFrom = date.NewAt(req.GetFrom().AsTime())
		windowTo   = date.NewAt(to)
	)

	return &pb.SpotResponse{
		Timeseries: mapTimeseries(ts.
			From(windowFrom).
			To(windowTo)),
	}, nil
}

func (s *service) validateSpotRequest(req *pb.SpotRequest) error {
	if req == nil {
		return errors.BadRequest("empty request")
	}

	if err := s.validateUnderlying(req.GetUnderlying()); err != nil {
		return fmt.Errorf("underlying is invalid: %w", err)
	}

	if req.GetTo() == nil {
		return errors.BadRequest("to timestamp is not provided")
	}

	if req.GetFrom().AsTime().After(req.GetTo().AsTime()) {
		return errors.BadRequest(
			"'from' time (%s) should not be after 'to' time (%s)",
			req.GetFrom(),
			req.GetTo(),
		)
	}

	return nil
}
