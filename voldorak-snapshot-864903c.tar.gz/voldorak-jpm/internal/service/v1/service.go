package service

import (
	"context"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/edgelaboratories/voldorak/internal/nowcasting"
	"github.com/edgelaboratories/voldorak/internal/scenario"
	surfcalib "github.com/edgelaboratories/voldorak/internal/surfacecalibration"
	"github.com/edgelaboratories/voldorak/internal/yield"
	pb "github.com/edgelaboratories/voldorak/pkg/voldorak/v1"
)

type service struct {
	pb.UnimplementedVoldorakServiceServer

	marketDataProvider         MarketDataProvider
	scenariosProvider          *scenario.Provider
	yieldProvider              yield.InterestRateProvider
	volatilityBackboneModel    model.VolatilityBackboneModel
	privateAssetMappingFetcher nowcasting.Fetcher

	privateAssetConfig         *PrivateAssetConfig
	SSVICalibrationActivated   bool
	HestonCalibrationActivated bool
}

func newDefaultService(marketDataProvider MarketDataProvider, scenariosProvider *scenario.Provider, yieldProvider yield.InterestRateProvider, privateAssetMappingFetcher nowcasting.Fetcher, privateAssetConfig *PrivateAssetConfig, ssviCalibrationActivated, hestonCalibrationActivated bool) *service {
	return &service{
		marketDataProvider:         marketDataProvider,
		scenariosProvider:          scenariosProvider,
		yieldProvider:              yieldProvider,
		volatilityBackboneModel:    model.DefaultVolatilityBackboneModel,
		privateAssetMappingFetcher: privateAssetMappingFetcher,
		privateAssetConfig:         privateAssetConfig,
		SSVICalibrationActivated:   ssviCalibrationActivated,
		HestonCalibrationActivated: hestonCalibrationActivated,
	}
}

// NewService instantiates a new voldorak service server.
func NewService(marketDataProvider MarketDataProvider, scenariosProvider *scenario.Provider, yieldProvider yield.InterestRateProvider, privateAssetMappingFetcher nowcasting.Fetcher, privateAssetConfig *PrivateAssetConfig, ssviCalibrationActivated, hestonCalibrationActivated bool, opts ...Option) pb.VoldorakServiceServer {
	s := newDefaultService(marketDataProvider, scenariosProvider, yieldProvider, privateAssetMappingFetcher, privateAssetConfig, ssviCalibrationActivated, hestonCalibrationActivated)
	for _, opt := range opts {
		opt(s)
	}

	return s
}

type MarketDataProvider interface {
	FetchSpotTimeseries(ctx context.Context, t marketdata.Type, id string, from, to time.Time) (*marketdata.Timeseries, error)
	FetchVolatilitySurface(ctx context.Context, id string) (*marketdata.VolatilitySurface, error)
	FetchDividendYieldCurve(ctx context.Context, id string) (*marketdata.DividendYieldCurve, error)
	FetchOptions(ctx context.Context, id string, at *date.Date) (surfcalib.OptionChainDescription, error)
}

// Option allows to customize the service configuration.
type Option func(*service)

// WithVolatilityBackboneModel sets the (default) universal volatility
// backbone model. The input context is available for logging purposes.
func WithVolatilityBackboneModel(model model.VolatilityBackboneModel) Option {
	return func(s *service) {
		if model != "" {
			s.volatilityBackboneModel = model
		}
	}
}
