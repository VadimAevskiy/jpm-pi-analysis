package testdata

import (
	"context"
	"fmt"
	"time"

	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/scenario"
)

func NewScenarioProvider() *scenario.Provider {
	return scenario.NewProvider(
		mockRealizationProvider{},
		mockFXProvider{},
	)
}

// mockFXProvider mocks the service fx provider.
type mockFXProvider struct{}

// FetchFXCorrelation fetches the FX correlation between two currency pairs.
func (m mockFXProvider) FetchFXCorrelation(_ context.Context, domAgainstRef, forAgainstRef *fx.Pair, snapshot time.Time) (float64, error) {
	return 0.7, nil
}

// FetchFXPerspective fetches the market perspective of an FX pair.
// We assume the perspective is always based on USD as foreign currency.
func (m mockFXProvider) FetchFXPerspective(ctx context.Context, p *fx.Pair) (*fx.Pair, error) {
	if p.Domestic == "USD" {
		return &fx.Pair{
			Foreign:  "USD",
			Domestic: p.Foreign,
		}, nil
	}

	return p, nil
}

// mockRealizationProvider is a realization provider.
type mockRealizationProvider struct{}

// FetchSpotScenarios fetches spot realizations.
func (m mockRealizationProvider) FetchSpotScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*scenario.Proxies, error) {
	switch id {
	case "e4808f35-2a90-4a60-bebe-263c938ac20b",
		"b0799580-2c2e-4384-92ce-31fd8a80e5fd",
		"73e54147-f8db-4204-8b24-8f6b7be90942":
		return map[uint32]float64{
			1: 33.0,
		}, nil, nil
	}

	return nil, nil, fmt.Errorf("spot scenario value not found for scenario %s", id)
}

// FetchVolatilityScenarios fetches volatility realizations.
func (m mockRealizationProvider) FetchVolatilityScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*scenario.Proxies, error) {
	switch id {
	case "ca9784af-ee3a-45b9-8162-824b41bbf386",
		"b0799580-2c2e-4384-92ce-31fd8a80e5fd",
		"73e54147-f8db-4204-8b24-8f6b7be90942":
		return map[uint32]float64{
			1: 0.20,
		}, nil, nil
	}

	return nil, nil, fmt.Errorf("volatility scenario value not found for scenario %s", id)
}
