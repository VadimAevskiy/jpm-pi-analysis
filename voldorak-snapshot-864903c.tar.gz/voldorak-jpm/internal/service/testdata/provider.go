package testdata

import (
	"context"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	surfcalib "github.com/edgelaboratories/voldorak/internal/surfacecalibration"
)

// Provider satisfies the requirements of a provider
// and is meant to act as a Cerberus resource mock.
type Provider struct{}

// FetchSpotTimeseries fetches the spot timeseries.
func (p *Provider) FetchSpotTimeseries(ctx context.Context, t marketdata.Type, id string, from, to time.Time) (*marketdata.Timeseries, error) {
	if data, ok := spotData[id]; ok {
		return mapDataToTimeseries(t, id, data)
	}

	return nil, errors.NotFound("spot data for id %s not found", id)
}

// FetchVolatilitySurface fetches the volatility surface.
func (p *Provider) FetchVolatilitySurface(ctx context.Context, id string) (*marketdata.VolatilitySurface, error) {
	if surface, ok := surfaceData[id]; ok {
		return &surface, nil
	}

	return nil, errors.NotFound("volatility surface for id %s not found", id)
}

// FetchDividendYieldCurve fetches the dividend yield curve.
func (p *Provider) FetchDividendYieldCurve(ctx context.Context, id string) (*marketdata.DividendYieldCurve, error) {
	if dividend, ok := dividendData[id]; ok {
		return &dividend, nil
	}

	return nil, errors.NotFound("dividend yield curve for id %s not found", id)
}

func (p *Provider) FetchOptions(ctx context.Context, id string, at *date.Date) (surfcalib.OptionChainDescription, error) {
	if options, ok := optionsData[id]; ok {
		return options, nil
	}

	return surfcalib.OptionChainDescription{}, errors.NotFound("options for id %s not found", id)
}
