package testdata

import (
	"testing"

	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func Test_mapDataToTimeseries(t *testing.T) {
	t.Parallel()

	const (
		id = "1b940b30-751f-4d55-b8af-b027ee5aed7a"
		tp = marketdata.Index
	)

	data := spotData[id]
	ts, err := mapDataToTimeseries(tp, id, data)
	require.NoError(t, err)

	assert.Equal(t, id, ts.ID)
	assert.Equal(t, tp, ts.Type)
	assert.Equal(t, 5, len(ts.Entries))
}
