package testdata

import "github.com/edgelaboratories/voldorak/internal/nowcasting"

// MockPrivateAssetFetcher mocks the private asset fetcher.
type MockPrivateAssetFetcher struct{}

// Fetch returns a mock AssetMapping for the given ID.
func (m MockPrivateAssetFetcher) Fetch(string) (*nowcasting.AssetMapping, error) {
	return &nowcasting.AssetMapping{
		Label:                "mock_label",
		FundType:             "mock_fund_type",
		AssetID:              "1b940b30-751f-4d55-b8af-b027ee5aed7a",
		IdiosyncraticProxyID: "73e54147-f8db-4204-8b24-8f6b7be90942",
		MarketProxyID:        "2ff645bf-50fe-492c-8f2e-04639a884560",
	}, nil
}
