package testdata

import (
	"sort"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

func mapDataToTimeseries(t marketdata.Type, id string, data map[string]float64) (*marketdata.Timeseries, error) {
	entries := make([]*marketdata.Entry, 0, len(data))
	for k, v := range data {
		t, err := date.ParseISO(k)
		if err != nil {
			return nil, err
		}

		entries = append(entries, &marketdata.Entry{
			Date:  t,
			Value: v,
		})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].Date.Before(entries[j].Date)
	})

	return &marketdata.Timeseries{
		Type:    t,
		ID:      id,
		Entries: entries,
	}, nil
}
