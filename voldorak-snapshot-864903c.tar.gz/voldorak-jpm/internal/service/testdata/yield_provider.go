package testdata

import (
	"context"
	"time"

	"github.com/edgelaboratories/go-libraries/date"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/termstructure"
)

// MockYieldProvider mocks the service yield provider.
type MockYieldProvider struct{}

func (m MockYieldProvider) Yield(ctx context.Context, snapshot time.Time, currency marketdata.Currency, to date.Date) (termstructure.TermStructure, error) {
	_ = ctx
	_ = snapshot
	_ = currency
	_ = to

	ts := termstructure.TermStructure{
		Data: map[termstructure.Tenor]float64{
			termstructure.M1: 0.01,
			termstructure.M3: 0.02,
			termstructure.M6: 0.03,
		},
	}
	ts.BuildInterpolator()

	return ts, nil
}
