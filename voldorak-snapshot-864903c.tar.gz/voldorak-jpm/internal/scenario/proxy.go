package scenario

// Proxies defines the proxies used to compute scenario realizations.
type Proxies struct {
	Intercept float64
	Betas     map[string]float64
}
