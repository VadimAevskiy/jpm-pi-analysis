package scenario

import (
	"context"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
)

// mockFXProvider mocks the service fx provider.
type mockFXProvider struct{}

// FetchFXCorrelation fetches the FX correlation between two currency pairs.
func (m mockFXProvider) FetchFXCorrelation(_ context.Context, domAgainstRef, forAgainstRef *fx.Pair, _ time.Time) (float64, error) {
	if domAgainstRef.Domestic == "CAD" || forAgainstRef.Domestic == "CAD" {
		return 0.0, errors.Bug("could not fetch correlation for CAD")
	}

	return 0.7, nil
}

// FetchFXPerspective fetches the market perspective of an FX pair.
// We assume the perspective is always based on USD as foreign currency.
func (m mockFXProvider) FetchFXPerspective(_ context.Context, p *fx.Pair) (*fx.Pair, error) {
	if p.Domestic == "XAU" || p.Foreign == "XAU" {
		return nil, errors.Bug("could not fetch perspective for XAU")
	}

	if p.Domestic == "JPY" || p.Foreign == "JPY" {
		// In this case USD is the domestic currency in the perspective.
		return &fx.Pair{
			Foreign:  "JPY",
			Domestic: "USD",
		}, nil
	}

	if p.Domestic == "USD" {
		return &fx.Pair{
			Foreign:  "USD",
			Domestic: p.Foreign,
		}, nil
	}

	return p, nil
}

// mockRealizationProvider is a realization provider.
type mockRealizationProvider struct{}

// FetchSpotScenarios fetches spot realizations.
func (m mockRealizationProvider) FetchSpotScenarios(_ context.Context, t marketdata.Type, id string, _ []uint32, _ time.Time) (map[uint32]float64, map[uint32]*Proxies, error) {
	switch id {
	case "317fe458-b31e-4e3f-b037-beff934a127d",
		"ca9784af-ee3a-45b9-8162-824b41bbf386",
		"USD-EUR",
		"USD-CHF",
		"USD-XAU",
		"USD-CAD":
		return map[uint32]float64{
				1: 1.007,
				2: 1.008,
				3: 1.004,
			}, map[uint32]*Proxies{
				2: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy": 10.0,
					},
				},
			}, nil

	case "JPY-USD":
		return map[uint32]float64{
			1: 1.0e-16,
			2: 1.0e-16,
			3: 1.0e-16,
		}, nil, nil

	case "USD-AUD":
		return map[uint32]float64{
			1: 0.0,
			2: 0.0,
			3: 0.0,
		}, nil, nil
	}

	return nil, nil, errors.Bug("%s spot scenario value not found for scenario %s", t, id)
}

// FetchVolatilityScenarios fetches volatility realizations.
func (m mockRealizationProvider) FetchVolatilityScenarios(_ context.Context, t marketdata.Type, id string, _ []uint32, _ time.Time) (map[uint32]float64, map[uint32]*Proxies, error) {
	switch id {
	case "317fe458-b31e-4e3f-b037-beff934a127d",
		"ca9784af-ee3a-45b9-8162-824b41bbf386",
		"USD-EUR",
		"USD-CHF",
		"USD-XAU",
		"USD-CAD":
		return map[uint32]float64{
				1: 1.007,
				2: 1.008,
				3: 1.004,
			}, map[uint32]*Proxies{
				2: {
					Intercept: 2.0,
					Betas: map[string]float64{
						"proxy": 10.0,
					},
				},
			}, nil
	}

	return nil, nil, errors.Bug("%s volatility scenario value not found for scenario %s", t, id)
}
