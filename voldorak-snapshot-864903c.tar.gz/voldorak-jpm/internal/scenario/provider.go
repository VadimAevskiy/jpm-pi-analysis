package scenario

import (
	"context"
	"fmt"
	"math"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
)

// RealizationProvider defines the interface of the back-end scenario realizations provider.
type RealizationProvider interface {
	FetchVolatilityScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*Proxies, error)
	FetchSpotScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*Proxies, error)
}

type FXProvider interface {
	FetchFXCorrelation(ctx context.Context, domAgainstRef, forAgainstRef *fx.Pair, snapshot time.Time) (float64, error)
	FetchFXPerspective(ctx context.Context, p *fx.Pair) (*fx.Pair, error)
}

// Provider defines a scenario provider.
type Provider struct {
	realizationProvider RealizationProvider
	fxProvider          FXProvider
}

func NewProvider(realizationProvider RealizationProvider, fxProvider FXProvider) *Provider {
	return &Provider{
		realizationProvider: realizationProvider,
		fxProvider:          fxProvider,
	}
}

const tolerance = 1.0e-15

// FetchSpotScenarios returns the spot scenario values, depending on the underlying type:
// * stock, index and fund do not require any pre-processing and can be fetched directly
// * FX rate scenario values instead are always computed with respect to a pivot currency
// and need prior manipulation. The final scenario values are obtained by inverting the
// scenario rates based on the reference currency.
func (p Provider) FetchSpotScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[string]map[uint32]*Proxies, error) {
	if t == marketdata.FX {
		pair, err := fx.NewPair(id)
		if err != nil {
			return nil, nil, fmt.Errorf("could not build the fx pair: %w", err)
		}

		return p.fetchFXSpotScenarios(ctx, pair, scenarios, snapshot)
	}

	spotScenarioValues, scenarioProxies, err := p.realizationProvider.FetchSpotScenarios(ctx, t, id, scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the spot scenario values for id %s and snapshot %s: %w", id, snapshot.String(), err)
	}

	scenarioProxiesMap := make(map[string]map[uint32]*Proxies, 1)
	scenarioProxiesMap[id] = scenarioProxies

	return spotScenarioValues, scenarioProxiesMap, nil
}

// FetchVolatilityScenarios returns the volatility scenario values, depending on the underlying type:
// * stock, index and fund do not require any pre-processing and can be fetched directly
// * FX rate scenario values instead are always computed with respect to a pivot currency
// and need prior manipulation. The final scenario values are obtained by correlating the scenario rates
// with the current correlation against the reference currency.
func (p Provider) FetchVolatilityScenarios(ctx context.Context, t marketdata.Type, id string, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[string]map[uint32]*Proxies, error) {
	if t == marketdata.FX {
		pair, err := fx.NewPair(id)
		if err != nil {
			return nil, nil, fmt.Errorf("could not build the fx pair: %w", err)
		}

		return p.fetchFXVolatilityScenarios(ctx, pair, scenarios, snapshot)
	}

	volatilityScenarioValues, scenarioProxies, err := p.realizationProvider.FetchVolatilityScenarios(ctx, t, id, scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the volatility scenario values for horizon: %w", err)
	}

	scenarioProxiesMap := make(map[string]map[uint32]*Proxies, 1)
	scenarioProxiesMap[id] = scenarioProxies

	return volatilityScenarioValues, scenarioProxiesMap, nil
}

func (p Provider) fetchFXSpotScenarios(ctx context.Context, id *fx.Pair, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[string]map[uint32]*Proxies, error) {
	if id.Domestic == fx.ReferenceCurrency || id.Foreign == fx.ReferenceCurrency {
		values, proxies, err := p.fetchFXSpotScenarioValuesAgainstRef(ctx, id, scenarios, snapshot)
		if err != nil {
			return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
		}

		scenarioProxiesMap := make(map[string]map[uint32]*Proxies, 1)
		scenarioProxiesMap[id.String()] = proxies

		return values, scenarioProxiesMap, nil
	}

	domesticFX := &fx.Pair{
		Foreign:  fx.ReferenceCurrency,
		Domestic: id.Domestic,
	}

	domValues, domProxies, err := p.fetchFXSpotScenarioValuesAgainstRef(ctx, domesticFX, scenarios, snapshot)
	if err != nil {
		return nil, nil, err
	}

	foreignFX := &fx.Pair{
		Foreign:  fx.ReferenceCurrency,
		Domestic: id.Foreign,
	}

	forValues, forProxies, err := p.fetchFXSpotScenarioValuesAgainstRef(ctx, foreignFX, scenarios, snapshot)
	if err != nil {
		return nil, nil, err
	}

	results := make(map[uint32]float64, len(domValues))
	for k, v := range domValues {
		w := forValues[k]
		if math.Abs(w) < tolerance {
			return nil, nil, errors.SetTag(errors.PreconditionFailed("foreign value for %s is too small: got %e", foreignFX.String(), w), tag.InvalidScenarioData)
		}

		results[k] = v / w
	}

	scenarioProxiesMap := map[string]map[uint32]*Proxies{
		domesticFX.String(): domProxies,
		foreignFX.String():  forProxies,
	}

	return results, scenarioProxiesMap, nil
}

func (p Provider) fetchFXSpotScenarioValuesAgainstRef(ctx context.Context, id *fx.Pair, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*Proxies, error) {
	perspective, err := p.fxProvider.FetchFXPerspective(ctx, id)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the FX perspective for %s: %w", id, err)
	}

	values, proxies, err := p.realizationProvider.FetchSpotScenarios(ctx, marketdata.FX, perspective.String(), scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
	}

	if *perspective == *id {
		return values, proxies, nil
	}

	res, err := invertScenarioValues(values)
	if err != nil {
		return nil, nil, fmt.Errorf("could not invert scenario values for %s: %w", id.String(), err)
	}

	return res, proxies, nil
}

func (p Provider) fetchFXVolatilityScenarios(ctx context.Context, id *fx.Pair, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[string]map[uint32]*Proxies, error) {
	if id.Domestic == fx.ReferenceCurrency || id.Foreign == fx.ReferenceCurrency {
		values, proxies, err := p.fetchFXVolatilityScenarioValuesAgainstRef(ctx, id, scenarios, snapshot)
		if err != nil {
			return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
		}

		scenarioProxiesMap := make(map[string]map[uint32]*Proxies, 1)
		scenarioProxiesMap[id.String()] = proxies

		return values, scenarioProxiesMap, nil
	}

	domesticFX := &fx.Pair{
		Foreign:  fx.ReferenceCurrency,
		Domestic: id.Domestic,
	}

	domValues, domProxies, err := p.fetchFXVolatilityScenarioValuesAgainstRef(ctx, domesticFX, scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
	}

	foreignFX := &fx.Pair{
		Foreign:  fx.ReferenceCurrency,
		Domestic: id.Foreign,
	}

	forValues, forProxies, err := p.fetchFXVolatilityScenarioValuesAgainstRef(ctx, foreignFX, scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
	}

	correlation, err := p.fxProvider.FetchFXCorrelation(ctx, domesticFX, foreignFX, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the correlation between %s and %s: %w", domesticFX, foreignFX, err)
	}

	results := make(map[uint32]float64)
	for k, domValue := range domValues {
		results[k] = crossVolatility(domValue, forValues[k], correlation)
	}

	scenarioProxiesMap := map[string]map[uint32]*Proxies{
		domesticFX.String(): domProxies,
		foreignFX.String():  forProxies,
	}

	return results, scenarioProxiesMap, nil
}

func (p Provider) fetchFXVolatilityScenarioValuesAgainstRef(ctx context.Context, id *fx.Pair, scenarios []uint32, snapshot time.Time) (map[uint32]float64, map[uint32]*Proxies, error) {
	perspective, err := p.fxProvider.FetchFXPerspective(ctx, id)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the FX perspective for %s: %w", id, err)
	}

	values, proxies, err := p.realizationProvider.FetchVolatilityScenarios(ctx, marketdata.FX, perspective.String(), scenarios, snapshot)
	if err != nil {
		return nil, nil, fmt.Errorf("could not fetch the scenario values for %s: %w", id, err)
	}

	return values, proxies, nil
}

func invertScenarioValues(values map[uint32]float64) (map[uint32]float64, error) {
	results := make(map[uint32]float64, len(values))
	for key, val := range values {
		if math.Abs(val) < tolerance {
			return nil, errors.SetTag(errors.PreconditionFailed("value %v is too small", val), tag.InvalidScenarioData)
		}

		results[key] = 1.0 / val
	}

	return results, nil
}

// crossVolatility computes the cross volatility given the parent's volatility and the correlation.
func crossVolatility(domAgainstRef, forAgainstRef, correlation float64) float64 {
	return math.Sqrt(domAgainstRef*domAgainstRef + forAgainstRef*forAgainstRef - 2.0*correlation*domAgainstRef*forAgainstRef)
}
