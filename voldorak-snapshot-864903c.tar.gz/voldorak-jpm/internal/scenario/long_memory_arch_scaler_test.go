package scenario

import (
	"math"
	"testing"

	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/leanovate/gopter"
	"github.com/leanovate/gopter/gen"
	"github.com/leanovate/gopter/prop"
	"github.com/stretchr/testify/assert"
)

func Test_NewLongMemoryARCHScaler(t *testing.T) {
	t.Parallel()

	t.Run("amplitude and slope values", func(t *testing.T) {
		t.Parallel()

		const tolerance = 1.0e-16

		for name, tc := range map[string]struct {
			scnHorizon float64
			amplitude  float64
			slope      float64
		}{
			"1 day": {
				scnHorizon: 1.0,
				amplitude:  0.58,
				slope:      0.42,
			},
			"10 days": {
				scnHorizon: 10.0,
				amplitude:  0.5,
				slope:      0.41,
			},
			"20 days": {
				scnHorizon: 20.0,
				amplitude:  0.5*0.5 + 0.5*0.42,
				slope:      0.5*0.41 + 0.5*0.4,
			},
			"30 days": {
				scnHorizon: 30.0,
				amplitude:  0.42,
				slope:      0.4,
			},
			"252 days": {
				scnHorizon: 252.0,
				amplitude:  0.26,
				slope:      0.38,
			},
			"504 days": {
				scnHorizon: 504.0,
				amplitude:  0.26,
				slope:      0.38,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				scaler := NewLongMemoryARCHScaler()

				assert.InDelta(t, tc.amplitude, scaler.amplitude(tc.scnHorizon), tolerance)
				assert.InDelta(t, tc.slope, scaler.slope(tc.scnHorizon), tolerance)
			})
		}
	})

	t.Run("amplitude and slope must stay positive", func(t *testing.T) {
		t.Parallel()

		// A thresholded interpolator is required to avoid extrapolating
		// outside of the horizon domain, which would result in negative
		// amplitude/slope and too high scaling factors.
		// See also https://github.com/edgelaboratories/team-quant-engine/issues/250.

		scaler := NewLongMemoryARCHScaler()

		props := gopter.NewProperties(gopter.DefaultTestParametersWithSeed(1234))
		defer props.TestingRun(t)

		props.Property("positive amplitude", prop.ForAll(
			func(scenarioHorizon float64) bool {
				return assert.Greater(t, scaler.amplitude(scenarioHorizon), 0.0)
			},
			gen.Float64Range(1.0, 5000.0),
		))

		props.Property("positive slope", prop.ForAll(
			func(scenarioHorizon float64) bool {
				return assert.Greater(t, scaler.slope(scenarioHorizon), 0.0)
			},
			gen.Float64Range(1.0, 5000.0),
		))
	})
}

func Test_LongMemoryARCHScaler_ComputeScalingFactor(t *testing.T) {
	t.Parallel()

	const horizon = 30.0

	for name, tc := range map[string]struct {
		scnHorizon float64
		amplitude  float64
		slope      float64
	}{
		"1 day scenario horizon": {
			scnHorizon: 1.0,
			amplitude:  0.58,
			slope:      0.42,
		},
		"10 days scenario horizon": {
			scnHorizon: 10.0,
			amplitude:  0.5,
			slope:      0.41,
		},
		"30 days scenario horizon": {
			scnHorizon: 30.0,
			amplitude:  0.42,
			slope:      0.4,
		},
		"1 year scenario horizon": {
			scnHorizon: 252.0,
			amplitude:  0.26,
			slope:      0.38,
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := NewLongMemoryARCHScaler().ComputeScalingFactor(horizon, tc.scnHorizon)
			expected := 1 - tc.amplitude*math.Tanh(tc.slope*math.Log(float64(horizon)/float64(model.ReferenceScenarioHorizon)))

			assert.InDelta(t, expected, got, tol)
		})
	}
}
