package scenario

import (
	"math"
	"testing"

	"github.com/edgelaboratories/voldorak/internal/model"
	"github.com/stretchr/testify/assert"
)

func newIdentityScaler() ScalerFunc {
	return func(_, _ float64) float64 {
		return 1.0
	}
}

func Test_ComputeScenarioScaler(t *testing.T) {
	t.Parallel()

	t.Run("identity", func(t *testing.T) {
		t.Parallel()

		const (
			referenceVol    = 0.5
			scenarioVol     = 0.2
			horizon         = 10.0
			scenarioHorizon = 30.0
		)

		got := ComputeScenarioScaler(
			scenarioVol,
			referenceVol,
			horizon,
			scenarioHorizon,
			newIdentityScaler(),
		)
		assert.InDelta(t, scenarioVol/referenceVol, got, tol)
	})

	t.Run("long memory arch", func(t *testing.T) {
		t.Parallel()

		const (
			refVol = 0.5
			scnVol = 0.2
		)

		for name, tc := range map[string]struct {
			horizon       float64
			scnHorizon    float64
			scalingFactor float64
		}{
			"10 days scenario horizon": {
				horizon:       100.0,
				scnHorizon:    10.0,
				scalingFactor: 1 - 0.5*math.Tanh(0.41*math.Log(100.0/float64(model.ReferenceScenarioHorizon))),
			},
			"one year scenario horizon": {
				horizon:       10.0,
				scnHorizon:    252.0,
				scalingFactor: 1 - 0.26*math.Tanh(0.38*math.Log(10.0/float64(model.ReferenceScenarioHorizon))),
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				expected := math.Pow((scnVol / refVol), tc.scalingFactor)
				got := ComputeScenarioScaler(
					scnVol,
					refVol,
					tc.horizon,
					tc.scnHorizon,
					NewLongMemoryARCHScaler(),
				)
				assert.InDelta(t, expected, got, tol)
			})
		}
	})

	t.Run("invalid reference volatility", func(t *testing.T) {
		t.Parallel()

		const (
			scenarioVolatility  = 1.0e-6
			referenceVolatility = 0.0
			horizon             = 50.0
			scenarioHorizon     = 30.0
			tol                 = 1e-15
		)

		t.Run("identity scaler", func(t *testing.T) {
			t.Parallel()

			// In this case, despite the input reference volatility is zero
			// the identity scaler requires no further scaling.
			// Hence, the scenario volatility is returned directly.

			math.IsInf(ComputeScenarioScaler(
				scenarioVolatility,
				referenceVolatility,
				horizon,
				scenarioHorizon,
				newIdentityScaler(),
			), 1)
		})

		t.Run("long memory arch scaler", func(t *testing.T) {
			t.Parallel()

			// In this case, despite the input reference volatility is zero
			// the identity scaler requires no further scaling.
			// Hence, the scenario volatility is returned directly.

			assert.True(t, math.IsNaN(ComputeScenarioScaler(
				scenarioVolatility,
				referenceVolatility,
				horizon,
				scenarioHorizon,
				NewLongMemoryARCHScaler(),
			)))
		})
	})
}
