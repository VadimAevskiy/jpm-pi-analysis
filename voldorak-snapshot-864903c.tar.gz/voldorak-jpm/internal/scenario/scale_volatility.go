package scenario

import "math"

// Scaler scales out the volatility for a specific horizon.
type Scaler interface {
	// ComputeScalingFactor computes the scaling factor up to an input horizon
	// for a pre-specified scenario horizon.
	ComputeScalingFactor(horizon, scenarioHorizon float64) float64
}

// ScalerFunc is a scaler functional.
type ScalerFunc func(horizon, scenarioHorizon float64) float64

var _ Scaler = ScalerFunc(nil)

// ComputeScalingFactor computes the scaling factor up to an input horizon
// for a pre-specified scenario horizon.
func (f ScalerFunc) ComputeScalingFactor(horizon, scenarioHorizon float64) float64 {
	return f(horizon, scenarioHorizon)
}

// ComputeScenarioScaler proxies the scenario volatility forecast scaling factor for a horizon
// using a scaler and the scenario volatility for a reference horizon.
// The scaling factor is configured depending on the input scenario horizon.
//
// This function assumes the input reference volatility is not zero. If this happens
// and a non-identity scaler is applied, the output scenario volatility will be NaN.
// We allow this case for simplicity because volatilities produced by Voldorak
// will be thresholded to a positive minimum value, and as long as these volatilities
// are not served (Deprecated model) an identity scaler will be used.
func ComputeScenarioScaler(scenarioVol, referenceVol, horizon, scenarioHorizon float64, scaler Scaler) float64 {
	const (
		volTol           = 1.0e-8
		scalingFactorTol = 1.0e-15
	)

	if referenceVol < volTol {
		return math.NaN()
	}

	if s := scaler.ComputeScalingFactor(horizon, scenarioHorizon); math.Abs(s-1.0) > scalingFactorTol {
		return math.Pow(scenarioVol/referenceVol, s)
	}

	return scenarioVol / referenceVol
}
