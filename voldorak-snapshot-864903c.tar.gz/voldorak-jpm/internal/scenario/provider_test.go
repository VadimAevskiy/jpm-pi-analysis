package scenario

import (
	"math"
	"testing"
	"time"

	errors "github.com/edgelaboratories/go-errors/goerror"
	"github.com/edgelaboratories/voldorak/internal/fx"
	"github.com/edgelaboratories/voldorak/internal/marketdata"
	"github.com/edgelaboratories/voldorak/internal/tag"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func newTestProvider() *Provider {
	return NewProvider(mockRealizationProvider{}, mockFXProvider{})
}

func Test_FetchSpotScenarios(t *testing.T) {
	t.Parallel()

	snapshot := time.Date(2018, time.July, 2, 0, 0, 0, 0, time.UTC)
	provider := newTestProvider()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id string
			t  marketdata.Type
		}{
			"index": {
				id: "317fe458-b31e-4e3f-b037-beff934a127d",
				t:  marketdata.Index,
			},
			"fx": {
				id: "USD-EUR",
				t:  marketdata.FX,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.FetchSpotScenarios(t.Context(), tc.t, tc.id, []uint32{1, 2, 3}, snapshot)
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id                 string
			t                  marketdata.Type
			expectStatus       errors.StatusCode
			expectTag          errors.Tag
			skipStatusAndTagEq bool
		}{
			"invalid format": {
				id:                 "USDX",
				t:                  marketdata.FX,
				skipStatusAndTagEq: true,
			},
			"not found": {
				id:                 "not-found",
				t:                  marketdata.Stock,
				skipStatusAndTagEq: true,
			},
			"foreign value too small": {
				id:           "AUD-EUR",
				t:            marketdata.FX,
				expectStatus: errors.StatusCodePreconditionFailed,
				expectTag:    tag.InvalidScenarioData,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.FetchSpotScenarios(t.Context(), tc.t, tc.id, []uint32{1, 2, 3}, snapshot)
				require.Error(t, err)

				if !tc.skipStatusAndTagEq {
					errors.AssertStatus(t, tc.expectStatus, err)
					errors.AssertTag(t, tc.expectTag, err)
				}
			})
		}
	})
}

func Test_fetchFXSpotScenarioValues(t *testing.T) {
	t.Parallel()

	snapshot := time.Date(2018, time.July, 2, 0, 0, 0, 0, time.UTC)
	provider := newTestProvider()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id fx.Pair
		}{
			"USD-EUR": {
				id: fx.Pair{Foreign: "USD", Domestic: "EUR"},
			},
			"EUR-USD": {
				id: fx.Pair{Foreign: "EUR", Domestic: "USD"},
			},
			"USD-CHF": {
				id: fx.Pair{Foreign: "USD", Domestic: "CHF"},
			},
			"EUR-CHF": {
				id: fx.Pair{Foreign: "EUR", Domestic: "CHF"},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.fetchFXSpotScenarios(t.Context(), &tc.id, []uint32{1, 2, 3}, snapshot)
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id fx.Pair
		}{
			"invalid domestic": {
				id: fx.Pair{
					Foreign:  "EUR",
					Domestic: "NOK",
				},
			},
			"invalid foreign": {
				id: fx.Pair{
					Foreign:  "NOK",
					Domestic: "EUR",
				},
			},
			"invalid perspective": {
				id: fx.Pair{
					Foreign:  "XAU",
					Domestic: "EUR",
				},
			},
			"inverted perspective with too small values": {
				id: fx.Pair{
					Foreign:  "JPY",
					Domestic: "EUR",
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.fetchFXSpotScenarios(t.Context(), &tc.id, []uint32{1, 2, 3}, snapshot)
				require.Error(t, err)
			})
		}
	})
}

func Test_FetchVolatilityScenarios(t *testing.T) {
	t.Parallel()

	snapshot := time.Date(2018, time.July, 2, 0, 0, 0, 0, time.UTC)
	provider := newTestProvider()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id string
			t  marketdata.Type
		}{
			"index": {
				id: "317fe458-b31e-4e3f-b037-beff934a127d",
				t:  marketdata.Index,
			},
			"fx": {
				id: "USD-EUR",
				t:  marketdata.FX,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.FetchVolatilityScenarios(t.Context(), tc.t, tc.id, []uint32{1, 2, 3}, snapshot)
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id string
			t  marketdata.Type
		}{
			"invalid format": {
				id: "USDX",
				t:  marketdata.FX,
			},
			"not found": {
				id: "not-found",
				t:  marketdata.Stock,
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.FetchVolatilityScenarios(t.Context(), tc.t, tc.id, []uint32{1, 2, 3}, snapshot)
				require.Error(t, err)
			})
		}
	})
}

func Test_fetchFXVolatilityScenarios(t *testing.T) {
	t.Parallel()

	snapshot := time.Date(2018, time.July, 2, 0, 0, 0, 0, time.UTC)
	provider := newTestProvider()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id fx.Pair
		}{
			"USD-EUR": {
				id: fx.Pair{Foreign: "USD", Domestic: "EUR"},
			},
			"EUR-USD": {
				id: fx.Pair{Foreign: "EUR", Domestic: "USD"},
			},
			"USD-CHF": {
				id: fx.Pair{Foreign: "USD", Domestic: "CHF"},
			},
			"EUR-CHF": {
				id: fx.Pair{Foreign: "EUR", Domestic: "CHF"},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.fetchFXVolatilityScenarios(t.Context(), &tc.id, []uint32{1, 2, 3}, snapshot)
				require.NoError(t, err)
			})
		}
	})

	t.Run("invalid", func(t *testing.T) {
		t.Parallel()

		for name, tc := range map[string]struct {
			id fx.Pair
		}{
			"invalid domestic": {
				id: fx.Pair{
					Foreign:  "EUR",
					Domestic: "NOK",
				},
			},
			"invalid foreign": {
				id: fx.Pair{
					Foreign:  "NOK",
					Domestic: "EUR",
				},
			},
			"invalid correlation": {
				id: fx.Pair{
					Foreign:  "EUR",
					Domestic: "CAD",
				},
			},
			"invalid perspective": {
				id: fx.Pair{
					Foreign:  "EUR",
					Domestic: "XAU",
				},
			},
		} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()

				_, _, err := provider.fetchFXVolatilityScenarios(t.Context(), &tc.id, []uint32{1, 2, 3}, snapshot)
				require.Error(t, err)
			})
		}
	})
}

func Test_invertScenarioValues(t *testing.T) {
	t.Parallel()

	t.Run("valid", func(t *testing.T) {
		t.Parallel()

		values := map[uint32]float64{
			1: 1003.7,
			2: 1000.1,
			3: 998.9,
		}
		expected := map[uint32]float64{
			1: 1.0 / 1003.7,
			2: 1.0 / 1000.1,
			3: 1.0 / 998.9,
		}

		got, err := invertScenarioValues(values)
		require.NoError(t, err)
		assert.InEpsilon(t, expected[1], got[1], 1.0e-8)
		assert.InEpsilon(t, expected[2], got[2], 1.0e-8)
		assert.InEpsilon(t, expected[3], got[3], 1.0e-8)
	})

	t.Run("values too small", func(t *testing.T) {
		t.Parallel()

		_, err := invertScenarioValues(map[uint32]float64{
			1: 1.0e-16,
			2: 1.0e-16,
			3: 1.0e-16,
		})
		require.Error(t, err)
		errors.AssertStatus(t, errors.StatusCodePreconditionFailed, err)
		errors.AssertTag(t, tag.InvalidScenarioData, err)
	})
}

const tol = 1.0e-5

func Test_crossVolatility(t *testing.T) {
	t.Parallel()

	for name, tc := range map[string]struct {
		domAgainstRef float64
		forAgainstRef float64
		correlation   float64
		expected      float64
	}{
		"normal": {
			domAgainstRef: 0.72,
			forAgainstRef: 0.11,
			correlation:   0.6,
			expected:      math.Sqrt(0.72*0.72 + 0.11*0.11 - 2.0*0.72*0.11*0.6),
		},
		"no correlation": {
			domAgainstRef: 0.72,
			forAgainstRef: 0.11,
			correlation:   0.0,
			expected:      math.Sqrt(0.72*0.72 + 0.11*0.11),
		},
		"no dom against ref vol": {
			domAgainstRef: 0.0,
			forAgainstRef: 0.11,
			correlation:   0.9,
			expected:      math.Sqrt(0.11 * 0.11),
		},
		"no for against ref vol": {
			domAgainstRef: 0.72,
			forAgainstRef: 0.0,
			correlation:   0.9,
			expected:      math.Sqrt(0.72 * 0.72),
		},
	} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := crossVolatility(tc.domAgainstRef, tc.forAgainstRef, tc.correlation)
			assert.InDelta(t, tc.expected, got, tol)
		})
	}
}
