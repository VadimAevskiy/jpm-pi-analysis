package scenario

import (
	"math"

	interp "github.com/edgelaboratories/go-libraries/interpolator"
	"github.com/edgelaboratories/voldorak/internal/model"
)

// LongMemoryARCHScaler scales LM-ARCH volatility scenarios.
type LongMemoryARCHScaler struct {
	amplitudeInterpolator *interp.PiecewiseLinearThreshold
	slopeInterpolator     *interp.PiecewiseLinearThreshold
}

// NewLongMemoryARCHScaler returns a LM-ARCH scaler.
//
//nolint:mnd
func NewLongMemoryARCHScaler() *LongMemoryARCHScaler {
	// Since the number of interpolation nodes is statically fixed
	// and known to be well-defined, we ignore the error returned
	// by the piecewise-linear interpolator.
	amplitudeInterpolator, _ := newInterpolator(
		xy(1, 0.58),
		xy(10, 0.5),
		xy(30, 0.42),
		xy(252, 0.26),
	)

	slopeInterpolator, _ := newInterpolator(
		xy(1, 0.42),
		xy(10, 0.41),
		xy(30, 0.4),
		xy(252, 0.38),
	)

	return &LongMemoryARCHScaler{
		amplitudeInterpolator: amplitudeInterpolator,
		slopeInterpolator:     slopeInterpolator,
	}
}

// ComputeScalingFactor computes the scaling factor up to an input horizon
// for a pre-specified scenario horizon.
func (scaler LongMemoryARCHScaler) ComputeScalingFactor(horizon, scenarioHorizon float64) float64 {
	amplitude := scaler.amplitude(scenarioHorizon)
	slope := scaler.slope(scenarioHorizon)

	return 1.0 - amplitude*math.Tanh(slope*math.Log(horizon/float64(model.ReferenceScenarioHorizon)))
}

func (scaler LongMemoryARCHScaler) amplitude(scenarioHorizon float64) float64 {
	return scaler.amplitudeInterpolator.Value(scenarioHorizon)
}

func (scaler LongMemoryARCHScaler) slope(scenarioHorizon float64) float64 {
	return scaler.slopeInterpolator.Value(scenarioHorizon)
}

// newInterpolator is syntatic sugar to build interpolators from a variadic list of points.
func newInterpolator(xys ...interp.XY) (*interp.PiecewiseLinearThreshold, error) {
	return interp.NewPiecewiseLinearThreshold(xys)
}

// xy is syntatic sugar to create an interpolation point.
func xy(x, y float64) interp.XY {
	return interp.XY{
		X: x,
		Y: y,
	}
}
